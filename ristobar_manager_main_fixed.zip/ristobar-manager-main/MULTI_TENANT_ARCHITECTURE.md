
# RistoBar Manager - Multi-Tenant Architecture

## Overview

RistoBar Manager is designed as a SaaS (Software as a Service) application with multi-tenant architecture. Each restaurant (tenant) has its own isolated data and resources, while the application code is shared across all tenants.

## Architecture Components

### Frontend (React + Tailwind CSS)

- **Tenant Context**: Manages the current tenant state and provides tenant-specific data to components.
- **Dynamic Routing**: Routes with tenant slugs (e.g., `/t/:tenantSlug/dashboard`) for direct tenant access.
- **Tenant Layout**: Wrapper component that ensures tenant isolation and authorization.

### API Layer

- **JWT Authentication**: Tokens contain tenant ID to validate access rights.
- **Tenant Middleware**: Extracts tenant ID from JWT tokens and enforces isolation.
- **API Services**: Tenant-aware API calls that include tenant headers.

### Database (PostgreSQL)

- **Schema per Tenant**: Each tenant has its own database schema.
- **Naming Convention**: Schemas follow the pattern `tenant_${tenantId}`.
- **Centralized Management**: Tenant metadata stored in a shared `tenant_management` schema.

### Storage (Firebase)

- **Tenant Folders**: Files stored in tenant-specific directories.
- **Path Pattern**: `tenant_${tenantId}/path/to/file`.
- **Access Control**: Firebase security rules enforce tenant isolation.

## Implementation Details

### Tenant Context

The `TenantContext` provides:
- Current tenant information
- Loading state
- Database schema name
- Storage path

### Tenant API Service

The tenant API service:
- Automatically includes tenant headers in all API requests
- Uses tenant-specific schemas for database queries
- Isolates tenant data in every operation

### Storage Service

The tenant storage service:
- Enforces tenant-specific file paths
- Prevents cross-tenant file access
- Manages file uploads and retrievals in tenant-specific locations

## Docker Setup

The application is containerized with Docker:
- **Frontend**: React application
- **Backend**: Node.js Express API
- **Database**: PostgreSQL with multi-tenant schemas
- **PgAdmin**: For database management

## Security Considerations

- **JWT Verification**: Tokens are verified on every request
- **Tenant Validation**: API middleware checks that users only access their own tenant
- **Database Isolation**: Schema-based isolation prevents cross-tenant data access
- **Row-Level Security**: Additional layer of database security for shared tables

## Development Guidelines

1. **Always Use Tenant Context**: All components should access data through the tenant context
2. **Include Tenant Headers**: API requests must include tenant identification
3. **Test Isolation**: Ensure no cross-tenant data leaks
4. **Database Migrations**: Apply changes to all tenant schemas
5. **Storage Paths**: Always prepend tenant identifiers to storage paths

## Production Considerations

- **Scaling**: Horizontal scaling for the API layer
- **Database Partitioning**: For very large tenants
- **Monitoring**: Tenant-specific metrics and logging
- **Backups**: Tenant-specific backup and restore functionality
