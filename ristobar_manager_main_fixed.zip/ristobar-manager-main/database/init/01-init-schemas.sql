
-- Create tenant schemas and roles

-- Create role for tenant management
CREATE ROLE tenant_manager WITH LOGIN PASSWORD 'secure_password';

-- Create schema for tenant management
CREATE SCHEMA IF NOT EXISTS tenant_management;

-- Grant privileges
GRANT ALL PRIVILEGES ON SCHEMA tenant_management TO tenant_manager;

-- Create tenant_users table for managing tenant-user relationships
CREATE TABLE IF NOT EXISTS tenant_management.tenant_users (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    tenant_id VARCHAR(255) NOT NULL,
    schema_name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, tenant_id)
);

-- Create tenant_info table for storing tenant information
CREATE TABLE IF NOT EXISTS tenant_management.tenant_info (
    id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    schema_name VARCHAR(255) NOT NULL UNIQUE,
    storage_path VARCHAR(255) NOT NULL,
    owner_id VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create function to create a new tenant schema
CREATE OR REPLACE FUNCTION tenant_management.create_tenant_schema(
    tenant_id VARCHAR,
    schema_name VARCHAR
) RETURNS VOID AS $$
BEGIN
    -- Create schema
    EXECUTE 'CREATE SCHEMA IF NOT EXISTS ' || quote_ident(schema_name);
    
    -- Create common tables for each tenant
    
    -- Menu categories
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.categories (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        image_url VARCHAR(255),
        sort_order INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Menu items
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.menu_items (
        id SERIAL PRIMARY KEY,
        category_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.categories(id) ON DELETE CASCADE,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        image_url VARCHAR(255),
        is_available BOOLEAN DEFAULT TRUE,
        is_featured BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Rooms
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.rooms (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        capacity INTEGER,
        sort_order INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Tables
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.tables (
        id SERIAL PRIMARY KEY,
        room_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.rooms(id) ON DELETE CASCADE,
        name VARCHAR(255) NOT NULL,
        capacity INTEGER NOT NULL,
        x_position INTEGER,
        y_position INTEGER,
        shape VARCHAR(50) DEFAULT ''rectangle'',
        width INTEGER DEFAULT 100,
        height INTEGER DEFAULT 100,
        status VARCHAR(50) DEFAULT ''available'',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Reservations
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.reservations (
        id SERIAL PRIMARY KEY,
        table_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.tables(id) ON DELETE SET NULL,
        customer_name VARCHAR(255) NOT NULL,
        customer_email VARCHAR(255),
        customer_phone VARCHAR(255),
        date DATE NOT NULL,
        time TIME NOT NULL,
        party_size INTEGER NOT NULL,
        status VARCHAR(50) DEFAULT ''confirmed'',
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Inventory items
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.inventory_items (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(255),
        quantity DECIMAL(10, 2) NOT NULL,
        unit VARCHAR(50),
        min_stock_level DECIMAL(10, 2),
        supplier VARCHAR(255),
        cost DECIMAL(10, 2),
        expiry_date DATE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Orders
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.orders (
        id SERIAL PRIMARY KEY,
        table_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.tables(id) ON DELETE SET NULL,
        customer_name VARCHAR(255),
        server_id VARCHAR(255),
        status VARCHAR(50) DEFAULT ''open'',
        total_amount DECIMAL(10, 2) DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Order items
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.order_items (
        id SERIAL PRIMARY KEY,
        order_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.orders(id) ON DELETE CASCADE,
        menu_item_id INTEGER REFERENCES ' || quote_ident(schema_name) || '.menu_items(id) ON DELETE SET NULL,
        quantity INTEGER NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        notes TEXT,
        status VARCHAR(50) DEFAULT ''pending'',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Staff
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.staff (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(255),
        permissions JSONB DEFAULT ''{}''::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    )';
    
    -- Restaurant settings
    EXECUTE 'CREATE TABLE IF NOT EXISTS ' || quote_ident(schema_name) || '.settings (
        id INTEGER PRIMARY KEY DEFAULT 1,
        restaurant_name VARCHAR(255) NOT NULL,
        address TEXT,
        phone VARCHAR(255),
        email VARCHAR(255),
        website VARCHAR(255),
        logo_url VARCHAR(255),
        tax_rate DECIMAL(5, 2) DEFAULT 0,
        currency VARCHAR(10) DEFAULT ''EUR'',
        opening_hours JSONB DEFAULT ''{}''::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT single_settings_row CHECK (id = 1)
    )';
    
END;
$$ LANGUAGE plpgsql;

-- Add test tenant schema
SELECT tenant_management.create_tenant_schema('tenant_test', 'tenant_test');

-- Insert test data
INSERT INTO tenant_management.tenant_info (id, name, slug, schema_name, storage_path, owner_id)
VALUES ('tenant_test', 'Test Restaurant', 'test-restaurant', 'tenant_test', 'tenant_test', 'user_1');

INSERT INTO tenant_management.tenant_users (user_id, tenant_id, schema_name, role)
VALUES ('user_1', 'tenant_test', 'tenant_test', 'owner');
