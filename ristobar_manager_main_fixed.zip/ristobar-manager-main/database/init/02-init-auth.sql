
-- Crea lo schema di gestione tenant se non esiste
CREATE SCHEMA IF NOT EXISTS tenant_management;

-- Crea la tabella dei tenant se non esiste
CREATE TABLE IF NOT EXISTS tenant_management.tenants (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  owner_email VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL,
  schema_name VARCHAR(255) NOT NULL,
  storage_path VARCHAR(255) NOT NULL
);

-- Funzione per creare uno schema tenant con le tabelle necessarie
CREATE OR REPLACE FUNCTION tenant_management.create_tenant_schema(
  schema_name VARCHAR
)
RETURNS VOID AS $$
BEGIN
  -- Crea lo schema del tenant
  EXECUTE 'CREATE SCHEMA IF NOT EXISTS ' || schema_name;
  
  -- Crea la tabella utenti per il tenant
  EXECUTE 'CREATE TABLE IF NOT EXISTS ' || schema_name || '.users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    created_at TIMESTAMP NOT NULL,
    restaurant_name VARCHAR(255),
    image_url VARCHAR(255)
  )';
  
END;
$$ LANGUAGE plpgsql;

-- Crea un trigger per creare automaticamente lo schema quando viene creato un nuovo tenant
CREATE OR REPLACE FUNCTION tenant_management.tenant_creation_trigger()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM tenant_management.create_tenant_schema(NEW.schema_name);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Collega il trigger alla tabella dei tenant
DROP TRIGGER IF EXISTS create_tenant_schema_trigger ON tenant_management.tenants;
CREATE TRIGGER create_tenant_schema_trigger
AFTER INSERT ON tenant_management.tenants
FOR EACH ROW
EXECUTE FUNCTION tenant_management.tenant_creation_trigger();

-- Crea un tenant di esempio se non esiste
INSERT INTO tenant_management.tenants (
  id, name, slug, owner_email, created_at, schema_name, storage_path
)
VALUES (
  'tenant_example',
  'Ristorante Demo',
  'ristorante-demo',
  'demo@ristobarmanager.it',
  NOW(),
  'tenant_example',
  'tenant_example'
)
ON CONFLICT (id) DO NOTHING;

-- Crea lo schema e le tabelle per il tenant di esempio
SELECT tenant_management.create_tenant_schema('tenant_example');

-- Crea un utente admin di esempio
INSERT INTO tenant_example.users (
  id, name, email, password_hash, role, created_at, restaurant_name
)
VALUES (
  'user_demo',
  'Utente Demo',
  'demo@ristobarmanager.it',
  -- Password: password123 (hashed with bcrypt)
  '$2b$10$zGT/4ORNp3PuYfZoIvj3KuBn/N3IzfLUAaIyX0/QjQ1AjPxQfXvqm',
  'admin',
  NOW(),
  'Ristorante Demo'
)
ON CONFLICT (id) DO NOTHING;
