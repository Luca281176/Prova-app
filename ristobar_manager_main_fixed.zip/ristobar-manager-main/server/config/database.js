
const { Pool } = require('pg');

// Configurazione del pool di connessioni PostgreSQL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@db:5432/ristobarmanager',
  max: 20, // numero massimo di client nel pool
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Evento di errore per il pool
pool.on('error', (err) => {
  console.error('PostgreSQL pool error:', err);
});

/**
 * Inizializza il database creando gli schemi necessari
 */
const initDatabase = async () => {
  try {
    // Crea lo schema di gestione tenant se non esiste
    await pool.query(`
      CREATE SCHEMA IF NOT EXISTS tenant_management;
      
      CREATE TABLE IF NOT EXISTS tenant_management.tenants (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        slug VARCHAR(255) UNIQUE NOT NULL,
        owner_email VARCHAR(255) NOT NULL,
        created_at TIMESTAMP NOT NULL,
        schema_name VARCHAR(255) NOT NULL,
        storage_path VARCHAR(255) NOT NULL
      );
    `);
    
    console.log('Database inizializzato con successo');
  } catch (error) {
    console.error('Errore nell\'inizializzazione del database:', error);
  }
};

module.exports = {
  pool,
  initDatabase
};
