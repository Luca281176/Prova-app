const UserModel = require('../models/userModel');
const jwtService = require('../services/jwtService');
const TenantModel = require('../models/tenantModel');
const bcrypt = require('bcrypt');

/**
 * Controller per la gestione dell'autenticazione
 */
const AuthController = {
  /**
   * Registrazione di un nuovo amministratore di ristorante
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   */
  async register(req, res) {
    try {
      const { name, email, password, restaurantName } = req.body;
      
      if (!name || !email || !password || !restaurantName) {
        return res.status(400).json({ message: 'Tutti i campi sono obbligatori' });
      }
      
      // Crea un nuovo tenant (ristorante)
      const tenant = await TenantModel.createTenant({ 
        name: restaurantName,
        ownerEmail: email
      });
      
      // Crea l'utente admin
      const user = await UserModel.createUser(
        { name, email, password, restaurantName },
        tenant.id
      );
      
      // Genera il token JWT
      const token = jwtService.generateToken(user, tenant.id);
      
      res.status(201).json({
        message: 'Registrazione completata con successo',
        user,
        tenant,
        token
      });
    } catch (error) {
      console.error('Errore durante la registrazione:', error);
      res.status(500).json({ message: 'Errore durante la registrazione' });
    }
  },
  
  /**
   * Gestisce il login dell'utente
   */
  async login(req, res) {
    try {
      const { email, password } = req.body;
      
      // Validazione input
      if (!email || !password) {
        return res.status(400).json({ error: 'Email e password sono obbligatori' });
      }
      
      // Trova l'utente
      const user = await UserModel.findByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Credenziali non valide' });
      }
      
      // Verifica la password
      const isPasswordValid = await bcrypt.compare(password, user.password_hash);
      if (!isPasswordValid) {
        return res.status(401).json({ error: 'Credenziali non valide' });
      }
      
      // Trova il tenant dell'utente
      const tenant = await TenantModel.findByOwnerId(user.id);
      const tenantId = tenant ? tenant.id : user.id; // Se non esiste un tenant specifico, usa l'id utente
      
      // Genera JWT con tenantId
      const token = jwtService.generateToken(user, tenantId);
      
      // Risposta
      res.json({
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          restaurantName: user.restaurant_name,
          imageUrl: user.image_url
        },
        token,
        tenantId
      });
    } catch (error) {
      console.error('Errore durante il login:', error);
      res.status(500).json({ error: 'Errore durante il login' });
    }
  },
  
  /**
   * Ottiene il profilo dell'utente corrente
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   */
  async getProfile(req, res) {
    try {
      const user = await UserModel.findById(req.user.id, req.tenantId);
      
      if (!user) {
        return res.status(404).json({ message: 'Utente non trovato' });
      }
      
      res.json({ user });
    } catch (error) {
      console.error('Errore nel recupero del profilo:', error);
      res.status(500).json({ message: 'Errore nel recupero del profilo' });
    }
  }
};

module.exports = AuthController;
