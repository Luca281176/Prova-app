exports.getEmployees = async ({ limit = 10, offset = 0 } = {}) => {
  try {
    // Fetch employees with pagination
    const employees = await db.query(
      `SELECT u.id, u.name, u.email, r.role
       FROM users u
       LEFT JOIN user_roles r ON u.id = r.user_id
       WHERE r.role = 'employee'
       ORDER BY u.name
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );

    // Get total count for pagination info
    const countResult = await db.query(
      `SELECT COUNT(*) as total
       FROM users u
       LEFT JOIN user_roles r ON u.id = r.user_id
       WHERE r.role = 'employee'`
    );

    const total = parseInt(countResult.rows[0].total, 10);
    
    return {
      data: employees.rows,
      pagination: {
        total,
        limit: parseInt(limit, 10),
        offset: parseInt(offset, 10),
        pages: Math.ceil(total / limit)
      }
    };
  } catch (error) {
    console.error('Error fetching employees:', error);
    throw error;
  }
};
