
const jwt = require('jsonwebtoken');
const { verifyToken } = require('../services/jwtService');
const { isTokenRevoked } = require('../services/tokenService');

/**
 * Middleware per verificare l'autenticazione e il tenant dell'utente
 */
const authMiddleware = async (req, res, next) => {
  // Estrae il token Bearer dall'header Authorization
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token di autenticazione mancante' });
  }

  const token = authHeader.split(' ')[1];

  try {
    // Verifica il token JWT
    const decoded = verifyToken(token);

    // 🔹 Verifica se il token è scaduto
    if (decoded.exp * 1000 < Date.now()) {
      return res.status(401).json({ error: 'Token scaduto, effettua nuovamente il login' });
    }

    // 🔹 Controlla se il token è stato revocato
    const revoked = await isTokenRevoked(token);
    if (revoked) {
      return res.status(401).json({ error: 'Token non valido (revocato)' });
    }

    // Aggiungi le informazioni dell'utente alla richiesta
    req.userId = decoded.userId;
    req.userRole = decoded.role;
    req.tenantId = decoded.tenantId;

    // 🔹 Blocca accesso senza tenantId
    if (!req.tenantId) {
      return res.status(403).json({ error: 'Accesso negato: tenantId non presente nel token' });
    }

    next();
  } catch (error) {
    console.error('Errore di autenticazione:', error);
    return res.status(401).json({ error: 'Token di autenticazione non valido' });
  }
};

module.exports = authMiddleware;
