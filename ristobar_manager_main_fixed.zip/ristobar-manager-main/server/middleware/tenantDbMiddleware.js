
const { Pool } = require('pg');
const jwtService = require('../services/jwtService');

// Utilizziamo un pool di connessioni per migliorare le prestazioni
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@db:5432/ristobarmanager',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

/**
 * Middleware per garantire che ogni richiesta utilizzi lo schema corretto del tenant.
 * Questo è fondamentale per l'isolamento dei dati tra tenant diversi.
 */
const tenantDbMiddleware = async (req, res, next) => {
  let client;

  try {
    // Recupera il token JWT dalla richiesta
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      console.log('🔴 Autenticazione mancante - Nessun token JWT');
      return res.status(401).json({ message: 'Autenticazione richiesta' });
    }

    // Decodifica il token per ottenere il tenantId
    let decoded;
    try {
      decoded = jwtService.verifyToken(token);
    } catch (err) {
      console.log('🔴 Token JWT non valido:', err.message);
      return res.status(401).json({ message: 'Token non valido' });
    }
    
    if (!decoded || !decoded.tenantId) {
      console.log('🔴 tenantId mancante nel token JWT:', decoded);
      return res.status(401).json({ message: 'Token invalido o mancante tenantId' });
    }

    // Connettersi al database
    client = await pool.connect();

    // Verifica che il tenantId esista nel database
    const checkTenant = await client.query(
      'SELECT schema_name FROM tenant_management.tenant_info WHERE id = $1',
      [decoded.tenantId]
    );

    if (checkTenant.rowCount === 0) {
      console.log('🔴 Tenant non trovato nel database:', decoded.tenantId);
      return res.status(403).json({ message: 'Accesso negato: tenant non valido' });
    }

    const tenantSchema = checkTenant.rows[0].schema_name;
    console.log(`🔹 Impostazione schema tenant: ${tenantSchema}`);

    // Imposta il search_path per garantire l'isolamento del tenant
    await client.query(`SET search_path TO ${tenantSchema}, public;`);
    console.log(`✅ Schema impostato: ${tenantSchema}`);

    // Assegna il client alla richiesta per l'uso nelle query successive
    req.dbClient = client;
    req.tenantSchema = tenantSchema;
    req.tenantId = decoded.tenantId;

    // Aggiungiamo informazioni di debug
    console.log(`🔹 Richiesta autenticata per tenant: ${decoded.tenantId} (Schema: ${tenantSchema})`);

    // Impostiamo una funzione di cleanup nella risposta
    res.on('finish', () => {
      if (req.dbClient) {
        req.dbClient.release();
        req.dbClient = null;
      }
    });

    next();
  } catch (error) {
    console.error('❌ Errore nel middleware tenantDbMiddleware:', error);
    if (error.code === 'ECONNREFUSED') {
      res.status(503).json({ message: 'Database non disponibile' });
    } else {
      res.status(500).json({ message: 'Errore interno del server' });
    }
  } finally {
    // Rilascio esplicito della connessione in caso di errori
    if (client && !res.headersSent) {
      client.release();
    }
  }
};

/**
 * Funzione per verificare l'isolamento tra tenant
 * Utile per il debugging e i test
 */
const testTenantIsolation = async (tenantId1, tenantId2) => {
  try {
    console.log(`🔍 Test isolamento tenant: ${tenantId1} vs ${tenantId2}`);
    
    // Crea schema e tabella di test per tenant1
    const schema1 = `tenant_${tenantId1.replace(/[^a-z0-9]/gi, '_')}`;
    const client1 = await pool.connect();
    await client1.query(`CREATE SCHEMA IF NOT EXISTS ${schema1}`);
    await client1.query(`SET search_path TO ${schema1}`);
    await client1.query(`CREATE TABLE IF NOT EXISTS test_isolation (id SERIAL PRIMARY KEY, data TEXT)`);
    await client1.query(`INSERT INTO test_isolation (data) VALUES ('Dati del tenant ${tenantId1}')`);
    client1.release();
    
    // Crea schema e tabella di test per tenant2
    const schema2 = `tenant_${tenantId2.replace(/[^a-z0-9]/gi, '_')}`;
    const client2 = await pool.connect();
    await client2.query(`CREATE SCHEMA IF NOT EXISTS ${schema2}`);
    await client2.query(`SET search_path TO ${schema2}`);
    await client2.query(`CREATE TABLE IF NOT EXISTS test_isolation (id SERIAL PRIMARY KEY, data TEXT)`);
    await client2.query(`INSERT INTO test_isolation (data) VALUES ('Dati del tenant ${tenantId2}')`);
    
    // Verifica che tenant2 non possa accedere ai dati di tenant1
    await client2.query(`SET search_path TO ${schema2}`);
    const result = await client2.query(`SELECT * FROM test_isolation`);
    client2.release();
    
    // Se l'isolamento funziona, tenant2 dovrebbe vedere solo i propri dati
    const isIsolated = result.rows.every(row => row.data.includes(tenantId2));
    console.log(`🔍 Test isolamento tenant: ${isIsolated ? 'SUCCESSO' : 'FALLIMENTO'}`);
    
    return isIsolated;
  } catch (error) {
    console.error('❌ Errore test isolamento tenant:', error);
    return false;
  }
};

module.exports = { tenantDbMiddleware, testTenantIsolation, pool };
