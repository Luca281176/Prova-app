
const { pool } = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const slugify = require('slugify');

/**
 * Modello per la gestione dei tenant (ristoranti)
 */
const TenantModel = {
  /**
   * Crea un nuovo tenant (ristorante)
   * @param {Object} tenantData - Dati del tenant
   * @returns {Promise<Object>} Tenant creato
   */
  async createTenant(tenantData) {
    const { name, ownerEmail } = tenantData;
    const tenantId = `tenant_${uuidv4()}`;
    
    // Crea uno slug dal nome del ristorante
    const slug = slugify(name, {
      lower: true,
      strict: true,
      remove: /[*+~.()'"!:@]/g
    });
    
    // Inserisci il record del tenant
    const query = `
      INSERT INTO tenant_management.tenants 
      (id, name, slug, owner_email, created_at, schema_name, storage_path)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    
    const schemaName = `tenant_${tenantId.replace(/[^a-z0-9]/gi, '_')}`;
    const storagePath = `tenant_${tenantId}`;
    
    const values = [
      tenantId,
      name,
      slug,
      ownerEmail,
      new Date(),
      schemaName,
      storagePath
    ];
    
    const result = await pool.query(query, values);
    
    // Crea lo schema per il tenant
    await pool.query(`CREATE SCHEMA IF NOT EXISTS ${schemaName}`);
    
    // Crea la tabella degli utenti per questo tenant
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ${schemaName}.users (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        created_at TIMESTAMP NOT NULL,
        restaurant_name VARCHAR(255),
        image_url VARCHAR(255)
      )
    `);
    
    return result.rows[0];
  },
  
  /**
   * Trova un tenant per ID
   * @param {string} tenantId - ID del tenant
   * @returns {Promise<Object|null>} Tenant trovato o null
   */
  async findById(tenantId) {
    const query = `
      SELECT * FROM tenant_management.tenants
      WHERE id = $1
    `;
    
    const result = await pool.query(query, [tenantId]);
    return result.rows[0] || null;
  },
  
  /**
   * Trova un tenant per slug
   * @param {string} slug - Slug del tenant
   * @returns {Promise<Object|null>} Tenant trovato o null
   */
  async findBySlug(slug) {
    const query = `
      SELECT * FROM tenant_management.tenants
      WHERE slug = $1
    `;
    
    const result = await pool.query(query, [slug]);
    return result.rows[0] || null;
  },
  
  /**
   * Trova un tenant in base all'email di un utente
   * @param {string} email - Email dell'utente
   * @returns {Promise<Object|null>} Tenant trovato o null
   */
  async findTenantByUserEmail(email) {
    const query = `
      SELECT t.* FROM tenant_management.tenants t
      WHERE t.owner_email = $1
      LIMIT 1
    `;
    
    const result = await pool.query(query, [email]);
    return result.rows[0] || null;
  },
  
  /**
   * Ottiene tutti i tenant
   * @returns {Promise<Array>} Lista di tenant
   */
  async getAllTenants() {
    const query = `
      SELECT id, name, slug, owner_email, created_at, schema_name, storage_path
      FROM tenant_management.tenants
      ORDER BY created_at DESC
    `;
    
    const result = await pool.query(query);
    return result.rows;
  }
};

module.exports = TenantModel;
