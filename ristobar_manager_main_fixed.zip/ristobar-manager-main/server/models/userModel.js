
const { pool } = require('../config/database');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');

/**
 * Modello per la gestione degli utenti
 */
const UserModel = {
  /**
   * Crea un nuovo utente (admin di un ristorante)
   * @param {Object} userData - Dati utente
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object>} Utente creato (senza password)
   */
  async createUser(userData, tenantId) {
    const { name, email, password, restaurantName } = userData;
    const userId = `user_${uuidv4()}`;
    
    // Hash della password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Usa lo schema del tenant
    const query = `
      INSERT INTO tenant_${tenantId}.users 
      (id, name, email, password_hash, role, created_at, restaurant_name) 
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, name, email, role, created_at, restaurant_name
    `;
    
    const values = [
      userId,
      name,
      email,
      hashedPassword,
      'admin', // Il primo utente è sempre admin
      new Date(),
      restaurantName
    ];
    
    const result = await pool.query(query, values);
    return result.rows[0];
  },
  
  /**
   * Cerca un utente per email
   * @param {string} email - Email dell'utente
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object|null>} Utente trovato o null
   */
  async findByEmail(email, tenantId) {
    const query = `
      SELECT * FROM tenant_${tenantId}.users
      WHERE email = $1
    `;
    
    const result = await pool.query(query, [email]);
    return result.rows[0] || null;
  },
  
  /**
   * Cerca un utente per ID
   * @param {string} userId - ID dell'utente
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object|null>} Utente trovato o null
   */
  async findById(userId, tenantId) {
    const query = `
      SELECT id, name, email, role, created_at, restaurant_name 
      FROM tenant_${tenantId}.users
      WHERE id = $1
    `;
    
    const result = await pool.query(query, [userId]);
    return result.rows[0] || null;
  },
  
  /**
   * Aggiunge un nuovo dipendente
   * @param {Object} employeeData - Dati del dipendente
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object>} Dipendente creato (senza password)
   */
  async addEmployee(employeeData, tenantId) {
    const { name, email, password, role } = employeeData;
    const userId = `user_${uuidv4()}`;
    
    // Hash della password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    const query = `
      INSERT INTO tenant_${tenantId}.users 
      (id, name, email, password_hash, role, created_at) 
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, name, email, role, created_at
    `;
    
    const values = [
      userId,
      name,
      email,
      hashedPassword,
      role || 'staff', // Ruolo predefinito
      new Date()
    ];
    
    const result = await pool.query(query, values);
    return result.rows[0];
  },
  
  /**
   * Elimina un dipendente
   * @param {string} userId - ID dell'utente da eliminare
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<boolean>} True se eliminato con successo
   */
  async deleteEmployee(userId, tenantId) {
    const query = `
      DELETE FROM tenant_${tenantId}.users
      WHERE id = $1 AND role != 'admin'
    `;
    
    const result = await pool.query(query, [userId]);
    return result.rowCount > 0;
  },
  
  /**
   * Verifica le credenziali di login
   * @param {string} email - Email dell'utente
   * @param {string} password - Password in chiaro
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object|null>} Utente verificato (senza password) o null
   */
  async verifyCredentials(email, password, tenantId) {
    const user = await this.findByEmail(email, tenantId);
    
    if (!user) return null;
    
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    
    if (!isPasswordValid) return null;
    
    // Non restituire la password
    const { password_hash, ...userWithoutPassword } = user;
    return userWithoutPassword;
  },
  
  /**
   * Ottiene tutti i dipendenti di un tenant
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Array>} Lista di dipendenti (senza password)
   */
  async getEmployees(tenantId) {
    const query = `
      SELECT id, name, email, role, created_at
      FROM tenant_${tenantId}.users
      ORDER BY created_at DESC
    `;
    
    const result = await pool.query(query);
    return result.rows;
  },
  
  /**
   * Aggiorna il ruolo di un dipendente
   * @param {string} userId - ID dell'utente
   * @param {string} role - Nuovo ruolo
   * @param {string} tenantId - ID del tenant (ristorante)
   * @returns {Promise<Object|null>} Utente aggiornato o null
   */
  async updateEmployeeRole(userId, role, tenantId) {
    const query = `
      UPDATE tenant_${tenantId}.users
      SET role = $1
      WHERE id = $2 AND role != 'admin'
      RETURNING id, name, email, role, created_at
    `;
    
    const result = await pool.query(query, [role, userId]);
    return result.rows[0] || null;
  }
};

module.exports = UserModel;
