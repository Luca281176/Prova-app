
const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController');
const { authenticate, requireAdmin } = require('../middleware/authMiddleware');
const cache = require('../utils/cacheService'); // Cache with Redis or local memory

// Middleware to log API response time
const logResponseTime = (req, res, next) => {
  const startTime = process.hrtime();
  
  res.on('finish', () => {
    const endTime = process.hrtime(startTime);
    const responseTime = (endTime[0] * 1000) + (endTime[1] / 1000000);
    console.log(`${req.method} ${req.originalUrl} - ${responseTime.toFixed(2)}ms`);
  });
  
  next();
};

// Apply authentication to all routes
router.use(authenticate);
// Apply response time logging
router.use(logResponseTime);

// Only admin can manage employees
router.get('/employees', requireAdmin, async (req, res) => {
    console.time('GET /employees');

    const { page = 1, limit = 10 } = req.query; // Default pagination
    const offset = (page - 1) * limit;

    // Create a cache key based on pagination parameters
    const cacheKey = `employees_list_page_${page}_limit_${limit}`;
    const cachedEmployees = await cache.get(cacheKey);

    if (cachedEmployees) {
        console.log(`Cache hit for ${cacheKey}`);
        console.timeEnd('GET /employees');
        return res.json(JSON.parse(cachedEmployees)); // Return data from cache
    }

    try {
        console.log(`Cache miss for ${cacheKey}, fetching from database`);
        const employees = await UserController.getEmployees({ 
            limit: parseInt(limit, 10), 
            offset: parseInt(offset, 10) 
        });

        // Cache results for 5 minutes
        await cache.set(cacheKey, JSON.stringify(employees), 300);

        console.timeEnd('GET /employees');
        res.json(employees);
    } catch (error) {
        console.timeEnd('GET /employees');
        console.error('Error fetching employees:', error);
        res.status(500).json({ error: 'Failed to fetch employees' });
    }
});

router.post('/employees', requireAdmin, async (req, res) => {
    console.time('POST /employees');
    try {
        const result = await UserController.addEmployee(req, res);
        
        // Invalidate cache when data changes
        cache.flush();
        
        console.timeEnd('POST /employees');
        return result;
    } catch (error) {
        console.timeEnd('POST /employees');
        console.error('Error adding employee:', error);
        return res.status(500).json({ error: 'Failed to add employee' });
    }
});

router.delete('/employees/:userId', requireAdmin, async (req, res) => {
    console.time('DELETE /employees/:userId');
    try {
        const result = await UserController.deleteEmployee(req, res);
        
        // Invalidate cache when data changes
        cache.flush();
        
        console.timeEnd('DELETE /employees/:userId');
        return result;
    } catch (error) {
        console.timeEnd('DELETE /employees/:userId');
        console.error('Error deleting employee:', error);
        return res.status(500).json({ error: 'Failed to delete employee' });
    }
});

router.put('/employees/:userId/role', requireAdmin, async (req, res) => {
    console.time('PUT /employees/:userId/role');
    try {
        const result = await UserController.updateEmployeeRole(req, res);
        
        // Invalidate cache when data changes
        cache.flush();
        
        console.timeEnd('PUT /employees/:userId/role');
        return result;
    } catch (error) {
        console.timeEnd('PUT /employees/:userId/role');
        console.error('Error updating employee role:', error);
        return res.status(500).json({ error: 'Failed to update employee role' });
    }
});

module.exports = router;
