
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const ingredientRoutes = require('./routes/ingredientRoutes');
const uploadRoutes = require('./routes/uploadRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');
const settingsRoutes = require('./routes/settingsRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const { notFound, errorHandler } = require('./middleware/errorMiddleware');
const path = require('path');
const app = express();

// Load environment variables
require('dotenv').config();

// Enable CORS for all origins
app.use(cors());

// Use Helmet for security headers
app.use(helmet());

// Log HTTP requests
app.use(morgan('dev'));

// Body parsing middleware
app.use(express.json());

// Serve static files from the 'uploads' directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Import tenant database middleware
const { tenantDbMiddleware, releaseDbConnection } = require('./middleware/tenantDbMiddleware');

// Apply the tenant middleware to ALL API routes
// Questo è un punto critico per l'isolamento dei tenant
app.use('/api', tenantDbMiddleware);

// Usa il middleware per rilasciare la connessione dopo ogni richiesta
app.use('/api', function(req, res, next) {
  // Chiamiamo next() per procedere con la catena di middleware
  next();
  
  // A questo punto la richiesta è stata completata, rilasciamo la connessione
  if (req.dbClient) {
    console.log(`✅ Rilascio connessione per schema: ${req.tenantSchema || 'sconosciuto'}`);
    req.dbClient.release();
  }
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/ingredients', ingredientRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Define a simple route
app.get('/', (req, res) => {
  res.send('RistoBar Manager API is running!');
});

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

// Define the port
const PORT = process.env.PORT || 3001;

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Multi-tenant isolation attivato per tutte le richieste API`);
});
