
const jwt = require('jsonwebtoken');

// Secret key for signing JWT tokens (ideally from env variables)
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';
const revokedTokens = new Set(); // Blacklist dei token revocati

/**
 * Genera un nuovo token JWT 
 * @param {Object} user - User information
 * @param {string} tenantId - Tenant ID
 * @returns {string} JWT token
 */
const generateToken = (user, tenantId) => {
  // Always include tenantId in the JWT payload
  return jwt.sign(
    { 
      userId: user.id, 
      email: user.email, 
      role: user.role,
      tenantId: tenantId // Ensure tenantId is always included
    },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
};

/**
 * Verifica un token JWT e controlla se è stato revocato
 * @param {string} token - JWT token to verify
 * @returns {Object} Decoded payload
 */
const verifyToken = (token) => {
  if (revokedTokens.has(token)) {
    throw new Error("Token revocato");
  }
  return jwt.verify(token, JWT_SECRET);
};

/**
 * Revoca un token JWT (logout sicuro)
 * @param {string} token - JWT token to revoke
 */
const revokeToken = (token) => {
  revokedTokens.add(token);
};

/**
 * Extract JWT token from request Authorization header
 * @param {Object} req - Express request object
 * @returns {string|null} JWT token or null if not found
 */
const extractTokenFromHeader = (req) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7); // Remove 'Bearer ' prefix
  }
  return null;
};

/**
 * Verifica se un token è stato revocato
 * @param {string} token - Token to check
 * @returns {boolean} True if token is revoked
 */
const isTokenRevoked = (token) => {
  return revokedTokens.has(token);
};

module.exports = { 
  generateToken, 
  verifyToken, 
  revokeToken, 
  extractTokenFromHeader,
  isTokenRevoked
};
