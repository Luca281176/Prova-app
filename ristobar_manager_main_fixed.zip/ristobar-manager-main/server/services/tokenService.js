
const { getRevocationListFromDB } = require('./dbService');

// In-memory cache di token revocati per prestazioni migliori
const revokedTokensCache = new Set();

// Aggiornamento periodico della cache dai dati del database
let lastCacheUpdate = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 minuti in millisecondi

/**
 * Verifica se un token è stato revocato
 * @param {string} token Il token JWT da verificare
 * @returns {Promise<boolean>} True se il token è stato revocato, false altrimenti
 */
async function isTokenRevoked(token) {
  try {
    // Prima verifica in cache (operazione veloce)
    if (revokedTokensCache.has(token)) {
      return true;
    }

    // Se la cache è vecchia, aggiorna dalla fonte autoritativa (database)
    const now = Date.now();
    if (now - lastCacheUpdate > CACHE_TTL) {
      const revokedTokens = await getRevocationListFromDB();
      
      // Aggiorna la cache
      revokedTokensCache.clear();
      revokedTokens.forEach(t => revokedTokensCache.add(t));
      
      lastCacheUpdate = now;
      console.log(`Cache di token revocati aggiornata con ${revokedTokensCache.size} token`);
      
      // Ricontrolla dopo l'aggiornamento della cache
      return revokedTokensCache.has(token);
    }

    // Il token non è in cache e la cache è ancora valida
    return false;
  } catch (error) {
    console.error('Errore durante la verifica del token revocato:', error);
    // In caso di errore, per sicurezza consideriamo il token come valido
    // in modo da non bloccare completamente il sistema
    return false;
  }
}

/**
 * Aggiunge un token alla lista di revoca
 * @param {string} token Il token JWT da revocare
 * @param {string} userId ID dell'utente associato al token (opzionale)
 * @returns {Promise<boolean>} True se l'operazione è riuscita, false altrimenti
 */
async function revokeToken(token, userId = null) {
  try {
    // Aggiungi alla cache immediatamente per un effetto istantaneo
    revokedTokensCache.add(token);
    
    // Salva nel database per persistenza
    // Nota: implementare la funzione saveRevokedTokenToDB nel servizio dbService
    // await saveRevokedTokenToDB(token, userId);
    
    return true;
  } catch (error) {
    console.error('Errore durante la revoca del token:', error);
    return false;
  }
}

/**
 * Rimuove un token dalla lista di revoca (usato raramente)
 * @param {string} token Il token JWT da rimuovere dalla lista di revoca
 * @returns {Promise<boolean>} True se l'operazione è riuscita, false altrimenti
 */
async function unrevokeToken(token) {
  try {
    // Rimuovi dalla cache
    revokedTokensCache.delete(token);
    
    // Rimuovi dal database
    // Nota: implementare la funzione removeRevokedTokenFromDB nel servizio dbService
    // await removeRevokedTokenFromDB(token);
    
    return true;
  } catch (error) {
    console.error('Errore durante la rimozione del token dalla lista di revoca:', error);
    return false;
  }
}

/**
 * Forza l'aggiornamento della cache dei token revocati
 * @returns {Promise<boolean>} True se l'aggiornamento è riuscito, false altrimenti
 */
async function refreshRevokedTokensCache() {
  try {
    const revokedTokens = await getRevocationListFromDB();
    
    // Aggiorna la cache
    revokedTokensCache.clear();
    revokedTokens.forEach(t => revokedTokensCache.add(t));
    
    lastCacheUpdate = Date.now();
    console.log(`Cache di token revocati aggiornata manualmente con ${revokedTokensCache.size} token`);
    
    return true;
  } catch (error) {
    console.error('Errore durante l\'aggiornamento manuale della cache:', error);
    return false;
  }
}

module.exports = {
  isTokenRevoked,
  revokeToken,
  unrevokeToken,
  refreshRevokedTokensCache
};
