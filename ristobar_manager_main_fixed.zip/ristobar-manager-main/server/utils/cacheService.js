
/**
 * Simple in-memory cache service
 * Could be replaced with Redis in production
 */

// In-memory cache storage
const cacheStore = new Map();

const cacheService = {
  /**
   * Get a value from cache
   * @param {string} key - Cache key
   * @returns {Promise<string|null>} - The cached value or null if not found
   */
  get: async (key) => {
    const item = cacheStore.get(key);
    if (!item) return null;
    
    // Check if the item has expired
    if (item.expiry && item.expiry < Date.now()) {
      cacheStore.delete(key);
      return null;
    }
    
    return item.value;
  },

  /**
   * Set a value in cache
   * @param {string} key - Cache key
   * @param {string} value - Value to cache
   * @param {number} ttlSeconds - Time to live in seconds
   * @returns {Promise<boolean>} - Success status
   */
  set: async (key, value, ttlSeconds = 300) => {
    const expiry = ttlSeconds > 0 ? Date.now() + (ttlSeconds * 1000) : null;
    cacheStore.set(key, { value, expiry });
    return true;
  },

  /**
   * Delete a value from cache
   * @param {string} key - Cache key
   * @returns {Promise<boolean>} - Success status
   */
  del: async (key) => {
    return cacheStore.delete(key);
  },

  /**
   * Clear all cache
   * @returns {Promise<boolean>} - Success status
   */
  flush: async () => {
    cacheStore.clear();
    return true;
  }
};

module.exports = cacheService;
