
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { UserProvider } from '@/contexts/user/UserProvider';
import { TenantProvider } from '@/contexts/tenant/TenantContext';
import { ThemeProvider } from '@/components/ui/theme-provider';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { NotificationProvider } from '@/contexts/notification/NotificationContext';
import React, { Suspense } from 'react';
import { Spinner } from '@/components/ui/spinner';

// Eager load critical components
import Index from './pages/Index';
import Login from './pages/Login';
import Register from './pages/Register';
import AuthCallback from './pages/AuthCallback';
import NotFound from './pages/NotFound';
import ComingSoon from './pages/ComingSoon';

// Lazy load remaining components
const Dashboard = React.lazy(() => import("@/pages/Dashboard"));
const Settings = React.lazy(() => import("./pages/Settings"));
const Profile = React.lazy(() => import("./pages/Profile"));
const Menu = React.lazy(() => import("./pages/Menu"));
const Rooms = React.lazy(() => import("./pages/Rooms"));
const DigitalMenu = React.lazy(() => import("./pages/DigitalMenu"));
const PublicDigitalMenu = React.lazy(() => import("./pages/PublicDigitalMenu"));
const Reservations = React.lazy(() => import("./pages/Reservations"));
const Inventory = React.lazy(() => import("./pages/Inventory"));
const Cashier = React.lazy(() => import("./pages/Cashier"));
const Personale = React.lazy(() => import("./pages/Personale"));
const Customers = React.lazy(() => import("./pages/Customers"));
const Subscriptions = React.lazy(() => import("./pages/Subscriptions"));
const SubscriptionsAdmin = React.lazy(() => import("./pages/SubscriptionsAdmin"));
const Checkout = React.lazy(() => import("./pages/Checkout"));
const TenantIsolationTestPage = React.lazy(() => import("./pages/TenantIsolationTestPage"));
const SystemStatusPage = React.lazy(() => import("./pages/SystemStatusPage"));
const DatabaseAdmin = React.lazy(() => import("./pages/DatabaseAdmin"));
const AdminSettings = React.lazy(() => import("./pages/AdminSettings"));
const AdminNotifications = React.lazy(() => import("./pages/AdminNotifications"));
const PaymentSystemTest = React.lazy(() => import('./pages/PaymentSystemTest'));
const Orders = React.lazy(() => import('./pages/Orders'));
const NewOrder = React.lazy(() => import('./pages/NewOrder'));

// Loading fallback component
const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-screen">
    <Spinner size="lg" />
    <span className="ml-2 text-muted-foreground">Caricamento...</span>
  </div>
);

const queryClient = new QueryClient();

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <UserProvider>
          <TenantProvider>
            <QueryClientProvider client={queryClient}>
              <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
                <NotificationProvider>
                  <Routes>
                    <Route path="/" element={<Index />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/auth/callback" element={<AuthCallback />} />
                    <Route path="/coming-soon" element={<ComingSoon />} />
                    
                    {/* Public Digital Menu Route - accessible without authentication */}
                    <Route path="/menu/:slug" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <PublicDigitalMenu />
                      </Suspense>
                    } />
                    
                    {/* Lazy loaded routes */}
                    <Route path="/dashboard" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Dashboard />
                      </Suspense>
                    } />
                    <Route path="/settings" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Settings />
                      </Suspense>
                    } />
                    <Route path="/profile" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Profile />
                      </Suspense>
                    } />
                    <Route path="/menu" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Menu />
                      </Suspense>
                    } />
                    <Route path="/rooms" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Rooms />
                      </Suspense>
                    } />
                    
                    {/* Order Routes */}
                    <Route path="/orders" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Orders />
                      </Suspense>
                    } />
                    <Route path="/orders/new" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <NewOrder />
                      </Suspense>
                    } />
                    
                    <Route path="/digital-menu" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <DigitalMenu />
                      </Suspense>
                    } />
                    <Route path="/reservations" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Reservations />
                      </Suspense>
                    } />
                    <Route path="/inventory" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Inventory />
                      </Suspense>
                    } />
                    <Route path="/cashier" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Cashier />
                      </Suspense>
                    } />
                    <Route path="/personale" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Personale />
                      </Suspense>
                    } />
                    <Route path="/customers" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Customers />
                      </Suspense>
                    } />
                    <Route path="/subscriptions" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Subscriptions />
                      </Suspense>
                    } />
                    
                    {/* Nuova rotta per il test del sistema di pagamenti */}
                    <Route path="/payment-system-test" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <PaymentSystemTest />
                      </Suspense>
                    } />
                    
                    {/* Rotte amministrative */}
                    <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
                    <Route path="/admin/dashboard" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Dashboard adminMode={true} />
                      </Suspense>
                    } />
                    <Route path="/admin/subscriptions" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <SubscriptionsAdmin />
                      </Suspense>
                    } />
                    <Route path="/admin/users" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Customers />
                      </Suspense>
                    } />
                    <Route path="/admin/system" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <SystemStatusPage />
                      </Suspense>
                    } />
                    <Route path="/admin/database" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <DatabaseAdmin />
                      </Suspense>
                    } />
                    <Route path="/admin/settings" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <AdminSettings />
                      </Suspense>
                    } />
                    <Route path="/admin/notifications" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <AdminNotifications />
                      </Suspense>
                    } />
                    <Route path="/subscriptions-admin" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <SubscriptionsAdmin />
                      </Suspense>
                    } />
                    
                    <Route path="/checkout" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <Checkout />
                      </Suspense>
                    } />
                    <Route path="/tenant-isolation-test" element={
                      <Suspense fallback={<LoadingFallback />}>
                        <TenantIsolationTestPage />
                      </Suspense>
                    } />
                    
                    {/* Fallback routes to handle 404s and redirects */}
                    <Route path="/404" element={<NotFound />} />
                    <Route path="*" element={<Navigate to="/404" replace />} />
                  </Routes>
                  <Toaster />
                </NotificationProvider>
              </ThemeProvider>
            </QueryClientProvider>
          </TenantProvider>
        </UserProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
