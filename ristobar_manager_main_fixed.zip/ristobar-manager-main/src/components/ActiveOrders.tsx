
import { useState, useEffect } from 'react';
import { fetchOrders, Order, completeOrder, getOrderById, updateOrderStatus } from '@/services/ordersService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { toast } from '@/hooks/use-toast';
import { Eye, CheckCircle, XCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ActiveOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderDialog, setShowOrderDialog] = useState<boolean>(false);
  const [processingOrderId, setProcessingOrderId] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "active" | "paid">("all");

  const loadOrders = async () => {
    try {
      setLoading(true);
      const ordersList = await fetchOrders();
      // Sort by timestamp (most recent first)
      const sortedOrders = ordersList
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      
      setOrders(sortedOrders);
    } catch (error) {
      console.error('Errore nel caricamento degli ordini:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();

    // Configure listeners for updates from other components
    const handleOrdersUpdated = () => loadOrders();
    window.addEventListener('orders-updated', handleOrdersUpdated);
    window.addEventListener('order-completed', handleOrdersUpdated);
    
    return () => {
      window.removeEventListener('orders-updated', handleOrdersUpdated);
      window.removeEventListener('order-completed', handleOrdersUpdated);
    };
  }, []);

  const handleViewOrder = async (orderId: string) => {
    try {
      const order = await getOrderById(orderId);
      if (order) {
        setSelectedOrder(order);
        setShowOrderDialog(true);
      } else {
        toast({
          title: "Errore",
          description: "Ordine non trovato",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Errore nel recupero dell\'ordine:', error);
      toast({
        title: "Errore",
        description: "Impossibile recuperare i dettagli dell'ordine",
        variant: "destructive"
      });
    }
  };

  const handleCompleteOrder = async (orderId: string) => {
    try {
      setProcessingOrderId(orderId);
      
      console.log('Completamento ordine iniziato per ID:', orderId);
      
      // Use the completeOrder function which handles everything
      const completedOrder = await completeOrder(orderId);
      console.log('Ordine completato con successo:', completedOrder);
      
      toast({
        title: "Completato",
        description: "Ordine contrassegnato come completato e inviato alla cassa",
      });
      
      // Reload orders to update the list
      loadOrders();
    } catch (error) {
      console.error('Errore nel completamento dell\'ordine:', error);
      toast({
        title: "Errore",
        description: `Impossibile completare l'ordine: ${error instanceof Error ? error.message : 'Errore sconosciuto'}`,
        variant: "destructive"
      });
    } finally {
      setProcessingOrderId(null);
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      setProcessingOrderId(orderId);
      await updateOrderStatus(orderId, 'cancelled');
      toast({
        title: "Annullato",
        description: "Ordine annullato",
      });
      loadOrders();
    } catch (error) {
      console.error('Errore nell\'annullamento dell\'ordine:', error);
      toast({
        title: "Errore",
        description: "Impossibile annullare l'ordine",
        variant: "destructive"
      });
    } finally {
      setProcessingOrderId(null);
    }
  };

  const getOrderStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending': return 'default';
      case 'completed': return 'secondary';
      case 'paid': return 'success';
      case 'cancelled': return 'destructive';
      default: return 'default';
    }
  };

  const getOrderStatusLabel = (status: string) => {
    switch (status) {
      case 'pending': return 'In attesa';
      case 'completed': return 'Completato';
      case 'paid': return 'Pagato';
      case 'cancelled': return 'Annullato';
      default: return status;
    }
  };

  // Filter orders based on selected filter
  const filteredOrders = orders.filter(order => {
    if (filter === "all") return true;
    if (filter === "active") return order.status === 'pending' || order.status === 'completed';
    if (filter === "paid") return order.status === 'paid';
    return true;
  });

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Ordini</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center h-24">
            <p className="text-muted-foreground">Caricamento ordini...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (orders.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Ordini</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center h-24">
            <p className="text-muted-foreground">Nessun ordine</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Ordini</CardTitle>
          <Select value={filter} onValueChange={(value) => setFilter(value as "all" | "active" | "paid")}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filtra ordini" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti gli ordini</SelectItem>
              <SelectItem value="active">Ordini attivi</SelectItem>
              <SelectItem value="paid">Ordini pagati</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent className="space-y-4">
          {filteredOrders.length === 0 ? (
            <div className="flex justify-center items-center h-24">
              <p className="text-muted-foreground">Nessun ordine {filter === "active" ? "attivo" : filter === "paid" ? "pagato" : ""}</p>
            </div>
          ) : (
            filteredOrders.map((order) => (
              <div key={order.id} className="border rounded-lg p-3">
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <span className="font-medium">Ordine #{order.id.substring(0, 6)}</span>
                    <Badge className="ml-2">{order.tableName}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={getOrderStatusBadgeVariant(order.status)}>
                      {getOrderStatusLabel(order.status)}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {format(new Date(order.timestamp), 'HH:mm', { locale: it })}
                    </span>
                  </div>
                </div>
                
                <div className="space-y-1">
                  {order.items.slice(0, 3).map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{item.quantity}x {item.name}</span>
                      <span>€{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  {order.items.length > 3 && (
                    <div className="text-sm text-muted-foreground">
                      + altri {order.items.length - 3} prodotti
                    </div>
                  )}
                </div>
                
                <div className="mt-2 pt-2 border-t flex justify-between">
                  <span className="font-medium">Totale</span>
                  <span className="font-medium">€{order.total.toFixed(2)}</span>
                </div>

                <div className="mt-3 pt-2 border-t flex gap-2 justify-end">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleViewOrder(order.id)}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    Visualizza
                  </Button>
                  {order.status === 'pending' && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-green-50 hover:bg-green-100 text-green-700 hover:text-green-800"
                        onClick={() => handleCompleteOrder(order.id)}
                        disabled={processingOrderId === order.id}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        {processingOrderId === order.id ? 'In corso...' : 'Completa'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800"
                        onClick={() => handleCancelOrder(order.id)}
                        disabled={processingOrderId === order.id}
                      >
                        <XCircle className="h-4 w-4 mr-1" />
                        Annulla
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {selectedOrder && (
        <Dialog open={showOrderDialog} onOpenChange={setShowOrderDialog}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Dettagli Ordine #{selectedOrder.id.substring(0, 6)}</DialogTitle>
            </DialogHeader>
            
            <div className="py-2">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <Badge>{selectedOrder.tableName}</Badge>
                  <p className="text-sm text-muted-foreground mt-1">
                    {format(new Date(selectedOrder.timestamp), 'dd/MM/yyyy HH:mm', { locale: it })}
                  </p>
                </div>
                <Badge variant={getOrderStatusBadgeVariant(selectedOrder.status)}>
                  {getOrderStatusLabel(selectedOrder.status)}
                </Badge>
              </div>
              
              <div className="border rounded-md">
                <div className="grid grid-cols-[1fr_80px_80px] gap-2 font-medium px-3 py-2 border-b">
                  <div>Prodotto</div>
                  <div className="text-right">Qtà</div>
                  <div className="text-right">Prezzo</div>
                </div>
                
                <div className="divide-y">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="grid grid-cols-[1fr_80px_80px] gap-2 px-3 py-2">
                      <div>{item.name}</div>
                      <div className="text-right">{item.quantity}</div>
                      <div className="text-right">€{(item.price * item.quantity).toFixed(2)}</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-between font-medium mt-4">
                <span>Totale</span>
                <span>€{selectedOrder.total.toFixed(2)}</span>
              </div>
            </div>
            
            <DialogFooter className="flex sm:justify-between">
              <DialogClose asChild>
                <Button variant="outline">Chiudi</Button>
              </DialogClose>
              
              <div className="flex gap-2">
                {selectedOrder.status === 'pending' && (
                  <>
                    <Button
                      variant="outline"
                      className="bg-green-50 hover:bg-green-100 text-green-700 hover:text-green-800"
                      onClick={() => {
                        handleCompleteOrder(selectedOrder.id);
                        setShowOrderDialog(false);
                      }}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Completa
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800"
                      onClick={() => {
                        handleCancelOrder(selectedOrder.id);
                        setShowOrderDialog(false);
                      }}
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Annulla
                    </Button>
                  </>
                )}
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
