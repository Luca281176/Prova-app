
import { Link } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { buttonVariants } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { CreditCard } from 'lucide-react';

const AdminSubscriptionLink = () => {
  const { user, isAdmin } = useUser();

  // Mostra il link solo agli amministratori o proprietari
  if (!user || !isAdmin()) {
    return null;
  }

  return (
    <Link to="/admin/subscriptions" className={cn(
      buttonVariants({ variant: "ghost", size: "nav" }),
      "justify-start"
    )}>
      <CreditCard className="mr-2 h-4 w-4" />
      Gestione Abbonamenti
    </Link>
  );
};

export default AdminSubscriptionLink;
