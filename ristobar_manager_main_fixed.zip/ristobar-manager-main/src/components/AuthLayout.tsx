
import { ReactNode } from 'react';
import { Navbar } from './Navbar';
import { ArrowUpIcon } from 'lucide-react';

interface AuthLayoutProps {
  children: ReactNode;
}

export function AuthLayout({ children }: AuthLayoutProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col w-full">
      <Navbar />
      <div className="flex-1 pt-24">
        <div className="container mx-auto max-w-7xl py-6">
          <div className="py-6 px-2 sm:px-4">
            {children}
          </div>
        </div>
      </div>
      
      {/* Footer con copyright */}
      <footer className="bg-background border-t border-border mt-8 py-4">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-foreground/60">
              © {new Date().getFullYear()} RistoBar Manager 4.0. Tutti i diritti riservati. Sviluppato da Luca Costanzo.
            </p>
            <button 
              onClick={scrollToTop} 
              className="flex items-center justify-center w-10 h-10 mt-4 md:mt-0 rounded-full bg-accent hover:bg-accent/80 transition-colors"
              aria-label="Torna all'inizio"
            >
              <ArrowUpIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default AuthLayout;
