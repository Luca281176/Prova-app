
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { toast } from "sonner";

export function LandingContact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate form
    if (!formData.name || !formData.email || !formData.message) {
      toast.error("Per favore, compila tutti i campi obbligatori.");
      setIsSubmitting(false);
      return;
    }

    try {
      // Create a mailto URL with the form data
      const recipient = "luca.costanzo@ristobarmanager.it";
      const subject = encodeURIComponent(formData.subject || "Messaggio da RistoBar Manager");
      const body = encodeURIComponent(
        `Nome: ${formData.name}\n` +
        `Email: ${formData.email}\n\n` +
        `Messaggio:\n${formData.message}`
      );
      
      // Log the email content for debugging
      console.log("Invio email a:", recipient);
      console.log("Oggetto:", decodeURIComponent(subject));
      console.log("Contenuto:", decodeURIComponent(body));

      // Create and open the mailto link
      const mailtoLink = `mailto:${recipient}?subject=${subject}&body=${body}`;
      window.open(mailtoLink, "_blank");
      
      // Show success message
      toast.success("Form preparato per l'invio! Completa l'operazione nel tuo client email.");
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      console.error("Errore nella preparazione dell'email:", error);
      toast.error("Si è verificato un errore. Riprova più tardi.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-16 md:py-24 bg-accent/50" id="contact">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-up">
            Contattaci
          </h2>
          <p className="text-lg text-foreground/80 animate-fade-up [animation-delay:150ms]">
            Hai domande o vuoi saperne di più? Il nostro team è qui per aiutarti.
          </p>
        </div>
        
        <div className="max-w-xl mx-auto glass-panel p-8 rounded-xl animate-scale-in [animation-delay:300ms]">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name">Nome *</Label>
                <Input
                  type="text"
                  id="name"
                  placeholder="Il tuo nome"
                  className="mt-2"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  type="email"
                  id="email"
                  placeholder="La tua email"
                  className="mt-2"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="subject">Oggetto</Label>
              <Input
                type="text"
                id="subject"
                placeholder="Oggetto del messaggio"
                className="mt-2"
                value={formData.subject}
                onChange={handleChange}
              />
            </div>
            
            <div>
              <Label htmlFor="message">Messaggio *</Label>
              <Textarea
                id="message"
                rows={4}
                className="w-full mt-2"
                placeholder="Il tuo messaggio"
                value={formData.message}
                onChange={handleChange}
                required
              />
            </div>
            
            <div className="text-sm text-foreground/70">
              * Campi obbligatori
            </div>
            
            <Button 
              type="submit" 
              className="w-full"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Invio in corso..." : "Invia Messaggio"}
            </Button>
            
            <div className="text-center text-sm text-foreground/70 pt-4">
              Tutti i messaggi saranno inviati a: <span className="font-medium">luca.costanzo@ristobarmanager.it</span>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default LandingContact;
