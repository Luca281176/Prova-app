
import { useState } from 'react';
import { 
  LayoutIcon, 
  ClipboardListIcon, 
  CalendarIcon, 
  UsersIcon, 
  ShoppingCartIcon,
  CreditCardIcon,
  PieChartIcon,
  GlobeIcon,
  RocketIcon,
  StarIcon,
  CrownIcon,
  CodeIcon,
  HeadphonesIcon,
  ShieldIcon,
  ServerIcon,
  ZapIcon,
  BuildingIcon,
  DiamondIcon,
  GemIcon
} from 'lucide-react';
import { Button } from './ui/button';
import { subscriptionPlans } from '@/services/subscriptions';
import { Link } from 'react-router-dom';
import './animations.css';

// Feature groups mapped to subscription plans
const featureTiers = {
  starter: ['Gestione Sale e Tavoli', 'Menu Digitale', 'Sistema di Prenotazioni', 'Gestione Ordini'],
  pro: ['Gestione del Personale', 'Pagamenti e Conti', 'Reportistica Avanzata'],
  ultimate: ['Accessibile Ovunque', 'Integrazione API Avanzata', 'Supporto Dedicato VIP', 'Multi-Location', 'Sicurezza Avanzata', 'Analisi Predittiva']
};

const features = [
  {
    title: 'Gestione Sale e Tavoli',
    description: 'Configura il layout del tuo ristorante e monitora in tempo reale lo stato di ogni tavolo.',
    detailedDescription: [
      'Mappa interattiva delle sale con editor drag-and-drop',
      'Tracking in tempo reale dello stato dei tavoli',
      'Gestione dei tempi di occupazione e rotazione'
    ],
    icon: <LayoutIcon className="h-8 w-8 text-primary" />,
    color: 'from-green-500/20 to-green-500/5',
    tier: 'starter'
  },
  {
    title: 'Menu Digitale',
    description: 'Crea e gestisci menu completi e personalizzabili con categorie, allergeni e varianti.',
    detailedDescription: [
      'QR code generati automaticamente per ogni tavolo',
      'Editor visuale per la creazione di menu accattivanti',
      'Etichette per allergeni e opzioni dietetiche'
    ],
    icon: <ClipboardListIcon className="h-8 w-8 text-primary" />,
    color: 'from-blue-500/20 to-blue-500/5',
    tier: 'starter'
  },
  {
    title: 'Sistema di Prenotazioni',
    description: 'Gestisci le prenotazioni online e ottimizza l\'occupazione del tuo locale.',
    detailedDescription: [
      'Widget per prenotazioni da aggiungere al tuo sito web',
      'Notifiche automatiche di conferma via email',
      'Gestione delle liste d\'attesa nei periodi di alta affluenza'
    ],
    icon: <CalendarIcon className="h-8 w-8 text-primary" />,
    color: 'from-purple-500/20 to-purple-500/5',
    tier: 'starter'
  },
  {
    title: 'Gestione Ordini',
    description: 'Prendi ordini in modo efficiente e trasmettili istantaneamente in cucina.',
    detailedDescription: [
      'Interfaccia touch ottimizzata per velocità di inserimento',
      'Stampa automatica degli ordini in cucina',
      'Tracciamento dello stato di preparazione dei piatti'
    ],
    icon: <ShoppingCartIcon className="h-8 w-8 text-primary" />,
    color: 'from-orange-500/20 to-orange-500/5',
    tier: 'starter'
  },
  {
    title: 'Gestione del Personale',
    description: 'Gestisci turni, permessi e performance del tuo staff in un unico posto.',
    detailedDescription: [
      'Pianificazione dei turni con controllo costi',
      'Tracciamento ore lavorate e calcolo stipendi',
      'Valutazione performance basata su metriche specifiche'
    ],
    icon: <UsersIcon className="h-8 w-8 text-primary" />,
    color: 'from-pink-500/20 to-pink-500/5',
    tier: 'pro'
  },
  {
    title: 'Pagamenti e Conti',
    description: 'Integrazione con sistemi POS e possibilità di dividere i conti tra più persone.',
    detailedDescription: [
      'Compatibilità con i principali sistemi POS del mercato',
      'Split bill intuitivo per divisione del conto',
      'Gestione delle mance e reportistica fiscale'
    ],
    icon: <CreditCardIcon className="h-8 w-8 text-primary" />,
    color: 'from-amber-500/20 to-amber-500/5',
    tier: 'pro'
  },
  {
    title: 'Reportistica Avanzata',
    description: 'Analizza vendite, costi e andamento del tuo locale con report dettagliati.',
    detailedDescription: [
      'Dashboard personalizzabili con metriche chiave',
      'Export automatici in formato Excel o PDF',
      'Confronto performance tra periodi diversi'
    ],
    icon: <PieChartIcon className="h-8 w-8 text-primary" />,
    color: 'from-teal-500/20 to-teal-500/5',
    tier: 'pro'
  },
  {
    title: 'Accessibile Ovunque',
    description: 'Accedi alla piattaforma da qualsiasi dispositivo, in qualsiasi momento e luogo.',
    detailedDescription: [
      'App mobile native per iOS e Android per gestione in mobilità',
      'Sincronizzazione in tempo reale tra tutti i dispositivi',
      'Modalità offline con sincronizzazione automatica'
    ],
    icon: <GlobeIcon className="h-8 w-8 text-primary" />,
    color: 'from-indigo-500/20 to-indigo-500/5',
    tier: 'ultimate'
  },
  {
    title: 'Integrazione API Avanzata',
    description: 'Connetti la piattaforma con qualsiasi sistema esterno tramite le nostre API RESTful.',
    detailedDescription: [
      'Documentazione completa con esempi di codice interattivi',
      'Webhooks per eventi in tempo reale',
      'SDK per le principali piattaforme (Node.js, Python, PHP, Java)'
    ],
    icon: <CodeIcon className="h-8 w-8 text-primary" />,
    color: 'from-violet-500/20 to-violet-500/5',
    tier: 'ultimate'
  },
  {
    title: 'Supporto Dedicato VIP',
    description: 'Un team dedicato disponibile 24/7 per assistenza tecnica e consulenza.',
    detailedDescription: [
      'Account manager personale per ottimizzazione continua',
      'Supporto telefonico diretto con priorità assoluta',
      'Formazione personalizzata per il tuo team'
    ],
    icon: <HeadphonesIcon className="h-8 w-8 text-primary" />,
    color: 'from-rose-500/20 to-rose-500/5',
    tier: 'ultimate'
  },
  {
    title: 'Multi-Location',
    description: 'Gestisci più sedi o catene di ristoranti da un\'unica dashboard centralizzata.',
    detailedDescription: [
      'Confronto performance tra diverse sedi',
      'Gestione centralizzata di menu e prezzi',
      'Reportistica consolidata e per singola sede'
    ],
    icon: <BuildingIcon className="h-8 w-8 text-primary" />,
    color: 'from-emerald-500/20 to-emerald-500/5',
    tier: 'ultimate'
  },
  {
    title: 'Sicurezza Avanzata',
    description: 'Protezione dei dati al massimo livello con crittografia end-to-end e compliance.',
    detailedDescription: [
      'Conformità GDPR e PCI DSS per gestione dati sensibili',
      'Autenticazione a due fattori e controllo accessi granulare',
      'Backup automatici crittografati su cloud privato'
    ],
    icon: <ShieldIcon className="h-8 w-8 text-primary" />,
    color: 'from-sky-500/20 to-sky-500/5',
    tier: 'ultimate'
  },
  {
    title: 'Analisi Predittiva',
    description: 'Algoritmi di AI per prevedere vendite, ottimizzare il personale e ridurre gli sprechi.',
    detailedDescription: [
      'Previsione accurate della domanda basate su storico, meteo e eventi',
      'Ottimizzazione automatica dei turni del personale',
      'Suggerimenti per la riduzione degli sprechi e gestione inventario'
    ],
    icon: <ZapIcon className="h-8 w-8 text-primary" />,
    color: 'from-fuchsia-500/20 to-fuchsia-500/5',
    tier: 'ultimate'
  }
];

const planIcons = {
  starter: <StarIcon className="h-5 w-5 text-green-500 mr-2" />,
  pro: <RocketIcon className="h-5 w-5 text-blue-500 mr-2" />,
  ultimate: <CrownIcon className="h-5 w-5 text-amber-500 mr-2" fill="currentColor" />
};

const planColors = {
  starter: 'bg-green-100 text-green-800 border-green-300',
  pro: 'bg-blue-100 text-blue-800 border-blue-300',
  ultimate: 'bg-amber-100 text-amber-800 border-amber-300'
};

const ultimateHighlights = [
  {
    title: 'Enterprise Ready',
    description: 'Infrastruttura scalabile progettata per catene di ristoranti',
    icon: <ServerIcon className="h-10 w-10 text-amber-500" />
  },
  {
    title: 'Tecnologia Avanzata',
    description: 'AI e analisi predittiva per decisioni data-driven',
    icon: <DiamondIcon className="h-10 w-10 text-amber-500" />
  },
  {
    title: 'Esperienza Premium',
    description: 'Team di supporto dedicato e consulenza personalizzata',
    icon: <GemIcon className="h-10 w-10 text-amber-500" />
  }
];

export function LandingFeatures() {
  const [selectedTier, setSelectedTier] = useState('all');
  const [hoveredFeature, setHoveredFeature] = useState<string | null>(null);
  const [expandedFeature, setExpandedFeature] = useState<string | null>(null);
  
  const filteredFeatures = selectedTier === 'all' 
    ? features 
    : features.filter(feature => feature.tier === selectedTier);
  
  const toggleExpand = (title: string) => {
    setExpandedFeature(expandedFeature === title ? null : title);
  };
  
  return (
    <div className="py-16 md:py-24 relative overflow-hidden" id="features">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-background z-0">
        <div className="absolute inset-0 opacity-30">
          {[...Array(20)].map((_, i) => (
            <div 
              key={i}
              className="absolute rounded-full bg-primary/10"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 200 + 50}px`,
                height: `${Math.random() * 200 + 50}px`,
                animationDuration: `${Math.random() * 10 + 10}s`,
                animationDelay: `${Math.random() * 5}s`,
                animation: 'pulse 10s infinite ease-in-out'
              }}
            />
          ))}
        </div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-up">
            Funzionalità Principali
          </h2>
          <p className="text-lg text-foreground/80 animate-fade-up [animation-delay:150ms]">
            Tutto ciò di cui hai bisogno per gestire efficacemente il tuo ristorante o bar, in un'unica soluzione.
          </p>
          
          {/* Piano selettore */}
          <div className="flex flex-wrap justify-center gap-3 mt-8 mb-12 animate-fade-up [animation-delay:250ms]">
            <Button 
              variant={selectedTier === 'all' ? "default" : "outline"} 
              className="rounded-full transition-all"
              onClick={() => setSelectedTier('all')}
            >
              Tutte le funzionalità
            </Button>
            {Object.keys(featureTiers).map((tier) => {
              const plan = subscriptionPlans.find(p => p.id === tier);
              return (
                <Button 
                  key={tier}
                  variant={selectedTier === tier ? "default" : "outline"} 
                  className={`rounded-full flex items-center transition-all ${
                    tier === 'starter' ? 'hover:bg-green-100 hover:text-green-800' :
                    tier === 'pro' ? 'hover:bg-blue-100 hover:text-blue-800' :
                    'hover:bg-amber-100 hover:text-amber-800'
                  }`}
                  onClick={() => setSelectedTier(tier)}
                >
                  {planIcons[tier as keyof typeof planIcons]}
                  Piano {plan?.name}
                </Button>
              );
            })}
          </div>
        </div>
        
        {/* Ultimate Plan Highlights - Only show when Ultimate is selected or All */}
        {(selectedTier === 'ultimate' || selectedTier === 'all') && (
          <div className="mb-16 p-6 rounded-xl bg-gradient-to-r from-amber-500/10 to-amber-500/5 border border-amber-200/50 shadow-lg">
            <div className="text-center mb-8">
              <div className="inline-flex items-center mb-3 px-4 py-1 rounded-full bg-amber-100 text-amber-800 font-medium">
                <CrownIcon className="h-5 w-5 mr-2" fill="currentColor" />
                Piano Ultimate
              </div>
              <h3 className="text-2xl md:text-3xl font-bold mb-2">La soluzione completa per catene di ristoranti</h3>
              <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
                Ottieni il massimo controllo e le funzionalità più avanzate per gestire più sedi con un'unica piattaforma centralizzata.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {ultimateHighlights.map((highlight, index) => (
                <div 
                  key={highlight.title}
                  className="p-6 rounded-lg bg-white/20 backdrop-blur-sm border border-amber-200/50 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 hover:bg-white/30 animate-fade-up"
                  style={{ animationDelay: `${200 * (index + 1)}ms` }}
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="mb-4 p-3 rounded-full bg-amber-100/50">
                      {highlight.icon}
                    </div>
                    <h4 className="text-xl font-semibold mb-2">{highlight.title}</h4>
                    <p className="text-foreground/80">{highlight.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredFeatures.map((feature, index) => (
            <div 
              key={feature.title} 
              className={`relative bg-gradient-to-br ${feature.color} p-6 rounded-xl border border-accent/40 shadow-lg backdrop-blur-sm transition-all duration-500 hover:shadow-xl ${expandedFeature === feature.title ? 'lg:col-span-2 row-span-2' : ''} animate-fade-up`}
              style={{ animationDelay: `${150 * (index + 1)}ms` }}
              onMouseEnter={() => setHoveredFeature(feature.title)}
              onMouseLeave={() => setHoveredFeature(null)}
            >
              {/* Badge per il piano */}
              <div className={`absolute -top-3 right-3 px-3 py-1 rounded-full text-xs font-medium ${
                feature.tier === 'starter' ? planColors.starter :
                feature.tier === 'pro' ? planColors.pro :
                planColors.ultimate
              }`}>
                {planIcons[feature.tier as keyof typeof planIcons]}
                <span>Piano {subscriptionPlans.find(p => p.id === feature.tier)?.name}</span>
              </div>
              
              <div className={`w-14 h-14 rounded-full flex items-center justify-center backdrop-blur-sm bg-white/10 border border-white/20 mb-5 transition-all duration-500 ${
                hoveredFeature === feature.title ? 'scale-110 bg-white/20' : ''
              }`}>
                {feature.icon}
              </div>
              
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-foreground/80 mb-4">{feature.description}</p>
              
              {/* Detailed bullet points that appear on expand */}
              {expandedFeature === feature.title && feature.detailedDescription && (
                <div className="mt-4 pt-4 border-t border-white/20 animate-fade-in">
                  <h4 className="font-medium mb-2">Caratteristiche dettagliate:</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    {feature.detailedDescription.map((item, i) => (
                      <li key={i} className="text-foreground/90">{item}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              {/* Action buttons */}
              <div className={`mt-4 flex justify-end ${expandedFeature === feature.title ? 'opacity-100' : hoveredFeature === feature.title ? 'opacity-100 animate-fade-in' : 'opacity-0'} transition-opacity`}>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-xs"
                  onClick={() => toggleExpand(feature.title)}
                >
                  {expandedFeature === feature.title ? 'Meno dettagli' : 'Più dettagli'}
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        {/* CTA Section with enhanced visual appeal */}
        <div className="mt-16 relative p-8 rounded-2xl bg-gradient-to-r from-primary/20 via-primary/10 to-transparent border border-primary/30 shadow-lg overflow-hidden animate-fade-up [animation-delay:800ms]">
          {/* Decorative elements */}
          <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-primary/20 blur-3xl"></div>
          <div className="absolute -bottom-24 -left-24 w-48 h-48 rounded-full bg-primary/20 blur-3xl"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0 text-center md:text-left">
              <h3 className="text-2xl font-bold mb-2">Pronto a trasformare il tuo ristorante?</h3>
              <p className="text-lg mb-0 max-w-lg">
                Scegli il piano più adatto alle tue esigenze e inizia subito con 30 giorni di prova gratuita. Nessuna carta di credito richiesta.
              </p>
            </div>
            <Button asChild size="lg" className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary shadow-lg hover:shadow-xl transition-all">
              <Link to="/register">Inizia la prova gratuita</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingFeatures;
