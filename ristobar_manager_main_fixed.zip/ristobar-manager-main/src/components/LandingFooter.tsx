
import { Link } from 'react-router-dom';
import { 
  FacebookIcon, 
  TwitterIcon, 
  InstagramIcon, 
  LinkedinIcon,
  ArrowUpIcon
} from 'lucide-react';

export function LandingFooter() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-background border-t border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center mb-4">
              <span className="text-2xl font-semibold tracking-tight">
                Risto<span className="text-primary">Bar</span>
              </span>
            </Link>
            <p className="text-foreground/70 mb-4">
              Semplifichiamo la gestione del tuo ristorante o bar con soluzioni innovative e intuitive.
            </p>
            <div className="flex space-x-4 text-foreground/70">
              <a href="#" className="hover:text-primary transition-colors">
                <FacebookIcon className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                <TwitterIcon className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                <InstagramIcon className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors">
                <LinkedinIcon className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div className="col-span-1">
            <h3 className="font-medium mb-4">Prodotto</h3>
            <ul className="space-y-2">
              <li><Link to="/#features" className="text-foreground/70 hover:text-primary transition-colors">Caratteristiche</Link></li>
              <li><Link to="/#pricing" className="text-foreground/70 hover:text-primary transition-colors">Prezzi</Link></li>
              <li><Link to="/register" className="text-foreground/70 hover:text-primary transition-colors">Prova Gratuita</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Aggiornamenti</Link></li>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="font-medium mb-4">Risorse</h3>
            <ul className="space-y-2">
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Blog</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Guide</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Webinar</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Supporto</Link></li>
            </ul>
          </div>
          
          <div className="col-span-1">
            <h3 className="font-medium mb-4">Azienda</h3>
            <ul className="space-y-2">
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Chi Siamo</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Contatti</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Lavora con noi</Link></li>
              <li><Link to="#" className="text-foreground/70 hover:text-primary transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-foreground/60">
            © {new Date().getFullYear()} RistoBar Manager 4.0. Tutti i diritti riservati. Sviluppato da Luca Costanzo.
          </p>
          <button 
            onClick={scrollToTop} 
            className="flex items-center justify-center w-10 h-10 mt-4 md:mt-0 rounded-full bg-accent hover:bg-accent/80 transition-colors"
            aria-label="Torna all'inizio"
          >
            <ArrowUpIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
    </footer>
  );
}

export default LandingFooter;
