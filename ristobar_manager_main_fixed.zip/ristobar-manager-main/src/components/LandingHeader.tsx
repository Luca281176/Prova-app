
import { useState, useEffect } from 'react';
import { Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/contexts/user';
import { useToast } from '@/hooks/use-toast';
import { HeaderBanner } from './landing/HeaderBanner';
import { CallToAction } from './landing/CallToAction';
import { MediaDisplay } from './landing/MediaDisplay';
import { MediaUploader } from './landing/MediaUploader';

export function LandingHeader() {
  const { isAdmin } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  const [mediaUrl, setMediaUrl] = useState<string>("");
  const [mediaType, setMediaType] = useState<"video" | "image">("image");
  const [isLoading, setIsLoading] = useState(true);
  const [objectUrls, setObjectUrls] = useState<string[]>([]);

  useEffect(() => {
    return () => {
      objectUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [objectUrls]);

  useEffect(() => {
    setIsLoading(true);
    try {
      const savedMediaType = localStorage.getItem("landingMediaType") as "video" | "image";
      
      const mediaReference = localStorage.getItem("landingMediaReference");
      
      if (mediaReference === "default" || !mediaReference) {
        // Using a high-resolution restaurant image as default
        setMediaUrl("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop");
        setMediaType("image");
        console.log("Using default high-resolution image");
        setIsLoading(false);
        return;
      }
      
      const savedMediaUrl = localStorage.getItem("landingMedia");
      
      if (savedMediaUrl && savedMediaType) {
        console.log("Loading saved media:", {
          type: savedMediaType,
          urlLength: savedMediaUrl.length,
          isDataUrl: savedMediaUrl.startsWith('data:'),
          isObjectUrl: savedMediaUrl.startsWith('blob:')
        });
        
        setMediaUrl("");
        setMediaType(savedMediaType);
        
        setTimeout(() => {
          setMediaUrl(savedMediaUrl);
          setIsLoading(false);
        }, 50);
      } else {
        // Using a high-resolution restaurant image as fallback
        setMediaUrl("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop");
        setMediaType("image");
        console.log("No saved media found, using default high-res image");
        setIsLoading(false);
      }
    } catch (error) {
      console.error("Error loading media from localStorage:", error);
      setMediaUrl("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2070&auto=format&fit=crop");
      setMediaType("image");
      setIsLoading(false);
    }
  }, []);

  const handleSaveMedia = (dataUrl: string, type: "video" | "image") => {
    if (!dataUrl) {
      toast({
        title: "Errore",
        description: "URL del media non valido",
        variant: "destructive"
      });
      return;
    }
    
    console.log("Saving media:", {
      type,
      urlLength: dataUrl.length,
      isDataUrl: dataUrl.startsWith('data:'),
      isObjectUrl: dataUrl.startsWith('blob:')
    });
    
    try {
      setMediaUrl("");
      setMediaType(type);
      setIsLoading(true);
      
      if (dataUrl.startsWith('blob:')) {
        setObjectUrls(prev => [...prev, dataUrl]);
        localStorage.setItem("landingMediaType", type);
        localStorage.setItem("landingMediaReference", "custom");
        
        setTimeout(() => {
          setMediaUrl(dataUrl);
          setIsLoading(false);
          
          toast({
            title: "Successo",
            description: "Media caricato con successo",
          });
        }, 100);
      } else {
        try {
          localStorage.setItem("landingMedia", dataUrl);
          localStorage.setItem("landingMediaType", type);
          localStorage.setItem("landingMediaReference", "embedded");
          
          setTimeout(() => {
            setMediaUrl(dataUrl);
            setIsLoading(false);
            
            toast({
              title: "Successo",
              description: "Media caricato con successo",
            });
          }, 100);
        } catch (storageError) {
          console.error("Error saving to localStorage:", storageError);
          
          setTimeout(() => {
            setMediaUrl(dataUrl);
            setIsLoading(false);
            
            toast({
              title: "Attenzione",
              description: "Il media è stato caricato ma non sarà salvato tra le sessioni (dimensione eccessiva)",
              variant: "destructive"
            });
          }, 100);
        }
      }
    } catch (error) {
      console.error("Error processing media:", error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante il salvataggio",
        variant: "destructive"
      });
      setIsLoading(false);
      setMediaUrl("/video/ristorante-demo.mp4");
      setMediaType("video");
    }
    
    setIsEditing(false);
  };

  return (
    <div className="relative overflow-hidden pt-20 pb-16 md:pt-32 md:pb-24">
      <div className="absolute inset-0 overflow-hidden">
        <div className="landing-gradient absolute -top-40 -right-40 w-[600px] h-[600px]"></div>
        <div className="landing-gradient absolute -bottom-40 -left-40 w-[600px] h-[600px]"></div>
      </div>

      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div className="text-center max-w-3xl mx-auto">
          <HeaderBanner />
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 animate-fade-up [animation-delay:150ms]">
            Gestisci il tuo ristorante con <span className="text-primary">facilità</span>
          </h1>
          
          <p className="text-lg md:text-xl text-foreground/80 mb-8 leading-relaxed mx-auto max-w-2xl animate-fade-up [animation-delay:300ms]">
            Risto Bar Manager 4.0 è la piattaforma all-in-one che semplifica la gestione di ristoranti e bar, dalla disposizione dei tavoli agli ordini, fino alla gestione del personale.
          </p>
          
          <CallToAction />
        </div>
        
        <div id="demo" className="mt-16 sm:mt-24 relative animate-scale-in [animation-delay:800ms]">
          <div className="glass-panel rounded-xl overflow-hidden shadow-2xl shadow-primary/10">
            {isLoading ? (
              <div className="w-full h-64 bg-muted/50 animate-pulse rounded-lg flex items-center justify-center text-muted-foreground">
                Caricamento media...
              </div>
            ) : (
              <MediaDisplay mediaUrl={mediaUrl} mediaType={mediaType} />
            )}
          </div>
          <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium">
            Gestione digitale all'avanguardia
          </div>
          
          {isAdmin() && (
            <div className="absolute top-2 right-2">
              {isEditing ? (
                <MediaUploader 
                  onSave={handleSaveMedia}
                  onCancel={() => setIsEditing(false)} 
                />
              ) : (
                <Button size="sm" variant="outline" className="bg-white/90 backdrop-blur-sm shadow-md" onClick={() => setIsEditing(true)}>
                  <Upload className="mr-2 h-4 w-4" />
                  Modifica media
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default LandingHeader;
