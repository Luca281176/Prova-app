import { useNavigate } from 'react-router-dom';
import { subscriptionPlans } from '@/services/subscriptions';
import { CheckIcon, LeafIcon, RocketIcon, CrownIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function LandingPricing() {
  const navigate = useNavigate();
  const [loadingPlanId, setLoadingPlanId] = useState<string | null>(null);
  
  const handleSelectPlan = (planId: string) => {
    setLoadingPlanId(planId);
    // Breve ritardo per mostrare lo stato di caricamento
    setTimeout(() => {
      if (planId === 'starter' || planId === 'pro') {
        // Modificato: Reindirizza alla pagina di registrazione per entrambi starter e pro
        // Tutti i nuovi utenti otterranno il piano Pro durante la registrazione
        navigate(`/register`);
      } else if (planId === 'ultimate') {
        // Scroll to contact section
        const contactSection = document.getElementById('contact');
        if (contactSection) {
          contactSection.scrollIntoView({ behavior: 'smooth' });
        }
      }
      setLoadingPlanId(null);
    }, 300);
  };

  const getPlanIcon = (planId: string) => {
    switch(planId) {
      case 'starter':
        return <LeafIcon className="h-5 w-5 mr-2 text-green-500" />;
      case 'pro':
        return <RocketIcon className="h-5 w-5 mr-2 text-blue-500" />;
      case 'ultimate':
        return <CrownIcon className="h-5 w-5 mr-2 text-amber-500" fill="currentColor" />;
      default:
        return null;
    }
  };

  // Function to get the appropriate button text based on plan ID
  const getButtonText = (planId: string, isLoading: boolean): string => {
    if (isLoading) return "Elaborazione...";
    
    switch(planId) {
      case 'starter':
        return "Inizia la prova gratuita";
      case 'pro':
        return "Inizia la prova gratuita"; // Modificato per indicare che è una prova gratuita
      case 'ultimate':
        return "Contattaci";
      default:
        return "Seleziona piano";
    }
  };

  return (
    <div className="py-16 md:py-24" id="pricing">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-up">
            Piani e Prezzi
          </h2>
          <p className="text-lg text-foreground/80 animate-fade-up [animation-delay:150ms]">
            Scegli il piano più adatto alle tue esigenze e inizia subito a gestire il tuo ristorante.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {subscriptionPlans.map((plan, index) => (
            <div 
              key={plan.id} 
              className={`glass-panel rounded-xl p-6 flex flex-col relative cursor-pointer transition-all duration-200 hover:shadow-lg ${
                plan.isRecommended 
                  ? "transform scale-105 shadow-xl border-primary/30 animate-fade-up [animation-delay:300ms]" 
                  : index === 0 
                    ? "animate-slide-from-left [animation-delay:300ms]" 
                    : "animate-slide-from-right [animation-delay:300ms]"
              }`}
              onClick={() => handleSelectPlan(plan.id)}
            >
              {plan.isPopular && (
                <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs font-bold rounded-tr-xl rounded-bl-xl">
                  Più popolare
                </div>
              )}
              
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  {getPlanIcon(plan.id)}
                  <h3 className="text-lg font-semibold text-foreground">{plan.name}</h3>
                </div>
                <div className="flex items-baseline">
                  <span className="text-3xl font-bold text-foreground">€{plan.price.toFixed(2)}</span>
                  <span className="text-foreground/80 ml-1">/mese</span>
                </div>
                <p className="mt-3 text-foreground/80 text-sm">
                  {plan.description}
                </p>
              </div>
              
              <ul className="space-y-3 mb-8 flex-grow">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start text-foreground">
                    <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button
                variant={plan.isRecommended ? "default" : "outline"}
                className="w-full"
                onClick={(e) => {
                  e.stopPropagation(); // Previene doppio click
                  handleSelectPlan(plan.id);
                }}
                disabled={loadingPlanId === plan.id}
              >
                {getButtonText(plan.id, loadingPlanId === plan.id)}
              </Button>
              
              {plan.id === 'starter' && (
                <div className="mt-3 text-center text-xs text-muted-foreground">
                  14 giorni di prova gratuita, nessuna carta di credito richiesta
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default LandingPricing;
