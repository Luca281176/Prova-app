
import { 
  LifeBuoyIcon, 
  BookOpenIcon, 
  MessagesSquareIcon, 
  PhoneIcon, 
  ClockIcon 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from "sonner";

const supportOptions = [
  {
    icon: <LifeBuoyIcon className="h-8 w-8 text-primary" />,
    title: "Assistenza Tecnica",
    description: "Supporto tecnico diretto per risolvere qualsiasi problema con la piattaforma.",
    buttonText: "Contatta Supporto",
    link: "#contact",
    action: null
  },
  {
    icon: <BookOpenIcon className="h-8 w-8 text-primary" />,
    title: "Guide e Tutorial",
    description: "Accedi a guide dettagliate e video tutorial per imparare ad utilizzare tutte le funzionalità.",
    buttonText: "Vai alle Guide",
    link: "#",
    action: () => {
      toast.info("Le guide e i tutorial saranno disponibili a breve!");
    }
  },
  {
    icon: <MessagesSquareIcon className="h-8 w-8 text-primary" />,
    title: "Community Forum",
    description: "Unisciti alla nostra community per condividere idee e trovare soluzioni insieme ad altri utenti.",
    buttonText: "Entra nel Forum",
    link: "#",
    action: () => {
      toast.info("Il forum della community sarà disponibile a breve!");
    }
  }
];

export function LandingSupport() {
  const handleSupportOptionClick = (index: number, e: React.MouseEvent<HTMLAnchorElement>) => {
    const option = supportOptions[index];
    
    if (option.action) {
      e.preventDefault();
      option.action();
    }
  };

  const handleDirectContact = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Create a mailto link with the recipient, subject, and body
    const recipient = "luca.costanzo@ristobarmanager.it";
    const subject = encodeURIComponent("Richiesta di Supporto - RistoBar Manager");
    const body = encodeURIComponent("Salve,\n\nHo bisogno di assistenza riguardo a RistoBar Manager.\n\nGrazie,");
    
    // Create and open the mailto link
    const mailtoLink = `mailto:${recipient}?subject=${subject}&body=${body}`;
    window.open(mailtoLink, "_blank");
    
    // Notify the user
    toast.success("Il tuo client email si aprirà a breve per inviarci un messaggio!");
  };

  return (
    <div className="py-16 md:py-24 bg-accent/30" id="support">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-up">
            Supporto Dedicato
          </h2>
          <p className="text-lg text-foreground/80 animate-fade-up [animation-delay:150ms]">
            Siamo al tuo fianco in ogni momento. Il nostro team di supporto è pronto ad aiutarti.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
          {supportOptions.map((option, index) => (
            <div 
              key={index} 
              className="glass-panel rounded-xl p-8 flex flex-col items-center text-center animate-fade-up" 
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="rounded-full w-16 h-16 flex items-center justify-center bg-primary/10 mb-6">
                {option.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{option.title}</h3>
              <p className="text-foreground/80 mb-6 flex-grow">{option.description}</p>
              <Button asChild variant="outline">
                <a 
                  href={option.link} 
                  onClick={(e) => handleSupportOptionClick(index, e)}
                >
                  {option.buttonText}
                </a>
              </Button>
            </div>
          ))}
        </div>
        
        <div className="max-w-3xl mx-auto glass-panel rounded-xl p-8 animate-scale-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Orari di Supporto</h3>
              <p className="text-foreground/80 mb-6">
                Il nostro team di supporto è disponibile per aiutarti durante i seguenti orari:
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <ClockIcon className="h-5 w-5 text-primary mr-3 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Lunedì - Venerdì</h4>
                    <p className="text-foreground/70">9:00 - 18:00</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <ClockIcon className="h-5 w-5 text-primary mr-3 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Sabato</h4>
                    <p className="text-foreground/70">10:00 - 14:00</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <ClockIcon className="h-5 w-5 text-primary mr-3 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Domenica</h4>
                    <p className="text-foreground/70">Chiuso</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-semibold mb-4">Contatto Diretto</h3>
              <p className="text-foreground/80 mb-6">
                Hai bisogno di assistenza immediata? Contattaci direttamente:
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <PhoneIcon className="h-5 w-5 text-primary mr-3" />
                  <span>+39 02 1234567</span>
                </div>
                <div className="flex items-center">
                  <MessagesSquareIcon className="h-5 w-5 text-primary mr-3" />
                  <a 
                    href="#" 
                    className="hover:text-primary transition-colors"
                    onClick={handleDirectContact}
                  >
                    luca.costanzo@ristobarmanager.it
                  </a>
                </div>
              </div>
              
              <div className="mt-8">
                <Button asChild className="w-full">
                  <a href="#contact">Invia Messaggio</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingSupport;
