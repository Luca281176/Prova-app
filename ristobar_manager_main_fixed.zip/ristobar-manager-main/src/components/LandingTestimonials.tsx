
import { StarIcon, Quote } from 'lucide-react';

type TestimonialType = {
  id: number;
  name: string;
  role: string;
  restaurant: string;
  content: string;
  rating: number;
  image: string;
};

const testimonials: TestimonialType[] = [
  {
    id: 1,
    name: "Marco Bianchi",
    role: "Proprietario",
    restaurant: "Trattoria da Marco",
    content: "Da quando abbiamo iniziato a usare RistoBar, la gestione del nostro ristorante è diventata molto più semplice. Possiamo concentrarci su ciò che conta davvero: i nostri clienti e il nostro cibo.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1287&q=80"
  },
  {
    id: 2,
    name: "Giulia Rossi",
    role: "Manager",
    restaurant: "Pasta & Amore",
    content: "Il modulo di prenotazione ha rivoluzionato il nostro modo di lavorare. I clienti possono prenotare 24/7 e noi abbiamo ridotto gli errori di gestione quasi a zero.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1361&q=80"
  },
  {
    id: 3,
    name: "Antonio Verdi",
    role: "Chef",
    restaurant: "Osteria del Sole",
    content: "La gestione degli ordini tramite RistoBar ha migliorato la comunicazione tra sala e cucina, riducendo i tempi di attesa e aumentando la soddisfazione dei clienti.",
    rating: 4,
    image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1284&q=80"
  }
];

export function LandingTestimonials() {
  return (
    <div className="py-16 md:py-24" id="testimonials">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-fade-up">
            Cosa Dicono i Nostri Clienti
          </h2>
          <p className="text-lg text-foreground/80 animate-fade-up [animation-delay:150ms]">
            Scopri come RistoBar Manager ha aiutato i ristoratori a migliorare la loro gestione quotidiana.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div 
              key={testimonial.id} 
              className="glass-panel rounded-xl p-6 relative animate-fade-up" 
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="absolute -top-4 -left-4 bg-primary/10 p-2 rounded-full">
                <Quote className="h-6 w-6 text-primary" />
              </div>
              
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-foreground/70">{testimonial.role}, {testimonial.restaurant}</p>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon 
                      key={i} 
                      className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400' : 'text-gray-300'}`}
                      fill={i < testimonial.rating ? 'currentColor' : 'none'}
                    />
                  ))}
                </div>
              </div>
              
              <p className="text-foreground/80">{testimonial.content}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a 
            href="#contact" 
            className="inline-flex items-center px-6 py-3 border border-primary rounded-md font-medium text-primary hover:bg-primary/10 transition-colors"
          >
            Diventa uno dei nostri clienti soddisfatti
          </a>
        </div>
      </div>
    </div>
  );
}

export default LandingTestimonials;
