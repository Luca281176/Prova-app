import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button, buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { 
  MenuIcon, 
  XIcon,
  HomeIcon, 
  LayoutIcon, 
  ClipboardListIcon, 
  CalendarIcon, 
  UsersIcon, 
  ShoppingCartIcon,
  UtensilsCrossedIcon,
  PhoneIcon,
  MailIcon,
  HelpCircleIcon,
  UserCircleIcon,
  LogOutIcon,
  CreditCardIcon,
  Settings2Icon,
  BadgeDollarSignIcon,
  ArrowRightIcon
} from 'lucide-react';
import { useUser } from '@/contexts/UserContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Avatar,
  AvatarFallback,
  AvatarImage, 
} from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

type NavItem = {
  label: string;
  href: string;
  icon: React.ReactNode;
};

export const dashboardNavItems: NavItem[] = [
  { 
    label: "Dashboard", 
    href: "/dashboard", 
    icon: <HomeIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Sale e Tavoli", 
    href: "/rooms", 
    icon: <LayoutIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Menu", 
    href: "/menu", 
    icon: <ClipboardListIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Prenotazioni", 
    href: "/reservations", 
    icon: <CalendarIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Cassa", 
    href: "/cashier", 
    icon: <BadgeDollarSignIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Personale", 
    href: "/personale", 
    icon: <UsersIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Magazzino", 
    href: "/inventory", 
    icon: <ShoppingCartIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Impostazioni", 
    href: "/settings", 
    icon: <Settings2Icon className="h-4 w-4 mr-2" /> 
  }
];

const landingNavItems: NavItem[] = [
  { 
    label: "Home", 
    href: "/", 
    icon: <HomeIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Caratteristiche", 
    href: "/#features", 
    icon: <ClipboardListIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Prezzi", 
    href: "/#pricing", 
    icon: <ShoppingCartIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Demo", 
    href: "/#demo", 
    icon: <LayoutIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Testimonianze", 
    href: "/#testimonials", 
    icon: <UsersIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Contatti", 
    href: "/#contact", 
    icon: <PhoneIcon className="h-4 w-4 mr-2" /> 
  },
  { 
    label: "Supporto", 
    href: "/#support", 
    icon: <HelpCircleIcon className="h-4 w-4 mr-2" /> 
  }
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [navItems, setNavItems] = useState<NavItem[]>([]);
  const [logoHover, setLogoHover] = useState(false);
  const location = useLocation();
  const { user, logout, isAdmin } = useUser();
  
  const isDashboard = location.pathname.startsWith('/dashboard') || 
                      location.pathname.startsWith('/rooms') || 
                      location.pathname.startsWith('/menu') || 
                      location.pathname.startsWith('/reservations') || 
                      location.pathname.startsWith('/personale') || 
                      location.pathname.startsWith('/staff') || 
                      location.pathname.startsWith('/inventory') ||
                      location.pathname.startsWith('/profile') ||
                      location.pathname.startsWith('/subscriptions') ||
                      location.pathname.startsWith('/admin') ||
                      location.pathname.startsWith('/cashier') ||
                      location.pathname.startsWith('/settings');

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    let navItemsToShow = isDashboard ? dashboardNavItems : landingNavItems;
    
    setNavItems(navItemsToShow);
  }, [isDashboard, location, isAdmin]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('/#')) {
      e.preventDefault();
      const targetId = href.substring(2);
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setIsOpen(false);
      }
    } else {
      setIsOpen(false);
    }
  };
  
  const getInitials = (name: string) => {
    if (!name) return "U";
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-md shadow-sm' : 
        'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link 
                to={isDashboard ? "/dashboard" : "/"} 
                className="flex items-center"
                onMouseEnter={() => setLogoHover(true)}
                onMouseLeave={() => setLogoHover(false)}
              >
                <div className="relative mr-2">
                  <UtensilsCrossedIcon 
                    className={`h-6 w-6 text-primary transition-all duration-300 ${
                      logoHover ? 'rotate-12 scale-110' : ''
                    }`} 
                  />
                </div>
                <span className="text-xl font-semibold tracking-tight">
                  Risto<span className="text-primary">Bar</span>
                </span>
              </Link>
            </div>
            
            <Separator orientation="vertical" className="h-8 mx-8 hidden md:block" />
            
            <div className="hidden md:block">
              <div className="flex items-center space-x-1 lg:space-x-2 overflow-x-auto pb-1 scrollbar-hide">
                {!isDashboard && navItems.map((item) => (
                  <Link
                    key={item.label}
                    to={item.href}
                    onClick={(e) => handleNavClick(e, item.href)}
                    className={cn(
                      buttonVariants({ 
                        variant: "ghost", 
                        size: "nav" 
                      }),
                      "flex items-center whitespace-nowrap",
                      location.pathname === item.href || 
                      (item.href.startsWith('/#') && location.hash === item.href.substring(1))
                        ? 'bg-gradient-to-r from-primary/20 to-primary/10 text-primary'
                        : 'text-foreground/80 hover:text-foreground hover:bg-gradient-to-r hover:from-accent/50 hover:to-accent/30'
                    )}
                  >
                    {item.icon}
                    <span className="hidden sm:inline-block">{item.label}</span>
                  </Link>
                ))}
                
                {isDashboard && navItems.map((item) => (
                  <Link
                    key={item.label}
                    to={item.href}
                    className={cn(
                      buttonVariants({ 
                        variant: "ghost", 
                        size: "nav" 
                      }),
                      "flex items-center whitespace-nowrap",
                      location.pathname === item.href
                        ? 'bg-gradient-to-r from-primary/20 to-primary/10 text-primary'
                        : 'text-foreground/80 hover:text-foreground hover:bg-gradient-to-r hover:from-accent/50 hover:to-accent/30'
                    )}
                  >
                    {item.icon}
                    <span className="hidden sm:inline-block">{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
          
          <div className="hidden md:flex md:items-center">
            {isDashboard && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="relative h-9 w-9 rounded-full ml-16">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={user?.image || ""} alt={user?.name || ""} />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="cursor-pointer flex items-center">
                      <UserCircleIcon className="mr-2 h-4 w-4" />
                      <span>Profilo</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/subscriptions" className="cursor-pointer flex items-center">
                      <CreditCardIcon className="mr-2 h-4 w-4" />
                      <span>Abbonamento</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings" className="cursor-pointer flex items-center">
                      <Settings2Icon className="mr-2 h-4 w-4" />
                      <span>Impostazioni</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="cursor-pointer text-destructive focus:text-destructive"
                    onClick={logout}
                  >
                    <LogOutIcon className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2">
                {!isDashboard && !user && (
                  <>
                    <Button asChild variant="ghost" size="sm" className="hidden sm:flex">
                      <Link to="/login">Accedi</Link>
                    </Button>
                    <Button asChild size="sm">
                      <Link to="/register">Registrati</Link>
                    </Button>
                  </>
                )}
                
                {!isDashboard && user && (
                  <Button asChild size="sm" className="flex items-center">
                    <Link to="/dashboard">
                      Ritorna in App
                      <ArrowRightIcon className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </div>
            )}
          </div>
          
          <div className="flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-foreground focus:outline-none"
              aria-label="Apri menu principale"
            >
              {isOpen ? (
                <XIcon className="h-6 w-6" aria-hidden="true" />
              ) : (
                <MenuIcon className="h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      <div 
        className={`md:hidden ${isOpen ? 'block' : 'hidden'} fixed inset-0 pt-16 z-40`}
        style={{ height: isOpen ? '100vh' : '0' }}
      >
        <div className="h-full overflow-y-auto px-2 pt-2 pb-3 bg-background/95 backdrop-blur-sm shadow-lg">
          {!isDashboard ? (
            <>
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className={cn(
                    "flex items-center px-3 py-3 rounded-md text-base font-medium",
                    location.pathname === item.href || 
                    (item.href.startsWith('/#') && location.hash === item.href.substring(1))
                      ? 'bg-gradient-to-r from-primary/20 to-primary/10 text-primary'
                      : 'text-foreground/80 hover:text-foreground hover:bg-gradient-to-r hover:from-accent/50 hover:to-accent/30'
                  )}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </Link>
              ))}
              
              {!user && (
                <div className="pt-4 mt-4 border-t border-border grid grid-cols-2 gap-2 px-3">
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/login" onClick={() => setIsOpen(false)}>Accedi</Link>
                  </Button>
                  <Button asChild className="w-full">
                    <Link to="/register" onClick={() => setIsOpen(false)}>Registrati</Link>
                  </Button>
                </div>
              )}
              
              {user && (
                <div className="pt-4 mt-4 border-t border-border px-3">
                  <Button asChild className="w-full">
                    <Link to="/dashboard" onClick={() => setIsOpen(false)}>
                      Ritorna in App
                      <ArrowRightIcon className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              )}
            </>
          ) : (
            <>
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className={cn(
                    "flex items-center px-3 py-3 rounded-md text-base font-medium",
                    location.pathname === item.href
                      ? 'bg-gradient-to-r from-primary/20 to-primary/10 text-primary'
                      : 'text-foreground/80 hover:text-foreground hover:bg-gradient-to-r hover:from-accent/50 hover:to-accent/30'
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </Link>
              ))}
              
              {user && (
                <>
                  <div className="pt-4 mt-4 border-t border-border">
                    <div className="px-3 py-2">
                      <div className="flex items-center">
                        <Avatar className="h-9 w-9 mr-3">
                          <AvatarImage src={user?.image || ""} alt={user?.name || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {getInitials(user.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{user.name}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                        </div>
                      </div>
                    </div>
                    
                    <Link
                      to="/profile"
                      className="flex items-center px-3 py-3 rounded-md text-base font-medium text-foreground/80 hover:text-foreground hover:bg-accent/20"
                      onClick={() => setIsOpen(false)}
                    >
                      <UserCircleIcon className="h-4 w-4 mr-3" />
                      Profilo
                    </Link>
                    
                    <Link
                      to="/subscriptions"
                      className="flex items-center px-3 py-3 rounded-md text-base font-medium text-foreground/80 hover:text-foreground hover:bg-accent/20"
                      onClick={() => setIsOpen(false)}
                    >
                      <CreditCardIcon className="h-4 w-4 mr-3" />
                      Abbonamento
                    </Link>
                    
                    <Link
                      to="/settings"
                      className="flex items-center px-3 py-3 rounded-md text-base font-medium text-foreground/80 hover:text-foreground hover:bg-accent/20"
                      onClick={() => setIsOpen(false)}
                    >
                      <Settings2Icon className="h-4 w-4 mr-3" />
                      Impostazioni
                    </Link>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className="w-full mt-4 mx-3 text-destructive border-destructive/30 hover:bg-destructive/10"
                    onClick={() => {
                      logout();
                      setIsOpen(false);
                    }}
                  >
                    <LogOutIcon className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </>
              )}
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
