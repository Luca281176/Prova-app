
import { useState, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { Skeleton } from '@/components/ui/skeleton';
import AuthService from '@/services/authService';

interface PrivateRouteProps {
  children: React.ReactNode;
  requiresAdmin?: boolean;
}

export const PrivateRoute = ({ children, requiresAdmin = false }: PrivateRouteProps) => {
  const { user, isLoading, isAdmin } = useUser();
  const location = useLocation();
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Enhanced authentication check that works with both Supabase and Firebase
  useEffect(() => {
    const checkAuthentication = async () => {
      try {
        console.log('PrivateRoute: Checking authentication status...');
        // Double-check if the user is authenticated with either provider
        const authState = await AuthService.isAuthenticated();
        
        console.log('PrivateRoute: Auth check result:', { 
          authServiceResult: authState, 
          contextUser: !!user 
        });
        
        setIsAuthenticated(authState || !!user);
      } catch (error) {
        console.error('PrivateRoute: Error checking authentication:', error);
        setIsAuthenticated(false);
      } finally {
        setIsCheckingAuth(false);
      }
    };

    if (!isLoading) {
      checkAuthentication();
    }
  }, [isLoading, user]);

  // Show loading state while checking authentication
  if (isLoading || isCheckingAuth) {
    return (
      <div className="flex flex-col w-full p-8 gap-4">
        <Skeleton className="h-10 w-[250px]" />
        <Skeleton className="h-6 w-[180px]" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
        <Skeleton className="h-80 w-full mt-6" />
      </div>
    );
  }

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    console.log('PrivateRoute: User not authenticated, redirecting to login');
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If route requires admin privileges and user is not admin, redirect to dashboard
  if (requiresAdmin && !isAdmin()) {
    console.log('User is not admin, redirecting to dashboard');
    return <Navigate to="/dashboard" state={{ from: location }} replace />;
  }

  // If authenticated and has required permissions, render the protected component
  console.log('PrivateRoute: User is authenticated, rendering protected content');
  return <>{children}</>;
};

export default PrivateRoute;
