
import { Navigate, useLocation } from 'react-router-dom';
import { useUser } from '@/contexts/UserContext';
import { Skeleton } from '@/components/ui/skeleton';
import AuthService from '@/services/authService';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiresAdmin?: boolean;
  allowedRoles?: string[];
}

export const ProtectedRoute = ({ 
  children, 
  requiresAdmin = false,
  allowedRoles = []
}: ProtectedRouteProps) => {
  const { user, isLoading, isAdmin } = useUser();
  const location = useLocation();
  
  // Verifica se l'utente ha un token valido
  const hasValidToken = AuthService.isAuthenticated();

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex flex-col w-full p-8 gap-4">
        <Skeleton className="h-10 w-[250px]" />
        <Skeleton className="h-6 w-[180px]" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
        <Skeleton className="h-80 w-full mt-6" />
      </div>
    );
  }

  // Se non c'è un token valido o l'utente non è autenticato, reindirizza al login
  if (!hasValidToken || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Se la route richiede privilegi admin e l'utente non è admin, reindirizza alla dashboard
  if (requiresAdmin && !isAdmin()) {
    console.log('User is not admin, redirecting to dashboard');
    return <Navigate to="/dashboard" state={{ from: location }} replace />;
  }
  
  // Se ci sono ruoli specifici consentiti e l'utente non ha uno di quei ruoli
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    console.log(`User role ${user.role} not allowed, redirecting to dashboard`);
    return <Navigate to="/dashboard" state={{ from: location }} replace />;
  }

  // Se l'autenticazione ha successo e l'utente ha i permessi corretti, renderizza il componente protetto
  return <>{children}</>;
};

export default ProtectedRoute;
