
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

export interface RoomDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (roomData: { name: string; capacity: number }) => Promise<void> | void;
  initialData?: { id: string; name: string; capacity: number } | null;
  title: string;
}

export function RoomDialog({ open, onOpenChange, onSave, initialData, title }: RoomDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [capacity, setCapacity] = useState(initialData?.capacity?.toString() || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  console.log("RoomDialog rendered with open =", open);

  // Reset form when dialog opens with new data
  useEffect(() => {
    if (open) {
      console.log("RoomDialog opened, initializing with data:", initialData);
      setName(initialData?.name || '');
      setCapacity(initialData?.capacity?.toString() || '');
      setIsSubmitting(false);
    }
  }, [open, initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted with name:", name, "and capacity:", capacity);
    
    if (!name.trim()) {
      toast({
        title: "Errore",
        description: "Il nome della sala è obbligatorio",
        variant: "destructive"
      });
      return;
    }

    if (!capacity || parseInt(capacity) <= 0) {
      toast({
        title: "Errore",
        description: "La capacità deve essere un numero maggiore di zero",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      await onSave({ 
        name: name.trim(), 
        capacity: parseInt(capacity) 
      });
      
      toast({
        title: "Operazione completata",
        description: initialData ? "Sala aggiornata con successo" : "Sala aggiunta con successo",
      });
      
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving room:', error);
      setIsSubmitting(false);
      toast({
        title: "Errore",
        description: "Si è verificato un errore. Riprova più tardi.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(newOpen) => {
      console.log("Dialog onOpenChange called with:", newOpen);
      if (!isSubmitting) {
        onOpenChange(newOpen);
      }
    }}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nome Sala</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Sala Principale"
                autoFocus
                disabled={isSubmitting}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="capacity">Capacità (n° persone)</Label>
              <Input
                id="capacity"
                type="number"
                value={capacity}
                onChange={(e) => setCapacity(e.target.value)}
                placeholder="50"
                min="1"
                disabled={isSubmitting}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvataggio...
                </>
              ) : initialData ? 'Aggiorna' : 'Salva'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default RoomDialog;
