
import React, { useState, useEffect } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PlusCircleIcon, Loader2 } from 'lucide-react';
import StatusLegend from './StatusLegend';
import ExpandableRoomView from './rooms/ExpandableRoomView';
import * as roomsService from '@/services/roomsService';
import './animations.css'; // Import animations

// Types
export type TableStatus = 'available' | 'occupied' | 'reserved' | 'cleaning' | 'maintenance' | 'waiting';
export type TableShape = 'round' | 'square' | 'rectangle';

export interface Table {
  id: string;
  name: string;
  status: TableStatus;
  seats: number;
  shape: TableShape;
  reservationId?: string;
  orderId?: string;
  assignedTo?: string;
}

export interface Room {
  id: string;
  name: string;
  capacity: number;
  tables: Table[];
}

interface RoomGridProps {
  onEditRoom: (room: Room) => void;
  onDeleteRoom: (room: Room) => void;
  onAddTable: () => void;
  onSelectRoom: (room: Room | null) => void;
  onEditTable: (table: Table) => void;
  onDeleteTable: (table: Table) => void;
  selectedRoomId?: string;
  lastUpdate: Date;
  locationId?: string;
}

const RoomGrid: React.FC<RoomGridProps> = ({
  onEditRoom,
  onDeleteRoom,
  onAddTable,
  onSelectRoom,
  onEditTable,
  onDeleteTable,
  selectedRoomId,
  lastUpdate,
  locationId
}) => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);

  // Load rooms on component mount and when lastUpdate changes
  useEffect(() => {
    console.log("RoomGrid: Loading rooms with lastUpdate:", lastUpdate);
    loadRooms();
    
    // Set up sync listener
    const cleanupListener = roomsService.setupRoomsSyncListeners((syncedLocationId) => {
      console.log("RoomGrid: Sync event triggered for location:", syncedLocationId);
      if (!syncedLocationId || syncedLocationId === locationId) {
        loadRooms();
      }
    });
    
    return () => {
      cleanupListener();
    };
  }, [lastUpdate, locationId]);

  // Load rooms from service
  const loadRooms = async () => {
    setLoading(true);
    try {
      console.log("RoomGrid: Fetching rooms from service for location:", locationId);
      const data = await roomsService.fetchRooms(locationId);
      console.log("RoomGrid: Loaded rooms:", data);
      
      // Add debugging to check table data and normalize if needed
      if (data && data.length > 0) {
        const normalizedData = data.map(room => {
          // Ensure tables is always an array
          if (!Array.isArray(room.tables)) {
            console.warn(`Room ${room.name} (${room.id}) does not have a valid tables array, creating one`);
            room.tables = [];
          }
          
          console.log(`Room ${room.name} has ${room.tables.length} tables:`, room.tables);
          return room;
        });
        
        setRooms(normalizedData);
      } else {
        setRooms([]);
      }
      
      // If selectedRoomId is set, try to select that room
      if (selectedRoomId) {
        const room = data.find(r => r.id === selectedRoomId);
        if (room) {
          console.log("RoomGrid: Selected room:", room);
          setSelectedRoom(room);
        } else {
          setSelectedRoom(null);
        }
      }
    } catch (error) {
      console.error('Error loading rooms:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle room selection
  const handleRoomClick = (room: Room) => {
    const isSelected = selectedRoom?.id === room.id;
    
    // If already selected, deselect
    if (isSelected) {
      console.log("RoomGrid: Deselecting room:", room.id);
      setSelectedRoom(null);
      onSelectRoom(null);
    } else {
      console.log("RoomGrid: Selecting room:", room.id);
      setSelectedRoom(room);
      onSelectRoom(room);
    }
  };

  const handleTableStatusChange = async (tableId: string, newStatus: TableStatus) => {
    console.log("RoomGrid: Changing table status:", tableId, newStatus);
    try {
      await roomsService.updateTableStatus(tableId, newStatus, locationId);
      // Refresh rooms after status change
      loadRooms();
    } catch (error) {
      console.error("Error updating table status:", error);
    }
  };

  // Function to handle add room button click in empty state
  const handleAddRoomClick = () => {
    console.log("RoomGrid: Add room button clicked in empty state");
    onSelectRoom(null); // Pass null to indicate we want to add a new room
  };

  return (
    <div className="space-y-6">
      <div className="bg-card border rounded-lg p-4 shadow-md backdrop-blur-sm bg-opacity-90">
        <StatusLegend items={[
          { color: "bg-gradient-to-r from-green-400 to-green-500 text-white border-green-200", label: "Libero", emoji: "🟢", status: "available" },
          { color: "bg-gradient-to-r from-red-400 to-red-500 text-white border-red-200", label: "Occupato", emoji: "🔴", status: "occupied" },
          { color: "bg-gradient-to-r from-blue-400 to-blue-500 text-white border-blue-200", label: "Prenotato", emoji: "🔵", status: "reserved" },
          { color: "bg-gradient-to-r from-yellow-400 to-yellow-500 text-white border-yellow-200", label: "In attesa", emoji: "🟡", status: "waiting" },
          { color: "bg-gradient-to-r from-gray-400 to-gray-500 text-white border-gray-200", label: "Manutenzione", emoji: "⚠️", status: "maintenance" }
        ]} />
      </div>
      
      <div className="space-y-4 animate-fade-in">
        {loading ? (
          <div className="w-full bg-card/80 backdrop-blur-sm border border-primary/20 rounded-lg p-8 text-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Caricamento sale...</p>
          </div>
        ) : rooms.length === 0 ? (
          <div className="w-full bg-gradient-to-br from-primary/5 to-secondary/5 backdrop-blur-sm border border-primary/20 rounded-lg p-8 text-center shadow-lg">
            <div className="max-w-md mx-auto">
              <h3 className="text-xl font-medium mb-2 text-gradient-primary">Nessuna sala disponibile</h3>
              <p className="text-muted-foreground mb-6">
                Non ci sono sale configurate. Aggiungi una sala per iniziare.
              </p>
              <button 
                onClick={handleAddRoomClick}
                className="inline-flex items-center justify-center px-4 py-2 rounded-md bg-gradient-to-r from-primary to-primary/80 text-primary-foreground hover:from-primary/90 hover:to-primary/70 transition-all duration-300 shadow-md hover:shadow-lg"
              >
                <PlusCircleIcon className="h-5 w-5 mr-2" />
                Aggiungi sala
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {rooms.map(room => (
              <ExpandableRoomView
                key={room.id}
                room={room}
                isSelected={selectedRoom?.id === room.id}
                onRoomSelect={handleRoomClick}
                onEditRoom={onEditRoom}
                onDeleteRoom={onDeleteRoom}
                onAddTable={onAddTable}
                onEditTable={onEditTable}
                onDeleteTable={onDeleteTable}
                onTableStatusChange={handleTableStatusChange}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default RoomGrid;
