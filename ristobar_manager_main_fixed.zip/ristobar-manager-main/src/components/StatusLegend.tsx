
import { Card, CardContent } from "@/components/ui/card";
import { useState } from "react";
import { Table } from "./RoomGrid";
import { motion } from "framer-motion";

export interface StatusLegendItem {
  color: string;
  label: string;
  emoji: string;
  status?: Table['status'];
}

export interface StatusLegendProps {
  items: StatusLegendItem[];
  onStatusFilter?: (status: Table['status']) => void;
  activeFilters?: Record<string, boolean>;
}

export function StatusLegend({ items, onStatusFilter, activeFilters }: StatusLegendProps) {
  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <h3 className="text-sm font-medium mb-2">Legenda Colori</h3>
        <div className="flex flex-wrap gap-2">
          {items.map((item, index) => (
            <motion.div 
              key={index} 
              className={`flex items-center p-2 rounded-md ${item.color} ${item.status && onStatusFilter ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''} ${item.status && activeFilters && !activeFilters[item.status] ? 'opacity-50' : ''}`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                if (item.status && onStatusFilter) {
                  onStatusFilter(item.status);
                }
              }}
            >
              <span className="mr-1">{item.emoji}</span>
              <span className="text-xs font-medium">{item.label}</span>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default StatusLegend;
