
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { validateCardForm } from '@/utils/cardValidation';
import CardNameField from '@/components/checkout/CardNameField';
import CardNumberField from '@/components/checkout/CardNumberField';
import CardExpiryField from '@/components/checkout/CardExpiryField';
import CardCvcField from '@/components/checkout/CardCvcField';

interface StripeCheckoutFormProps {
  onSubmit: () => void;
  isLoading: boolean;
}

const StripeCheckoutForm = ({ onSubmit, isLoading }: StripeCheckoutFormProps) => {
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateCardForm(cardName, cardNumber, expiry, cvc)) {
      onSubmit();
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <CardNameField 
        value={cardName}
        onChange={setCardName}
        isLoading={isLoading}
      />
      
      <CardNumberField
        value={cardNumber}
        onChange={setCardNumber}
        isLoading={isLoading}
      />
      
      <div className="grid grid-cols-2 gap-4">
        <CardExpiryField
          value={expiry}
          onChange={setExpiry}
          isLoading={isLoading}
        />
        
        <CardCvcField
          value={cvc}
          onChange={setCvc}
          isLoading={isLoading}
        />
      </div>
      
      <Button 
        type="submit" 
        className="w-full mt-4"
        disabled={isLoading}
      >
        {isLoading ? "Elaborazione..." : "Completa Pagamento"}
      </Button>
    </form>
  );
};

export default StripeCheckoutForm;
