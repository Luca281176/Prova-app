
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from '@/hooks/use-toast';
import { Table } from './RoomGrid';
import { Loader2 } from 'lucide-react';

export interface TableEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (tableData: Partial<Table>) => Promise<void> | void;
  initialData: Table;
  title: string;
}

export function TableEditDialog({ 
  open, 
  onOpenChange, 
  onSave, 
  initialData, 
  title
}: TableEditDialogProps) {
  const [name, setName] = useState(initialData?.name || '');
  const [seats, setSeats] = useState(initialData?.seats?.toString() || '4');
  const [shape, setShape] = useState<Table['shape']>(initialData?.shape || 'round');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when dialog opens with new data
  useEffect(() => {
    if (open && initialData) {
      setName(initialData.name || '');
      setSeats(initialData.seats?.toString() || '4');
      setShape(initialData.shape || 'round');
      setIsSubmitting(false);
    }
  }, [open, initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Errore",
        description: "Il nome del tavolo è obbligatorio",
        variant: "destructive"
      });
      return;
    }

    if (!seats || parseInt(seats) <= 0) {
      toast({
        title: "Errore",
        description: "Il numero di posti deve essere maggiore di zero",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const tableData: Partial<Table> = {
        name: name.trim(),
        seats: parseInt(seats),
        shape
      };
      
      await onSave(tableData);
      
      toast({
        title: "Operazione completata",
        description: "Tavolo aggiornato con successo",
      });
      
      onOpenChange(false);
    } catch (error) {
      console.error('Error saving table:', error);
      setIsSubmitting(false);
      toast({
        title: "Errore",
        description: "Si è verificato un errore. Riprova più tardi.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(newOpen) => {
      if (!isSubmitting) {
        onOpenChange(newOpen);
      }
    }}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nome Tavolo</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Tavolo 1"
                autoFocus
                disabled={isSubmitting}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="seats">Numero Posti</Label>
              <Input
                id="seats"
                type="number"
                value={seats}
                onChange={(e) => setSeats(e.target.value)}
                placeholder="4"
                min="1"
                disabled={isSubmitting}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="shape">Forma Tavolo</Label>
              <Select 
                value={shape} 
                onValueChange={(value) => setShape(value as Table['shape'])}
                disabled={isSubmitting}
              >
                <SelectTrigger id="shape">
                  <SelectValue placeholder="Seleziona forma" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="round">Rotondo ⭕</SelectItem>
                  <SelectItem value="square">Quadrato 🟥</SelectItem>
                  <SelectItem value="rectangle">Rettangolare 🟩</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvataggio...
                </>
              ) : 'Aggiorna'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default TableEditDialog;
