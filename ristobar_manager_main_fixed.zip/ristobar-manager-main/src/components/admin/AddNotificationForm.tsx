
import { useState } from 'react';
import { useNotifications } from '@/contexts/notification/NotificationContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { PlusCircle } from 'lucide-react';

export default function AddNotificationForm({ triggerButton = true }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState<'user' | 'payment' | 'system' | 'alert'>('system');
  const { addNotification } = useNotifications();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !message) return;
    
    await addNotification({
      title,
      message,
      type
    });
    
    // Reset form
    setTitle('');
    setMessage('');
    setType('system');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {triggerButton ? (
        <DialogTrigger asChild>
          <Button className="gap-1">
            <PlusCircle className="h-4 w-4" />
            Nuova Notifica
          </Button>
        </DialogTrigger>
      ) : null}
      
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Aggiungi Notifica</DialogTitle>
          <DialogDescription>
            Crea una nuova notifica di sistema. Questa apparirà nel pannello delle notifiche.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="notification-type">Tipo</Label>
            <Select 
              value={type} 
              onValueChange={(value) => setType(value as any)}
            >
              <SelectTrigger id="notification-type">
                <SelectValue placeholder="Seleziona un tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">Utente</SelectItem>
                <SelectItem value="payment">Pagamento</SelectItem>
                <SelectItem value="system">Sistema</SelectItem>
                <SelectItem value="alert">Avviso</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notification-title">Titolo</Label>
            <Input
              id="notification-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Titolo della notifica"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notification-message">Messaggio</Label>
            <Textarea
              id="notification-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Messaggio della notifica"
              required
              rows={3}
            />
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annulla
            </Button>
            <Button type="submit">Aggiungi</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
