
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { Download, CreditCard, AlertCircle } from "lucide-react";

const PaymentsTable = () => {
  // Format the date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd MMMM yyyy', { locale: it });
  };

  return (
    <div className="rounded-md border">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-muted/50">
              <th className="p-3 text-left font-medium">ID Transazione</th>
              <th className="p-3 text-left font-medium">Utente</th>
              <th className="p-3 text-left font-medium">Piano</th>
              <th className="p-3 text-left font-medium">Importo</th>
              <th className="p-3 text-left font-medium">Data</th>
              <th className="p-3 text-left font-medium">Metodo</th>
              <th className="p-3 text-left font-medium">Fattura</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={7} className="p-8 text-center">
                <div className="flex flex-col items-center justify-center text-muted-foreground">
                  <AlertCircle className="h-8 w-8 mb-2" />
                  <p>Nessuna transazione disponibile.</p>
                  <p className="text-sm">Le transazioni appariranno qui una volta effettuate.</p>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PaymentsTable;
