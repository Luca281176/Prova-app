
import React from 'react';
import PaymentsTable from './PaymentsTable';
import { Skeleton } from '@/components/ui/skeleton';

interface PaymentsTableWrapperProps {
  isLoading: boolean;
}

const PaymentsTableWrapper: React.FC<PaymentsTableWrapperProps> = ({ isLoading }) => {
  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }

  return <PaymentsTable />;
};

export default PaymentsTableWrapper;
