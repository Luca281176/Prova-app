
import { Button } from "@/components/ui/button";
import { Download, Mail } from "lucide-react";

const SubscriptionAdminHeader = () => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Gestione Abbonamenti</h1>
        <p className="text-muted-foreground">Amministra e monitora gli abbonamenti degli utenti</p>
      </div>
      <div className="flex gap-2">
        <Button variant="outline" size="sm">
          <Download className="mr-2 h-4 w-4" />
          Esporta CSV
        </Button>
        <Button variant="default" size="sm">
          <Mail className="mr-2 h-4 w-4" />
          Notifiche
        </Button>
      </div>
    </div>
  );
};

export default SubscriptionAdminHeader;
