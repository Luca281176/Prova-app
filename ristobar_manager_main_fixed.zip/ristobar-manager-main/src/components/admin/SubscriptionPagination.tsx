
import { Button } from "@/components/ui/button";

interface SubscriptionPaginationProps {
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
  onNextPage: () => void;
  onPrevPage: () => void;
}

const SubscriptionPagination = ({
  currentPage,
  totalItems,
  itemsPerPage,
  onNextPage,
  onPrevPage,
}: SubscriptionPaginationProps) => {
  return (
    <div className="flex items-center justify-between py-4">
      <div className="text-sm text-muted-foreground">
        Mostrando <b>{Math.min(itemsPerPage, totalItems - (currentPage - 1) * itemsPerPage)}</b> di <b>{totalItems}</b> abbonamenti
      </div>
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onPrevPage}
          disabled={currentPage <= 1}
        >
          Precedente
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={onNextPage}
          disabled={currentPage >= Math.ceil(totalItems / itemsPerPage)}
        >
          Successivo
        </Button>
      </div>
    </div>
  );
};

export default SubscriptionPagination;
