
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UserSubscription } from "@/services/subscriptions";
import { subscriptionPlans } from "@/services/subscriptions";
import { Check, Pause, X, ArrowUp, ArrowDown } from "lucide-react";

interface SubscriptionTableProps {
  subscriptions: UserSubscription[];
  isLoading: boolean;
  onActivate: (subscription: UserSubscription) => void;
  onSuspend: (subscription: UserSubscription) => void;
  onCancel: (subscription: UserSubscription) => void;
  onUpgrade: (subscription: UserSubscription) => void;
  onDowngrade: (subscription: UserSubscription) => void;
}

const SubscriptionTable = ({
  subscriptions,
  isLoading,
  onActivate,
  onSuspend,
  onCancel,
  onUpgrade,
  onDowngrade
}: SubscriptionTableProps) => {

  // Format the date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd MMMM yyyy', { locale: it });
  };

  // Get the name of the plan
  const getPlanName = (planId: string) => {
    const plan = subscriptionPlans.find(p => p.id === planId);
    return plan ? plan.name : planId;
  };

  // Get the badge for the subscription status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default">Attivo</Badge>;
      case 'past_due':
        return <Badge variant="secondary">In ritardo</Badge>;
      case 'canceled':
        return <Badge variant="outline">Cancellato</Badge>;
      case 'trialing':
        return <Badge variant="default" className="bg-blue-500">In prova</Badge>;
      default:
        return <Badge variant="destructive">Inattivo</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <p>Caricamento abbonamenti...</p>
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Nessun abbonamento trovato</p>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-muted/50">
              <th className="p-3 text-left font-medium">Utente</th>
              <th className="p-3 text-left font-medium">Ristorante</th>
              <th className="p-3 text-left font-medium">Piano</th>
              <th className="p-3 text-left font-medium">Stato</th>
              <th className="p-3 text-left font-medium">Data di Scadenza</th>
              <th className="p-3 text-left font-medium">Azioni</th>
            </tr>
          </thead>
          <tbody>
            {subscriptions.map((subscription) => (
              <tr key={subscription.id} className="border-b hover:bg-muted/50">
                <td className="p-3">
                  <div className="font-medium">{subscription.userId}</div>
                </td>
                <td className="p-3">
                  <div>{subscription.restaurantId || 'N/A'}</div>
                </td>
                <td className="p-3">
                  <div>{getPlanName(subscription.planId)}</div>
                </td>
                <td className="p-3">
                  <div>{getStatusBadge(subscription.status)}</div>
                </td>
                <td className="p-3">
                  <div>{formatDate(subscription.currentPeriodEnd)}</div>
                </td>
                <td className="p-3">
                  <div className="flex gap-2">
                    {subscription.status !== 'active' && (
                      <Button variant="outline" size="sm" onClick={() => onActivate(subscription)} title="Attiva">
                        <Check className="h-4 w-4 text-green-500" />
                      </Button>
                    )}
                    {subscription.status === 'active' && (
                      <Button variant="outline" size="sm" onClick={() => onSuspend(subscription)} title="Sospendi">
                        <Pause className="h-4 w-4 text-yellow-500" />
                      </Button>
                    )}
                    {!subscription.cancelAtPeriodEnd && (
                      <Button variant="outline" size="sm" onClick={() => onCancel(subscription)} title="Cancella">
                        <X className="h-4 w-4 text-red-500" />
                      </Button>
                    )}
                    <Button variant="outline" size="sm" onClick={() => onUpgrade(subscription)} title="Upgrade" disabled={subscription.planId === 'enterprise'}>
                      <ArrowUp className="h-4 w-4 text-blue-500" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => onDowngrade(subscription)} title="Downgrade" disabled={subscription.planId === 'basic'}>
                      <ArrowDown className="h-4 w-4 text-orange-500" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SubscriptionTable;
