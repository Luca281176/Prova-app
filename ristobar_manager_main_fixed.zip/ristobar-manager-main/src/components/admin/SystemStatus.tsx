
import React, { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, XCircle, AlertTriangle, DatabaseIcon, Activity, RefreshCw } from 'lucide-react';
import { backupModule } from '@/integrations/supabase/clientModules/backup';
import { toast } from 'sonner';

type BackupRecord = {
  id: string;
  created_at: string;
  status: string;
  backup_location: string | null;
  backup_size: number | null;
  error_message: string | null;
};

type ErrorLog = {
  id: string;
  service: string;
  error_message: string;
  error_details: string | null;
  timestamp: string;
};

type FailedTransaction = {
  id: string;
  original_transaction_id: string;
  error_message: string;
  created_at: string;
  retry_count: number;
};

export function SystemStatus() {
  const [pendingTransactions, setPendingTransactions] = useState<number>(0);
  const [failedTransactions, setFailedTransactions] = useState<FailedTransaction[]>([]);
  const [lastBackup, setLastBackup] = useState<BackupRecord | null>(null);
  const [backupHistory, setBackupHistory] = useState<BackupRecord[]>([]);
  const [supabaseStatus, setSupabaseStatus] = useState<'online' | 'offline' | 'checking'>('checking');
  const [errorLogs, setErrorLogs] = useState<ErrorLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isBackupLoading, setIsBackupLoading] = useState(false);
  const [isSyncLoading, setIsSyncLoading] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch pending transactions
      const { data: pendingData, error: pendingError } = await supabase
        .from('transactions')
        .select('id')
        .eq('synced', false);
      
      if (pendingError) {
        console.error('Error fetching pending transactions:', pendingError);
        toast.error('Failed to fetch pending transactions');
      } else {
        setPendingTransactions(pendingData?.length || 0);
      }

      // Fetch failed transactions
      const { data: failedData, error: failedError } = await supabase
        .from('failed_transactions')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (failedError) {
        console.error('Error fetching failed transactions:', failedError);
        toast.error('Failed to fetch failed transactions');
      } else {
        setFailedTransactions(failedData || []);
      }

      // Fetch backup history
      const { data: backupsData, error: backupsError } = await supabase
        .from('backups')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (backupsError) {
        console.error('Error fetching backup history:', backupsError);
        toast.error('Failed to fetch backup history');
      } else {
        setBackupHistory(backupsData || []);
        setLastBackup(backupsData && backupsData.length > 0 ? backupsData[0] : null);
      }

      // Fetch error logs
      const { data: errorsData, error: errorsError } = await supabase
        .from('error_logs')
        .select('*')
        .order('timestamp', { ascending: false })
        .limit(10);
      
      if (errorsError) {
        console.error('Error fetching error logs:', errorsError);
        toast.error('Failed to fetch error logs');
      } else {
        setErrorLogs(errorsData || []);
      }

      // Check if Supabase is online
      const { error: supabaseError } = await supabase.auth.getSession();
      setSupabaseStatus(supabaseError ? 'offline' : 'online');

    } catch (error) {
      console.error('Error fetching system status data:', error);
      toast.error('Failed to load system status data');
      setSupabaseStatus('offline');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleManualBackup = async () => {
    setIsBackupLoading(true);
    try {
      const success = await backupModule.performBackup();
      if (success) {
        toast.success('Manual backup completed successfully');
        fetchData(); // Refresh data
      } else {
        toast.error('Manual backup failed');
      }
    } catch (error) {
      console.error('Error performing manual backup:', error);
      toast.error('Failed to perform manual backup');
    } finally {
      setIsBackupLoading(false);
    }
  };

  const handleSyncTransactions = async () => {
    setIsSyncLoading(true);
    try {
      // This is a placeholder - you would implement the actual sync logic
      const { error } = await supabase.functions.invoke('sync-transactions');
      
      if (error) {
        toast.error('Failed to sync transactions');
        console.error('Error syncing transactions:', error);
      } else {
        toast.success('Transactions synced successfully');
        fetchData(); // Refresh data
      }
    } catch (error) {
      console.error('Error syncing transactions:', error);
      toast.error('Failed to sync transactions');
    } finally {
      setIsSyncLoading(false);
    }
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    }).format(date);
  };

  const StatusIndicator = ({ status }: { status: 'online' | 'offline' | 'checking' }) => {
    if (status === 'checking') {
      return <span className="flex items-center"><RefreshCw className="h-4 w-4 animate-spin mr-1" /> Verifica in corso...</span>;
    }
    return (
      <span className={`flex items-center ${status === 'online' ? 'text-green-600' : 'text-red-600'}`}>
        {status === 'online' ? <CheckCircle className="h-4 w-4 mr-1" /> : <XCircle className="h-4 w-4 mr-1" />}
        {status === 'online' ? 'Online' : 'Offline'}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard di Stato del Sistema</h1>
        <Button 
          variant="outline" 
          onClick={fetchData} 
          disabled={isLoading}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          Aggiorna
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Supabase Status */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Stato Supabase</CardTitle>
            <CardDescription>Connessione al database</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <DatabaseIcon className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm font-medium">Supabase</p>
                  <StatusIndicator status={supabaseStatus} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transactions Stats */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Stato Transazioni</CardTitle>
            <CardDescription>Panoramica delle transazioni</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">Transazioni in attesa:</span>
                <span className="font-semibold">{pendingTransactions}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Transazioni fallite:</span>
                <span className="font-semibold">{failedTransactions.length}</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleSyncTransactions} 
              disabled={isSyncLoading}
              className="w-full"
            >
              {isSyncLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Sincronizzazione...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Sincronizza Transazioni
                </>
              )}
            </Button>
          </CardFooter>
        </Card>

        {/* Backup Status */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Stato Backup</CardTitle>
            <CardDescription>Ultimo backup del database</CardDescription>
          </CardHeader>
          <CardContent>
            {lastBackup ? (
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Data:</span>
                  <span className="font-semibold">{formatDateTime(lastBackup.created_at)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Stato:</span>
                  <span className={`font-semibold ${lastBackup.status === 'completed' ? 'text-green-600' : 'text-red-600'}`}>
                    {lastBackup.status === 'completed' ? 'Completato' : 'Fallito'}
                  </span>
                </div>
                {lastBackup.backup_size && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Dimensione:</span>
                    <span className="font-semibold">{(lastBackup.backup_size / 1024).toFixed(2)} KB</span>
                  </div>
                )}
                {lastBackup.error_message && (
                  <div className="mt-2">
                    <span className="text-sm text-red-600">Errore: {lastBackup.error_message}</span>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">Nessun backup registrato</p>
            )}
          </CardContent>
          <CardFooter>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleManualBackup} 
              disabled={isBackupLoading}
              className="w-full"
            >
              {isBackupLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Backup in corso...
                </>
              ) : (
                <>
                  <Activity className="h-4 w-4 mr-2" />
                  Esegui Backup Manuale
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="failed-transactions">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="failed-transactions">Transazioni Fallite</TabsTrigger>
          <TabsTrigger value="backup-history">Storico Backup</TabsTrigger>
        </TabsList>
        
        <TabsContent value="failed-transactions" className="p-0 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Transazioni Fallite</CardTitle>
              <CardDescription>Elenco delle ultime transazioni fallite</CardDescription>
            </CardHeader>
            <CardContent>
              {failedTransactions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Errore</TableHead>
                      <TableHead>Tentativi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {failedTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">{transaction.id.slice(0, 8)}...</TableCell>
                        <TableCell>{formatDateTime(transaction.created_at)}</TableCell>
                        <TableCell className="max-w-[200px] truncate" title={transaction.error_message}>
                          {transaction.error_message}
                        </TableCell>
                        <TableCell>{transaction.retry_count}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground text-center py-4">Nessuna transazione fallita</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="backup-history" className="p-0 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Storico Backup</CardTitle>
              <CardDescription>Elenco degli ultimi backup eseguiti</CardDescription>
            </CardHeader>
            <CardContent>
              {backupHistory.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Stato</TableHead>
                      <TableHead>Dimensione</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backupHistory.map((backup) => (
                      <TableRow key={backup.id}>
                        <TableCell className="font-medium">{backup.id.slice(0, 8)}...</TableCell>
                        <TableCell>{formatDateTime(backup.created_at)}</TableCell>
                        <TableCell>
                          <span className={backup.status === 'completed' ? 'text-green-600' : 'text-red-600'}>
                            {backup.status === 'completed' ? 'Completato' : 'Fallito'}
                          </span>
                        </TableCell>
                        <TableCell>
                          {backup.backup_size ? `${(backup.backup_size / 1024).toFixed(2)} KB` : 'N/A'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground text-center py-4">Nessun backup registrato</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {errorLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Errori di Sistema Recenti
            </CardTitle>
            <CardDescription>Ultimi errori registrati nel sistema</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Servizio</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Messaggio</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {errorLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium">{log.service}</TableCell>
                    <TableCell>{formatDateTime(log.timestamp)}</TableCell>
                    <TableCell className="max-w-[300px] truncate" title={log.error_message}>
                      {log.error_message}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
