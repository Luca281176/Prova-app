
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Users, CreditCard, DollarSign, ChevronsUpDown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface DashboardStatsProps {
  isLoading: boolean;
  stats: {
    totalUsers: number;
    totalRevenue: number;
    activeSubscriptions: number;
    userGrowth: number;
    activePlans: {
      starter: number;
      pro: number;
      ultimate: number;
    };
  } | null;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

const DashboardStats: React.FC<DashboardStatsProps> = ({ isLoading, stats }) => {
  const subscriptionDataForChart = [
    { name: 'Starter', value: stats?.activePlans.starter || 0 },
    { name: 'Pro', value: stats?.activePlans.pro || 0 },
    { name: 'Ultimate', value: stats?.activePlans.ultimate || 0 }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Utenti Totali</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-24" />
          ) : (
            <>
              <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.userGrowth && stats.userGrowth > 0 ? (
                  <>+{stats.userGrowth}% rispetto al mese scorso</>
                ) : (
                  <>Dati stabili</>
                )}
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Abbonamenti Attivi</CardTitle>
          <CreditCard className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-24" />
          ) : (
            <>
              <div className="text-2xl font-bold">{stats?.activeSubscriptions || 0}</div>
              <p className="text-xs text-muted-foreground">
                {((stats?.totalUsers || 0) > 0) 
                  ? `${Math.round(((stats?.activeSubscriptions || 0) / (stats?.totalUsers || 1)) * 100)}% degli utenti`
                  : 'Nessun utente registrato'}
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ricavi Totali</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-8 w-24" />
          ) : (
            <>
              <div className="text-2xl font-bold">€{stats?.totalRevenue || 0}</div>
              <p className="text-xs text-muted-foreground">
                Inclusi tutti gli abbonamenti attivi
              </p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Abbonamenti Attivi</CardTitle>
          <ChevronsUpDown className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent className="flex justify-between items-center">
          {isLoading ? (
            <Skeleton className="h-16 w-full" />
          ) : (
            <>
              <div className="grid gap-1">
                <div className="text-sm flex items-center gap-2">
                  <Badge className="bg-[#0088FE]" variant="secondary">S</Badge>
                  <span>Starter: {stats?.activePlans.starter || 0}</span>
                </div>
                <div className="text-sm flex items-center gap-2">
                  <Badge className="bg-[#00C49F]" variant="secondary">P</Badge>
                  <span>Pro: {stats?.activePlans.pro || 0}</span>
                </div>
                <div className="text-sm flex items-center gap-2">
                  <Badge className="bg-[#FFBB28]" variant="secondary">U</Badge>
                  <span>Ultimate: {stats?.activePlans.ultimate || 0}</span>
                </div>
              </div>
              
              <div className="h-16 w-16">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={subscriptionDataForChart}
                      cx="50%"
                      cy="50%"
                      innerRadius={15}
                      outerRadius={30}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {subscriptionDataForChart.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DashboardStats;
