
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertTriangle, Clock, Check } from 'lucide-react';

interface ExpiringSubscriptionsProps {
  isLoading: boolean;
}

const ExpiringSubscriptions: React.FC<ExpiringSubscriptionsProps> = ({ isLoading }) => {
  return (
    <Card className="col-span-1">
      <CardHeader>
        <CardTitle>Abbonamenti in Scadenza</CardTitle>
        <CardDescription>Prossimi 7 giorni</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="mb-4">
              <Skeleton className="h-16 w-full" />
            </div>
          ))
        ) : (
          <div className="space-y-4">
            <Alert>
              <Clock className="h-4 w-4" />
              <AlertTitle>Nessun abbonamento in scadenza</AlertTitle>
              <AlertDescription>
                Tutti gli abbonamenti sono attivi o già rinnovati.
              </AlertDescription>
            </Alert>
            
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Abbonamento scaduto</AlertTitle>
              <AlertDescription className="flex flex-col gap-2">
                <div className="flex justify-between">
                  <span>Marco Rossi</span>
                  <span>2 giorni fa</span>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  <Check className="mr-2 h-4 w-4" /> Contattato
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ExpiringSubscriptions;
