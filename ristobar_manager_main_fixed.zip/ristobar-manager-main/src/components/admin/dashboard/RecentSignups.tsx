
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';
import { it } from 'date-fns/locale';

interface RecentSignup {
  id: string;
  name: string;
  email: string;
  date: string;
  plan: string;
}

interface RecentSignupsProps {
  isLoading: boolean;
  recentSignups: RecentSignup[] | undefined;
}

const RecentSignups: React.FC<RecentSignupsProps> = ({ isLoading, recentSignups }) => {
  const getInitials = (name: string) => {
    if (!name) return '??';
    const parts = name.split(' ');
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const getPlanBadgeVariant = (plan: string) => {
    switch (plan?.toLowerCase()) {
      case 'pro':
        return 'default';
      case 'ultimate':
        return 'destructive';
      case 'starter':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle>Iscrizioni Recenti</CardTitle>
        <CardDescription>Ultimi 4 utenti registrati</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          Array(4).fill(0).map((_, i) => (
            <div key={i} className="flex items-center mb-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="ml-4 space-y-1">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-24" />
              </div>
            </div>
          ))
        ) : recentSignups && recentSignups.length > 0 ? (
          <div className="space-y-4">
            {recentSignups.map((signup) => (
              <div key={signup.id} className="flex items-center">
                <Avatar>
                  <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(signup.name || 'User')}`} alt={signup.name || 'User'} />
                  <AvatarFallback>{getInitials(signup.name || 'User')}</AvatarFallback>
                </Avatar>
                <div className="ml-4 space-y-1">
                  <p className="text-sm font-medium leading-none">{signup.name || 'Utente senza nome'}</p>
                  <p className="text-sm text-muted-foreground overflow-hidden text-ellipsis max-w-[200px]">
                    {signup.email || 'Email non disponibile'}
                  </p>
                </div>
                <div className="ml-auto flex flex-col items-end">
                  <Badge variant={getPlanBadgeVariant(signup.plan)}>
                    {signup.plan || 'Trial'}
                  </Badge>
                  <span className="text-xs text-muted-foreground mt-1">
                    {signup.date ? formatDistanceToNow(new Date(signup.date), { addSuffix: true, locale: it }) : 'Data non disponibile'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-muted-foreground">Nessuna iscrizione recente</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentSignups;
