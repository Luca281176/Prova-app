
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import PaymentsTableWrapper from '../PaymentsTableWrapper';

interface RecentTransactionsProps {
  isLoading: boolean;
}

const RecentTransactions: React.FC<RecentTransactionsProps> = ({ isLoading }) => {
  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="space-y-0">
        <CardTitle>Transazioni Recenti</CardTitle>
        <CardDescription>Le ultime 5 transazioni nel sistema</CardDescription>
      </CardHeader>
      <CardContent>
        <PaymentsTableWrapper isLoading={isLoading} />
      </CardContent>
    </Card>
  );
};

export default RecentTransactions;
