
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import SubscriptionFilters from '../SubscriptionFilters';
import SubscriptionTable from '../SubscriptionTable';
import SubscriptionPagination from '../SubscriptionPagination';
import { UserSubscription } from '@/services/subscriptions';

interface SubscriptionsTabProps {
  isLoading: boolean;
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  statusFilter: string;
  setStatusFilter: (value: string) => void;
  planFilter: string;
  setPlanFilter: (value: string) => void;
  subscriptions: UserSubscription[];
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
  onNextPage: () => void;
  onPrevPage: () => void;
  onActivate: (subscription: UserSubscription) => void;
  onSuspend: (subscription: UserSubscription) => void;
  onCancel: (subscription: UserSubscription) => void;
  onUpgrade: (subscription: UserSubscription) => void;
  onDowngrade: (subscription: UserSubscription) => void;
}

const SubscriptionsTab: React.FC<SubscriptionsTabProps> = ({
  isLoading,
  searchTerm,
  setSearchTerm,
  statusFilter,
  setStatusFilter,
  planFilter,
  setPlanFilter,
  subscriptions,
  currentPage,
  totalItems,
  itemsPerPage,
  onNextPage,
  onPrevPage,
  onActivate,
  onSuspend,
  onCancel,
  onUpgrade,
  onDowngrade
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Gestione Abbonamenti</CardTitle>
        <CardDescription>
          Monitora e gestisci gli abbonamenti degli utenti.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <SubscriptionFilters 
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          planFilter={planFilter}
          setPlanFilter={setPlanFilter}
        />
        <SubscriptionTable 
          subscriptions={subscriptions}
          isLoading={isLoading}
          onActivate={onActivate}
          onSuspend={onSuspend}
          onCancel={onCancel}
          onUpgrade={onUpgrade}
          onDowngrade={onDowngrade}
        />
        <SubscriptionPagination 
          currentPage={currentPage}
          totalItems={totalItems}
          itemsPerPage={itemsPerPage}
          onNextPage={onNextPage}
          onPrevPage={onPrevPage}
        />
      </CardContent>
    </Card>
  );
};

export default SubscriptionsTab;
