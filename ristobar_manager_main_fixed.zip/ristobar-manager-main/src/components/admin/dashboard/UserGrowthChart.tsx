
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';

interface UserGrowthChartProps {
  isLoading: boolean;
}

const UserGrowthChart: React.FC<UserGrowthChartProps> = ({ isLoading }) => {
  // This would ideally be passed as a prop from the parent component
  const chartData = [
    { name: 'Gen', total: 120 },
    { name: 'Feb', total: 180 },
    { name: 'Mar', total: 240 },
    { name: 'Apr', total: 280 },
    { name: 'Mag', total: 300 },
    { name: 'Giu', total: 400 },
  ];

  return (
    <Card className="col-span-4">
      <CardHeader>
        <CardTitle>Nuovi Utenti</CardTitle>
        <CardDescription>Conversione e crescita degli utenti</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        {isLoading ? (
          <Skeleton className="h-[200px] w-full" />
        ) : (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart
              data={chartData}
              margin={{ top: 0, right: 5, left: 0, bottom: 5 }}
            >
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-2 border rounded shadow">
                        <p className="font-medium">{`${payload[0].payload.name}`}</p>
                        <p>{`Nuovi utenti: ${payload[0].value}`}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="total" fill="#8884d8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default UserGrowthChart;
