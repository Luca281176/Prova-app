
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { UserMinus, UserPlus, Split, DivideCircle, Wallet } from 'lucide-react';
import { OrderItem } from '@/services/ordersService';

interface BillSplitterProps {
  total: number;
  orderItems?: OrderItem[];
  onFullPaymentToggle?: (isFullPayment: boolean) => void;
  isFullPayment?: boolean;
  onCustomSplitsChange?: (splits: { id: number; amount: number }[]) => void;
}

const BillSplitter = ({ 
  total, 
  orderItems = [], 
  onFullPaymentToggle = () => {}, 
  isFullPayment = false,
  onCustomSplitsChange = () => {}
}: BillSplitterProps) => {
  const [splits, setSplits] = useState(2);
  const [splitType, setSplitType] = useState<'equal' | 'custom'>('equal');
  const [customSplits, setCustomSplits] = useState<{ id: number; amount: number }[]>([
    { id: 1, amount: total / 2 },
    { id: 2, amount: total / 2 }
  ]);

  useEffect(() => {
    // When total changes, update the split amounts
    if (splitType === 'equal') {
      const evenAmount = total / splits;
      setCustomSplits(Array.from({ length: splits }, (_, i) => ({
        id: i + 1,
        amount: evenAmount
      })));
    }
  }, [total, splits, splitType]);

  useEffect(() => {
    // Notify parent component when custom splits change
    onCustomSplitsChange(customSplits);
  }, [customSplits, onCustomSplitsChange]);

  const handleSplitsChange = (newSplits: number) => {
    if (newSplits < 2) return;
    if (newSplits > 10) return;
    
    setSplits(newSplits);
    
    if (splitType === 'equal') {
      const evenAmount = total / newSplits;
      setCustomSplits(Array.from({ length: newSplits }, (_, i) => ({
        id: i + 1,
        amount: evenAmount
      })));
    } else {
      // Adjust custom splits if needed
      if (newSplits > customSplits.length) {
        // Add more splits
        const newCustomSplits = [...customSplits];
        for (let i = customSplits.length; i < newSplits; i++) {
          newCustomSplits.push({ id: i + 1, amount: 0 });
        }
        setCustomSplits(newCustomSplits);
      } else {
        // Remove splits
        setCustomSplits(customSplits.slice(0, newSplits));
      }
    }
  };

  const handleCustomAmountChange = (id: number, amount: number) => {
    setCustomSplits(customSplits.map(split => 
      split.id === id ? { ...split, amount } : split
    ));
  };

  const resetToEqualSplit = () => {
    const evenAmount = total / splits;
    setCustomSplits(Array.from({ length: splits }, (_, i) => ({
      id: i + 1,
      amount: evenAmount
    })));
  };

  const totalCustomAmount = customSplits.reduce((sum, split) => sum + split.amount, 0);
  const remainingAmount = Number((total - totalCustomAmount).toFixed(2));

  const handleFullPaymentToggle = () => {
    onFullPaymentToggle(!isFullPayment);
  };

  if (isFullPayment) {
    return (
      <Card className="mt-4 border-dashed">
        <CardContent className="pt-4">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium">Pagamento completo</h4>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleFullPaymentToggle}
            >
              <Split className="h-4 w-4 mr-1" />
              Dividi conto
            </Button>
          </div>
          <Separator className="my-2" />
          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground mb-2">Importo totale da pagare:</p>
            <p className="text-xl font-bold">€{total.toFixed(2)}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mt-4 border-dashed">
      <CardContent className="pt-4">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium">Divisione Conto</h4>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleFullPaymentToggle}
          >
            <Wallet className="h-4 w-4 mr-1" />
            Pagamento completo
          </Button>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleSplitsChange(splits - 1)}
              disabled={splits <= 2}
            >
              <UserMinus className="h-4 w-4" />
            </Button>
            <span className="mx-2">{splits} persone</span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleSplitsChange(splits + 1)}
              disabled={splits >= 10}
            >
              <UserPlus className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant={splitType === 'equal' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setSplitType('equal')}
            >
              <DivideCircle className="h-4 w-4 mr-1" />
              Equo
            </Button>
            <Button 
              variant={splitType === 'custom' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setSplitType('custom')}
            >
              <Split className="h-4 w-4 mr-1" />
              Custom
            </Button>
          </div>
        </div>
        
        <Separator className="my-2" />
        
        {splitType === 'equal' ? (
          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground mb-2">Ogni persona paga:</p>
            <p className="text-xl font-bold">€{(total / splits).toFixed(2)}</p>
          </div>
        ) : (
          <div className="mt-4 space-y-2">
            {customSplits.map((split) => (
              <div key={split.id} className="flex items-center gap-2">
                <Label className="w-24">Persona {split.id}</Label>
                <Input 
                  type="number"
                  min="0"
                  step="0.01"
                  value={split.amount}
                  onChange={(e) => handleCustomAmountChange(split.id, Number(e.target.value))}
                  className="flex-1"
                />
                <div className="text-sm w-20 text-right">
                  €{split.amount.toFixed(2)}
                </div>
              </div>
            ))}
            
            <div className="flex justify-between mt-2 text-sm">
              <span>Totale assegnato:</span>
              <span className={remainingAmount !== 0 ? 'text-red-500' : 'text-green-500'}>
                €{totalCustomAmount.toFixed(2)}
              </span>
            </div>
            
            {remainingAmount !== 0 && (
              <div className="flex justify-between text-sm text-red-500">
                <span>Importo rimanente:</span>
                <span>€{remainingAmount}</span>
              </div>
            )}
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={resetToEqualSplit}
              className="mt-2 w-full"
            >
              <DivideCircle className="h-4 w-4 mr-2" />
              Reset parti uguali
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BillSplitter;
