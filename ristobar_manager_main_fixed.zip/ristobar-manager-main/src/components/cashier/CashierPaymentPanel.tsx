
import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ShoppingCart, CreditCard, Check, Percent, HandCoins, Printer, FileText, Receipt, FileCheck } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import OrderSummary from './OrderSummary';
import PaymentMethodSelector from './PaymentMethodSelector';
import BillSplitter from './BillSplitter';
import PrintableBill from './PrintableBill';
import CustomerDataDialog from './CustomerDataDialog';
import { Order, getCashierOrders, removeOrderFromCashier, updateOrderStatus } from '@/services/ordersService';
import { updateTableStatus } from '@/services/roomsService';
import { createTransactionFromOrder } from '@/services/transactionService';
import { toast } from '@/hooks/use-toast';
import { loadCashierSettings } from '@/services/settingsService';
import { getRestaurantInfoSync } from './bill/RestaurantInfoProvider';

interface CustomerData {
  name: string;
  vatId: string;
  address: string;
  email?: string;
}

export default function CashierPaymentPanel() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>('cash');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [isFullPayment, setIsFullPayment] = useState<boolean>(true);
  const [discount, setDiscount] = useState<number>(0);
  const [tip, setTip] = useState<number>(0);
  const [receiptType, setReceiptType] = useState<'fiscal' | 'invoice'>('fiscal');
  const [customerDataDialogOpen, setCustomerDataDialogOpen] = useState<boolean>(false);
  const [customerData, setCustomerData] = useState<CustomerData | null>(null);
  const [customSplits, setCustomSplits] = useState<{ id: number; amount: number }[]>([]);
  const printBillRef = useRef<HTMLDivElement>(null);
  
  const calculateAdjustedTotal = (): number => {
    if (!selectedOrder) return 0;
    return selectedOrder.total - discount + tip;
  };
  
  const loadCashierOrders = async () => {
    try {
      const cashierOrders = await getCashierOrders();
      setOrders(cashierOrders);
      
      if (cashierOrders.length > 0 && !selectedOrder) {
        setSelectedOrder(cashierOrders[0]);
      }
    } catch (error) {
      console.error('Error loading cashier orders:', error);
      toast({
        title: "Errore",
        description: "Impossibile caricare gli ordini da pagare",
        variant: "destructive"
      });
    }
  };
  
  useEffect(() => {
    loadCashierOrders();
    
    const handleCashierQueueUpdated = () => {
      loadCashierOrders();
    };
    
    window.addEventListener('cashier-queue-updated', handleCashierQueueUpdated);
    window.addEventListener('order-completed', handleCashierQueueUpdated);
    
    return () => {
      window.removeEventListener('cashier-queue-updated', handleCashierQueueUpdated);
      window.removeEventListener('order-completed', handleCashierQueueUpdated);
    };
  }, []);
  
  const handleOrderSelect = (order: Order) => {
    setSelectedOrder(order);
    setDiscount(0);
    setTip(0);
    setCustomerData(null);
  };
  
  const handleProcessPayment = async () => {
    if (!selectedOrder) return;
    
    if (receiptType === 'invoice' && !customerData) {
      setCustomerDataDialogOpen(true);
      return;
    }
    
    try {
      setIsProcessingPayment(true);
      
      // Step 1: Update table status to available
      const tableId = selectedOrder.tableId;
      const locationId = selectedOrder.locationId;
      
      // Update table status to available - this is now separated from the try/catch
      // to ensure it always runs and any errors are properly logged but don't stop payment
      console.log(`Attempting to update table ${tableId} status to available`);
      
      try {
        if (tableId) {
          await updateTableStatus(tableId, 'available', locationId);
          console.log(`Table ${tableId} status successfully updated to available`);
          
          // Dispatch a rooms-updated event to force refresh the UI
          window.dispatchEvent(new CustomEvent('rooms-updated', {
            detail: { 
              locationId: locationId,
              tableId: tableId,
              forceUpdate: true
            }
          }));
        }
      } catch (updateError) {
        console.warn(`Could not update table status, but will continue with payment processing: ${updateError instanceof Error ? updateError.message : 'Unknown error'}`);
      }
      
      // Step 2: Update order status
      await updateOrderStatus(selectedOrder.id, 'paid');
      
      // Step 3: Remove from cashier queue
      await removeOrderFromCashier(selectedOrder.id);
      
      // Step 4: Create the transaction record
      const transaction = await createTransactionFromOrder(
        selectedOrder, 
        paymentMethod as any, 
        undefined,
        undefined,
        { 
          discount, 
          tip, 
          customerData: receiptType === 'invoice' ? customerData : undefined,
          splitPayments: !isFullPayment ? customSplits : undefined,
          isSplitPayment: !isFullPayment
        }
      );
      
      console.log('Transaction created:', transaction);
      
      // Step 5: Print receipt
      handlePrintReceipt();
      
      // Step 6: Dispatch event and show success message
      window.dispatchEvent(new CustomEvent('transaction-created'));
      console.log('Dispatched transaction-created event');
      
      toast({
        title: "Pagamento completato",
        description: `Ordine #${selectedOrder.id.substring(0, 6)} pagato con successo`,
      });
      
      // Step 7: Update local state
      const newOrders = orders.filter(order => order.id !== selectedOrder.id);
      setOrders(newOrders);
      setSelectedOrder(newOrders.length > 0 ? newOrders[0] : null);
      setDiscount(0);
      setTip(0);
      setCustomerData(null);
      
    } catch (error) {
      console.error('Error processing payment:', error);
      toast({
        title: "Errore",
        description: "Impossibile processare il pagamento: " + (error instanceof Error ? error.message : "Errore sconosciuto"),
        variant: "destructive"
      });
    } finally {
      setIsProcessingPayment(false);
    }
  };
  
  const handleDiscountChange = (value: string) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) {
      setDiscount(0);
    } else {
      setDiscount(Math.min(numValue, selectedOrder?.total || 0));
    }
  };
  
  const handleTipChange = (value: string) => {
    const numValue = parseFloat(value);
    setTip(isNaN(numValue) ? 0 : numValue);
  };
  
  const handlePrintBill = async () => {
    if (!selectedOrder) return;
    
    try {
      const tableId = selectedOrder.tableId;
      if (tableId) {
        await updateTableStatus(tableId, 'available');
      }
      
      toast({
        title: "Preparazione stampa",
        description: `Preparazione del preconto per l'ordine #${selectedOrder.id.substring(0, 6)}`,
      });
      
      const printFrame = document.createElement('iframe');
      printFrame.style.position = 'fixed';
      printFrame.style.right = '0';
      printFrame.style.bottom = '0';
      printFrame.style.width = '0';
      printFrame.style.height = '0';
      printFrame.style.border = '0';
      document.body.appendChild(printFrame);
      
      const frameDoc = printFrame.contentDocument || printFrame.contentWindow?.document;
      if (!frameDoc) return;
      
      const cashierSettings = loadCashierSettings();
      // Get restaurant info from provider using sync version
      const restaurantInfo = getRestaurantInfoSync();
      const footerText = cashierSettings?.receiptFooter || "Grazie per averci scelto!";
      
      // Add split payment information section if needed
      const splitPaymentsSection = !isFullPayment && customSplits.length > 0 
        ? `
        <div class="split-payments-section">
          <div class="split-payments-title">Pagamento Diviso:</div>
          ${customSplits.map(split => `
            <div class="summary-row split-payment-row">
              <span>Parte ${split.id}:</span>
              <span>€${split.amount.toFixed(2)}</span>
            </div>
          `).join('')}
        </div>
        ` 
        : '';
      
      frameDoc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Preconto</title>
            <style>
              body {
                font-family: 'Courier New', monospace;
                width: 80mm;
                margin: 0 auto;
                padding: 5mm;
              }
              
              .restaurant-name {
                font-size: 16pt;
                font-weight: bold;
                text-align: center;
                margin: 0;
              }
              
              .logo-container {
                text-align: center;
                margin-bottom: 5pt;
              }
              
              .restaurant-logo {
                max-width: 60mm;
                max-height: 20mm;
                margin: 0 auto;
              }
              
              .restaurant-info {
                text-align: center;
                font-size: 10pt;
                margin-bottom: 5pt;
              }
              
              .restaurant-info p {
                margin: 2pt 0;
              }
              
              .bill-title {
                font-size: 14pt;
                font-weight: bold;
                text-align: center;
                margin: 0 0 10pt 0;
              }
              
              .header {
                margin-bottom: 10pt;
              }
              
              .divider {
                border-top: 1px dashed #000;
                margin: 10pt 0;
              }
              
              .info-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5pt;
              }
              
              .item-row {
                margin-bottom: 5pt;
              }
              
              .item-details {
                display: flex;
                justify-content: space-between;
              }
              
              .item-notes {
                font-style: italic;
                font-size: 10pt;
                margin-left: 10pt;
              }
              
              .summary-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5pt;
              }
              
              .total-row {
                display: flex;
                justify-content: space-between;
                font-weight: bold;
                font-size: 14pt;
                margin: 10pt 0;
              }
              
              .footer {
                text-align: center;
                margin-top: 15pt;
                font-size: 10pt;
              }
              
              .split-payments-section {
                margin: 5pt 0;
                border-top: 1px dashed #000;
                padding-top: 5pt;
              }
              
              .split-payments-title {
                font-weight: bold;
                margin-bottom: 3pt;
                text-decoration: underline;
              }
              
              .split-payment-row {
                padding-left: 5pt;
                font-size: 11pt;
              }
              
              ${receiptType === 'invoice' ? `
              .invoice-details {
                border: 1px solid #000;
                padding: 10pt;
                margin: 10pt 0;
              }
              ` : ''}
            </style>
          </head>
          <body>
            <div class="bill-content">
              <div class="header">
                ${(cashierSettings?.printLogo && restaurantInfo.logo) ? `
                  <div class="logo-container">
                    <img src="${restaurantInfo.logo}" alt="Logo Ristorante" class="restaurant-logo" />
                  </div>
                ` : ''}
                <h2 class="restaurant-name">${restaurantInfo.name}</h2>
                <div class="restaurant-info">
                  <p>${restaurantInfo.address}</p>
                  <p>${restaurantInfo.phone}</p>
                  <p>${restaurantInfo.vat}</p>
                </div>
                <h3 class="bill-title">PRECONTO</h3>
              </div>
              
              <div class="info-row">
                <span>Data:</span>
                <span>${format(new Date(selectedOrder.timestamp), 'dd/MM/yyyy', { locale: it })}</span>
              </div>
              <div class="info-row">
                <span>Ora:</span>
                <span>${format(new Date(selectedOrder.timestamp), 'HH:mm', { locale: it })}</span>
              </div>
              <div class="info-row">
                <span>Tavolo:</span>
                <span>${selectedOrder.tableName}</span>
              </div>
              <div class="info-row">
                <span>Operatore:</span>
                <span>${selectedOrder.operatorName}</span>
              </div>
              <div class="info-row">
                <span>Comanda:</span>
                <span>#${selectedOrder.id.substring(0, 6)}</span>
              </div>
              
              <div class="divider"></div>
              
              ${selectedOrder.items.map((item) => `
                <div class="item-row">
                  <div class="item-details">
                    <span>${item.quantity}x ${item.name}</span>
                    <span>€${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                  ${item.notes ? `<div class="item-notes">→ ${item.notes}</div>` : ''}
                </div>
              `).join('')}
              
              <div class="divider"></div>
              
              ${discount > 0 ? `
                <div class="summary-row">
                  <span>Sconto:</span>
                  <span>-€${discount.toFixed(2)}</span>
                </div>
              ` : ''}
              
              ${tip > 0 ? `
                <div class="summary-row">
                  <span>Mancia:</span>
                  <span>+€${tip.toFixed(2)}</span>
                </div>
              ` : ''}
              
              ${splitPaymentsSection}
              
              <div class="total-row">
                <span>Totale:</span>
                <span>€${calculateAdjustedTotal().toFixed(2)}</span>
              </div>
              
              <div class="footer">
                <p>${footerText}</p>
              </div>
            </div>
          </body>
        </html>
      `);
      frameDoc.close();
      
      printFrame.onload = () => {
        try {
          printFrame.contentWindow?.print();
          
          setTimeout(() => {
            document.body.removeChild(printFrame);
          }, 500);
        } catch (error) {
          console.error('Error during print operation:', error);
          document.body.removeChild(printFrame);
        }
      };
    } catch (error) {
      console.error('Error preparing bill for print:', error);
      toast({
        title: "Errore",
        description: "Impossibile stampare il preconto",
        variant: "destructive"
      });
    }
  };
  
  const handlePrintReceipt = async () => {
    if (!selectedOrder) return;
    
    try {
      toast({
        title: receiptType === 'fiscal' ? "Stampa scontrino fiscale" : "Stampa fattura",
        description: `Preparazione stampa per l'ordine #${selectedOrder.id.substring(0, 6)}`,
      });
      
      const printFrame = document.createElement('iframe');
      printFrame.style.position = 'fixed';
      printFrame.style.right = '0';
      printFrame.style.bottom = '0';
      printFrame.style.width = '0';
      printFrame.style.height = '0';
      printFrame.style.border = '0';
      document.body.appendChild(printFrame);
      
      const frameDoc = printFrame.contentDocument || printFrame.contentWindow?.document;
      if (!frameDoc) return;
      
      const title = receiptType === 'fiscal' ? 'SCONTRINO FISCALE' : 'FATTURA';
      const receiptNumber = `${Date.now().toString().substring(8)}-${selectedOrder.id.substring(0, 4)}`;
      
      const cashierSettings = loadCashierSettings();
      // Get restaurant info from provider using sync version
      const restaurantInfo = getRestaurantInfoSync();
      const footerText = cashierSettings?.receiptFooter || "Grazie per averci scelto!";
      
      // Add split payment information section if needed
      const splitPaymentsSection = !isFullPayment && customSplits.length > 0 
        ? `
        <div class="split-payments-section">
          <div class="split-payments-title">Pagamento Diviso:</div>
          ${customSplits.map(split => `
            <div class="summary-row split-payment-row">
              <span>Parte ${split.id}:</span>
              <span>€${split.amount.toFixed(2)}</span>
            </div>
          `).join('')}
        </div>
        ` 
        : '';
      
      frameDoc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>${title}</title>
            <style>
              body {
                font-family: 'Courier New', monospace;
                width: 80mm;
                margin: 0 auto;
                padding: 5mm;
              }
              
              .restaurant-name {
                font-size: 16pt;
                font-weight: bold;
                text-align: center;
                margin: 0;
              }
              
              .logo-container {
                text-align: center;
                margin-bottom: 5pt;
              }
              
              .restaurant-logo {
                max-width: 60mm;
                max-height: 20mm;
                margin: 0 auto;
              }
              
              .restaurant-info {
                text-align: center;
                font-size: 10pt;
                margin-bottom: 5pt;
              }
              
              .receipt-title {
                font-size: 14pt;
                font-weight: bold;
                text-align: center;
                margin: 0 0 10pt 0;
              }
              
              .header {
                margin-bottom: 10pt;
              }
              
              .divider {
                border-top: 1px dashed #000;
                margin: 10pt 0;
              }
              
              .info-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5pt;
              }
              
              .item-row {
                margin-bottom: 5pt;
              }
              
              .item-details {
                display: flex;
                justify-content: space-between;
              }
              
              .item-notes {
                font-style: italic;
                font-size: 10pt;
                margin-left: 10pt;
              }
              
              .summary-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 5pt;
              }
              
              .total-row {
                display: flex;
                justify-content: space-between;
                font-weight: bold;
                font-size: 14pt;
                margin: 10pt 0;
              }
              
              .footer {
                text-align: center;
                margin-top: 15pt;
                font-size: 10pt;
              }
              
              .split-payments-section {
                margin: 5pt 0;
                border-top: 1px dashed #000;
                padding-top: 5pt;
              }
              
              .split-payments-title {
                font-weight: bold;
                margin-bottom: 3pt;
                text-decoration: underline;
              }
              
              .split-payment-row {
                padding-left: 5pt;
                font-size: 11pt;
              }
              
              ${receiptType === 'invoice' ? `
              .invoice-details {
                border: 1px solid #000;
                padding: 10pt;
                margin: 10pt 0;
              }
              ` : ''}
            </style>
          </head>
          <body>
            <div class="receipt-content">
              <div class="header">
                ${(cashierSettings?.printLogo && restaurantInfo.logo) ? `
                  <div class="logo-container">
                    <img src="${restaurantInfo.logo}" alt="Logo Ristorante" class="restaurant-logo" />
                  </div>
                ` : ''}
                <h2 class="restaurant-name">${restaurantInfo.name}</h2>
                <div class="restaurant-info">
                  <p>${restaurantInfo.address}</p>
                  <p>${restaurantInfo.phone}</p>
                  <p>${restaurantInfo.vat}</p>
                </div>
                <h3 class="receipt-title">${title}</h3>
              </div>
              
              <div class="info-row">
                <span>Data:</span>
                <span>${format(new Date(), 'dd/MM/yyyy', { locale: it })}</span>
              </div>
              <div class="info-row">
                <span>Ora:</span>
                <span>${format(new Date(), 'HH:mm', { locale: it })}</span>
              </div>
              
              ${receiptType === 'fiscal' ? `
              <div class="info-row">
                <span>Numero scontrino:</span>
                <span>${receiptNumber}</span>
              </div>
              ` : `
              <div class="info-row">
                <span>Numero fattura:</span>
                <span>${receiptNumber}</span>
              </div>
              <div class="invoice-details">
                <p><strong>Cliente:</strong> ${customerData?.name || 'N/A'}</p>
                <p><strong>P.IVA / C.F.:</strong> ${customerData?.vatId || 'N/A'}</p>
                <p><strong>Indirizzo:</strong> ${customerData?.address || 'N/A'}</p>
                ${customerData?.email ? `<p><strong>Email:</strong> ${customerData.email}</p>` : ''}
              </div>
              `}
              
              <div class="info-row">
                <span>Tavolo:</span>
                <span>${selectedOrder.tableName}</span>
              </div>
              <div class="info-row">
                <span>Operatore:</span>
                <span>${selectedOrder.operatorName}</span>
              </div>
              <div class="info-row">
                <span>Comanda:</span>
                <span>#${selectedOrder.id.substring(0, 6)}</span>
              </div>
              
              <div class="divider"></div>
              
              ${selectedOrder.items.map((item) => `
                <div class="item-row">
                  <div class="item-details">
                    <span>${item.quantity}x ${item.name}</span>
                    <span>€${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                  ${item.notes ? `<div class="item-notes">→ ${item.notes}</div>` : ''}
                </div>
              `).join('')}
              
              <div class="divider"></div>
              
              ${discount > 0 ? `
                <div class="summary-row">
                  <span>Sconto:</span>
                  <span>-€${discount.toFixed(2)}</span>
                </div>
              ` : ''}
              
              ${tip > 0 ? `
                <div class="summary-row">
                  <span>Mancia:</span>
                  <span>+€${tip.toFixed(2)}</span>
                </div>
              ` : ''}
              
              ${splitPaymentsSection}
              
              <div class="total-row">
                <span>Totale:</span>
                <span>€${calculateAdjustedTotal().toFixed(2)}</span>
              </div>
              
              <div class="info-row">
                <span>Metodo di pagamento:</span>
                <span>${paymentMethod === 'cash' ? 'Contanti' : 
                       paymentMethod === 'card' ? 'Carta' : 
                       paymentMethod === 'digital' ? 'Pagamento digitale' : 
                       'Fattura'}</span>
              </div>
              
              <div class="divider"></div>
              
              <div class="footer">
                <p>${footerText}</p>
                ${receiptType === 'fiscal' ? '<p>SCONTRINO FISCALE</p>' : '<p>COPIA FATTURA</p>'}
              </div>
            </div>
          </body>
        </html>
      `);
      frameDoc.close();
      
      printFrame.onload = () => {
        try {
          printFrame.contentWindow?.print();
          
          setTimeout(() => {
            document.body.removeChild(printFrame);
          }, 500);
        } catch (error) {
          console.error('Error during print operation:', error);
          document.body.removeChild(printFrame);
        }
      };
    } catch (error) {
      console.error('Error preparing receipt for print:', error);
      toast({
        title: "Errore",
        description: "Impossibile stampare la ricevuta",
        variant: "destructive"
      });
    }
  };
  
  const handleCustomerDataSubmit = (data: CustomerData) => {
    setCustomerData(data);
    setCustomerDataDialogOpen(false);
    handleProcessPayment();
  };
  
  const handleCustomSplitsChange = (splits: { id: number; amount: number }[]) => {
    setCustomSplits(splits);
  };
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-4">
          <Card>
            <CardHeader>
              <CardTitle>Ordini da Pagare</CardTitle>
            </CardHeader>
            <CardContent>
              {orders.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Nessun ordine da pagare</p>
                </div>
              ) : (
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2">
                    {orders.map(order => (
                      <Button
                        key={order.id}
                        variant={selectedOrder?.id === order.id ? 'default' : 'outline'}
                        className="w-full justify-start h-auto py-3 px-4"
                        onClick={() => handleOrderSelect(order)}
                      >
                        <div className="flex flex-col items-start w-full">
                          <div className="flex justify-between w-full">
                            <span className="font-medium">#{order.id.substring(0, 6)}</span>
                            <Badge>{order.tableName}</Badge>
                          </div>
                          <div className="flex justify-between w-full mt-1 text-sm">
                            <span>{format(new Date(order.timestamp), 'dd/MM HH:mm', { locale: it })}</span>
                            <span className="font-semibold">€{order.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-8">
          {selectedOrder ? (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle>Riepilogo Ordine #{selectedOrder.id.substring(0, 6)}</CardTitle>
                <Button 
                  variant="default" 
                  size="sm" 
                  className="flex items-center gap-1 bg-indigo-500 hover:bg-indigo-600"
                  onClick={handlePrintBill}
                >
                  <FileText className="h-4 w-4" /> 
                  <Printer className="h-4 w-4" /> 
                  Stampa Preconto
                </Button>
              </CardHeader>
              <CardContent className="space-y-6">
                <OrderSummary order={selectedOrder} />
                
                <Separator />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="discount" className="flex items-center gap-1 font-medium">
                      <Percent className="h-4 w-4" /> Sconto
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2">€</span>
                      <Input
                        id="discount"
                        type="number"
                        min="0"
                        step="0.01"
                        max={selectedOrder.total}
                        value={discount}
                        onChange={(e) => handleDiscountChange(e.target.value)}
                        className="pl-8"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tip" className="flex items-center gap-1 font-medium">
                      <HandCoins className="h-4 w-4" /> Mancia
                    </Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2">€</span>
                      <Input
                        id="tip"
                        type="number"
                        min="0"
                        step="0.01"
                        value={tip}
                        onChange={(e) => handleTipChange(e.target.value)}
                        className="pl-8"
                      />
                    </div>
                  </div>
                </div>
                
                {discount > 0 || tip > 0 ? (
                  <div className="bg-muted rounded-md p-3 text-sm">
                    <div className="flex justify-between mb-1">
                      <span>Totale originale:</span>
                      <span>€{selectedOrder.total.toFixed(2)}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between mb-1 text-red-500">
                        <span>Sconto:</span>
                        <span>-€{discount.toFixed(2)}</span>
                      </div>
                    )}
                    {tip > 0 && (
                      <div className="flex justify-between mb-1 text-green-600">
                        <span>Mancia:</span>
                        <span>+€{tip.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-medium border-t border-border pt-1 mt-1">
                      <span>Importo finale:</span>
                      <span>€{calculateAdjustedTotal().toFixed(2)}</span>
                    </div>
                  </div>
                ) : null}
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Metodo di Pagamento</h3>
                  <PaymentMethodSelector 
                    selectedMethod={paymentMethod} 
                    onSelectMethod={setPaymentMethod} 
                  />
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Tipo di Ricevuta</h3>
                  <RadioGroup 
                    value={receiptType} 
                    onValueChange={(value) => setReceiptType(value as 'fiscal' | 'invoice')}
                    className="flex flex-col space-y-2"
                  >
                    <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-accent transition-colors duration-150">
                      <RadioGroupItem value="fiscal" id="receipt-fiscal" />
                      <Label htmlFor="receipt-fiscal" className="flex items-center cursor-pointer">
                        <Receipt className="h-5 w-5 mr-2 text-orange-500" />
                        Scontrino Fiscale
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-accent transition-colors duration-150">
                      <RadioGroupItem value="invoice" id="receipt-invoice" />
                      <Label htmlFor="receipt-invoice" className="flex items-center cursor-pointer">
                        <FileCheck className="h-5 w-5 mr-2 text-blue-500" />
                        Fattura
                      </Label>
                    </div>
                  </RadioGroup>
                  
                  {receiptType === 'invoice' && customerData && (
                    <div className="mt-3 bg-muted p-3 rounded-md text-sm">
                      <h4 className="font-semibold mb-1">Dati cliente per fatturazione:</h4>
                      <p><strong>Nome:</strong> {customerData.name}</p>
                      <p><strong>P.IVA/C.F.:</strong> {customerData.vatId}</p>
                      <p><strong>Indirizzo:</strong> {customerData.address}</p>
                      {customerData.email && <p><strong>Email:</strong> {customerData.email}</p>}
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="mt-1" 
                        onClick={() => setCustomerDataDialogOpen(true)}
                      >
                        Modifica
                      </Button>
                    </div>
                  )}
                </div>
                
                <Separator />
                
                <BillSplitter 
                  total={calculateAdjustedTotal()} 
                  orderItems={selectedOrder.items}
                  isFullPayment={isFullPayment}
                  onFullPaymentToggle={setIsFullPayment}
                  onCustomSplitsChange={handleCustomSplitsChange}
                />
                
                <div className="pt-4 flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="h-14 w-1/4 bg-indigo-500 hover:bg-indigo-600 text-white"
                    onClick={handlePrintBill}
                  >
                    <Printer className="mr-2 h-5 w-5" />
                    Preconto
                  </Button>
                  <Button 
                    className="w-3/4 h-14" 
                    size="lg"
                    onClick={handleProcessPayment}
                    disabled={isProcessingPayment}
                  >
                    <CreditCard className="mr-2 h-5 w-5" />
                    {isProcessingPayment ? 'Elaborazione...' : `Conferma Pagamento (€${calculateAdjustedTotal().toFixed(2)})`}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                <CreditCard className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nessun ordine selezionato</h3>
                <p className="text-muted-foreground">Seleziona un ordine dalla lista per procedere con il pagamento</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      <div className="hidden">
        {selectedOrder && (
          <div ref={printBillRef}>
            <PrintableBill 
              order={selectedOrder} 
              discount={discount} 
              tip={tip} 
              isInvoice={receiptType === 'invoice'}
              customerData={customerData || undefined}
              splitPayments={!isFullPayment ? customSplits : undefined}
              isSplitPayment={!isFullPayment}
            />
          </div>
        )}
      </div>

      <CustomerDataDialog
        open={customerDataDialogOpen}
        onOpenChange={setCustomerDataDialogOpen}
        onSubmit={handleCustomerDataSubmit}
        initialData={customerData || undefined}
      />
    </>
  );
}
