
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { CreditCard, Printer, Euro, Wallet, Receipt, Save, RotateCcw, CloudSun, LockIcon } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { saveCashierSettings, loadCashierSettings, type CashierSettings as CashierSettingsType } from '@/services/settingsService';
import { useUser } from '@/contexts/user/UserProvider';
import { getUserData, saveUserDataToStorage, syncSpecificDataToSupabase } from '@/contexts/user/storageUtils';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription, FeatureAccessLevel } from '@/services/subscriptions/types';
import { hasSubscriptionLevel } from '@/services/subscriptions';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';

const defaultSettings: CashierSettingsType = {
  enableCreditCard: true,
  enableDigitalPayments: true,
  enableInvoice: true,
  vatRate: 22,
  autoPrint: true,
  printLogo: true,
  receiptFooter: 'Grazie per averci scelto!'
};

const CashierSettings = () => {
  const [settings, setSettings] = useState<CashierSettingsType>(defaultSettings);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [isLoadingSubscription, setIsLoadingSubscription] = useState(true);
  const { user } = useUser();

  // Check if user has access to advanced settings (Pro+ plan)
  const hasAdvancedAccess = hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO);

  useEffect(() => {
    const fetchSubscription = async () => {
      if (user?.id) {
        try {
          const subscription = await getUserSubscription(user.id);
          setUserSubscription(subscription as unknown as UserSubscription);
        } catch (error) {
          console.error("Error fetching subscription:", error);
          setUserSubscription(null);
        }
      }
      setIsLoadingSubscription(false);
    };
    
    fetchSubscription();
  }, [user?.id]);

  useEffect(() => {
    const loadSettings = async () => {
      if (!user?.id) return;
      
      try {
        const userSettings = await getUserData(user.id, 'cashierSettings', null);
        
        if (userSettings) {
          setSettings(userSettings);
          toast({
            title: "Impostazioni caricate",
            description: "Le impostazioni salvate sono state caricate con successo",
          });
        } else {
          const savedSettings = loadCashierSettings(user.id);
          if (savedSettings) {
            setSettings(savedSettings);
            
            await saveUserDataToStorage(user.id, 'cashierSettings', savedSettings);
            
            toast({
              title: "Impostazioni caricate",
              description: "Le impostazioni salvate sono state caricate con successo",
            });
          }
        }
      } catch (error) {
        console.error("Error loading cashier settings:", error);
        toast({
          title: "Errore",
          description: "Impossibile caricare le impostazioni",
          variant: "destructive"
        });
      }
    };
    
    loadSettings();
  }, [user?.id]);
  
  const handleSaveSettings = async () => {
    if (!user?.id) {
      toast({
        title: "Errore",
        description: "Devi essere autenticato per salvare le impostazioni",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const saveSuccess = saveCashierSettings(settings, user.id);
      const saveSuccessNew = await saveUserDataToStorage(user.id, 'cashierSettings', settings);
      
      if (saveSuccess || saveSuccessNew) {
        const syncSuccess = await syncSpecificDataToSupabase(user.id, 'cashierSettings', settings);
        
        toast({
          title: "Impostazioni salvate",
          description: syncSuccess 
            ? "Le impostazioni sono state salvate e sincronizzate su tutti i dispositivi" 
            : "Le impostazioni del punto cassa sono state aggiornate",
        });
      } else {
        toast({
          title: "Errore di salvataggio",
          description: "Non è stato possibile salvare le impostazioni. Spazio di archiviazione insufficiente.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error saving cashier settings:", error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante il salvataggio",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetSettings = () => {
    setSettings(defaultSettings);
    toast({
      title: "Impostazioni reimpostate",
      description: "Le impostazioni sono state riportate ai valori predefiniti",
    });
  };

  const handleSettingChange = (key: keyof CashierSettingsType, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const handleForceSync = async () => {
    if (!user?.id) {
      toast({
        title: "Errore",
        description: "Devi essere autenticato per sincronizzare",
        variant: "destructive"
      });
      return;
    }
    
    setIsSyncing(true);
    
    try {
      const latestSettings = await getUserData(user.id, 'cashierSettings', null);
      
      if (latestSettings) {
        setSettings(latestSettings);
        toast({
          title: "Sincronizzazione completata",
          description: "Impostazioni sincronizzate da altri dispositivi",
        });
      } else {
        const syncSuccess = await syncSpecificDataToSupabase(user.id, 'cashierSettings', settings);
        
        if (syncSuccess) {
          toast({
            title: "Sincronizzazione completata",
            description: "Impostazioni sincronizzate su tutti i dispositivi",
          });
        } else {
          toast({
            title: "Errore di sincronizzazione",
            description: "Non è stato possibile sincronizzare le impostazioni",
            variant: "destructive"
          });
        }
      }
    } catch (error) {
      console.error("Error during force sync:", error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la sincronizzazione",
        variant: "destructive"
      });
    } finally {
      setIsSyncing(false);
    }
  };
  
  if (isLoadingSubscription) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="rounded-lg bg-muted p-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <CloudSun className="h-5 w-5 text-primary" />
          <p className="text-sm">Le impostazioni vengono automaticamente sincronizzate tra i tuoi dispositivi.</p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleForceSync}
          disabled={isSyncing}
        >
          {isSyncing ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Sincronizzazione...
            </>
          ) : "Forza sincronizzazione"}
        </Button>
      </div>

      {hasAdvancedAccess ? (
        <Card>
          <CardHeader>
            <CardTitle>Metodi di Pagamento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CreditCard className="h-4 w-4" />
                <Label htmlFor="enable-credit-card">Carta di Credito/Debito</Label>
              </div>
              <Switch 
                id="enable-credit-card" 
                checked={settings.enableCreditCard}
                onCheckedChange={(checked) => handleSettingChange('enableCreditCard', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Wallet className="h-4 w-4" />
                <Label htmlFor="enable-digital">Pagamenti Digitali (Apple Pay, Google Pay)</Label>
              </div>
              <Switch 
                id="enable-digital" 
                checked={settings.enableDigitalPayments}
                onCheckedChange={(checked) => handleSettingChange('enableDigitalPayments', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Receipt className="h-4 w-4" />
                <Label htmlFor="enable-invoice">Fatturazione Elettronica</Label>
              </div>
              <Switch 
                id="enable-invoice" 
                checked={settings.enableInvoice}
                onCheckedChange={(checked) => handleSettingChange('enableInvoice', checked)}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label htmlFor="vat-rate">Aliquota IVA (%)</Label>
              <Input
                id="vat-rate"
                type="number"
                min="0"
                max="30"
                value={settings.vatRate}
                onChange={(e) => handleSettingChange('vatRate', Number(e.target.value))}
              />
            </div>
          </CardContent>
        </Card>
      ) : (
        <PlanFeatureAlert
          title="Configurazione pagamenti avanzata non disponibile"
          description="La gestione dei metodi di pagamento avanzati è disponibile solo per gli abbonamenti Pro e Ultimate."
          availableInPlans={['Pro', 'Ultimate']}
          buttonText="Aggiorna il tuo piano"
          buttonLink="/subscriptions"
        />
      )}
      
      {hasAdvancedAccess ? (
        <Card>
          <CardHeader>
            <CardTitle>Impostazioni Ricevute</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Printer className="h-4 w-4" />
                <Label htmlFor="auto-print">Stampa automatica ricevuta</Label>
              </div>
              <Switch 
                id="auto-print" 
                checked={settings.autoPrint}
                onCheckedChange={(checked) => handleSettingChange('autoPrint', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Receipt className="h-4 w-4" />
                <Label htmlFor="print-logo">Includi logo su ricevuta</Label>
              </div>
              <Switch 
                id="print-logo" 
                checked={settings.printLogo}
                onCheckedChange={(checked) => handleSettingChange('printLogo', checked)}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label htmlFor="receipt-footer">Piè di pagina ricevuta</Label>
              <Input
                id="receipt-footer"
                placeholder="Grazie per la visita!"
                value={settings.receiptFooter || ''}
                onChange={(e) => handleSettingChange('receiptFooter', e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Testo che apparirà in fondo a ogni ricevuta
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <PlanFeatureAlert
          title="Personalizzazione ricevute non disponibile"
          description="Le opzioni avanzate per la personalizzazione delle ricevute sono disponibili solo per gli abbonamenti Pro e Ultimate."
          availableInPlans={['Pro', 'Ultimate']}
          buttonText="Aggiorna il tuo piano"
          buttonLink="/subscriptions"
        />
      )}
      
      <div className="flex justify-between">
        <Button variant="outline" onClick={handleResetSettings}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Ripristina predefiniti
        </Button>
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Salvataggio...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Salva impostazioni
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default CashierSettings;
