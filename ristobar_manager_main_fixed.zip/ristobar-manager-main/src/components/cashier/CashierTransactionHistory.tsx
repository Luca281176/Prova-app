
import { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { 
  Search, 
  Filter, 
  Calendar as CalendarIcon, 
  Download, 
  RefreshCcw,
  Percent,
  HandCoins
} from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { 
  Transaction, 
  getTransactions, 
  getTransactionsByDate 
} from '@/services/transactionService';
import { Card } from '@/components/ui/card';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const CashierTransactionHistory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dateFilter, setDateFilter] = useState(format(new Date(), 'yyyy-MM-dd'));

  // Load transactions
  const loadTransactions = async () => {
    try {
      setIsLoading(true);
      let fetchedTransactions: Transaction[];
      
      if (dateFilter) {
        console.log('Loading transactions with date filter:', dateFilter);
        fetchedTransactions = await getTransactionsByDate(dateFilter);
        console.log('Filtered transactions:', fetchedTransactions);
      } else {
        console.log('Loading all transactions');
        fetchedTransactions = await getTransactions();
        console.log('All transactions:', fetchedTransactions);
      }
      
      setTransactions(fetchedTransactions);
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Update date filter when calendar date changes
  const handleDateChange = (date: Date | undefined) => {
    setSelectedDate(date);
    if (date) {
      const formattedDate = format(date, 'yyyy-MM-dd');
      setDateFilter(formattedDate);
    }
  };

  // Initial load of transactions
  useEffect(() => {
    loadTransactions();
    
    // Add event listener for new transactions
    const handleTransactionCreated = () => {
      console.log('Transaction created event fired, reloading transactions');
      loadTransactions();
    };
    
    window.addEventListener('transaction-created', handleTransactionCreated);
    
    return () => {
      window.removeEventListener('transaction-created', handleTransactionCreated);
    };
  }, []);

  // Reload transactions when date filter changes
  useEffect(() => {
    loadTransactions();
  }, [dateFilter]);

  // Filter transactions based on search term
  const filteredTransactions = transactions.filter(tx => 
    tx.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get status badge
  const getStatusBadge = (status: Transaction['status']) => {
    switch (status) {
      case 'completed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Completato</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">In attesa</Badge>;
      case 'refunded':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rimborsato</Badge>;
      default:
        return <Badge variant="outline">Sconosciuto</Badge>;
    }
  };

  // Get payment method display text
  const getPaymentMethod = (method: Transaction['method']) => {
    switch (method) {
      case 'card': return 'Carta';
      case 'cash': return 'Contanti';
      case 'digital': return 'Pagamento digitale';
      case 'invoice': return 'Fattura';
      default: return 'Altro';
    }
  };

  const handleRefresh = () => {
    loadTransactions();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca transazioni..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="pl-3 pr-3">
                <CalendarIcon className="h-4 w-4 mr-2" />
                {selectedDate ? format(selectedDate, 'dd/MM/yyyy', { locale: it }) : 'Seleziona data'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateChange}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCcw className="h-4 w-4 mr-2" />
            Aggiorna
          </Button>
          
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Esporta
          </Button>
        </div>
      </div>

      {selectedDate && (
        <div className="text-sm text-muted-foreground">
          Transazioni del {format(selectedDate, 'dd MMMM yyyy', { locale: it })}
          {filteredTransactions.length > 0 && (
            <span className="ml-2 font-medium">
              ({filteredTransactions.length} {filteredTransactions.length === 1 ? 'transazione' : 'transazioni'})
            </span>
          )}
        </div>
      )}

      <div className="border rounded-md overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Ora</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Metodo</TableHead>
                <TableHead>Importo</TableHead>
                <TableHead>Sconto/Mancia</TableHead>
                <TableHead>Stato</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    Nessuna transazione trovata
                  </TableCell>
                </TableRow>
              ) : (
                filteredTransactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell className="font-medium">#{transaction.id.substring(0, 6)}</TableCell>
                    <TableCell>{transaction.time}</TableCell>
                    <TableCell>{transaction.customerName}</TableCell>
                    <TableCell>{getPaymentMethod(transaction.method)}</TableCell>
                    <TableCell className="font-medium">€{transaction.amount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {transaction.discount && transaction.discount > 0 && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="bg-red-50 text-red-500 border-red-200">
                                  <Percent className="h-3 w-3 mr-1" /> 
                                  {transaction.discount.toFixed(2)}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent>
                                Sconto applicato
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {transaction.tip && transaction.tip > 0 && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="bg-green-50 text-green-500 border-green-200">
                                  <HandCoins className="h-3 w-3 mr-1" /> 
                                  {transaction.tip.toFixed(2)}
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent>
                                Mancia ricevuta
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        )}
      </div>

      {filteredTransactions.length > 0 && (
        <Card className="p-4 bg-muted/50">
          <div className="flex justify-between items-center">
            <div>
              <span className="font-medium">Totale giornaliero:</span>
            </div>
            <div className="text-xl font-bold">
              €{filteredTransactions
                .filter(tx => tx.status === 'completed')
                .reduce((sum, tx) => sum + tx.amount, 0)
                .toFixed(2)}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

export default CashierTransactionHistory;
