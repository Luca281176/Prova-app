
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface CustomerData {
  name: string;
  vatId: string;
  address: string;
  email?: string;
}

interface CustomerDataDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: CustomerData) => void;
  initialData?: CustomerData;
}

const CustomerDataDialog: React.FC<CustomerDataDialogProps> = ({
  open,
  onOpenChange,
  onSubmit,
  initialData
}) => {
  const [customerData, setCustomerData] = useState<CustomerData>(
    initialData || {
      name: '',
      vatId: '',
      address: '',
      email: ''
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomerData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(customerData);
  };

  const isValid = customerData.name && customerData.vatId && customerData.address;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Dati Fatturazione Cliente</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nome/Ragione Sociale *</Label>
              <Input
                id="name"
                name="name"
                value={customerData.name}
                onChange={handleChange}
                placeholder="Nome completo o ragione sociale"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="vatId">P.IVA / Codice Fiscale *</Label>
              <Input
                id="vatId"
                name="vatId"
                value={customerData.vatId}
                onChange={handleChange}
                placeholder="Partita IVA o codice fiscale"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="address">Indirizzo *</Label>
              <Textarea
                id="address"
                name="address"
                value={customerData.address}
                onChange={handleChange}
                placeholder="Indirizzo completo"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={customerData.email}
                onChange={handleChange}
                placeholder="Email (opzionale)"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annulla
            </Button>
            <Button type="submit" disabled={!isValid}>
              Conferma
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerDataDialog;
