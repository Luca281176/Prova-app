
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Order } from '@/services/ordersService';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface OrderSummaryProps {
  order: Order;
}

export default function OrderSummary({ order }: OrderSummaryProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant="outline">{order.tableName}</Badge>
          <span className="text-sm text-muted-foreground">
            {format(new Date(order.timestamp), 'dd/MM/yyyy HH:mm', { locale: it })}
          </span>
        </div>
        <Badge variant="secondary">Operatore: {order.operatorName}</Badge>
      </div>
      
      <Separator />
      
      <div className="border rounded-md">
        <div className="grid grid-cols-[1fr_80px_80px] gap-2 font-medium p-3 border-b">
          <div>Prodotto</div>
          <div className="text-right">Qtà</div>
          <div className="text-right">Prezzo</div>
        </div>
        
        <div className="divide-y">
          {order.items.map((item, index) => (
            <div key={index} className="grid grid-cols-[1fr_80px_80px] gap-2 p-3">
              <div>{item.name}</div>
              <div className="text-right">{item.quantity}</div>
              <div className="text-right">€{(item.price * item.quantity).toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-between font-medium text-lg pt-2">
        <span>Totale</span>
        <span>€{order.total.toFixed(2)}</span>
      </div>
    </div>
  );
}
