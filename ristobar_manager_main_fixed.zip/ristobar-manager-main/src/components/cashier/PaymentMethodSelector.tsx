
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CreditCard, Banknote, Smartphone, Receipt } from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from '@/hooks/use-toast';

interface PaymentMethodSelectorProps {
  selectedMethod: string;
  onSelectMethod: (method: string) => void;
}

const PaymentMethodSelector = ({ selectedMethod, onSelectMethod }: PaymentMethodSelectorProps) => {
  const [isChanging, setIsChanging] = useState(false);
  
  const paymentMethods = [
    { id: 'cash', name: 'Contanti', icon: <Banknote className="h-4 w-4" />, color: 'bg-green-500 hover:bg-green-600' },
    { id: 'card', name: 'Carta', icon: <CreditCard className="h-4 w-4" />, color: 'bg-blue-500 hover:bg-blue-600' },
    { id: 'digital', name: 'Digitale', icon: <Smartphone className="h-4 w-4" />, color: 'bg-purple-500 hover:bg-purple-600' },
    { id: 'invoice', name: 'Fattura', icon: <Receipt className="h-4 w-4" />, color: 'bg-amber-500 hover:bg-amber-600' },
  ];

  const handleSelectMethod = (methodId: string) => {
    if (methodId === selectedMethod) return;
    
    setIsChanging(true);
    
    // Simulate a small delay for feedback
    setTimeout(() => {
      onSelectMethod(methodId);
      setIsChanging(false);
      
      const methodName = paymentMethods.find(m => m.id === methodId)?.name || methodId;
      toast({
        title: "Metodo di pagamento aggiornato",
        description: `Metodo di pagamento impostato su: ${methodName}`,
      });
      
      // Log for debugging
      console.log(`Payment method changed to: ${methodId}`);
    }, 300);
  };

  return (
    <div className="grid grid-cols-2 gap-2">
      {paymentMethods.map((method) => (
        <Button
          key={method.id}
          variant="outline"
          className={`flex-col h-20 py-2 transition-all duration-200 text-white ${
            selectedMethod === method.id ? 'ring-2 ring-primary ring-opacity-50' : ''
          } ${method.color} ${
            isChanging ? 'opacity-70 pointer-events-none' : ''
          }`}
          onClick={() => handleSelectMethod(method.id)}
          disabled={isChanging}
          data-selected={selectedMethod === method.id}
          aria-pressed={selectedMethod === method.id}
        >
          <div className="flex flex-col items-center justify-center">
            {method.icon}
            <span className="mt-1">{method.name}</span>
          </div>
        </Button>
      ))}
    </div>
  );
};

export default PaymentMethodSelector;
