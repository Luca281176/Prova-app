
import React from 'react';
import { Order } from '@/services/ordersService';
import { loadCashierSettings } from '@/services/settingsService';
import BillHeader from './bill/BillHeader';
import BillInfo from './bill/BillInfo';
import BillItems from './bill/BillItems';
import BillSummary from './bill/BillSummary';
import { getRestaurantInfoSync } from './bill/RestaurantInfoProvider';
import './bill/billStyles.css';

interface PrintableBillProps {
  order: Order;
  discount?: number;
  tip?: number;
  isInvoice?: boolean;
  customerData?: {
    name: string;
    vatId: string;
    address: string;
    email?: string;
  };
  splitPayments?: {
    id: number;
    amount: number;
  }[];
  isSplitPayment?: boolean;
}

const PrintableBill: React.FC<PrintableBillProps> = ({ 
  order, 
  discount = 0, 
  tip = 0, 
  isInvoice = false,
  customerData,
  splitPayments = [],
  isSplitPayment = false
}) => {
  const adjustedTotal = order.total - discount + tip;
  const cashierSettings = loadCashierSettings();
  const restaurantInfo = getRestaurantInfoSync();
  const footerText = cashierSettings?.receiptFooter || "Grazie per averci scelto!";
  const showLogo = !!cashierSettings?.printLogo && !!restaurantInfo.logo;
  
  return (
    <div className="print-container" id="printable-bill">
      <div className="bill-content">
        <BillHeader 
          restaurantName={restaurantInfo.name}
          restaurantAddress={restaurantInfo.address}
          restaurantPhone={restaurantInfo.phone}
          restaurantVAT={restaurantInfo.vat}
          showLogo={showLogo}
          logoUrl={restaurantInfo.logo}
          isInvoice={isInvoice}
        />
        
        {isInvoice && customerData && (
          <div className="customer-data">
            <h4>Dati Cliente:</h4>
            <p><strong>Nome:</strong> {customerData.name}</p>
            <p><strong>P.IVA/CF:</strong> {customerData.vatId}</p>
            <p><strong>Indirizzo:</strong> {customerData.address}</p>
            {customerData.email && <p><strong>Email:</strong> {customerData.email}</p>}
          </div>
        )}
        
        <BillInfo
          timestamp={order.timestamp}
          tableName={order.tableName}
          operatorName={order.operatorName}
          orderId={order.id}
        />
        
        <div className="divider"></div>
        
        <BillItems items={order.items} />
        
        <div className="divider"></div>
        
        <BillSummary
          discount={discount}
          tip={tip}
          total={adjustedTotal}
          footerText={footerText}
          isInvoice={isInvoice}
          splitPayments={splitPayments}
          isSplitPayment={isSplitPayment}
        />
      </div>
    </div>
  );
};

export default PrintableBill;
