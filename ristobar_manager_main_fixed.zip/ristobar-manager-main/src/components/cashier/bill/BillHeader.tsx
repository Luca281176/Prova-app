
import React from 'react';

interface BillHeaderProps {
  restaurantName: string;
  restaurantAddress: string;
  restaurantPhone: string;
  restaurantVAT: string;
  showLogo: boolean;
  logoUrl: string | null;
  isInvoice?: boolean;
}

const BillHeader: React.FC<BillHeaderProps> = ({
  restaurantName,
  restaurantAddress,
  restaurantPhone,
  restaurantVAT,
  showLogo,
  logoUrl,
  isInvoice = false
}) => {
  return (
    <div className="header">
      {showLogo && logoUrl && (
        <div className="logo-container">
          <img src={logoUrl} alt="Logo Ristorante" className="restaurant-logo" />
        </div>
      )}
      <h2 className="restaurant-name">{restaurantName}</h2>
      <div className="restaurant-info">
        <p>{restaurantAddress}</p>
        <p>{restaurantPhone}</p>
        <p>{restaurantVAT}</p>
      </div>
      <h3 className="bill-title">{isInvoice ? "FATTURA" : "PRECONTO"}</h3>
    </div>
  );
};

export default BillHeader;
