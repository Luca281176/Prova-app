
import React from 'react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface BillInfoProps {
  timestamp: string;
  tableName: string;
  operatorName: string;
  orderId: string;
}

const BillInfo: React.FC<BillInfoProps> = ({
  timestamp,
  tableName,
  operatorName,
  orderId
}) => {
  return (
    <>
      <div className="info-row">
        <span>Data:</span>
        <span>{format(new Date(timestamp), 'dd/MM/yyyy', { locale: it })}</span>
      </div>
      <div className="info-row">
        <span>Ora:</span>
        <span>{format(new Date(timestamp), 'HH:mm', { locale: it })}</span>
      </div>
      <div className="info-row">
        <span>Tavolo:</span>
        <span>{tableName}</span>
      </div>
      <div className="info-row">
        <span>Operatore:</span>
        <span>{operatorName}</span>
      </div>
      <div className="info-row">
        <span>Comanda:</span>
        <span>#{orderId.substring(0, 6)}</span>
      </div>
    </>
  );
};

export default BillInfo;
