
import React from 'react';

interface BillItem {
  name: string;
  quantity: number;
  price: number;
  notes?: string;
}

interface BillItemsProps {
  items: BillItem[];
}

const BillItems: React.FC<BillItemsProps> = ({ items }) => {
  return (
    <>
      {items.map((item, index) => (
        <div key={index} className="item-row">
          <div className="item-details">
            <span>{item.quantity}x {item.name}</span>
            <span>€{(item.price * item.quantity).toFixed(2)}</span>
          </div>
          {item.notes && (
            <div className="item-notes">→ {item.notes}</div>
          )}
        </div>
      ))}
    </>
  );
};

export default BillItems;
