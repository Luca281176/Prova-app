
import React from 'react';

interface BillSummaryProps {
  discount: number;
  tip: number;
  total: number;
  footerText: string;
  isInvoice?: boolean;
  splitPayments?: {
    id: number;
    amount: number;
  }[];
  isSplitPayment?: boolean;
}

const BillSummary: React.FC<BillSummaryProps> = ({ 
  discount, 
  tip, 
  total, 
  footerText, 
  isInvoice = false,
  splitPayments = [],
  isSplitPayment = false
}) => {
  return (
    <>
      {discount > 0 && (
        <div className="summary-row">
          <span>Sconto:</span>
          <span>-€{discount.toFixed(2)}</span>
        </div>
      )}
      
      {tip > 0 && (
        <div className="summary-row">
          <span>Mancia:</span>
          <span>+€{tip.toFixed(2)}</span>
        </div>
      )}
      
      {isSplitPayment && splitPayments.length > 0 && (
        <div className="split-payments-section">
          <div className="split-payments-title">Pagamento Diviso:</div>
          {splitPayments.map((split) => (
            <div key={split.id} className="summary-row split-payment-row">
              <span>Parte {split.id}:</span>
              <span>€{split.amount.toFixed(2)}</span>
            </div>
          ))}
        </div>
      )}
      
      <div className="total-row">
        <span>Totale:</span>
        <span>€{total.toFixed(2)}</span>
      </div>
      
      <div className="footer">
        <p>{footerText}</p>
        {isInvoice && <p className="tax-note">L'IVA è inclusa nel prezzo</p>}
      </div>
    </>
  );
};

export default BillSummary;
