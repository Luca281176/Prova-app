import React from 'react';
import { getUserData, saveUserDataToStorage } from '@/contexts/user/storageUtils';
import { deleteRestaurantLogo as deleteLogoFromSettings, loadRestaurantInfo as loadSettingsRestaurantInfo } from '@/services/settingsService';
import { toast } from 'sonner';
import { useTenant } from '@/contexts/tenant/TenantContext';

export interface RestaurantInfo {
  name: string;
  address: string;
  phone: string;
  vat: string;
  logo: string | null;
  email?: string;
  website?: string;
  description?: string;
  openingHours?: string;
}

// Default restaurant info to use as fallback
const DEFAULT_RESTAURANT_INFO: RestaurantInfo = {
  name: "Ristorante Esempio",
  address: "Via Roma 123, 00100 Roma",
  phone: "+39 06 1234567",
  vat: "P.IVA: IT12345678901",
  logo: null,
  email: "",
  website: "",
  description: "",
  openingHours: ""
};

// Sync version of getRestaurantInfo for components that can't use async/await
export const getRestaurantInfoSync = (): RestaurantInfo => {
  try {
    console.log("Getting restaurant info synchronously");
    
    // Get current user from localStorage
    const userStr = localStorage.getItem('user');
    const user = userStr ? JSON.parse(userStr) : null;
    const userId = user?.id;
    
    // If no user is found, use default restaurant info
    if (!userId) {
      console.warn('User ID not found, using default restaurant info');
      return DEFAULT_RESTAURANT_INFO;
    }
    
    // Try to get cached info from localStorage first
    const cachedInfoStr = localStorage.getItem(`${userId}_restaurantInfo_cache`);
    if (cachedInfoStr) {
      try {
        const cachedInfo = JSON.parse(cachedInfoStr);
        console.log("Using cached restaurant info:", cachedInfo);
        return cachedInfo;
      } catch (error) {
        console.warn("Error parsing cached restaurant info:", error);
      }
    }
    
    // If we don't have cached info, construct from separate pieces
    // Load settings for this specific user
    const settingsInfo = loadSettingsRestaurantInfo();
    
    // Get restaurant logo from localStorage
    let restaurantLogo = null;
    try {
      const logoStr = localStorage.getItem(`${userId}_restaurantLogo`);
      restaurantLogo = logoStr || null;
    } catch (error) {
      console.warn("Error getting restaurant logo:", error);
    }
    
    // Try to get restaurant info from localStorage
    let restaurantInfo = null;
    try {
      const infoStr = localStorage.getItem(`${userId}_restaurantInfo`);
      restaurantInfo = infoStr ? JSON.parse(infoStr) : null;
    } catch (error) {
      console.warn("Error parsing restaurant info:", error);
    }
    
    // Use real data from user settings or fall back to default values
    const result: RestaurantInfo = {
      name: restaurantInfo?.name || user?.restaurantName || DEFAULT_RESTAURANT_INFO.name,
      address: restaurantInfo?.address || DEFAULT_RESTAURANT_INFO.address,
      phone: restaurantInfo?.phone || DEFAULT_RESTAURANT_INFO.phone,
      vat: restaurantInfo?.vat || user?.vatId || DEFAULT_RESTAURANT_INFO.vat,
      logo: restaurantLogo,
      email: restaurantInfo?.email || DEFAULT_RESTAURANT_INFO.email,
      website: restaurantInfo?.website || DEFAULT_RESTAURANT_INFO.website,
      description: restaurantInfo?.description || DEFAULT_RESTAURANT_INFO.description,
      openingHours: restaurantInfo?.openingHours || DEFAULT_RESTAURANT_INFO.openingHours
    };
    
    // Cache the result for future sync calls
    try {
      localStorage.setItem(`${userId}_restaurantInfo_cache`, JSON.stringify(result));
    } catch (error) {
      console.warn("Error caching restaurant info:", error);
    }
    
    return result;
  } catch (error) {
    console.error("Error in getRestaurantInfoSync:", error);
    // Return default values if there's an error
    return DEFAULT_RESTAURANT_INFO;
  }
};

// Force reload from localStorage to ensure we get fresh data
export const getRestaurantInfo = async (forceRefresh = false): Promise<RestaurantInfo> => {
  try {
    console.log("Getting restaurant info with forceRefresh:", forceRefresh);
    
    // Get current user from localStorage
    const userStr = localStorage.getItem('user');
    const user = userStr ? JSON.parse(userStr) : null;
    const userId = user?.id;
    
    console.log("Getting restaurant info, userId:", userId);
    
    // If no user is found, use default restaurant info
    if (!userId) {
      console.warn('User ID not found, using default restaurant info');
      return DEFAULT_RESTAURANT_INFO;
    }
    
    // If forceRefresh is true, clear user-specific restaurant info
    if (forceRefresh) {
      console.log("Force refreshing restaurant info for user:", userId);
      const keysToRemove = [`${userId}_restaurantInfo`, `${userId}_restaurantLogo`, `${userId}_restaurantInfo_cache`];
      keysToRemove.forEach(key => {
        console.log("Clearing cache for key:", key);
        try {
          localStorage.removeItem(key);
        } catch (error) {
          console.warn("Error clearing localStorage:", error);
        }
      });
    }
    
    // Load settings for this specific user
    const settingsInfo = loadSettingsRestaurantInfo();
    
    // Get user-specific restaurant information
    const restaurantInfo = await getUserData(userId, 'restaurantInfo', null);
    console.log("User-specific restaurant info:", restaurantInfo);
    
    // Get restaurant logo from user-specific storage or from defaults
    const restaurantLogo = await getUserData(userId, 'restaurantLogo', null);
    console.log("Restaurant logo loaded:", restaurantLogo ? "Present" : "Not present");
    
    // Use real data from user settings or fall back to default values
    const result: RestaurantInfo = {
      name: restaurantInfo?.name || user?.restaurantName || DEFAULT_RESTAURANT_INFO.name,
      address: restaurantInfo?.address || DEFAULT_RESTAURANT_INFO.address,
      phone: restaurantInfo?.phone || DEFAULT_RESTAURANT_INFO.phone,
      vat: restaurantInfo?.vat || user?.vatId || DEFAULT_RESTAURANT_INFO.vat,
      logo: restaurantLogo || null,
      email: restaurantInfo?.email || DEFAULT_RESTAURANT_INFO.email,
      website: restaurantInfo?.website || DEFAULT_RESTAURANT_INFO.website,
      description: restaurantInfo?.description || DEFAULT_RESTAURANT_INFO.description,
      openingHours: restaurantInfo?.openingHours || DEFAULT_RESTAURANT_INFO.openingHours
    };
    
    console.log("Final restaurant info (detailed):", JSON.stringify(result));
    
    // Cache the result for future sync calls
    try {
      localStorage.setItem(`${userId}_restaurantInfo_cache`, JSON.stringify(result));
    } catch (error) {
      console.warn("Error caching restaurant info:", error);
    }
    
    return result;
  } catch (error) {
    console.error("Error in getRestaurantInfo:", error);
    // Return default values if there's an error
    return DEFAULT_RESTAURANT_INFO;
  }
};

// Helper function to save restaurant information
export const saveRestaurantInfo = (userId: string, data: Partial<RestaurantInfo>): void => {
  if (!userId) {
    console.error('Cannot save restaurant info: User ID is missing');
    return;
  }
  
  try {
    // First get existing data
    const currentInfo = getUserData(userId, 'restaurantInfo', {
      name: "",
      address: "",
      phone: "",
      vat: ""
    });
    
    // Merge with new data
    const updatedInfo = { ...currentInfo, ...data };
    
    // Save to user-specific storage
    saveUserDataToStorage(userId, 'restaurantInfo', updatedInfo);
    
    // Also update user object for restaurant name if provided
    if (data.name) {
      const userStr = localStorage.getItem('user');
      if (userStr) {
        try {
          const user = JSON.parse(userStr);
          user.restaurantName = data.name;
          localStorage.setItem('user', JSON.stringify(user));
        } catch (error) {
          console.warn("Error updating user for restaurant name:", error);
        }
      }
    }
    
    // If VAT is provided, update the user's vatId as well
    if (data.vat) {
      const userStr = localStorage.getItem('user');
      if (userStr) {
        try {
          const user = JSON.parse(userStr);
          user.vatId = data.vat;
          localStorage.setItem('user', JSON.stringify(user));
        } catch (error) {
          console.warn("Error updating user for VAT:", error);
        }
      }
    }
    
    // Clear the cached info to force a refresh on next sync call
    try {
      localStorage.removeItem(`${userId}_restaurantInfo_cache`);
    } catch (error) {
      console.warn("Error clearing cached restaurant info:", error);
    }
    
    // Dispatch an event to notify other components
    window.dispatchEvent(new CustomEvent('restaurant-info-updated'));
    
    console.log("Restaurant info updated successfully:", updatedInfo);
    toast.success("Informazioni ristorante aggiornate con successo");
  } catch (error) {
    console.error("Error saving restaurant info:", error);
    toast.error("Errore nel salvare le informazioni del ristorante");
  }
};

// Helper function to delete restaurant logo
export const deleteRestaurantLogo = (userId: string): boolean => {
  if (!userId) {
    console.error('Cannot delete restaurant logo: User ID is missing');
    return false;
  }
  
  try {
    // Remove logo from user-specific storage
    try {
      localStorage.removeItem(`${userId}_restaurantLogo`);
      localStorage.removeItem(`${userId}_restaurantInfo_cache`); // Clear cache to force refresh
    } catch (error) {
      console.warn("Error clearing from localStorage:", error);
    }
    
    // Dispatch an event to notify other components
    window.dispatchEvent(new CustomEvent('restaurant-info-updated'));
    
    console.log("Restaurant logo deleted successfully");
    toast.success("Logo ristorante rimosso con successo");
    
    return true;
  } catch (error) {
    console.error("Error deleting restaurant logo:", error);
    return false;
  }
};

