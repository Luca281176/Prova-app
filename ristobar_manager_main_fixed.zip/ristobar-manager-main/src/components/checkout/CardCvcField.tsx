
import { Lock } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { formatCvc } from '@/utils/cardFormatters';

interface CardCvcFieldProps {
  value: string;
  onChange: (value: string) => void;
  isLoading: boolean;
}

const CardCvcField = ({ value, onChange, isLoading }: CardCvcFieldProps) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatCvc(e.target.value);
    onChange(formattedValue);
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="cvc">CVC</Label>
      <div className="relative">
        <Input
          id="cvc"
          placeholder="123"
          value={value}
          onChange={handleChange}
          maxLength={3}
          required
          disabled={isLoading}
        />
        <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
};

export default CardCvcField;
