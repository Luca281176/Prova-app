
import { Calendar } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { formatExpiry } from '@/utils/cardFormatters';

interface CardExpiryFieldProps {
  value: string;
  onChange: (value: string) => void;
  isLoading: boolean;
}

const CardExpiryField = ({ value, onChange, isLoading }: CardExpiryFieldProps) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatExpiry(e.target.value);
    onChange(formattedValue);
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="expiry">Data di scadenza</Label>
      <div className="relative">
        <Input
          id="expiry"
          placeholder="MM/YY"
          value={value}
          onChange={handleChange}
          maxLength={5}
          required
          disabled={isLoading}
        />
        <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
};

export default CardExpiryField;
