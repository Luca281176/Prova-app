
import { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

interface CardNameFieldProps {
  value: string;
  onChange: (value: string) => void;
  isLoading: boolean;
}

const CardNameField = ({ value, onChange, isLoading }: CardNameFieldProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="card-name">Nome sulla carta</Label>
      <Input
        id="card-name"
        placeholder="Mario Rossi"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
        disabled={isLoading}
      />
    </div>
  );
};

export default CardNameField;
