
import { CreditCard } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { formatCardNumber } from '@/utils/cardFormatters';

interface CardNumberFieldProps {
  value: string;
  onChange: (value: string) => void;
  isLoading: boolean;
}

const CardNumberField = ({ value, onChange, isLoading }: CardNumberFieldProps) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatCardNumber(e.target.value);
    onChange(formattedValue);
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="card-number">Numero della carta</Label>
      <div className="relative">
        <Input
          id="card-number"
          placeholder="4242 4242 4242 4242"
          value={value}
          onChange={handleChange}
          maxLength={19}
          required
          disabled={isLoading}
        />
        <CreditCard className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      </div>
    </div>
  );
};

export default CardNumberField;
