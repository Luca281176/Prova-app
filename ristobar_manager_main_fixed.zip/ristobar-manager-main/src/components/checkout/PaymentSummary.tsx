
import { CheckCircle } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { SubscriptionPlan } from '@/services/subscriptions/types';

interface PaymentSummaryProps {
  plan: SubscriptionPlan;
  showFeatures?: boolean;
  className?: string;
}

const PaymentSummary = ({ plan, showFeatures = true, className = '' }: PaymentSummaryProps) => {
  const calculateTax = (price: number) => {
    return price * 0.22; // 22% VAT (IVA in Italy)
  };

  const calculateTotal = (price: number) => {
    return price * 1.22; // Price + 22% VAT
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Riepilogo ordine</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">{plan.name}</h3>
            <p className="text-sm text-muted-foreground">{plan.description}</p>
          </div>
          
          {showFeatures && (
            <div className="space-y-1">
              <h4 className="text-sm font-medium">Funzionalità incluse:</h4>
              <ul className="text-sm space-y-1">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="h-3 w-3 text-green-600 mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col items-start border-t pt-4">
        <div className="flex justify-between w-full mb-2">
          <span>Subtotale</span>
          <span>€{plan.price.toFixed(2)}</span>
        </div>
        <div className="flex justify-between w-full mb-4">
          <span>IVA (22%)</span>
          <span>€{calculateTax(plan.price).toFixed(2)}</span>
        </div>
        <div className="flex justify-between w-full text-lg font-bold">
          <span>Totale</span>
          <span>€{calculateTotal(plan.price).toFixed(2)}</span>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Pagamento mensile. Puoi annullare in qualsiasi momento.
        </p>
      </CardFooter>
    </Card>
  );
};

export default PaymentSummary;
