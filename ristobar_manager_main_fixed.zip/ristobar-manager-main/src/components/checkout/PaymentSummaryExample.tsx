
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { subscriptionPlans } from '@/services/subscriptions';
import PaymentSummary from './PaymentSummary';

const PaymentSummaryExample = () => {
  const [selectedPlanId, setSelectedPlanId] = useState(subscriptionPlans[0].id);
  
  const selectedPlan = subscriptionPlans.find(plan => plan.id === selectedPlanId) || subscriptionPlans[0];
  
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Example: Payment Summary in Different Views</h1>
        <p className="text-muted-foreground">
          This component shows how PaymentSummary can be reused in different contexts
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        {/* Plan selection */}
        <Card>
          <CardHeader>
            <CardTitle>Select a Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Choose a subscription plan</label>
                <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a plan" />
                  </SelectTrigger>
                  <SelectContent>
                    {subscriptionPlans.map(plan => (
                      <SelectItem key={plan.id} value={plan.id}>
                        {plan.name} - €{plan.price.toFixed(2)}/month
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button className="w-full">Proceed to Checkout</Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Payment summary */}
        <PaymentSummary plan={selectedPlan} className="h-fit" />
        
        {/* Example of compact view without features */}
        <Card className="md:col-span-2 mt-4">
          <CardHeader>
            <CardTitle>Compact Payment Summary (without features)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-w-xs">
              <PaymentSummary plan={selectedPlan} showFeatures={false} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PaymentSummaryExample;
