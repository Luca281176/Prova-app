
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom'; // Importiamo questa libreria per i matcher di Jest DOM
import PaymentSummary from '../PaymentSummary';

// Mock subscription plan data
const mockPlan = {
  id: 'premium',
  name: 'Premium Plan',
  description: 'Advanced features for growing businesses',
  price: 29.99,
  features: [
    'Unlimited access to all features',
    'Priority support',
    'Custom branding'
  ],
  isRecommended: true,
  stripePriceId: 'price_premium_monthly' // Added the missing property
};

describe('PaymentSummary Component', () => {
  it('renders plan details correctly', () => {
    render(<PaymentSummary plan={mockPlan} />);
    
    // Check plan name and description
    expect(screen.getByText('Premium Plan')).toBeInTheDocument();
    expect(screen.getByText('Advanced features for growing businesses')).toBeInTheDocument();
    
    // Check features
    expect(screen.getByText('Unlimited access to all features')).toBeInTheDocument();
    expect(screen.getByText('Priority support')).toBeInTheDocument();
    expect(screen.getByText('Custom branding')).toBeInTheDocument();
    
    // Check price calculations
    expect(screen.getByText('€29.99')).toBeInTheDocument(); // Subtotal
    expect(screen.getByText('€6.60')).toBeInTheDocument(); // Tax (rounded from 6.5978)
    expect(screen.getByText('€36.59')).toBeInTheDocument(); // Total (rounded from 36.5878)
  });
  
  it('hides features when showFeatures is false', () => {
    render(<PaymentSummary plan={mockPlan} showFeatures={false} />);
    
    // Plan name and description should still be visible
    expect(screen.getByText('Premium Plan')).toBeInTheDocument();
    
    // Features should not be visible
    expect(screen.queryByText('Funzionalità incluse:')).not.toBeInTheDocument();
    expect(screen.queryByText('Unlimited access to all features')).not.toBeInTheDocument();
  });
  
  it('applies additional className when provided', () => {
    const { container } = render(<PaymentSummary plan={mockPlan} className="custom-class" />);
    const card = container.firstChild;
    
    expect(card).toHaveClass('custom-class');
  });
});
