
import { Tabs, TabsList, TabsContent, TabsTrigger } from '@/components/ui/tabs';
import SubscriptionAdminHeader from '../admin/SubscriptionAdminHeader';
import { SystemStatus } from '../admin/SystemStatus';
import { useAdminDashboard } from '@/hooks/useAdminDashboard';
import { useAdminSubscriptions } from '@/hooks/admin-dashboard/useAdminSubscriptions';

// Import the component extractions
import DashboardStats from '../admin/dashboard/DashboardStats';
import UserGrowthChart from '../admin/dashboard/UserGrowthChart';
import RecentSignups from '../admin/dashboard/RecentSignups';
import RecentTransactions from '../admin/dashboard/RecentTransactions';
import ExpiringSubscriptions from '../admin/dashboard/ExpiringSubscriptions';
import SubscriptionsTab from '../admin/dashboard/SubscriptionsTab';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';

const AdminDashboard = () => {
  const {
    activeTab,
    setActiveTab,
    stats,
    isLoading: statsLoading,
    users,
    isLoadingUsers,
    refreshUsers
  } = useAdminDashboard();
  
  const {
    subscriptions,
    isLoading: subscriptionsLoading,
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    planFilter,
    setPlanFilter,
    currentPage,
    totalItems,
    itemsPerPage,
    handleActivateSubscription,
    handleSuspendSubscription,
    handleCancelSubscription,
    handleUpgradeSubscription,
    handleDowngradeSubscription,
    handleNextPage,
    handlePrevPage,
    refreshSubscriptions
  } = useAdminSubscriptions();

  // Define handlers that show feedback using toast
  const onActivate = async (subscription) => {
    try {
      await handleActivateSubscription(subscription);
      toast("Abbonamento attivato con successo");
    } catch (error) {
      console.error("Error activating subscription:", error);
      toast.error("Errore nell'attivazione dell'abbonamento");
    }
  };

  const onSuspend = async (subscription) => {
    try {
      await handleSuspendSubscription(subscription);
      toast("Abbonamento sospeso con successo");
    } catch (error) {
      console.error("Error suspending subscription:", error);
      toast.error("Errore nella sospensione dell'abbonamento");
    }
  };

  const onCancel = async (subscription) => {
    try {
      await handleCancelSubscription(subscription);
      toast("Abbonamento cancellato con successo");
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      toast.error("Errore nella cancellazione dell'abbonamento");
    }
  };

  const onUpgrade = async (subscription) => {
    try {
      await handleUpgradeSubscription(subscription);
      toast("Abbonamento aggiornato con successo");
    } catch (error) {
      console.error("Error upgrading subscription:", error);
      toast.error("Errore nell'aggiornamento dell'abbonamento");
    }
  };

  const onDowngrade = async (subscription) => {
    try {
      await handleDowngradeSubscription(subscription);
      toast("Abbonamento declassato con successo");
    } catch (error) {
      console.error("Error downgrading subscription:", error);
      toast.error("Errore nel declassamento dell'abbonamento");
    }
  };

  // Format date in Italian format
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <SubscriptionAdminHeader />
      
      <Tabs 
        defaultValue="overview" 
        value={activeTab}
        onValueChange={(value) => setActiveTab(value)}
        className="space-y-4"
      >
        <TabsList className="grid grid-cols-4 md:w-[600px]">
          <TabsTrigger value="overview">Panoramica</TabsTrigger>
          <TabsTrigger value="subscriptions">Abbonamenti</TabsTrigger>
          <TabsTrigger value="users">Utenti</TabsTrigger>
          <TabsTrigger value="system">Sistema</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          {/* Dashboard Stats Cards */}
          <DashboardStats isLoading={statsLoading} stats={stats} />
          
          {/* Charts and Recent Signups */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <UserGrowthChart isLoading={statsLoading} />
            <RecentSignups isLoading={statsLoading} recentSignups={stats?.recentSignups} />
          </div>
          
          {/* Transactions and Expirations */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            <RecentTransactions isLoading={statsLoading} />
            <ExpiringSubscriptions isLoading={statsLoading} />
          </div>
        </TabsContent>
        
        <TabsContent value="subscriptions">
          <SubscriptionsTab 
            isLoading={subscriptionsLoading}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            planFilter={planFilter}
            setPlanFilter={setPlanFilter}
            subscriptions={subscriptions}
            currentPage={currentPage}
            totalItems={totalItems}
            itemsPerPage={itemsPerPage}
            onNextPage={handleNextPage}
            onPrevPage={handlePrevPage}
            onActivate={onActivate}
            onSuspend={onSuspend}
            onCancel={onCancel}
            onUpgrade={onUpgrade}
            onDowngrade={onDowngrade}
          />
        </TabsContent>
        
        <TabsContent value="users" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Gestione Utenti</h2>
            <button 
              onClick={refreshUsers} 
              className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90 transition-colors"
            >
              Aggiorna
            </button>
          </div>
          
          {isLoadingUsers ? (
            <div className="space-y-2">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-8 w-full" />
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">ID Utente</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Data registrazione</TableHead>
                    <TableHead>Tenant ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                        Nessun utente trovato
                      </TableCell>
                    </TableRow>
                  ) : (
                    users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-mono text-xs">{user.id.substring(0, 8)}...</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.name || 'N/A'}</TableCell>
                        <TableCell>{formatDate(user.created_at)}</TableCell>
                        <TableCell className="font-mono text-xs">
                          {user.tenant_id ? user.tenant_id.substring(0, 8) + '...' : 'N/A'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="system">
          <SystemStatus />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
