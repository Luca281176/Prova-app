
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Package, 
  Settings, 
  Users, 
  Home, 
  Bell, 
  Database,
  BadgeDollarSign 
} from 'lucide-react';

export const AdminNavbar = () => {
  return (
    <div className="sticky top-0 z-40 border-b bg-background px-4 py-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold">Admin Dashboard</span>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/dashboard">
              <Home className="mr-1 h-4 w-4" />
              Dashboard
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/subscriptions">
              <BadgeDollarSign className="mr-1 h-4 w-4" />
              Abbonamenti
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/users">
              <Users className="mr-1 h-4 w-4" />
              Utenti
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/system">
              <Package className="mr-1 h-4 w-4" />
              Sistema
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/database">
              <Database className="mr-1 h-4 w-4" />
              Database
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/notifications">
              <Bell className="mr-1 h-4 w-4" />
              Notifiche
            </Link>
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/admin/settings">
              <Settings className="mr-1 h-4 w-4" />
              Impostazioni
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
};
