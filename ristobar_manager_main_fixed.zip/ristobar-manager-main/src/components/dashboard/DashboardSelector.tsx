import { useUser } from '@/contexts/user';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { StarterDashboard } from './StarterDashboard';
import { ProDashboard } from './ProDashboard';
import { UltimateDashboard } from './UltimateDashboard';
import NoSubscriptionView from '@/components/subscriptions/NoSubscriptionView';
import { isSubscriptionActive } from '@/services/subscriptions';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboardIcon, UsersIcon, CreditCardIcon, HomeIcon, LeafIcon, StarIcon, RocketIcon, ServerIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface DashboardSelectorProps {
  adminMode?: boolean;
}

export function DashboardSelector({ adminMode = false }: DashboardSelectorProps) {
  const { user, isAdmin, updateUser } = useUser();
  const { currentTenant } = useTenant();
  const [previewPlan, setPreviewPlan] = useState<string | null>(null);
  const location = useLocation();
  
  useEffect(() => {
    console.log("DashboardSelector mounted, user:", user);
    console.log("Admin mode:", adminMode);
    console.log("User subscription:", user?.subscription);
    console.log("Current tenant:", currentTenant);
    console.log("Is admin:", isAdmin());
  }, [user, currentTenant, isAdmin, adminMode]);
  
  if (!user) {
    console.log("DashboardSelector: No user found");
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-semibold mb-4">Caricamento dashboard...</h2>
      </div>
    );
  }

  const isAppOwner = user?.email === 'luca.costanzo@ristobarmanager.it';
  console.log("User is app owner:", isAppOwner);
  
  if (!currentTenant) {
    console.log("DashboardSelector: No tenant found");
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-semibold mb-4">Nessun ristorante configurato</h2>
        <p>Completa il profilo del tuo ristorante nelle impostazioni.</p>
      </div>
    );
  }
  
  const hasActiveSubscription = user.subscription && isSubscriptionActive(user.subscription);
  
  if (!hasActiveSubscription && !previewPlan && !adminMode) {
    console.log("DashboardSelector: No active subscription found");
    return <NoSubscriptionView />;
  }
  
  const planId = previewPlan || user.subscription?.planId || 'starter';
  console.log(`DashboardSelector: Rendering dashboard for plan: ${planId}`);
  
  let DashboardComponent;
  switch (planId) {
    case 'ultimate':
      DashboardComponent = <UltimateDashboard />;
      break;
    case 'pro':
      DashboardComponent = <ProDashboard />;
      break;
    case 'starter':
    default:
      DashboardComponent = <StarterDashboard />;
      break;
  }

  const handleSwitchPlan = async (newPlanId: string) => {
    if (!isAppOwner) return;
    
    if (previewPlan === newPlanId) {
      setPreviewPlan(null);
      toast.info("Tornato al piano corrente");
      return;
    }
    
    setPreviewPlan(newPlanId);
    toast.success(`Visualizzazione piano ${newPlanId.charAt(0).toUpperCase() + newPlanId.slice(1)}`, {
      description: "Stai visualizzando questa dashboard in modalità anteprima."
    });
  };
  
  return (
    <div className="flex flex-col gap-6">
      {isAppOwner && (
        <div className="p-4 bg-accent/20 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Controlli Amministratore</h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Button 
              asChild 
              variant={location.pathname === '/admin/dashboard' ? 'default' : 'outline'} 
              className="flex items-center gap-2"
            >
              <Link to="/admin/dashboard">
                <LayoutDashboardIcon className="h-4 w-4" />
                Dashboard
              </Link>
            </Button>
            <Button 
              asChild 
              variant={location.pathname === '/admin/subscriptions' ? 'default' : 'outline'} 
              className="flex items-center gap-2"
            >
              <Link to="/admin/subscriptions">
                <CreditCardIcon className="h-4 w-4" />
                Abbonamenti
              </Link>
            </Button>
            <Button 
              asChild 
              variant={location.pathname === '/admin/users' ? 'default' : 'outline'} 
              className="flex items-center gap-2"
            >
              <Link to="/admin/users">
                <UsersIcon className="h-4 w-4" />
                Utenti
              </Link>
            </Button>
            <Button 
              asChild 
              variant={location.pathname === '/admin/system' ? 'default' : 'outline'} 
              className="flex items-center gap-2"
            >
              <Link to="/admin/system">
                <ServerIcon className="h-4 w-4" />
                Stato Sistema
              </Link>
            </Button>
            <Button 
              asChild 
              variant={location.pathname === '/' ? 'default' : 'outline'} 
              className="flex items-center gap-2"
            >
              <Link to="/">
                <HomeIcon className="h-4 w-4" />
                Home
              </Link>
            </Button>
          </div>
          
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-3">Anteprima Piani (solo per test)</h3>
            <div className="flex flex-wrap gap-3">
              <Button 
                variant={previewPlan === 'starter' ? "default" : "outline"} 
                size="sm" 
                onClick={() => handleSwitchPlan('starter')}
                className="flex items-center gap-2"
              >
                <LeafIcon className="h-4 w-4" />
                Starter
                {user.subscription?.planId === 'starter' && !previewPlan && (
                  <Badge variant="success" className="ml-1 text-[10px] px-1">Attuale</Badge>
                )}
              </Button>
              
              <Button 
                variant={previewPlan === 'pro' ? "default" : "outline"} 
                size="sm" 
                onClick={() => handleSwitchPlan('pro')}
                className="flex items-center gap-2"
              >
                <StarIcon className="h-4 w-4" />
                Pro
                {user.subscription?.planId === 'pro' && !previewPlan && (
                  <Badge variant="success" className="ml-1 text-[10px] px-1">Attuale</Badge>
                )}
              </Button>
              
              <Button 
                variant={previewPlan === 'ultimate' ? "default" : "outline"} 
                size="sm" 
                onClick={() => handleSwitchPlan('ultimate')}
                className="flex items-center gap-2"
              >
                <RocketIcon className="h-4 w-4" />
                Ultimate
                {user.subscription?.planId === 'ultimate' && !previewPlan && (
                  <Badge variant="success" className="ml-1 text-[10px] px-1">Attuale</Badge>
                )}
              </Button>
              
              {previewPlan && (
                <Badge className="ml-1 h-6 flex items-center">
                  Anteprima: {previewPlan.charAt(0).toUpperCase() + previewPlan.slice(1)}
                </Badge>
              )}
            </div>
          </div>
        </div>
      )}
      
      {DashboardComponent}
    </div>
  );
}
