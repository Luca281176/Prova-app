
import React from 'react';
import { Link } from 'react-router-dom';
import { InfoIcon, LockIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PlanFeatureAlertProps {
  title: string;
  description: string;
  availableInPlans: string[];
  buttonText: string;
  buttonLink: string;
  iconOnly?: boolean;
}

export function PlanFeatureAlert({ 
  title, 
  description, 
  availableInPlans, 
  buttonText, 
  buttonLink,
  iconOnly = false
}: PlanFeatureAlertProps) {
  if (iconOnly) {
    return (
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <LockIcon className="h-5 w-5 text-muted-foreground mr-2" />
          <div>
            <h3 className="font-medium">{title}</h3>
            <p className="text-xs text-muted-foreground">{description}</p>
          </div>
        </div>
        <Button variant="outline" size="sm" asChild>
          <Link to={buttonLink}>
            {buttonText}
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="p-4 rounded-lg bg-accent/30 border border-accent">
      <div className="flex items-start">
        <InfoIcon className="h-5 w-5 text-primary mr-2 mt-0.5" />
        <div className="flex-1">
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
          
          <div className="mt-2">
            <p className="text-xs text-muted-foreground">
              Disponibile nei piani: {availableInPlans.join(', ')}
            </p>
          </div>
          
          <Button size="sm" className="mt-3" asChild>
            <Link to={buttonLink}>
              {buttonText}
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
