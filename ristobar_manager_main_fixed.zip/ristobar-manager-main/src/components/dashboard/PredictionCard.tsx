
import React from 'react';
import { TrendingUpIcon, TrendingDownIcon } from 'lucide-react';

interface PredictionCardProps {
  title: string;
  value: string;
  percentageIncrease: number;
  trend: 'up' | 'down' | 'neutral';
}

export function PredictionCard({ title, value, percentageIncrease, trend }: PredictionCardProps) {
  return (
    <div className="border border-accent rounded-lg p-3">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-medium">{title}</h3>
        {trend === 'up' ? (
          <div className="bg-green-500/10 p-1 rounded-full">
            <TrendingUpIcon className="h-4 w-4 text-green-600" />
          </div>
        ) : trend === 'down' ? (
          <div className="bg-red-500/10 p-1 rounded-full">
            <TrendingDownIcon className="h-4 w-4 text-red-600" />
          </div>
        ) : null}
      </div>
      <div className="mt-2">
        <span className="text-xl font-bold">{value}</span>
        {percentageIncrease !== 0 && (
          <span className={`ml-2 text-xs ${trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : ''}`}>
            {trend === 'up' ? '+' : ''}{percentageIncrease}%
          </span>
        )}
      </div>
    </div>
  );
}
