
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  LayoutIcon, 
  ClipboardListIcon, 
  CalendarIcon, 
  UsersIcon,
  ShoppingBagIcon,
  TrendingUpIcon,
  ActivityIcon,
  ChevronUpIcon,
  ExternalLinkIcon,
  Download,
  InfoIcon,
  Crown,
  Award
} from 'lucide-react';
import { PlanFeatureAlert } from './PlanFeatureAlert';
import { SalesChart } from './SalesChart';

const DEFAULT_STATS = {
  totalSales: 0,
  averageOrder: 0,
  totalOrders: 0,
  totalCustomers: 0,
  tableOccupancy: 0,
  pendingReservations: 0,
};

const DEFAULT_SALES_DATA = [
  { name: 'Lun', value: 0 },
  { name: 'Mar', value: 0 },
  { name: 'Mer', value: 0 },
  { name: 'Gio', value: 0 },
  { name: 'Ven', value: 0 },
  { name: 'Sab', value: 0 },
  { name: 'Dom', value: 0 },
];

const DEFAULT_COMPARISONS = {
  salesPercentage: {
    value: 0,
    trend: 'neutral' as 'positive' | 'negative' | 'neutral'
  },
  ordersPercentage: {
    value: 0,
    trend: 'neutral' as 'positive' | 'negative' | 'neutral'
  },
  tableOccupancyPercentage: {
    value: 0,
    trend: 'neutral' as 'positive' | 'negative' | 'neutral'
  },
  reservationsPercentage: {
    value: 0,
    trend: 'neutral' as 'positive' | 'negative' | 'neutral'
  }
};

export function ProDashboard() {
  const [tab, setTab] = useState("today");
  const [restaurantStats, setRestaurantStats] = useState(DEFAULT_STATS);
  const [salesData, setSalesData] = useState(DEFAULT_SALES_DATA);
  const [comparisons, setComparisons] = useState(DEFAULT_COMPARISONS);
  const [notifications, setNotifications] = useState([]);

  // Simulate data loading
  useEffect(() => {
    // In a real app, this would be fetched from an API
    setRestaurantStats({
      totalSales: 2580.75,
      averageOrder: 42.25,
      totalOrders: 61,
      totalCustomers: 95,
      tableOccupancy: 78,
      pendingReservations: 12,
    });

    setSalesData([
      { name: 'Lun', value: 1200 },
      { name: 'Mar', value: 1800 },
      { name: 'Mer', value: 1400 },
      { name: 'Gio', value: 2200 },
      { name: 'Ven', value: 2800 },
      { name: 'Sab', value: 3200 },
      { name: 'Dom', value: 2400 },
    ]);

    setComparisons({
      salesPercentage: {
        value: 12.5,
        trend: 'positive' as const
      },
      ordersPercentage: {
        value: 8.3,
        trend: 'positive' as const
      },
      tableOccupancyPercentage: {
        value: 5.2,
        trend: 'positive' as const
      },
      reservationsPercentage: {
        value: 15.0,
        trend: 'positive' as const
      }
    });
  }, []);

  return (
    <div className="animate-fade-up">
      <div className="mb-8">
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-[#FEF7CD] border border-[#FEF7CD] text-black">
          <Award className="h-4 w-4 mr-1.5 text-amber-600" />
          <span className="text-xs font-medium">Piano Pro</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight mt-2">Dashboard Avanzata</h1>
        <p className="text-muted-foreground">Analisi dettagliata e monitoraggio delle performance</p>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="mb-8">
        <TabsList>
          <TabsTrigger value="today">Oggi</TabsTrigger>
          <TabsTrigger value="week">Settimana</TabsTrigger>
          <TabsTrigger value="month">Mese</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="glass-panel animate-fade-up [animation-delay:150ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Incasso Totale</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">€{restaurantStats.totalSales.toFixed(2)}</div>
              <div className="p-2 rounded-full bg-green-500/10 text-green-600">
                <TrendingUpIcon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {comparisons.salesPercentage.value === 0 ? 
                'Nessun dato di confronto' : 
                `${comparisons.salesPercentage.value > 0 ? '+' : ''}${comparisons.salesPercentage.value}% rispetto a ieri`
              }
            </p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:300ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Ordini Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.totalOrders}</div>
              <div className="p-2 rounded-full bg-blue-500/10 text-blue-600">
                <ClipboardListIcon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Media per ordine: €{restaurantStats.averageOrder.toFixed(2)}</p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:450ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Occupazione Tavoli</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.tableOccupancy}%</div>
              <div className="p-2 rounded-full bg-green-500/10 text-green-600">
                <LayoutIcon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {comparisons.tableOccupancyPercentage.value === 0 ? 
                'Nessun dato di confronto' : 
                `${comparisons.tableOccupancyPercentage.value > 0 ? '+' : ''}${comparisons.tableOccupancyPercentage.value}% rispetto alla scorsa settimana`
              }
            </p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:600ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Prenotazioni in Attesa</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.pendingReservations}</div>
              <div className="p-2 rounded-full bg-purple-500/10 text-purple-600">
                <CalendarIcon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {comparisons.reservationsPercentage.value === 0 ? 
                'Nessun dato di confronto' : 
                `${comparisons.reservationsPercentage.value > 0 ? '+' : ''}${comparisons.reservationsPercentage.value} prenotazioni per oggi`
              }
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="glass-panel col-span-1 lg:col-span-2 animate-fade-up [animation-delay:750ms] overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-[#f5f7fb] to-[#f0f2f8] dark:from-transparent dark:to-transparent border-b border-border/30">
            <CardTitle>Vendite Settimanali</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="h-[300px]">
              <SalesChart data={salesData} />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-panel animate-fade-up [animation-delay:900ms]">
          <CardHeader>
            <CardTitle>Inventario</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Prodotti sotto soglia</p>
                  <p className="text-sm text-muted-foreground">5 prodotti da riordinare</p>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/inventory">
                    Gestisci
                  </Link>
                </Button>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Ordini fornitori</p>
                  <p className="text-sm text-muted-foreground">2 ordini in arrivo</p>
                </div>
                <Button variant="outline" size="sm" asChild>
                  <Link to="/inventory">
                    Visualizza
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-up [animation-delay:1050ms]">
        <Link to="/rooms">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <LayoutIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Sale e Tavoli</h3>
                <p className="text-xs text-muted-foreground">Gestisci la disposizione</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/menu">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <ClipboardListIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Menu</h3>
                <p className="text-xs text-muted-foreground">Gestisci i tuoi piatti</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/reservations">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <CalendarIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Prenotazioni</h3>
                <p className="text-xs text-muted-foreground">Gestisci le prenotazioni</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/personale">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <UsersIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Personale</h3>
                <p className="text-xs text-muted-foreground">Gestisci il tuo staff</p>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      <Card className="glass-panel bg-[#FEF7CD]/10 border border-[#FEF7CD] mt-8">
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium">Funzionalità Ultimate</h3>
              <p className="text-sm text-muted-foreground">Passa a Ultimate per sbloccare l'analisi avanzata con Machine Learning e API personalizzate.</p>
            </div>
            <Button asChild>
              <Link to="/subscriptions">
                Aggiorna Piano
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col sm:flex-row mt-8 justify-end gap-4">
        <Button variant="outline" size="sm" className="flex items-center">
          <Download className="mr-2 h-4 w-4" />
          Esporta Report Completo
        </Button>
        <Button variant="secondary" size="sm" asChild>
          <Link to="/subscriptions" className="flex items-center">
            <ChevronUpIcon className="mr-2 h-4 w-4" />
            Passa al Piano Ultimate
          </Link>
        </Button>
      </div>
    </div>
  );
}
