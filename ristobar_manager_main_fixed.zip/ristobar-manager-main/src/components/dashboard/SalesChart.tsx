
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine,
  Label,
  Area,
  AreaChart,
  ComposedChart,
  Line
} from 'recharts';

interface SalesChartProps {
  data: { name: string; value: number }[];
  showPrediction?: boolean;
  predictedValue?: number;
  ultimateVersion?: boolean;
}

export function SalesChart({ 
  data, 
  showPrediction = false, 
  predictedValue = 0,
  ultimateVersion = false 
}: SalesChartProps) {
  const formatCurrency = (value: number) => `€${value.toFixed(0)}`;
  
  if (ultimateVersion) {
    // Create enhanced data with trend line data
    const enhancedData = data.map(item => ({
      ...item,
      trend: item.value * 0.85 + Math.random() * item.value * 0.3,
      forecast: item.value * 1.1 + Math.random() * item.value * 0.2
    }));
    
    return (
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart
          data={enhancedData}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 10,
          }}
        >
          <defs>
            <linearGradient id="colorSalesUltimate" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.9}/>
              <stop offset="95%" stopColor="#818CF8" stopOpacity={0.6}/>
            </linearGradient>
            <linearGradient id="colorTrend" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#34D399" stopOpacity={0.2}/>
            </linearGradient>
            <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#FCD34D" stopOpacity={0.2}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.1)" />
          <XAxis 
            dataKey="name" 
            axisLine={{ stroke: '#666' }}
            tickLine={false}
            tick={{ fill: 'var(--muted-foreground)' }}
          />
          <YAxis 
            tickFormatter={formatCurrency}
            domain={[0, 'auto']}
            axisLine={{ stroke: '#666' }}
            tickLine={false}
            tick={{ fill: 'var(--muted-foreground)' }}
            width={60}
          />
          <Tooltip 
            formatter={(value, name) => {
              const formattedValue = `€${Number(value).toFixed(2)}`;
              let label = 'Vendite';
              if (name === 'trend') label = 'Tendenza';
              if (name === 'forecast') label = 'Previsione';
              return [formattedValue, label];
            }}
            labelFormatter={(label) => `${label}`}
            contentStyle={{
              backgroundColor: 'rgba(30, 41, 59, 0.9)',
              border: '1px solid rgba(71, 85, 105, 0.5)',
              borderRadius: '8px',
              boxShadow: '0 10px 25px rgba(0, 0, 0, 0.2)',
              backdropFilter: 'blur(8px)'
            }}
            itemStyle={{ color: '#e2e8f0' }}
            cursor={{ fill: 'rgba(79, 70, 229, 0.1)' }}
          />
          <Bar 
            dataKey="value" 
            fill="url(#colorSalesUltimate)" 
            radius={[6, 6, 0, 0]}
            barSize={40}
            animationDuration={1800}
            animationEasing="ease-in-out"
            name="value"
          />
          <Area 
            type="monotone" 
            dataKey="trend" 
            stroke="#10B981" 
            strokeWidth={2}
            fill="url(#colorTrend)"
            animationDuration={2000}
            animationEasing="ease-out"
          />
          <Line 
            type="monotone" 
            dataKey="forecast" 
            stroke="#F59E0B" 
            strokeWidth={3}
            strokeDasharray="5 5"
            dot={{ stroke: '#F59E0B', fill: '#FCD34D', strokeWidth: 2, r: 4 }}
            activeDot={{ stroke: '#F59E0B', fill: '#FCD34D', strokeWidth: 2, r: 6 }}
            animationDuration={2200}
            animationEasing="ease-in-out"
          />
          
          {showPrediction && predictedValue > 0 && (
            <ReferenceLine 
              y={predictedValue} 
              stroke="#EC4899" 
              strokeDasharray="3 3" 
              strokeWidth={2}
            >
              <Label 
                value={`AI Prediction: €${predictedValue.toFixed(0)}`} 
                position="insideBottomRight"
                fill="#EC4899"
                fontWeight="600"
              />
            </ReferenceLine>
          )}
        </ComposedChart>
      </ResponsiveContainer>
    );
  }
  
  // Regular version (non-Ultimate)
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <defs>
          <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.8}/>
            <stop offset="95%" stopColor="#D6BCFA" stopOpacity={0.6}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
        <XAxis 
          dataKey="name" 
          axisLine={{ stroke: '#e0e0e0' }}
          tickLine={false}
          tick={{ fill: 'var(--muted-foreground)' }}
        />
        <YAxis 
          tickFormatter={formatCurrency}
          domain={[0, 'auto']}
          axisLine={{ stroke: '#e0e0e0' }}
          tickLine={false}
          tick={{ fill: 'var(--muted-foreground)' }}
        />
        <Tooltip 
          formatter={(value) => [`€${Number(value).toFixed(2)}`, 'Vendite']}
          labelFormatter={(label) => `${label}`}
          contentStyle={{
            backgroundColor: 'var(--background)',
            border: '1px solid var(--border)',
            borderRadius: '6px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
          }}
          itemStyle={{ color: 'var(--foreground)' }}
          cursor={{ fill: 'rgba(139, 92, 246, 0.1)' }}
        />
        <Bar 
          dataKey="value" 
          fill="url(#colorSales)" 
          radius={[4, 4, 0, 0]}
          barSize={36}
          animationDuration={1500}
          animationEasing="ease-in-out"
        />
        
        {showPrediction && predictedValue > 0 && (
          <ReferenceLine 
            y={predictedValue} 
            stroke="#F97316" 
            strokeDasharray="3 3" 
            strokeWidth={2}
          >
            <Label 
              value={`Previsione ML: €${predictedValue.toFixed(0)}`} 
              position="insideBottomRight"
              fill="#F97316"
              fontWeight="500"
            />
          </ReferenceLine>
        )}
      </BarChart>
    </ResponsiveContainer>
  );
}
