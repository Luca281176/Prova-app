
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  LayoutIcon, 
  ClipboardListIcon,
  InfoIcon,
  ChevronUpIcon,
  ExternalLinkIcon,
  Download
} from 'lucide-react';
import { PlanFeatureAlert } from './PlanFeatureAlert';

const DEFAULT_STATS = {
  totalSales: 0,
  averageOrder: 0,
  totalOrders: 0,
  tableOccupancy: 0,
};

export function StarterDashboard() {
  const [restaurantStats, setRestaurantStats] = useState(DEFAULT_STATS);

  // Initialize with zero values instead of mock data
  useEffect(() => {
    setRestaurantStats(DEFAULT_STATS);
  }, []);

  return (
    <div className="animate-fade-up">
      <div className="mb-8">
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-[#F2FCE2]/30 border border-[#F2FCE2] text-primary-foreground">
          <span className="text-xs font-medium">Piano Starter</span>
        </div>
        <h1 className="text-2xl font-bold tracking-tight mt-2">Dashboard Ristorante</h1>
        <p className="text-muted-foreground">Monitora le statistiche principali del tuo locale</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="glass-panel animate-fade-up [animation-delay:150ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Incasso Totale</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">€{restaurantStats.totalSales.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-2">Oggi</p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:300ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Ordini Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{restaurantStats.totalOrders}</div>
            <p className="text-xs text-muted-foreground mt-2">Media per ordine: €{restaurantStats.averageOrder.toFixed(2)}</p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:450ms]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Occupazione Tavoli</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{restaurantStats.tableOccupancy}%</div>
            <p className="text-xs text-muted-foreground mt-2">Tasso di occupazione attuale</p>
          </CardContent>
        </Card>
        
        <Card className="glass-panel animate-fade-up [animation-delay:600ms] bg-[#F2FCE2]/10 border-dashed border-[#F2FCE2]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Prenotazioni</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <InfoIcon className="h-8 w-8 text-muted-foreground/50" />
              <Button variant="outline" size="sm" asChild>
                <Link to="/subscriptions">
                  Aggiorna Piano
                </Link>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Disponibile nei piani Pro e Ultimate</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="glass-panel col-span-1 lg:col-span-2 animate-fade-up [animation-delay:750ms]">
          <CardHeader>
            <CardTitle>Ordini Giornalieri</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center bg-accent/30 rounded-md">
              <div className="text-center">
                <p className="text-muted-foreground mb-2">Nessun dato disponibile</p>
                <p className="text-xs text-muted-foreground">Aggiungi ordini per visualizzare le statistiche</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-panel animate-fade-up [animation-delay:900ms] bg-[#F2FCE2]/10 border-dashed border-[#F2FCE2]">
          <CardHeader>
            <CardTitle>Inventario</CardTitle>
          </CardHeader>
          <CardContent className="pt-2">
            <PlanFeatureAlert 
              title="Gestione Inventario" 
              description="Monitoraggio dell'inventario in tempo reale"
              availableInPlans={["Pro", "Ultimate"]}
              buttonText="Aggiorna Piano"
              buttonLink="/subscriptions"
            />
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-up [animation-delay:1050ms]">
        <Link to="/rooms">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <LayoutIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Sale e Tavoli</h3>
                <p className="text-xs text-muted-foreground">Gestisci la disposizione</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/menu">
          <Card className="glass-panel hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-primary/10">
                <ClipboardListIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">Menu</h3>
                <p className="text-xs text-muted-foreground">Gestisci i tuoi piatti</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Card className="glass-panel bg-[#F2FCE2]/10 border-dashed border-[#F2FCE2]">
          <CardContent className="flex items-center p-4">
            <div className="w-full">
              <PlanFeatureAlert
                iconOnly
                title="Prenotazioni"
                description="Gestione prenotazioni avanzata"
                availableInPlans={["Pro", "Ultimate"]}
                buttonText="Aggiorna"
                buttonLink="/subscriptions"
              />
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-panel bg-[#F2FCE2]/10 border-dashed border-[#F2FCE2]">
          <CardContent className="flex items-center p-4">
            <div className="w-full">
              <PlanFeatureAlert
                iconOnly
                title="Personale" 
                description="Gestione completa del personale"
                availableInPlans={["Pro", "Ultimate"]}
                buttonText="Aggiorna"
                buttonLink="/subscriptions"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col sm:flex-row mt-8 justify-end gap-4">
        <Button variant="outline" size="sm" className="flex items-center">
          <Download className="mr-2 h-4 w-4" />
          Esporta Dati Base
        </Button>
        <Button variant="secondary" size="sm" asChild>
          <Link to="/subscriptions" className="flex items-center">
            <ChevronUpIcon className="mr-2 h-4 w-4" />
            Passa al Piano Pro
          </Link>
        </Button>
      </div>
    </div>
  );
}
