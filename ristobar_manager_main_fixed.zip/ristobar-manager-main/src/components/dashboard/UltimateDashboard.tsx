
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutIcon, 
  ClipboardListIcon, 
  CalendarIcon, 
  UsersIcon,
  ShoppingBagIcon,
  TrendingUpIcon,
  ActivityIcon,
  BarChart3Icon,
  BriefcaseIcon,
  Store,
  UsersIcon as UsersMultipleIcon,
  Download,
  ArrowUpDown,
  BrainCircuitIcon,
  Layers,
  BoxesIcon,
  Code,
  Globe,
  Crown,
  Zap,
  LineChart,
  BarChart4,
  PieChart,
  Sparkles,
  Bot,
  Shield,
  Blocks,
  AreaChart
} from 'lucide-react';
import { SalesChart } from './SalesChart';
import { PredictionCard } from './PredictionCard';

const DEFAULT_STATS = {
  totalSales: 0,
  averageOrder: 0,
  totalOrders: 0,
  totalCustomers: 0,
  tableOccupancy: 0,
  pendingReservations: 0,
  weeklyTrend: 0,
  monthlyTrend: 0,
  locations: 0,
};

const DEFAULT_SALES_DATA = [
  { name: 'Lun', value: 0 },
  { name: 'Mar', value: 0 },
  { name: 'Mer', value: 0 },
  { name: 'Gio', value: 0 },
  { name: 'Ven', value: 0 },
  { name: 'Sab', value: 0 },
  { name: 'Dom', value: 0 },
];

export function UltimateDashboard() {
  const [tab, setTab] = useState("today");
  const [locationTab, setLocationTab] = useState("all");
  const [chartType, setChartType] = useState("sales");
  const [restaurantStats, setRestaurantStats] = useState(DEFAULT_STATS);
  const [salesData, setSalesData] = useState(DEFAULT_SALES_DATA);
  const [highlightedStats, setHighlightedStats] = useState({
    growth: 0,
    potentialRevenue: 0,
    trendingItems: []
  });
  const [predictionsData, setPredictionsData] = useState({
    salesPrediction: 0,
    customersPrediction: 0,
    occupancyPrediction: 0,
    stockPrediction: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const [selectedInsight, setSelectedInsight] = useState(0);
  
  const aiInsights = [
    {
      title: "Apertura domenicale",
      description: "I dati mostrano che un'apertura estesa la domenica potrebbe aumentare le vendite del 18%",
      impact: "Alto",
      actionable: true,
      category: "operations"
    },
    {
      title: "Prenotazioni ottimizzate",
      description: "Ridurre i tempi tra prenotazioni di 15 minuti aumenterebbe la capacità del 12%",
      impact: "Medio",
      actionable: true,
      category: "reservations"
    },
    {
      title: "Menu stagionale",
      description: "L'introduzione di 5 piatti stagionali aumenterebbe lo scontrino medio del 15%",
      impact: "Alto",
      actionable: true,
      category: "menu"
    }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    setRestaurantStats({
      totalSales: 12580.75,
      averageOrder: 65.50,
      totalOrders: 192,
      totalCustomers: 455,
      tableOccupancy: 92,
      pendingReservations: 38,
      weeklyTrend: 22.4,
      monthlyTrend: 15.8,
      locations: 5,
    });

    setSalesData([
      { name: 'Lun', value: 8200 },
      { name: 'Mar', value: 7800 },
      { name: 'Mer', value: 9400 },
      { name: 'Gio', value: 10200 },
      { name: 'Ven', value: 12800 },
      { name: 'Sab', value: 15200 },
      { name: 'Dom', value: 13400 },
    ]);

    setHighlightedStats({
      growth: 24.7,
      potentialRevenue: 15680,
      trendingItems: [
        { name: "Pasta al tartufo", percentage: 32 },
        { name: "Tiramisù", percentage: 28 },
        { name: "Cocktail signature", percentage: 24 }
      ]
    });

    setPredictionsData({
      salesPrediction: 14850.25,
      customersPrediction: 520,
      occupancyPrediction: 95,
      stockPrediction: [
        { item: 'Vino rosso', currentStock: 24, predictedNeed: 42 },
        { item: 'Bistecca', currentStock: 18, predictedNeed: 35 },
        { item: 'Pane', currentStock: 45, predictedNeed: 80 }
      ]
    });
    
    return () => clearTimeout(timer);
  }, []);

  const getImpactColor = (impact) => {
    switch(impact) {
      case "Alto": return "bg-green-500/10 text-green-600";
      case "Medio": return "bg-amber-500/10 text-amber-600";
      case "Basso": return "bg-blue-500/10 text-blue-600";
      default: return "bg-gray-500/10 text-gray-600";
    }
  };

  return (
    <div className="animate-fade-up relative">
      {isLoading && (
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-spin"></div>
            <Crown className="absolute inset-0 m-auto h-8 w-8 text-primary animate-pulse" />
          </div>
          <p className="mt-4 text-lg font-medium">Caricamento Dashboard Ultimate...</p>
        </div>
      )}
      
      <div className="mb-8">
        <div className="inline-flex items-center px-3 py-1 rounded-full bg-gradient-to-r from-indigo-500/30 via-purple-500/30 to-pink-500/30 border border-indigo-500/50">
          <Crown className="h-4 w-4 mr-2 text-amber-400" />
          <span className="text-xs font-medium bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-yellow-300">Piano Ultimate</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight mt-2 flex items-center">
          Dashboard Enterprise
          <Badge variant="outline" className="ml-3 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-indigo-500/50">
            <Sparkles className="h-3 w-3 mr-1 text-amber-400" />
            Premium
          </Badge>
        </h1>
        <p className="text-muted-foreground">Analisi avanzata con AI e gestione multi-sede</p>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <Tabs value={tab} onValueChange={setTab} className="bg-accent/20 p-1 rounded-lg">
          <TabsList className="bg-transparent">
            <TabsTrigger value="today" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Oggi</TabsTrigger>
            <TabsTrigger value="week" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Settimana</TabsTrigger>
            <TabsTrigger value="month" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Mese</TabsTrigger>
            <TabsTrigger value="quarter" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Trimestre</TabsTrigger>
            <TabsTrigger value="year" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Anno</TabsTrigger>
          </TabsList>
        </Tabs>

        <Tabs value={locationTab} onValueChange={setLocationTab} className="bg-accent/20 p-1 rounded-lg">
          <TabsList className="bg-transparent">
            <TabsTrigger value="all" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">
              <Globe className="h-4 w-4 mr-1" />
              Tutte le sedi
            </TabsTrigger>
            <TabsTrigger value="milan" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Milano</TabsTrigger>
            <TabsTrigger value="rome" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Roma</TabsTrigger>
            <TabsTrigger value="naples" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">Napoli</TabsTrigger>
            <TabsTrigger value="more" className="data-[state=active]:bg-white data-[state=active]:text-primary dark:data-[state=active]:bg-slate-800">+2</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border-indigo-500/20 animate-fade-up [animation-delay:150ms] overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
              <TrendingUpIcon className="h-4 w-4 mr-1.5 text-indigo-500" />
              Incasso Totale
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">€{restaurantStats.totalSales.toFixed(2)}</div>
              <div className="p-2 rounded-full bg-green-500/10 text-green-600 animate-pulse">
                <TrendingUpIcon className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-600 font-medium">
                +{restaurantStats.weeklyTrend}%
              </span>
              <span className="text-xs text-muted-foreground ml-2">
                rispetto alla scorsa settimana
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-purple-500/5 to-pink-500/5 border-purple-500/20 animate-fade-up [animation-delay:300ms] overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
              <ClipboardListIcon className="h-4 w-4 mr-1.5 text-purple-500" />
              Ordini Totali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.totalOrders}</div>
              <div className="p-2 rounded-full bg-blue-500/10 text-blue-600">
                <BarChart3Icon className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 font-medium">
                €{restaurantStats.averageOrder.toFixed(2)}
              </span>
              <span className="text-xs text-muted-foreground ml-2">
                scontrino medio
              </span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-pink-500/5 to-red-500/5 border-pink-500/20 animate-fade-up [animation-delay:450ms] overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
              <Store className="h-4 w-4 mr-1.5 text-pink-500" />
              Multi-sede
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.locations}</div>
              <div className="p-2 rounded-full bg-purple-500/10 text-purple-600">
                <Layers className="h-4 w-4" />
              </div>
            </div>
            <div className="text-xs text-muted-foreground mt-2 flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              <span>Tutte le sedi attive</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-red-500/5 to-orange-500/5 border-red-500/20 animate-fade-up [animation-delay:600ms] overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
              <UsersMultipleIcon className="h-4 w-4 mr-1.5 text-red-500" />
              Clienti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{restaurantStats.totalCustomers}</div>
              <div className="p-2 rounded-full bg-amber-500/10 text-amber-600">
                <ActivityIcon className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 font-medium">
                {restaurantStats.pendingReservations}
              </span>
              <span className="text-xs text-muted-foreground ml-2">
                prenotazioni in attesa
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="col-span-1 lg:col-span-2 animate-fade-up [animation-delay:750ms] overflow-hidden bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900/50 dark:to-slate-800/50 border border-indigo-500/20">
          <CardHeader className="bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-b border-indigo-500/20 flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="flex items-center">
                <AreaChart className="h-5 w-5 mr-2 text-indigo-500" />
                Analisi Vendite Avanzata
              </CardTitle>
              <CardDescription>
                Visualizzazione multi-dimensionale con previsioni AI
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Tabs value={chartType} onValueChange={setChartType} className="bg-white/50 dark:bg-slate-800/50 p-0.5 rounded-lg">
                <TabsList className="bg-transparent h-8">
                  <TabsTrigger value="sales" className="text-xs px-2 h-7 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700">
                    <BarChart4 className="h-3.5 w-3.5 mr-1" />
                    Vendite
                  </TabsTrigger>
                  <TabsTrigger value="forecast" className="text-xs px-2 h-7 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700">
                    <LineChart className="h-3.5 w-3.5 mr-1" />
                    Trend
                  </TabsTrigger>
                  <TabsTrigger value="comparison" className="text-xs px-2 h-7 data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700">
                    <PieChart className="h-3.5 w-3.5 mr-1" />
                    Confronto
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              <Button variant="outline" size="sm" className="h-8 bg-white/50 dark:bg-slate-800/50 border-indigo-500/20 hover:bg-white dark:hover:bg-slate-700">
                <ArrowUpDown className="h-3.5 w-3.5 mr-1.5" />
                Esporta
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-6 px-6 pb-6">
            <div className="h-[320px]">
              <SalesChart 
                data={salesData} 
                showPrediction 
                predictedValue={predictionsData.salesPrediction} 
                ultimateVersion={true}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="animate-fade-up [animation-delay:900ms] bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-slate-900/50 dark:to-slate-800/50 border border-purple-500/20">
          <CardHeader className="pb-2 border-b border-purple-500/10">
            <CardTitle className="flex items-center">
              <BrainCircuitIcon className="h-5 w-5 mr-2 text-purple-600" />
              Insights IA
            </CardTitle>
            <CardDescription>
              Analisi predittiva avanzata con intelligenza artificiale
            </CardDescription>
          </CardHeader>
          <CardContent className="py-4 space-y-4">
            <div className="grid grid-cols-3 gap-3">
              {aiInsights.map((insight, index) => (
                <Card 
                  key={index} 
                  className={`border ${index === selectedInsight ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20' : 'border-slate-200 dark:border-slate-700 bg-white/50 dark:bg-slate-800/50'} cursor-pointer hover:shadow-md transition-all duration-300 hover:-translate-y-0.5`}
                  onClick={() => setSelectedInsight(index)}
                >
                  <CardContent className="p-3">
                    <h4 className="font-medium text-sm">{insight.title}</h4>
                    <div className={`mt-2 text-xs px-1.5 py-0.5 rounded-full inline-flex items-center ${getImpactColor(insight.impact)}`}>
                      <Zap className="h-3 w-3 mr-1" />
                      {insight.impact}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <Card className="border-purple-200 dark:border-purple-900/30 bg-white/70 dark:bg-slate-800/50">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <h3 className="font-medium">{aiInsights[selectedInsight].title}</h3>
                  <Badge variant="outline" className={getImpactColor(aiInsights[selectedInsight].impact)}>
                    Impatto {aiInsights[selectedInsight].impact}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {aiInsights[selectedInsight].description}
                </p>
                
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center">
                    <Bot className="h-4 w-4 text-purple-500 mr-1.5" />
                    <span className="text-xs text-muted-foreground">Analisi basata su AI</span>
                  </div>
                  <Button size="sm" variant="secondary" className="text-xs h-8">
                    Approfondisci
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <div className="space-y-3">
              <PredictionCard 
                title="Vendite Previste Domani" 
                value={`€${predictionsData.salesPrediction.toFixed(2)}`}
                percentageIncrease={8.5}
                trend="up"
              />
              
              <PredictionCard 
                title="Clienti Attesi" 
                value={predictionsData.customersPrediction.toString()}
                percentageIncrease={12.2}
                trend="up"
              />
              
              <PredictionCard 
                title="Occupazione Stimata" 
                value={`${predictionsData.occupancyPrediction}%`}
                percentageIncrease={3.4}
                trend="up"
              />
            </div>
          </CardContent>
          
          <CardFooter className="pt-0 pb-3 px-6">
            <Button variant="ghost" className="w-full text-purple-600 border border-purple-200 dark:border-purple-800/30 hover:bg-purple-50 dark:hover:bg-purple-900/20 flex items-center justify-center">
              <Sparkles className="h-4 w-4 mr-2" />
              Visualizza Tutte le Previsioni
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="animate-fade-up [animation-delay:1050ms] bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-slate-900/50 dark:to-slate-800/50 border border-blue-500/20">
          <CardHeader className="border-b border-blue-500/10">
            <CardTitle className="flex items-center">
              <Code className="h-5 w-5 mr-2 text-blue-600" />
              API & Integrazioni
            </CardTitle>
            <CardDescription>
              API personalizzate per integrazione con sistemi esterni
            </CardDescription>
          </CardHeader>
          <CardContent className="py-4">
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-blue-100 dark:border-blue-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg mr-3">
                    <Blocks className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Webhook Ordini</p>
                    <p className="text-sm text-muted-foreground">Integrazione con sistemi esterni</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-blue-200 dark:border-blue-900/30 hover:bg-blue-50 dark:hover:bg-blue-900/20">
                  Configura
                </Button>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-blue-100 dark:border-blue-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg mr-3">
                    <BriefcaseIcon className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Integrazione ERP</p>
                    <div className="flex items-center">
                      <p className="text-sm text-muted-foreground">Sincronizzazione automatica</p>
                      <span className="ml-2 text-xs px-1.5 py-0.5 rounded-full bg-green-500/10 text-green-600">Attivo</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-blue-200 dark:border-blue-900/30 hover:bg-blue-50 dark:hover:bg-blue-900/20">
                  Gestisci
                </Button>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-blue-100 dark:border-blue-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg mr-3">
                    <Globe className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">API Prenotazioni</p>
                    <p className="text-sm text-muted-foreground">Per portali esterni</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-blue-200 dark:border-blue-900/30 hover:bg-blue-50 dark:hover:bg-blue-900/20">
                  Documenti
                </Button>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0 pb-3 px-6">
            <Button variant="ghost" className="w-full text-blue-600 border border-blue-200 dark:border-blue-800/30 hover:bg-blue-50 dark:hover:bg-blue-900/20 flex items-center justify-center">
              <Code className="h-4 w-4 mr-2" />
              Gestione API Avanzate
            </Button>
          </CardFooter>
        </Card>

        <Card className="animate-fade-up [animation-delay:1200ms] bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-slate-900/50 dark:to-slate-800/50 border border-emerald-500/20">
          <CardHeader className="border-b border-emerald-500/10">
            <CardTitle className="flex items-center">
              <Layers className="h-5 w-5 mr-2 text-emerald-600" />
              Gestione Multi-Sede
            </CardTitle>
            <CardDescription>
              Controllo centralizzato di tutte le location
            </CardDescription>
          </CardHeader>
          <CardContent className="py-4">
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-emerald-100 dark:border-emerald-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg mr-3">
                    <Store className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="font-medium">Milano</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <div className="w-16 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mr-2 overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{width: '92%'}}></div>
                      </div>
                      <span>Occupazione: 92%</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-emerald-200 dark:border-emerald-900/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20">
                  Dettagli
                </Button>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-emerald-100 dark:border-emerald-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg mr-3">
                    <Store className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="font-medium">Roma</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <div className="w-16 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mr-2 overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{width: '85%'}}></div>
                      </div>
                      <span>Occupazione: 85%</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-emerald-200 dark:border-emerald-900/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20">
                  Dettagli
                </Button>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-white/70 dark:bg-slate-800/50 rounded-lg border border-emerald-100 dark:border-emerald-900/20">
                <div className="flex items-center">
                  <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg mr-3">
                    <Store className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <p className="font-medium">Napoli</p>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <div className="w-16 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mr-2 overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{width: '88%'}}></div>
                      </div>
                      <span>Occupazione: 88%</span>
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-emerald-200 dark:border-emerald-900/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20">
                  Dettagli
                </Button>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0 pb-3 px-6">
            <Button variant="ghost" className="w-full text-emerald-600 border border-emerald-200 dark:border-emerald-800/30 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 flex items-center justify-center">
              <BoxesIcon className="h-4 w-4 mr-2" />
              Gestione Completa Multi-Sede
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mb-6">
        <Card className="p-3 border-amber-200 dark:border-amber-800/30 bg-amber-50/50 dark:bg-amber-900/10">
          <CardContent className="p-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center">
                <Shield className="h-8 w-8 text-amber-500 mr-3" />
                <div>
                  <h3 className="font-semibold">Ultimate Protection™</h3>
                  <p className="text-sm text-muted-foreground">Sicurezza avanzata e backup automatico attivi</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-amber-100 hover:bg-amber-200 text-amber-800 border-none">Backup quotidiano</Badge>
                <Badge className="bg-amber-100 hover:bg-amber-200 text-amber-800 border-none">Crittografia</Badge>
                <Badge className="bg-amber-100 hover:bg-amber-200 text-amber-800 border-none">Protezione dati</Badge>
                <Badge className="bg-amber-100 hover:bg-amber-200 text-amber-800 border-none">Supporto 24/7</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-up [animation-delay:1350ms]">
        <Link to="/rooms">
          <Card className="hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900/50 dark:to-slate-800/50 border-slate-300/30">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-indigo-500/10">
                <LayoutIcon className="h-5 w-5 text-indigo-500" />
              </div>
              <div>
                <h3 className="font-medium">Sale e Tavoli</h3>
                <p className="text-xs text-muted-foreground">Gestisci la disposizione</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/menu">
          <Card className="hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900/50 dark:to-slate-800/50 border-slate-300/30">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-purple-500/10">
                <ClipboardListIcon className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <h3 className="font-medium">Menu</h3>
                <p className="text-xs text-muted-foreground">Gestisci i tuoi piatti</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/reservations">
          <Card className="hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900/50 dark:to-slate-800/50 border-slate-300/30">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-pink-500/10">
                <CalendarIcon className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium">Prenotazioni</h3>
                <p className="text-xs text-muted-foreground">Gestisci le prenotazioni</p>
              </div>
            </CardContent>
          </Card>
        </Link>
        
        <Link to="/personale">
          <Card className="hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900/50 dark:to-slate-800/50 border-slate-300/30">
            <CardContent className="flex items-center p-4">
              <div className="flex-shrink-0 mr-3 p-2 rounded-full bg-blue-500/10">
                <UsersIcon className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium">Personale</h3>
                <p className="text-xs text-muted-foreground">Gestisci il tuo staff</p>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row mt-8 justify-end gap-4">
        <Button variant="outline" size="sm" className="flex items-center border-indigo-200 dark:border-indigo-800/30">
          <Download className="mr-2 h-4 w-4" />
          Esporta Report Completo
        </Button>
        <Button variant="secondary" size="sm" className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:from-indigo-600 hover:to-purple-600 border-none">
          <BrainCircuitIcon className="mr-2 h-4 w-4" />
          Analisi Predittiva Avanzata
        </Button>
      </div>
    </div>
  );
}
