
import React from 'react';
import { InventoryItem } from '@/contexts/InventoryContext';
import { Button } from '@/components/ui/button';
import { Clock, AlertTriangle } from 'lucide-react';

interface ExpiringItemsAlertProps {
  items: InventoryItem[];
  onManageItem?: (itemId: string) => void;
}

export function ExpiringItemsAlert({ items, onManageItem }: ExpiringItemsAlertProps) {
  if (items.length === 0) {
    return (
      <div className="text-center p-4 text-muted-foreground">
        <p>Nessun prodotto in scadenza nei prossimi 14 giorni.</p>
      </div>
    );
  }

  // Format date in Italian format
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT');
  };

  // Calculate days until expiration
  const getDaysUntilExpiration = (dateString?: string) => {
    if (!dateString) return 0;
    const expiryDate = new Date(dateString);
    const today = new Date();
    const diffTime = expiryDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="space-y-3">
      {items.map((item) => {
        // Use expiryDate with fallback to expirationDate for compatibility
        const expiryDate = item.expiryDate || item.expirationDate;
        const daysLeft = getDaysUntilExpiration(expiryDate);
        const isUrgent = daysLeft <= 3;
        
        return (
          <div 
            key={item.id} 
            className={`flex items-center justify-between p-2 border rounded-md ${
              isUrgent ? 'bg-red-50 border-red-200' : 'bg-orange-50 border-orange-200'
            }`}
          >
            <div className="flex items-center">
              {isUrgent ? (
                <AlertTriangle className="w-4 h-4 text-red-500 mr-2" />
              ) : (
                <Clock className="w-4 h-4 text-orange-500 mr-2" />
              )}
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-xs text-muted-foreground">
                  Scadenza: {formatDate(expiryDate)} ({daysLeft} giorni)
                </p>
              </div>
            </div>
            <Button 
              size="sm" 
              variant="outline" 
              className={`ml-2 ${isUrgent ? 'border-red-300 hover:bg-red-100' : 'border-orange-300 hover:bg-orange-100'}`}
              onClick={() => onManageItem && onManageItem(item.id)}
            >
              Gestisci
            </Button>
          </div>
        );
      })}
    </div>
  );
}
