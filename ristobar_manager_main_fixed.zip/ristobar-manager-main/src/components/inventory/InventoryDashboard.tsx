
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  ShoppingCart, 
  PackageOpen, 
  TrendingDown, 
  AlertCircle, 
  Clock, 
  DollarSign, 
  BarChart3, 
  Bell
} from 'lucide-react';
import { useInventory } from '@/contexts/InventoryContext';
import { LowStockAlert } from './LowStockAlert';
import { ExpiringItemsAlert } from './ExpiringItemsAlert';
import { InventoryStatusChart } from './InventoryStatusChart';
import { RecentActivityList } from './RecentActivityList';
import { NotificationsList } from './NotificationsList';

export function InventoryDashboard() {
  const { 
    items, 
    orders, 
    getLowStockItems, 
    getExpiringItems, 
    notifications 
  } = useInventory();
  
  const lowStockItems = getLowStockItems();
  const expiringItems = getExpiringItems();
  const unreadNotifications = notifications.filter(n => !n.read);
  
  // Calcola il valore totale dell'inventario
  const totalInventoryValue = items.reduce((total, item) => 
    total + (item.quantity * item.unitPrice), 0).toFixed(2);
  
  // Calcola il valore degli ordini in sospeso
  const pendingOrdersValue = orders
    .filter(order => order.status === 'pending' || order.status === 'in-transit')
    .reduce((total, order) => total + order.totalAmount, 0).toFixed(2);

  // Data per i grafici mensili - array vuoti di default
  const months = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago'];
  const consumptionData = [0, 0, 0, 0, 0, 0, 0, 0];
  const orderData = [0, 0, 0, 0, 0, 0, 0, 0];
  
  return (
    <div className="space-y-6">
      {/* Statistiche principali */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Prodotti totali</CardTitle>
            <PackageOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{items.length}</div>
            <p className="text-xs text-muted-foreground">
              {lowStockItems.length} sotto soglia minima
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Valore inventario</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">€{totalInventoryValue}</div>
            <p className="text-xs text-muted-foreground">
              Valore totale dei prodotti
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ordini in corso</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {orders.filter(o => o.status === 'pending' || o.status === 'in-transit').length}
            </div>
            <p className="text-xs text-muted-foreground">
              Valore: €{pendingOrdersValue}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Notifiche</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{unreadNotifications.length}</div>
            <p className="text-xs text-muted-foreground">
              {lowStockItems.length} avvisi di scorta, {expiringItems.length} in scadenza
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Avvisi ed elementi in scadenza */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-amber-500" />
              Prodotti sotto scorta minima
            </CardTitle>
            <CardDescription>
              Articoli che richiedono rifornimento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <LowStockAlert items={lowStockItems} />
          </CardContent>
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-orange-500" />
              Prodotti in scadenza
            </CardTitle>
            <CardDescription>
              Articoli che scadranno entro 14 giorni
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ExpiringItemsAlert items={expiringItems} />
          </CardContent>
        </Card>
      </div>
      
      {/* Grafici e analisi */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Analisi consumi e ordini</CardTitle>
            <CardDescription>
              Confronto tra consumo prodotti e ordini effettuati
            </CardDescription>
          </CardHeader>
          <CardContent>
            <InventoryStatusChart 
              labels={months} 
              consumption={consumptionData} 
              orders={orderData} 
            />
          </CardContent>
        </Card>
        
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Notifiche recenti</CardTitle>
            <CardDescription>
              Aggiornamenti e avvisi del sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <NotificationsList 
              notifications={notifications.slice(0, 5)} 
              showMarkAsRead={true} 
            />
            {notifications.length > 5 && (
              <Button variant="link" className="mt-2 w-full">
                Visualizza tutte ({notifications.length})
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Attività recenti */}
      <Card>
        <CardHeader>
          <CardTitle>Attività recenti</CardTitle>
          <CardDescription>
            Ultimi aggiornamenti dell'inventario e ordini
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RecentActivityList items={items} orders={orders} maxItems={5} />
        </CardContent>
      </Card>
    </div>
  );
}
