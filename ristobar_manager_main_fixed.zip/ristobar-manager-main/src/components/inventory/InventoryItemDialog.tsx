
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  useInventory, 
  InventoryItem, 
  UnitOfMeasure, 
  InventoryItemCategory 
} from '@/contexts/InventoryContext';
import { useToast } from '@/hooks/use-toast';

interface InventoryItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  itemToEdit: InventoryItem | null;
}

export function InventoryItemDialog({ open, onOpenChange, itemToEdit }: InventoryItemDialogProps) {
  const { addItem, updateItem, suppliers } = useInventory();
  const { toast } = useToast();
  
  // State per i campi del form
  const [name, setName] = useState('');
  const [category, setCategory] = useState<InventoryItemCategory>('food-dry');
  const [quantity, setQuantity] = useState('0');
  const [unitOfMeasure, setUnitOfMeasure] = useState<UnitOfMeasure>('pcs');
  const [minQuantity, setMinQuantity] = useState('0');
  const [unitPrice, setUnitPrice] = useState('0');
  const [expirationDate, setExpirationDate] = useState('');
  const [supplierId, setSupplierId] = useState('');
  const [location, setLocation] = useState('');
  const [barcode, setBarcode] = useState('');
  
  // Popoliamo i campi se stiamo modificando un articolo esistente
  useEffect(() => {
    if (itemToEdit) {
      setName(itemToEdit.name);
      setCategory(itemToEdit.category);
      setQuantity(itemToEdit.quantity.toString());
      setUnitOfMeasure((itemToEdit.unit || itemToEdit.unitOfMeasure || 'pcs') as UnitOfMeasure);
      setMinQuantity((itemToEdit.minStockLevel || itemToEdit.minQuantity || 0).toString());
      setUnitPrice(itemToEdit.unitPrice.toString());
      setExpirationDate(itemToEdit.expiryDate || itemToEdit.expirationDate || '');
      setSupplierId(itemToEdit.supplier);
      setLocation(itemToEdit.location || '');
      setBarcode(itemToEdit.barcode || '');
    } else {
      // Reset dei campi se stiamo creando un nuovo articolo
      setName('');
      setCategory('food-dry');
      setQuantity('0');
      setUnitOfMeasure('pcs');
      setMinQuantity('0');
      setUnitPrice('0');
      setExpirationDate('');
      setSupplierId(suppliers.length > 0 ? suppliers[0].id : '');
      setLocation('');
      setBarcode('');
    }
  }, [itemToEdit, suppliers]);
  
  // Gestisce il salvataggio del form
  const handleSave = () => {
    if (!name || !category || !unitOfMeasure || !supplierId) {
      toast({
        variant: "destructive",
        title: "Errore di validazione",
        description: "Tutti i campi obbligatori devono essere compilati.",
      });
      return;
    }
    
    const itemData = {
      name,
      category,
      quantity: Number(quantity),
      unit: unitOfMeasure,
      minStockLevel: Number(minQuantity),
      unitPrice: Number(unitPrice),
      expiryDate: expirationDate || undefined,
      supplier: supplierId,
      location: location || undefined,
      barcode: barcode || undefined,
    };
    
    if (itemToEdit) {
      // Stiamo modificando un articolo esistente
      updateItem(itemToEdit.id, itemData);
      toast({
        title: "Articolo aggiornato",
        description: `${name} è stato aggiornato con successo.`,
      });
    } else {
      // Stiamo creando un nuovo articolo
      addItem(itemData);
      toast({
        title: "Articolo aggiunto",
        description: `${name} è stato aggiunto all'inventario.`,
      });
    }
    
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            {itemToEdit ? `Modifica ${itemToEdit.name}` : 'Aggiungi nuovo prodotto'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome prodotto *</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nome del prodotto"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="category">Categoria *</Label>
              <Select value={category} onValueChange={(value: InventoryItemCategory) => setCategory(value)}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Seleziona categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="food-fresh">Alimenti freschi</SelectItem>
                  <SelectItem value="food-frozen">Alimenti surgelati</SelectItem>
                  <SelectItem value="food-dry">Alimenti secchi</SelectItem>
                  <SelectItem value="beverages-alcoholic">Bevande alcoliche</SelectItem>
                  <SelectItem value="beverages-non-alcoholic">Bevande analcoliche</SelectItem>
                  <SelectItem value="cleaning">Prodotti pulizia</SelectItem>
                  <SelectItem value="equipment">Attrezzature</SelectItem>
                  <SelectItem value="other">Altro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantità *</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                step="0.01"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="unitOfMeasure">Unità di misura *</Label>
              <Select value={unitOfMeasure} onValueChange={(value: UnitOfMeasure) => setUnitOfMeasure(value)}>
                <SelectTrigger id="unitOfMeasure">
                  <SelectValue placeholder="Seleziona unità" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kg">Chilogrammi (kg)</SelectItem>
                  <SelectItem value="g">Grammi (g)</SelectItem>
                  <SelectItem value="l">Litri (l)</SelectItem>
                  <SelectItem value="ml">Millilitri (ml)</SelectItem>
                  <SelectItem value="pcs">Pezzi (pz)</SelectItem>
                  <SelectItem value="box">Scatole (sc)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="minQuantity">Quantità minima</Label>
              <Input
                id="minQuantity"
                type="number"
                min="0"
                step="0.01"
                value={minQuantity}
                onChange={(e) => setMinQuantity(e.target.value)}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="unitPrice">Prezzo unitario (€) *</Label>
              <Input
                id="unitPrice"
                type="number"
                min="0"
                step="0.01"
                value={unitPrice}
                onChange={(e) => setUnitPrice(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="expirationDate">Data di scadenza</Label>
              <Input
                id="expirationDate"
                type="date"
                value={expirationDate}
                onChange={(e) => setExpirationDate(e.target.value)}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="supplier">Fornitore *</Label>
              <Select value={supplierId} onValueChange={setSupplierId}>
                <SelectTrigger id="supplier">
                  <SelectValue placeholder="Seleziona fornitore" />
                </SelectTrigger>
                <SelectContent>
                  {suppliers.map((supplier) => (
                    <SelectItem key={supplier.id} value={supplier.id}>
                      {supplier.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="location">Posizione in magazzino</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="es. Scaffale A1"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="barcode">Codice a barre</Label>
            <Input
              id="barcode"
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              placeholder="Scansiona o inserisci codice a barre"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annulla
          </Button>
          <Button onClick={handleSave}>
            {itemToEdit ? 'Aggiorna' : 'Aggiungi'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
