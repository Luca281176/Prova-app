import { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Plus, 
  Filter, 
  Download, 
  Upload, 
  Edit, 
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Loader2
} from 'lucide-react';
import { useInventory, InventoryItem } from '@/contexts/InventoryContext';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { InventoryItemDialog } from './InventoryItemDialog';
import { useToast } from '@/hooks/use-toast';
import { ConfirmDialog } from '@/components/ConfirmDialog';

// Componente per gestire l'elenco dell'inventario
export function InventoryList() {
  const { items, suppliers, updateItem, deleteItem, loading } = useInventory();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [itemToEdit, setItemToEdit] = useState<InventoryItem | null>(null);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [deletingItems, setDeletingItems] = useState(false);
  const { toast } = useToast();
  
  // Reset selected items when items list changes
  useEffect(() => {
    if (items.length === 0 && selectedItems.length > 0) {
      setSelectedItems([]);
    }
  }, [items, selectedItems]);
  
  // Filtra gli articoli in base alla ricerca e alla categoria
  const filteredItems = items.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      suppliers.find(s => s.id === item.supplier)?.name.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });
  
  // Gestisce l'apertura del dialogo di modifica
  const handleEditItem = (item: InventoryItem) => {
    setItemToEdit(item);
    setShowAddDialog(true);
  };
  
  // Gestisce l'eliminazione di un articolo
  const handleDeleteItem = (id: string) => {
    setItemToDelete(id);
    setShowDeleteDialog(true);
  };

  // Conferma l'eliminazione di un articolo
  const confirmDeleteItem = async () => {
    if (!itemToDelete) return;
    
    try {
      await deleteItem(itemToDelete);
      toast({
        title: "Articolo eliminato",
        description: "L'articolo è stato rimosso dall'inventario",
      });
      setItemToDelete(null);
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  // Gestisce l'eliminazione di più articoli selezionati
  const handleDeleteSelected = () => {
    setDeletingItems(true);
    setShowDeleteDialog(true);
  };

  // Conferma l'eliminazione di più articoli selezionati
  const confirmDeleteSelected = async () => {
    try {
      // Delete items one by one
      for (const id of selectedItems) {
        await deleteItem(id);
      }
      
      toast({
        title: "Articoli eliminati",
        description: `${selectedItems.length} articoli sono stati rimossi dall'inventario`,
      });
      
      setSelectedItems([]);
    } catch (error) {
      console.error('Error deleting selected items:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'eliminazione degli articoli",
        variant: "destructive"
      });
    }
  };
  
  // Controlla se un articolo è sotto scorta
  const isLowStock = (item: InventoryItem) => item.quantity <= (item.minStockLevel || item.minQuantity || 0);
  
  // Controlla se un articolo sta per scadere (entro 14 giorni)
  const isExpiringSoon = (item: InventoryItem) => {
    // Check both expiryDate and expirationDate for compatibility
    const expiryDate = item.expiryDate || item.expirationDate;
    if (!expiryDate) return false;
    
    const expirationDate = new Date(expiryDate);
    const today = new Date();
    const twoWeeksLater = new Date(today);
    twoWeeksLater.setDate(today.getDate() + 14);
    return expirationDate <= twoWeeksLater && expirationDate >= today;
  };
  
  // Gestisce la selezione di tutti gli elementi
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(filteredItems.map(item => item.id));
    } else {
      setSelectedItems([]);
    }
  };
  
  // Gestisce la selezione di un singolo elemento
  const handleSelectItem = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedItems(prev => [...prev, id]);
    } else {
      setSelectedItems(prev => prev.filter(itemId => itemId !== id));
    }
  };

  // Ottiene il nome del fornitore da ID
  const getSupplierName = (supplierId: string) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    return supplier ? supplier.name : 'N/A';
  };
  
  // Formatta la data in formato italiano
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('it-IT');
  };
  
  // Ottiene l'etichetta della categoria
  const getCategoryLabel = (category: string) => {
    const categories: Record<string, string> = {
      'food-fresh': 'Alimenti freschi',
      'food-frozen': 'Alimenti surgelati',
      'food-dry': 'Alimenti secchi',
      'beverages-alcoholic': 'Bevande alcoliche',
      'beverages-non-alcoholic': 'Bevande analcoliche',
      'cleaning': 'Prodotti pulizia',
      'equipment': 'Attrezzature',
      'other': 'Altro'
    };
    
    return categories[category] || category;
  };
  
  // Funzione di esportazione dati (placeholder)
  const handleExportData = () => {
    toast({
      title: "Esportazione dati",
      description: "La funzione di esportazione sarà disponibile presto",
    });
  };
  
  // Funzione di importazione dati (placeholder)
  const handleImportData = () => {
    toast({
      title: "Importazione dati",
      description: "La funzione di importazione sarà disponibile presto",
    });
  };
  
  return (
    <div className="space-y-4">
      {/* Barra degli strumenti */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-1 items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Cerca prodotti o fornitori..."
              className="w-full pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutte le categorie</SelectItem>
              <SelectItem value="food-fresh">Alimenti freschi</SelectItem>
              <SelectItem value="food-frozen">Alimenti surgelati</SelectItem>
              <SelectItem value="food-dry">Alimenti secchi</SelectItem>
              <SelectItem value="beverages-alcoholic">Bevande alcoliche</SelectItem>
              <SelectItem value="beverages-non-alcoholic">Bevande analcoliche</SelectItem>
              <SelectItem value="cleaning">Prodotti pulizia</SelectItem>
              <SelectItem value="equipment">Attrezzature</SelectItem>
              <SelectItem value="other">Altro</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-2 flex-wrap md:flex-nowrap">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filtri avanzati
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportData}>
            <Download className="mr-2 h-4 w-4" />
            Esporta
          </Button>
          <Button variant="outline" size="sm" onClick={handleImportData}>
            <Upload className="mr-2 h-4 w-4" />
            Importa
          </Button>
          <Button size="sm" onClick={() => {
            setItemToEdit(null);
            setShowAddDialog(true);
          }}>
            <Plus className="mr-2 h-4 w-4" />
            Nuovo prodotto
          </Button>
        </div>
      </div>
      
      {/* Loading state */}
      {loading && (
        <div className="flex justify-center items-center h-40">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2 text-lg">Caricamento inventario...</span>
        </div>
      )}
      
      {/* Funzioni di massa quando elementi selezionati */}
      {!loading && selectedItems.length > 0 && (
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                {selectedItems.length} {selectedItems.length === 1 ? 'prodotto selezionato' : 'prodotti selezionati'}
              </span>
              <div className="flex items-center gap-2 flex-wrap md:flex-nowrap">
                <Button variant="outline" size="sm">
                  Aggiungi all'ordine
                </Button>
                <Button variant="outline" size="sm">
                  Modifica in blocco
                </Button>
                <Button variant="destructive" size="sm" onClick={handleDeleteSelected}>
                  Elimina selezionati
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Tabella inventario */}
      {!loading && (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">
                  <Checkbox 
                    checked={filteredItems.length > 0 && selectedItems.length === filteredItems.length}
                    onCheckedChange={(checked) => handleSelectAll(checked as boolean)}
                  />
                </TableHead>
                <TableHead>Prodotto</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-right">Quantità</TableHead>
                <TableHead className="text-right">Prezzo unitario</TableHead>
                <TableHead>Fornitore</TableHead>
                <TableHead>Scadenza</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="h-24 text-center">
                    Nessun prodotto trovato.
                  </TableCell>
                </TableRow>
              ) : (
                filteredItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Checkbox 
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={(checked) => handleSelectItem(item.id, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{getCategoryLabel(item.category)}</TableCell>
                    <TableCell className="text-right">
                      {item.quantity} {item.unit || item.unitOfMeasure || 'pz'}
                    </TableCell>
                    <TableCell className="text-right">€{item.unitPrice.toFixed(2)}</TableCell>
                    <TableCell>{getSupplierName(item.supplier)}</TableCell>
                    <TableCell>{formatDate(item.expiryDate || item.expirationDate)}</TableCell>
                    <TableCell>
                      {isLowStock(item) ? (
                        <Badge variant="destructive" className="flex items-center gap-1">
                          <AlertTriangle className="h-3 w-3" />
                          Sotto scorta
                        </Badge>
                      ) : isExpiringSoon(item) ? (
                        <Badge variant="secondary" className="flex items-center gap-1 bg-orange-500">
                          <Clock className="h-3 w-3" />
                          In scadenza
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="flex items-center gap-1 bg-green-500 hover:bg-green-600">
                          <CheckCircle2 className="h-3 w-3" />
                          Normale
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={() => handleEditItem(item)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteItem(item.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Dialogo per aggiungere/modificare un articolo */}
      {showAddDialog && (
        <InventoryItemDialog 
          open={showAddDialog} 
          onOpenChange={setShowAddDialog} 
          itemToEdit={itemToEdit} 
        />
      )}
      
      {/* Dialogo di conferma eliminazione */}
      <ConfirmDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        onConfirm={deletingItems ? confirmDeleteSelected : confirmDeleteItem}
        title={deletingItems 
          ? "Elimina articoli selezionati" 
          : "Elimina articolo"
        }
        description={deletingItems
          ? `Sei sicuro di voler eliminare ${selectedItems.length} articoli? Questa azione non può essere annullata.`
          : "Sei sicuro di voler eliminare questo articolo? Questa azione non può essere annullata."
        }
        confirmText="Elimina"
        cancelText="Annulla"
        variant="destructive"
      />
    </div>
  );
}
