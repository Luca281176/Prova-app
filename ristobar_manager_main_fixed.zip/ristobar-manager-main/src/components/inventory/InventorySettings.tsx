
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  saveInventorySettings, 
  loadInventorySettings, 
  type InventorySettings as InventorySettingsType 
} from '@/services/settingsService';
import { useUser } from '@/contexts/user/UserProvider';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription, FeatureAccessLevel } from '@/services/subscriptions/types';
import { hasSubscriptionLevel } from '@/services/subscriptions';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';

interface InternalSettings {
  lowStockNotifications: boolean;
  expirationNotifications: boolean;
  daysBeforeExpiration: string;
  emailNotifications: boolean;
  emailAddress: string;
  defaultView: string;
  itemsPerPage: string;
  defaultSorting: string;
  autoUpdateQuantity: boolean;
  barcodeScanning: boolean;
  exportFormat: string;
}

const defaultInternalSettings: InternalSettings = {
  lowStockNotifications: true,
  expirationNotifications: true,
  daysBeforeExpiration: '14',
  emailNotifications: false,
  emailAddress: '',
  defaultView: 'dashboard',
  itemsPerPage: '20',
  defaultSorting: 'name-asc',
  autoUpdateQuantity: true,
  barcodeScanning: true,
  exportFormat: 'csv'
};

const defaultServiceSettings: InventorySettingsType = {
  lowStockThreshold: 10,
  expiryWarningDays: 14,
  autoOrderEnabled: true,
  orderNotifications: true,
  preferredSuppliers: []
};

export function InventorySettings() {
  const [internalSettings, setInternalSettings] = useState<InternalSettings>(defaultInternalSettings);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [isLoadingSubscription, setIsLoadingSubscription] = useState(true);
  const { user } = useUser();
  
  // Check if user has access to system settings (Pro+ plan)
  const hasAdvancedAccess = hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO);
  
  useEffect(() => {
    const fetchSubscription = async () => {
      if (user?.id) {
        try {
          const subscription = await getUserSubscription(user.id);
          setUserSubscription(subscription as unknown as UserSubscription);
        } catch (error) {
          console.error("Error fetching subscription:", error);
          setUserSubscription(null);
        }
      }
      setIsLoadingSubscription(false);
    };
    
    fetchSubscription();
  }, [user?.id]);
  
  useEffect(() => {
    const savedSettings = loadInventorySettings(user?.id);
    if (savedSettings) {
      setInternalSettings({
        ...defaultInternalSettings,
        lowStockNotifications: savedSettings.orderNotifications,
        expirationNotifications: true,
        daysBeforeExpiration: savedSettings.expiryWarningDays.toString(),
        emailNotifications: false,
        emailAddress: '',
        defaultView: 'dashboard',
        itemsPerPage: '20',
        defaultSorting: 'name-asc',
        autoUpdateQuantity: savedSettings.autoOrderEnabled,
        barcodeScanning: true,
        exportFormat: 'csv'
      });
      
      toast({
        title: "Impostazioni caricate",
        description: "Le impostazioni salvate sono state caricate con successo",
      });
    }
  }, [user?.id]);

  const handleSaveSettings = () => {
    const serviceSettings: InventorySettingsType = {
      lowStockThreshold: 10,
      expiryWarningDays: parseInt(internalSettings.daysBeforeExpiration, 10),
      autoOrderEnabled: internalSettings.autoUpdateQuantity,
      orderNotifications: internalSettings.lowStockNotifications,
      preferredSuppliers: []
    };
    
    const saveSuccess = saveInventorySettings(serviceSettings, user?.id);
    
    if (saveSuccess) {
      toast({
        title: "Impostazioni salvate",
        description: "Le impostazioni del magazzino sono state aggiornate",
      });
    } else {
      toast({
        title: "Errore di salvataggio",
        description: "Non è stato possibile salvare le impostazioni. Spazio di archiviazione insufficiente.",
        variant: "destructive"
      });
    }
  };

  const updateSetting = <K extends keyof InternalSettings>(key: K, value: InternalSettings[K]) => {
    setInternalSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const handleResetSettings = () => {
    setInternalSettings(defaultInternalSettings);
    saveInventorySettings(defaultServiceSettings);
    
    toast({
      title: "Impostazioni ripristinate",
      description: "Le impostazioni sono state ripristinate ai valori predefiniti.",
    });
  };
  
  if (isLoadingSubscription) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Notifiche</CardTitle>
          <CardDescription>
            Configura come e quando ricevere notifiche relative al magazzino
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="low-stock">Notifiche scorte basse</Label>
              <p className="text-sm text-muted-foreground">
                Ricevi avvisi quando un prodotto scende sotto la soglia minima
              </p>
            </div>
            <Switch 
              id="low-stock" 
              checked={internalSettings.lowStockNotifications} 
              onCheckedChange={(value) => updateSetting('lowStockNotifications', value)} 
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="expiration">Notifiche scadenze</Label>
              <p className="text-sm text-muted-foreground">
                Ricevi avvisi quando i prodotti sono prossimi alla scadenza
              </p>
            </div>
            <Switch 
              id="expiration" 
              checked={internalSettings.expirationNotifications} 
              onCheckedChange={(value) => updateSetting('expirationNotifications', value)} 
            />
          </div>
          
          {internalSettings.expirationNotifications && (
            <div className="ml-6 space-y-2">
              <Label htmlFor="expiration-days">Giorni prima della scadenza</Label>
              <Input
                id="expiration-days"
                type="number"
                min="1"
                max="90"
                value={internalSettings.daysBeforeExpiration}
                onChange={(e) => updateSetting('daysBeforeExpiration', e.target.value)}
                className="w-20"
              />
            </div>
          )}
          
          {hasAdvancedAccess && (
            <>
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-notifications">Notifiche via email</Label>
                  <p className="text-sm text-muted-foreground">
                    Ricevi le notifiche anche via email
                  </p>
                </div>
                <Switch 
                  id="email-notifications" 
                  checked={internalSettings.emailNotifications} 
                  onCheckedChange={(value) => updateSetting('emailNotifications', value)} 
                />
              </div>
              
              {internalSettings.emailNotifications && (
                <div className="ml-6 space-y-2">
                  <Label htmlFor="email-address">Indirizzo email</Label>
                  <Input
                    id="email-address"
                    type="email"
                    value={internalSettings.emailAddress}
                    onChange={(e) => updateSetting('emailAddress', e.target.value)}
                    placeholder="esempio@ristorante.com"
                  />
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Visualizzazione</CardTitle>
          <CardDescription>
            Personalizza come visualizzare i dati del magazzino
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="default-view">Vista predefinita</Label>
            <Select 
              value={internalSettings.defaultView} 
              onValueChange={(value) => updateSetting('defaultView', value)}
            >
              <SelectTrigger id="default-view">
                <SelectValue placeholder="Seleziona vista predefinita" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dashboard">Dashboard</SelectItem>
                <SelectItem value="inventory">Inventario</SelectItem>
                <SelectItem value="suppliers">Fornitori</SelectItem>
                <SelectItem value="orders">Ordini</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="items-per-page">Elementi per pagina</Label>
            <Select 
              value={internalSettings.itemsPerPage} 
              onValueChange={(value) => updateSetting('itemsPerPage', value)}
            >
              <SelectTrigger id="items-per-page">
                <SelectValue placeholder="Seleziona elementi per pagina" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="20">20</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="default-sorting">Ordinamento predefinito</Label>
            <Select 
              value={internalSettings.defaultSorting} 
              onValueChange={(value) => updateSetting('defaultSorting', value)}
            >
              <SelectTrigger id="default-sorting">
                <SelectValue placeholder="Seleziona ordinamento predefinito" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                <SelectItem value="quantity-asc">Quantità (crescente)</SelectItem>
                <SelectItem value="quantity-desc">Quantità (decrescente)</SelectItem>
                <SelectItem value="price-asc">Prezzo (crescente)</SelectItem>
                <SelectItem value="price-desc">Prezzo (decrescente)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
      
      {hasAdvancedAccess ? (
        <Card>
          <CardHeader>
            <CardTitle>Sistema</CardTitle>
            <CardDescription>
              Configura il comportamento del sistema di gestione magazzino
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-update">Aggiornamento automatico quantità</Label>
                <p className="text-sm text-muted-foreground">
                  Aggiorna automaticamente le quantità in base agli ordini
                </p>
              </div>
              <Switch 
                id="auto-update" 
                checked={internalSettings.autoUpdateQuantity} 
                onCheckedChange={(value) => updateSetting('autoUpdateQuantity', value)} 
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="barcode">Scansione codici a barre</Label>
                <p className="text-sm text-muted-foreground">
                  Abilita la scansione di codici a barre per la gestione veloce
                </p>
              </div>
              <Switch 
                id="barcode" 
                checked={internalSettings.barcodeScanning} 
                onCheckedChange={(value) => updateSetting('barcodeScanning', value)} 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="export-format">Formato esportazione dati</Label>
              <Select 
                value={internalSettings.exportFormat} 
                onValueChange={(value) => updateSetting('exportFormat', value)}
              >
                <SelectTrigger id="export-format">
                  <SelectValue placeholder="Seleziona formato esportazione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      ) : (
        <PlanFeatureAlert
          title="Impostazioni di sistema avanzate non disponibili"
          description="Le impostazioni avanzate di sistema sono disponibili solo per gli abbonamenti Pro e Ultimate."
          availableInPlans={['Pro', 'Ultimate']}
          buttonText="Aggiorna il tuo piano"
          buttonLink="/subscriptions"
        />
      )}
      
      <div className="flex justify-end">
        <Button variant="outline" className="mr-2" onClick={handleResetSettings}>
          Ripristina impostazioni predefinite
        </Button>
        <Button onClick={handleSaveSettings}>
          Salva impostazioni
        </Button>
      </div>
    </div>
  );
}
