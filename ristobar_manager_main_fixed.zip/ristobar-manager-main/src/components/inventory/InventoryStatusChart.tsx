
import React from 'react';
import { 
  Area, 
  AreaChart, 
  Bar, 
  BarChart, 
  CartesianGrid, 
  Legend, 
  ResponsiveContainer, 
  Tooltip, 
  XAxis, 
  YAxis 
} from 'recharts';

interface InventoryStatusChartProps {
  labels: string[];
  consumption: number[];
  orders: number[];
}

export function InventoryStatusChart({ labels, consumption, orders }: InventoryStatusChartProps) {
  // Prepariamo i dati per il grafico
  const data = labels.map((month, index) => ({
    name: month,
    consumo: consumption[index],
    ordini: orders[index]
  }));

  return (
    <ResponsiveContainer width="100%" height={300}>
      <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="colorConsumption" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
            <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1}/>
          </linearGradient>
          <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8}/>
            <stop offset="95%" stopColor="#82ca9d" stopOpacity={0.1}/>
          </linearGradient>
        </defs>
        <XAxis dataKey="name" />
        <YAxis />
        <CartesianGrid strokeDasharray="3 3" />
        <Tooltip />
        <Legend />
        <Area 
          type="monotone" 
          dataKey="consumo" 
          name="Consumo" 
          stroke="#8884d8" 
          fillOpacity={1} 
          fill="url(#colorConsumption)" 
        />
        <Area 
          type="monotone" 
          dataKey="ordini" 
          name="Ordini" 
          stroke="#82ca9d" 
          fillOpacity={1} 
          fill="url(#colorOrders)" 
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
