
import React from 'react';
import { InventoryItem } from '@/contexts/InventoryContext';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ShoppingCart } from 'lucide-react';

interface LowStockAlertProps {
  items: InventoryItem[];
}

export function LowStockAlert({ items }: LowStockAlertProps) {
  if (items.length === 0) {
    return (
      <div className="text-center p-4 text-muted-foreground">
        <p>Nessun prodotto sotto scorta minima.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div 
          key={item.id} 
          className="flex items-center justify-between p-2 border rounded-md bg-amber-50"
        >
          <div className="flex items-center">
            <AlertTriangle className="w-4 h-4 text-amber-500 mr-2" />
            <div>
              <p className="font-medium">{item.name}</p>
              <p className="text-xs text-muted-foreground">
                Disponibili: {item.quantity} {item.unit || item.unitOfMeasure} (min. {item.minStockLevel || item.minQuantity})
              </p>
            </div>
          </div>
          <Button size="sm" variant="outline" className="ml-2">
            <ShoppingCart className="h-4 w-4 mr-1" />
            Ordina
          </Button>
        </div>
      ))}
    </div>
  );
}
