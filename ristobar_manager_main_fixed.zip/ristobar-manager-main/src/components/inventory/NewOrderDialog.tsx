
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useInventory, InventoryItem } from "@/contexts/InventoryContext";
import { Calendar as CalendarIcon, X, Minus, Plus, Trash2 } from 'lucide-react';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";

type OrderItemForm = {
  itemId: string;
  quantity: number;
  unitPrice: number;
  name?: string; // For display purposes
};

type NewOrderDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function NewOrderDialog({ open, onOpenChange }: NewOrderDialogProps) {
  const { suppliers, items, createOrder } = useInventory();
  const { toast } = useToast();
  
  const [supplierId, setSupplierId] = useState<string>("");
  const [orderItems, setOrderItems] = useState<OrderItemForm[]>([]);
  const [availableItems, setAvailableItems] = useState<InventoryItem[]>([]);
  const [notes, setNotes] = useState<string>("");
  const [expectedDelivery, setExpectedDelivery] = useState<Date | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Aggiorna la lista di prodotti disponibili quando cambia il fornitore
  useEffect(() => {
    if (supplierId) {
      const filteredItems = items.filter(item => item.supplier === supplierId);
      setAvailableItems(filteredItems);
      setOrderItems([]); // Reset items when supplier changes
    } else {
      setAvailableItems([]);
      setOrderItems([]);
    }
  }, [supplierId, items]);
  
  // Calcola il totale dell'ordine
  const orderTotal = orderItems.reduce((total, item) => {
    return total + (item.quantity * item.unitPrice);
  }, 0);
  
  // Aggiunge un articolo all'ordine
  const handleAddItem = () => {
    if (availableItems.length === 0) return;
    
    const firstItem = availableItems[0];
    const newItem: OrderItemForm = {
      itemId: firstItem.id,
      quantity: 1,
      unitPrice: firstItem.unitPrice,
      name: firstItem.name
    };
    
    setOrderItems([...orderItems, newItem]);
  };
  
  // Rimuove un articolo dall'ordine
  const handleRemoveItem = (index: number) => {
    const newItems = [...orderItems];
    newItems.splice(index, 1);
    setOrderItems(newItems);
  };
  
  // Aggiorna un articolo dell'ordine
  const updateOrderItem = (index: number, field: keyof OrderItemForm, value: any) => {
    const newItems = [...orderItems];
    
    if (field === 'itemId') {
      const selectedItem = items.find(item => item.id === value);
      if (selectedItem) {
        newItems[index] = {
          ...newItems[index],
          itemId: value,
          unitPrice: selectedItem.unitPrice,
          name: selectedItem.name
        };
      }
    } else {
      newItems[index] = {
        ...newItems[index],
        [field]: value
      };
    }
    
    setOrderItems(newItems);
  };
  
  // Gestisce l'invio del form
  const handleSubmit = async () => {
    if (!supplierId) {
      toast({
        title: "Errore",
        description: "Seleziona un fornitore per l'ordine",
        variant: "destructive"
      });
      return;
    }
    
    if (orderItems.length === 0) {
      toast({
        title: "Errore",
        description: "Aggiungi almeno un prodotto all'ordine",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      const supplierName = suppliers.find(s => s.id === supplierId)?.name || '';
      
      await createOrder({
        supplierId,
        supplierName,
        items: orderItems.map(item => ({
          itemId: item.itemId,
          name: item.name || items.find(i => i.id === item.itemId)?.name || 'Prodotto',
          quantity: item.quantity,
          unitPrice: item.unitPrice
        })),
        totalAmount: orderTotal,
        status: 'pending',
        expectedDeliveryDate: expectedDelivery ? format(expectedDelivery, 'yyyy-MM-dd') : undefined,
        notes: notes || undefined,
        orderDate: new Date().toISOString().split('T')[0]
      });
      
      toast({
        title: "Ordine creato",
        description: "L'ordine è stato creato con successo"
      });
      
      onOpenChange(false);
    } catch (error) {
      console.error('Error creating order:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la creazione dell'ordine",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nuovo Ordine</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4">
          {/* Selezione fornitore */}
          <div className="grid gap-2">
            <Label htmlFor="supplier">Fornitore</Label>
            <Select 
              value={supplierId} 
              onValueChange={setSupplierId}
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue placeholder="Seleziona un fornitore" />
              </SelectTrigger>
              <SelectContent>
                {suppliers.map(supplier => (
                  <SelectItem key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Data di consegna prevista */}
          <div className="grid gap-2">
            <Label>Data di consegna prevista</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="justify-start text-left font-normal"
                  disabled={isSubmitting}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {expectedDelivery ? (
                    format(expectedDelivery, "d MMMM yyyy", { locale: it })
                  ) : (
                    <span>Seleziona una data</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={expectedDelivery}
                  onSelect={setExpectedDelivery}
                  locale={it}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>
          
          {/* Lista prodotti */}
          <div className="grid gap-3">
            <div className="flex justify-between items-center">
              <Label>Prodotti</Label>
              <Button 
                type="button" 
                size="sm" 
                variant="outline"
                onClick={handleAddItem}
                disabled={!supplierId || isSubmitting}
              >
                <Plus className="h-4 w-4 mr-1" />
                Aggiungi prodotto
              </Button>
            </div>
            
            {orderItems.length === 0 ? (
              <div className="text-center p-4 text-muted-foreground border rounded-md">
                {!supplierId 
                  ? "Seleziona un fornitore per aggiungere prodotti" 
                  : "Nessun prodotto nell'ordine"}
              </div>
            ) : (
              <div className="space-y-3">
                {orderItems.map((item, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardContent className="p-3">
                      <div className="grid grid-cols-12 gap-3 items-center">
                        {/* Prodotto */}
                        <div className="col-span-5">
                          <Label className="text-xs mb-1 block">Prodotto</Label>
                          <Select 
                            value={item.itemId} 
                            onValueChange={(val) => updateOrderItem(index, 'itemId', val)}
                            disabled={isSubmitting}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Seleziona" />
                            </SelectTrigger>
                            <SelectContent>
                              {availableItems.map(availItem => (
                                <SelectItem key={availItem.id} value={availItem.id}>
                                  {availItem.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {/* Quantità */}
                        <div className="col-span-3">
                          <Label className="text-xs mb-1 block">Quantità</Label>
                          <div className="flex items-center">
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                if (item.quantity > 1) {
                                  updateOrderItem(index, 'quantity', item.quantity - 1);
                                }
                              }}
                              disabled={isSubmitting}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <Input 
                              type="number"
                              value={item.quantity}
                              onChange={(e) => updateOrderItem(index, 'quantity', parseInt(e.target.value) || 1)}
                              className="h-8 text-center mx-1"
                              min={1}
                              disabled={isSubmitting}
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateOrderItem(index, 'quantity', item.quantity + 1)}
                              disabled={isSubmitting}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Prezzo */}
                        <div className="col-span-3">
                          <Label className="text-xs mb-1 block">Prezzo (€)</Label>
                          <Input 
                            type="number"
                            value={item.unitPrice}
                            onChange={(e) => updateOrderItem(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                            className="h-8"
                            min={0}
                            step={0.01}
                            disabled={isSubmitting}
                          />
                        </div>
                        
                        {/* Rimuovi */}
                        <div className="col-span-1 flex justify-center items-end h-full pb-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleRemoveItem(index)}
                            disabled={isSubmitting}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                <div className="flex justify-end border-t pt-2">
                  <div className="text-right">
                    <span className="text-muted-foreground text-sm">Totale ordine:</span>
                    <div className="text-lg font-medium">€{orderTotal.toFixed(2)}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Note */}
          <div className="grid gap-2">
            <Label htmlFor="notes">Note (opzionale)</Label>
            <Input
              id="notes" 
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Aggiungi note all'ordine..."
              disabled={isSubmitting}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Annulla
          </Button>
          <Button 
            type="button" 
            onClick={handleSubmit}
            disabled={orderItems.length === 0 || !supplierId || isSubmitting}
          >
            {isSubmitting ? (
              <>Creazione in corso...</>
            ) : (
              <>Crea Ordine</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
