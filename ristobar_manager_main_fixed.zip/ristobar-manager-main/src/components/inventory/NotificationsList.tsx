
import React from 'react';
import { InventoryNotification } from '@/contexts/InventoryContext';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Info, CheckCircle, X, Bell } from 'lucide-react';
import { useInventory } from '@/contexts/InventoryContext';

interface NotificationsListProps {
  notifications: InventoryNotification[];
  showMarkAsRead?: boolean;
}

export function NotificationsList({ notifications, showMarkAsRead = false }: NotificationsListProps) {
  const { markNotificationAsRead } = useInventory();
  
  if (notifications.length === 0) {
    return (
      <div className="text-center p-4 text-muted-foreground">
        <Bell className="h-5 w-5 mx-auto mb-2 opacity-50" />
        <p>Nessuna notifica.</p>
      </div>
    );
  }
  
  // Format date in relative format (e.g. "2 days ago")
  const formatRelativeDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const diffHours = Math.round(diffTime / (1000 * 60 * 60));
      if (diffHours === 0) {
        const diffMinutes = Math.round(diffTime / (1000 * 60));
        return `${diffMinutes} minuti fa`;
      }
      return `${diffHours} ore fa`;
    } else if (diffDays === 1) {
      return `ieri`;
    } else if (diffDays < 7) {
      return `${diffDays} giorni fa`;
    } else {
      return date.toLocaleDateString('it-IT');
    }
  };
  
  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'info':
      default:
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-3">
      {notifications.map((notification) => (
        <div 
          key={notification.id} 
          className={`flex items-start space-x-2 p-2 border rounded-md ${notification.read ? 'bg-background' : 'bg-muted/20'}`}
        >
          <div className="mt-0.5">
            {getNotificationIcon(notification.type)}
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex justify-between">
              <p className={`text-sm ${notification.read ? 'font-normal' : 'font-medium'}`}>
                {notification.message}
              </p>
              {showMarkAsRead && !notification.read && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-5 w-5 -mt-1 -mr-1"
                  onClick={() => markNotificationAsRead(notification.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {formatRelativeDate(notification.createdAt)}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
