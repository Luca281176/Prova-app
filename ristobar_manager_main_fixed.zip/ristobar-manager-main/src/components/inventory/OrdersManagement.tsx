import { useState } from 'react';
import { useInventory, InventoryOrder, OrderStatus } from '@/contexts/InventoryContext';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from '@/components/ui/card';
import { 
  Badge
} from '@/components/ui/badge';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import { ShoppingCart, Truck, PackageCheck, X, Plus, Clock, Calendar, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { NewOrderDialog } from './NewOrderDialog';

export function OrdersManagement() {
  const { orders, suppliers, updateOrderStatus } = useInventory();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeStatus, setActiveStatus] = useState<string>('all');
  const [showNewOrderDialog, setShowNewOrderDialog] = useState(false);
  
  // Filtra gli ordini in base alla ricerca e allo stato
  const filteredOrders = orders.filter(order => {
    const supplier = suppliers.find(s => s.id === order.supplierId);
    const matchesSearch = 
      supplier?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.includes(searchTerm);
      
    const matchesStatus = activeStatus === 'all' || order.status === activeStatus;
    
    return matchesSearch && matchesStatus;
  });
  
  // Raggruppa gli ordini per stato
  const pendingOrders = orders.filter(order => order.status === 'pending');
  const inTransitOrders = orders.filter(order => order.status === 'in-transit');
  const deliveredOrders = orders.filter(order => order.status === 'delivered');
  const canceledOrders = orders.filter(order => order.status === 'cancelled');
  
  // Formatta la data in italiano
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Non specificato';
    return new Date(dateString).toLocaleDateString('it-IT');
  };
  
  // Ottiene il nome del fornitore
  const getSupplierName = (supplierId: string) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    return supplier ? supplier.name : 'Fornitore sconosciuto';
  };
  
  // Gestisce il cambio di stato dell'ordine
  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    updateOrderStatus(orderId, newStatus);
  };
  
  // Componente per il badge dello stato
  const StatusBadge = ({ status }: { status: OrderStatus }) => {
    switch (status) {
      case 'pending':
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
            <Clock className="h-3 w-3 mr-1" />
            In attesa
          </Badge>
        );
      case 'in-transit':
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">
            <Truck className="h-3 w-3 mr-1" />
            In transito
          </Badge>
        );
      case 'delivered':
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
            <PackageCheck className="h-3 w-3 mr-1" />
            Consegnato
          </Badge>
        );
      case 'cancelled':
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">
            <X className="h-3 w-3 mr-1" />
            Annullato
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  // Componente per la card dell'ordine
  const OrderCard = ({ order }: { order: InventoryOrder }) => (
    <Card key={order.id} className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base">Ordine #{order.id}</CardTitle>
            <CardDescription>{getSupplierName(order.supplierId)}</CardDescription>
          </div>
          <StatusBadge status={order.status} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Data ordine:</span>
            <span>{formatDate(order.createdAt.split('T')[0])}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Consegna prevista:</span>
            <span>{formatDate(order.expectedDeliveryDate)}</span>
          </div>
          {order.status === 'delivered' && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Data consegna:</span>
              <span>{formatDate(order.actualDeliveryDate)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Prodotti:</span>
            <span>{order.items.length}</span>
          </div>
          <div className="flex justify-between font-medium">
            <span>Totale:</span>
            <span>€{order.totalAmount.toFixed(2)}</span>
          </div>
          
          {/* Azioni disponibili in base allo stato dell'ordine */}
          <div className="pt-2 flex gap-2 justify-end">
            {order.status === 'pending' && (
              <>
                <Button variant="outline" size="sm" onClick={() => handleStatusChange(order.id, 'in-transit')}>
                  <Truck className="h-4 w-4 mr-1" />
                  In transito
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleStatusChange(order.id, 'cancelled')}>
                  <X className="h-4 w-4 mr-1" />
                  Annulla
                </Button>
              </>
            )}
            {order.status === 'in-transit' && (
              <Button variant="outline" size="sm" onClick={() => handleStatusChange(order.id, 'delivered')}>
                <PackageCheck className="h-4 w-4 mr-1" />
                Segna come consegnato
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Cerca ordini..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button onClick={() => setShowNewOrderDialog(true)}>
          <Plus className="h-4 w-4 mr-1" />
          Nuovo ordine
        </Button>
      </div>
      
      {/* Conteggio ordini per stato */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-muted-foreground text-sm">In attesa</p>
              <p className="text-2xl font-bold">{pendingOrders.length}</p>
            </div>
            <Clock className="h-8 w-8 text-yellow-500 opacity-80" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-muted-foreground text-sm">In transito</p>
              <p className="text-2xl font-bold">{inTransitOrders.length}</p>
            </div>
            <Truck className="h-8 w-8 text-blue-500 opacity-80" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-muted-foreground text-sm">Consegnati</p>
              <p className="text-2xl font-bold">{deliveredOrders.length}</p>
            </div>
            <PackageCheck className="h-8 w-8 text-green-500 opacity-80" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex justify-between items-center">
            <div>
              <p className="text-muted-foreground text-sm">Annullati</p>
              <p className="text-2xl font-bold">{canceledOrders.length}</p>
            </div>
            <X className="h-8 w-8 text-red-500 opacity-80" />
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs per filtrare gli ordini per stato */}
      <Tabs defaultValue="all" value={activeStatus} onValueChange={setActiveStatus}>
        <TabsList className="grid grid-cols-5 mb-4">
          <TabsTrigger value="all">Tutti</TabsTrigger>
          <TabsTrigger value="pending">In attesa</TabsTrigger>
          <TabsTrigger value="in-transit">In transito</TabsTrigger>
          <TabsTrigger value="delivered">Consegnati</TabsTrigger>
          <TabsTrigger value="cancelled">Annullati</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-4">
          {filteredOrders.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Nessun ordine corrisponde ai criteri di ricerca.</p>
            </div>
          ) : (
            filteredOrders.map(order => <OrderCard key={order.id} order={order} />)
          )}
        </TabsContent>
        
        <TabsContent value="pending" className="space-y-4">
          {pendingOrders.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Non ci sono ordini in attesa.</p>
            </div>
          ) : (
            pendingOrders.map(order => <OrderCard key={order.id} order={order} />)
          )}
        </TabsContent>
        
        <TabsContent value="in-transit" className="space-y-4">
          {inTransitOrders.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <Truck className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Non ci sono ordini in transito.</p>
            </div>
          ) : (
            inTransitOrders.map(order => <OrderCard key={order.id} order={order} />)
          )}
        </TabsContent>
        
        <TabsContent value="delivered" className="space-y-4">
          {deliveredOrders.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <PackageCheck className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Non ci sono ordini consegnati.</p>
            </div>
          ) : (
            deliveredOrders.map(order => <OrderCard key={order.id} order={order} />)
          )}
        </TabsContent>
        
        <TabsContent value="cancelled" className="space-y-4">
          {canceledOrders.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <X className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p>Non ci sono ordini annullati.</p>
            </div>
          ) : (
            canceledOrders.map(order => <OrderCard key={order.id} order={order} />)
          )}
        </TabsContent>
      </Tabs>
      
      {/* Dialog per creare un nuovo ordine */}
      {showNewOrderDialog && (
        <NewOrderDialog 
          open={showNewOrderDialog} 
          onOpenChange={setShowNewOrderDialog} 
        />
      )}
    </div>
  );
}
