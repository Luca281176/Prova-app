import React from 'react';
import { InventoryItem, InventoryOrder } from '@/contexts/InventoryContext';
import { Package, ShoppingCart, ArrowDown, ArrowUp, AlertTriangle } from 'lucide-react';

interface RecentActivityListProps {
  items: InventoryItem[];
  orders: InventoryOrder[];
  maxItems?: number;
}

type Activity = {
  id: string;
  type: 'item-update' | 'order-created' | 'order-delivered';
  date: string;
  title: string;
  description: string;
  icon: JSX.Element;
};

export function RecentActivityList({ items, orders, maxItems = 10 }: RecentActivityListProps) {
  // Crea un elenco combinato di attività
  const activities: Activity[] = [
    // Attività dagli aggiornamenti degli articoli
    ...items.map(item => ({
      id: `item-${item.id}`,
      type: 'item-update' as const,
      date: item.updatedAt,
      title: `Aggiornato ${item.name}`,
      description: `Quantità: ${item.quantity} ${item.unit || item.unitOfMeasure || 'pz'}`,
      icon: <Package className="h-4 w-4 text-blue-500" />
    })),
    
    // Attività dagli ordini
    ...orders.map(order => {
      if (order.status === 'delivered') {
        return {
          id: `order-delivered-${order.id}`,
          type: 'order-delivered' as const,
          date: order.updatedAt,
          title: `Ordine #${order.id} consegnato`,
          description: `€${order.totalAmount.toFixed(2)} - ${order.items.length} prodotti`,
          icon: <ArrowDown className="h-4 w-4 text-green-500" />
        };
      }
      return {
        id: `order-created-${order.id}`,
        type: 'order-created' as const,
        date: order.createdAt,
        title: `Nuovo ordine #${order.id}`,
        description: `€${order.totalAmount.toFixed(2)} - ${order.items.length} prodotti`,
        icon: <ShoppingCart className="h-4 w-4 text-purple-500" />
      };
    })
  ];
  
  // Ordina le attività per data (più recenti prima)
  const sortedActivities = activities.sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  // Limita il numero di attività da mostrare
  const limitedActivities = sortedActivities.slice(0, maxItems);
  
  // Formatta la data in formato relativo (es. "2 giorni fa")
  const formatRelativeDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      const diffHours = Math.round(diffTime / (1000 * 60 * 60));
      if (diffHours === 0) {
        const diffMinutes = Math.round(diffTime / (1000 * 60));
        return `${diffMinutes} minuti fa`;
      }
      return `${diffHours} ore fa`;
    } else if (diffDays === 1) {
      return `ieri`;
    } else if (diffDays < 7) {
      return `${diffDays} giorni fa`;
    } else {
      return date.toLocaleDateString('it-IT');
    }
  };
  
  if (limitedActivities.length === 0) {
    return (
      <div className="text-center p-4 text-muted-foreground">
        <p>Nessuna attività recente.</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {limitedActivities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-4 py-2">
          <div className="bg-muted p-2 rounded-full">
            {activity.icon}
          </div>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{activity.title}</p>
            <p className="text-sm text-muted-foreground">{activity.description}</p>
          </div>
          <p className="text-xs text-muted-foreground">
            {formatRelativeDate(activity.date)}
          </p>
        </div>
      ))}
    </div>
  );
}
