
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useInventory, Supplier } from '@/contexts/InventoryContext';
import { toast } from '@/hooks/use-toast';

interface SupplierDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  supplierToEdit: Supplier | null;
}

export function SupplierDialog({ open, onOpenChange, supplierToEdit }: SupplierDialogProps) {
  const { addSupplier } = useInventory();
  
  // State per i campi del form
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  
  // Popoliamo i campi se stiamo modificando un fornitore esistente
  useEffect(() => {
    if (supplierToEdit) {
      setName(supplierToEdit.name);
      setEmail(supplierToEdit.email);
      setPhone(supplierToEdit.phone);
      setAddress(supplierToEdit.address);
    } else {
      // Reset dei campi se stiamo creando un nuovo fornitore
      setName('');
      setEmail('');
      setPhone('');
      setAddress('');
    }
  }, [supplierToEdit]);
  
  // Validazione dell'email
  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  // Gestisce il salvataggio del form
  const handleSave = () => {
    if (!name || !email || !phone) {
      toast({
        variant: "destructive",
        title: "Errore di validazione",
        description: "Nome, email e telefono sono campi obbligatori.",
      });
      return;
    }
    
    if (!isValidEmail(email)) {
      toast({
        variant: "destructive",
        title: "Email non valida",
        description: "Inserisci un indirizzo email valido.",
      });
      return;
    }
    
    const supplierData = {
      name,
      email,
      phone,
      address,
    };
    
    if (supplierToEdit) {
      // TODO: implementare la modifica del fornitore
      toast({
        title: "Fornitore aggiornato",
        description: `${name} è stato aggiornato con successo.`,
      });
    } else {
      // Stiamo creando un nuovo fornitore
      addSupplier(supplierData);
      toast({
        title: "Fornitore aggiunto",
        description: `${name} è stato aggiunto all'elenco dei fornitori.`,
      });
    }
    
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {supplierToEdit ? `Modifica ${supplierToEdit.name}` : 'Aggiungi nuovo fornitore'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome fornitore *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome dell'azienda"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="contatto@azienda.it"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Telefono *</Label>
              <Input
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+39 123 456 7890"
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="address">Indirizzo</Label>
            <Textarea
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Via, numero civico, città, CAP"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annulla
          </Button>
          <Button onClick={handleSave}>
            {supplierToEdit ? 'Aggiorna' : 'Aggiungi'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
