
import { useState } from 'react';
import { useInventory, Supplier } from '@/contexts/InventoryContext';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, Mail, Phone, MapPin, Edit, Trash2 } from 'lucide-react';
import { SupplierDialog } from './SupplierDialog';
import { useToast } from '@/hooks/use-toast';

export function SuppliersList() {
  const { suppliers } = useInventory();
  const [searchTerm, setSearchTerm] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [supplierToEdit, setSupplierToEdit] = useState<Supplier | null>(null);
  const { toast } = useToast();
  
  // Filtra i fornitori in base alla ricerca
  const filteredSuppliers = suppliers.filter(supplier => 
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.phone.includes(searchTerm)
  );
  
  // Gestisce l'apertura del dialogo per modificare un fornitore
  const handleEditSupplier = (supplier: Supplier) => {
    setSupplierToEdit(supplier);
    setShowDialog(true);
  };
  
  // Gestisce l'eliminazione di un fornitore
  const handleDeleteSupplier = (id: string) => {
    // In una vera implementazione, controlleremmo se ci sono elementi che fanno riferimento a questo fornitore
    toast({
      title: "Fornitore eliminato",
      description: "Il fornitore è stato rimosso dal sistema",
    });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Cerca fornitori..."
            className="w-full pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button onClick={() => {
          setSupplierToEdit(null);
          setShowDialog(true);
        }}>
          <Plus className="mr-2 h-4 w-4" />
          Nuovo fornitore
        </Button>
      </div>
      
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filteredSuppliers.map((supplier) => (
          <Card key={supplier.id}>
            <CardHeader className="pb-3">
              <CardTitle>{supplier.name}</CardTitle>
              <CardDescription className="line-clamp-1">
                ID: {supplier.id}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 pb-4">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{supplier.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{supplier.phone}</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{supplier.address}</span>
              </div>
            </CardContent>
            <CardFooter className="pt-0 flex justify-between">
              <Button variant="outline" size="sm" onClick={() => handleEditSupplier(supplier)}>
                <Edit className="mr-2 h-4 w-4" />
                Modifica
              </Button>
              <Button variant="outline" size="sm" onClick={() => handleDeleteSupplier(supplier.id)}>
                <Trash2 className="mr-2 h-4 w-4" />
                Elimina
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        {/* Card per aggiungere un nuovo fornitore */}
        <Card className="border-dashed flex flex-col items-center justify-center cursor-pointer h-[262px]" onClick={() => {
          setSupplierToEdit(null);
          setShowDialog(true);
        }}>
          <CardContent className="flex flex-col items-center justify-center h-full">
            <Plus className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-lg font-medium">Aggiungi fornitore</p>
            <p className="text-sm text-muted-foreground text-center mt-2">
              Crea un nuovo fornitore per i tuoi prodotti
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Dialogo per aggiungere/modificare un fornitore */}
      {showDialog && (
        <SupplierDialog 
          open={showDialog} 
          onOpenChange={setShowDialog} 
          supplierToEdit={supplierToEdit} 
        />
      )}
    </div>
  );
}
