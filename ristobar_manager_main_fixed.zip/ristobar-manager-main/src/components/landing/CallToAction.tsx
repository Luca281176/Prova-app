
import { ChevronRightIcon, PlayCircleIcon, StarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function CallToAction() {
  return (
    <>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up [animation-delay:450ms]">
        <Button asChild size="lg" className="w-full sm:w-auto">
          <Link to="/register" className="flex items-center">
            Prova Gratis 14 Giorni
            <ChevronRightIcon className="ml-2 h-4 w-4" />
          </Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
          <Link to="/login">Accedi</Link>
        </Button>
        <Button asChild variant="ghost" size="lg" className="w-full sm:w-auto">
          <a href="#features" className="flex items-center">
            Scopri di più
            <ChevronRightIcon className="ml-2 h-4 w-4" />
          </a>
        </Button>
      </div>
      
      <div className="mt-8 flex items-center justify-center gap-8 animate-fade-up [animation-delay:600ms]">
        <div className="flex items-center">
          <a href="#demo" className="flex items-center text-primary hover:text-primary/80 transition-colors">
            <PlayCircleIcon className="mr-2 h-5 w-5" />
            <span>Guarda la demo</span>
          </a>
        </div>
        <div className="flex items-center">
          <div className="flex -space-x-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="w-8 h-8 rounded-full bg-accent flex items-center justify-center border-2 border-background">
                <span className="text-xs font-medium">{i}</span>
              </div>
            ))}
          </div>
          <span className="ml-2 text-sm text-foreground/70">
            +800 ristoranti utilizzano RistoBar
          </span>
        </div>
      </div>
      
      <div className="mt-4 flex items-center justify-center gap-2 animate-fade-up [animation-delay:650ms]">
        <div className="flex">
          {[1, 2, 3, 4, 5].map((i) => (
            <StarIcon key={i} className="h-4 w-4 text-yellow-400" fill="currentColor" />
          ))}
        </div>
        <span className="text-sm text-foreground/70">
          Valutazione 4.9/5 - Recensito da +500 clienti
        </span>
      </div>
    </>
  );
}
