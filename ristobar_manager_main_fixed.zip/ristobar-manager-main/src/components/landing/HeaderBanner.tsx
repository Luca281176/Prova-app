
export function HeaderBanner() {
  return (
    <div className="inline-flex items-center px-3 py-1 mb-6 rounded-full border border-primary/20 bg-primary/5 text-primary text-sm font-medium animate-fade-in">
      <span className="flex h-2 w-2 mr-2">
        <span className="animate-ping absolute inline-flex h-2 w-2 rounded-full bg-primary opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
      </span>
      Novità: Gestione Multi-Ristorante Disponibile
    </div>
  );
}
