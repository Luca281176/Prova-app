
import { useEffect, useState, useRef } from 'react';

interface MediaDisplayProps {
  mediaUrl: string;
  mediaType: "video" | "image";
}

export function MediaDisplay({ mediaUrl, mediaType }: MediaDisplayProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  useEffect(() => {
    // Reset states when mediaUrl changes
    setIsLoading(true);
    setError(null);
    
    // Check if URL is valid
    if (!mediaUrl) {
      setError("URL non valido");
      setIsLoading(false);
      return;
    }
    
    console.log("MediaDisplay: URL changed", { 
      type: mediaType, 
      urlLength: mediaUrl?.length, 
      isDataUrl: mediaUrl?.startsWith('data:'),
      isObjectUrl: mediaUrl?.startsWith('blob:')
    });
    
    // Short timeout to allow the UI to update
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 100);
    
    return () => clearTimeout(timer);
  }, [mediaUrl, mediaType]);

  // Set playback rate when video loads
  useEffect(() => {
    if (videoRef.current && mediaType === "video" && !isLoading) {
      // Set playback rate to 0.7 (slower than normal)
      videoRef.current.playbackRate = 0.7;
      
      // Add event listeners to handle loading errors better
      const handleError = () => {
        console.error("Video error occurred");
        setError("Errore nel caricamento del video");
      };
      
      videoRef.current.addEventListener('error', handleError);
      
      return () => {
        videoRef.current?.removeEventListener('error', handleError);
      };
    }
  }, [mediaType, isLoading]);

  // Default background for loading state
  if (isLoading) {
    return <div className="w-full h-64 bg-gray-200 animate-pulse rounded-lg flex items-center justify-center">Caricamento...</div>;
  }
  
  // Error state
  if (error) {
    return (
      <div className="w-full h-64 bg-red-100 flex items-center justify-center flex-col p-4">
        <p className="text-red-600 font-medium">{error}</p>
        <p className="text-sm text-red-500 mt-2">Controlla il file e riprova con un formato supportato.</p>
      </div>
    );
  }

  // Render video 
  if (mediaType === "video") {
    return (
      <video 
        ref={videoRef}
        className="w-full h-auto" 
        controls
        autoPlay
        muted
        loop
        onError={(e) => {
          console.error("Video loading error:", e);
          setError("Errore nel caricamento del video. Formato non supportato.");
        }}
        poster="/placeholder.svg"
      >
        <source src={mediaUrl} type="video/mp4" />
        Il tuo browser non supporta i video HTML5.
      </video>
    );
  } 
  
  // Render image
  return (
    <img 
      src={mediaUrl} 
      alt="Dashboard del ristorante" 
      className="w-full h-auto object-cover"
      loading="lazy"
      onError={(e) => {
        console.error("Image loading error:", e);
        setError("Errore nel caricamento dell'immagine. Formato non supportato.");
      }}
    />
  );
}
