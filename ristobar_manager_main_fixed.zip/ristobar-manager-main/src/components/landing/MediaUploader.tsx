
import { useState, useRef } from 'react';
import { Upload, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface MediaUploaderProps {
  onSave: (mediaUrl: string, mediaType: "video" | "image") => void;
  onCancel: () => void;
}

export function MediaUploader({ onSave, onCancel }: MediaUploaderProps) {
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaType, setMediaType] = useState<"video" | "image">("video");
  const [isLoading, setIsLoading] = useState(false);
  const [fileName, setFileName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check that the file is an image or video
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      toast({
        title: "Errore",
        description: "Il file deve essere un'immagine o un video",
        variant: "destructive"
      });
      return;
    }

    // Check file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      toast({
        title: "Errore",
        description: "Il file è troppo grande. La dimensione massima è 5MB",
        variant: "destructive"
      });
      return;
    }

    setMediaFile(file);
    setFileName(file.name);
    setMediaType(file.type.startsWith('image/') ? "image" : "video");
  };

  const handleSaveMedia = () => {
    if (!mediaFile) return;
    setIsLoading(true);

    try {
      // For direct file URL use instead of data URLs (more efficient for storage)
      if (mediaType === "video") {
        // Use URL.createObjectURL for videos
        const objectUrl = URL.createObjectURL(mediaFile);
        onSave(objectUrl, mediaType);
        setIsLoading(false);
      } else {
        // For images, we can still use Data URLs but with compression
        const reader = new FileReader();
        
        reader.onloadend = () => {
          const dataUrl = reader.result as string;
          console.log("Media processed successfully");
          onSave(dataUrl, mediaType);
          setMediaFile(null);
          setFileName("");
          setIsLoading(false);
        };
        
        reader.onerror = () => {
          console.error("Error reading file:", reader.error);
          toast({
            title: "Errore",
            description: "Si è verificato un errore durante la lettura del file",
            variant: "destructive"
          });
          setIsLoading(false);
        };
        
        // Read file as Data URL for images
        reader.readAsDataURL(mediaFile);
      }
    } catch (error) {
      console.error("Errore nel salvataggio del media:", error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante il salvataggio del media",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg flex flex-col gap-2">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*"
        onChange={handleFileChange}
        className="hidden"
      />
      <div className="flex gap-2">
        <Button size="sm" onClick={handleUploadClick} className="flex-1">
          <Upload className="mr-2 h-4 w-4" />
          Seleziona file
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel} className="flex-1">
          Annulla
        </Button>
      </div>
      {mediaFile && (
        <div className="mt-2">
          <p className="text-xs text-gray-600 truncate mb-1">{fileName}</p>
          <Button 
            size="sm" 
            variant="default" 
            onClick={handleSaveMedia} 
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Caricamento...
              </>
            ) : "Salva"}
          </Button>
        </div>
      )}
    </div>
  );
}
