
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  MessagesSquareIcon, 
  MailIcon, 
  PhoneIcon, 
  HelpCircleIcon, 
  SearchIcon,
  ArrowRightIcon,
  ThumbsUpIcon,
  ThumbsDownIcon,
  SendIcon,
  RefreshCwIcon
} from "lucide-react";
import { toast } from "sonner";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const CustomerSupport = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [chatMessages, setChatMessages] = useState<{type: 'user' | 'bot', content: string}[]>([
    {type: 'bot', content: 'Ciao! Sono l\'assistente virtuale di RistoBar Manager. Come posso aiutarti oggi?'}
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [supportForm, setSupportForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const handleSupportFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setSupportForm(prev => ({
      ...prev,
      [id]: value
    }));
  };
  
  const handleSupportFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!supportForm.name || !supportForm.email || !supportForm.message) {
      toast.error("Per favore, compila tutti i campi obbligatori");
      return;
    }
    
    // Here you would typically send the form data to your backend
    console.log("Support form submitted:", supportForm);
    
    toast.success("La tua richiesta è stata inviata con successo! Ti risponderemo al più presto.");
    
    // Reset form
    setSupportForm({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };
  
  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    // Add user message
    setChatMessages(prev => [...prev, {type: 'user', content: newMessage}]);
    
    // Simulate bot response
    setTimeout(() => {
      let botResponse = '';
      const userMessageLower = newMessage.toLowerCase();
      
      if (userMessageLower.includes('prenotazioni') || userMessageLower.includes('prenotare')) {
        botResponse = 'Per gestire le prenotazioni, vai alla sezione "Prenotazioni" nel menu principale. Lì potrai visualizzare, aggiungere e modificare tutte le prenotazioni. Posso aiutarti con qualcos\'altro sulle prenotazioni?';
      } else if (userMessageLower.includes('menu') || userMessageLower.includes('piatti')) {
        botResponse = 'Per gestire il tuo menu, accedi alla sezione "Menu" dove potrai creare categorie, aggiungere piatti e impostare prezzi. Puoi anche caricare immagini per ogni piatto. Hai bisogno di aiuto specifico sulla gestione del menu?';
      } else if (userMessageLower.includes('pagamento') || userMessageLower.includes('abbonamento')) {
        botResponse = 'Per informazioni sul tuo abbonamento o per gestire i pagamenti, vai alla sezione "Abbonamento" nelle impostazioni. Per assistenza specifica sui pagamenti, ti consiglio di contattare il nostro team via email a supporto@ristobarmanager.it';
      } else if (userMessageLower.includes('ciao') || userMessageLower.includes('salve')) {
        botResponse = 'Ciao! Come posso aiutarti oggi con RistoBar Manager?';
      } else {
        botResponse = 'Grazie per la tua domanda. Posso aiutarti con prenotazioni, gestione del menu, inventario, personale e altre funzionalità di RistoBar Manager. Potresti fornire maggiori dettagli sulla tua richiesta?';
      }
      
      setChatMessages(prev => [...prev, {type: 'bot', content: botResponse}]);
    }, 1000);
    
    setNewMessage('');
  };

  const faqItems = [
    {
      question: "Come posso iniziare a usare RistoBar Manager?",
      answer: "Per iniziare, registra il tuo account su ristobarmanager.it. Dopo la registrazione, riceverai un'email di conferma. Una volta confermato l'account, potrai accedere alla piattaforma e iniziare a configurare il tuo ristorante seguendo la procedura guidata di onboarding."
    },
    {
      question: "Quali sono i requisiti di sistema per usare RistoBar Manager?",
      answer: "RistoBar Manager è basato sul web, quindi funziona su qualsiasi dispositivo con un browser moderno (Chrome, Firefox, Safari, Edge) e una connessione internet. Per la versione mobile, offriamo app dedicate per iOS e Android disponibili negli app store ufficiali."
    },
    {
      question: "Posso provare RistoBar Manager prima di acquistarlo?",
      answer: "Sì, offriamo una prova gratuita di 30 giorni con tutte le funzionalità attive. Non è richiesta una carta di credito per iniziare la prova. Alla fine del periodo di prova, potrai scegliere il piano di abbonamento più adatto alle tue esigenze."
    },
    {
      question: "Come funziona il sistema di prenotazioni?",
      answer: "Il sistema di prenotazioni ti permette di gestire le prenotazioni online e telefoniche in un unico posto. Puoi visualizzare le prenotazioni in un calendario o in vista giornaliera, assegnare tavoli automaticamente o manualmente, inviare conferme ai clienti via email o SMS, e gestire liste d'attesa nei periodi di picco."
    },
    {
      question: "È possibile gestire più locali con un solo account?",
      answer: "Sì, con i piani Pro e Ultimate puoi gestire più locali dalla stessa dashboard. Ogni locale avrà la sua configurazione indipendente (menu, inventario, personale), ma potrai accedere a tutti con lo stesso account e avere reportistica aggregata."
    },
    {
      question: "Come posso ricevere assistenza tecnica?",
      answer: "Offriamo diverse opzioni di supporto: documentazione online completa, video tutorial, assistenza via email disponibile 7 giorni su 7, chat dal vivo durante l'orario lavorativo, e supporto telefonico dedicato per i clienti dei piani Pro e Ultimate."
    },
    {
      question: "I miei dati sono sicuri?",
      answer: "Assolutamente sì. Utilizziamo la crittografia SSL per tutte le comunicazioni, i tuoi dati sono archiviati in data center certificati ISO 27001, eseguiamo backup giornalieri automatici, e rispettiamo completamente il GDPR per i clienti europei."
    },
    {
      question: "Posso esportare i miei dati dal sistema?",
      answer: "Sì, puoi esportare tutti i tuoi dati in formati standard come CSV o Excel. Questo include reportistica, dati cliente, inventario, menu e storico delle transazioni. L'esportazione può essere configurata come automatica o manuale."
    },
    {
      question: "Come funziona il sistema di fatturazione?",
      answer: "RistoBar Manager si integra con i principali sistemi di fatturazione elettronica italiani. Puoi generare fatture direttamente dalla piattaforma, inviarle ai clienti via email, e l'integrazione con l'Agenzia delle Entrate permette la trasmissione automatica delle fatture elettroniche."
    },
    {
      question: "È possibile personalizzare le ricevute e gli scontrini?",
      answer: "Sì, puoi personalizzare completamente il layout delle ricevute e degli scontrini con il tuo logo, informazioni del ristorante, messaggi promozionali, e scegliere quali informazioni mostrare. Supportiamo anche la stampa su diverse dimensioni di carta in base alle tue esigenze."
    },
  ];
  
  const filteredFaqs = searchQuery 
    ? faqItems.filter(item => 
        item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
        item.answer.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : faqItems;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Sistema di Supporto Clienti</h2>
      
      <Tabs defaultValue="faq" className="mb-8">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="faq" className="flex items-center gap-2">
            <HelpCircleIcon className="h-4 w-4" /> FAQ
          </TabsTrigger>
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <MessagesSquareIcon className="h-4 w-4" /> Chatbot
          </TabsTrigger>
          <TabsTrigger value="email" className="flex items-center gap-2">
            <MailIcon className="h-4 w-4" /> Email
          </TabsTrigger>
          <TabsTrigger value="contact" className="flex items-center gap-2">
            <PhoneIcon className="h-4 w-4" /> Contatti
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="faq">
          <Card>
            <CardContent className="pt-6">
              <div className="mb-6">
                <div className="relative">
                  <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Cerca nelle FAQ..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              {searchQuery && filteredFaqs.length === 0 ? (
                <div className="text-center py-8">
                  <HelpCircleIcon className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <h3 className="text-lg font-medium mb-2">Nessun risultato trovato</h3>
                  <p className="text-muted-foreground mb-4">
                    Non abbiamo trovato risposte per la tua ricerca "{searchQuery}"
                  </p>
                  <Button onClick={() => setSearchQuery('')} variant="outline" className="gap-2">
                    <RefreshCwIcon className="h-4 w-4" /> Reset ricerca
                  </Button>
                </div>
              ) : (
                <Accordion type="single" collapsible className="w-full">
                  {filteredFaqs.map((item, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="text-left">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pt-2 pb-4">
                          <p className="text-muted-foreground">{item.answer}</p>
                          <div className="flex items-center justify-end mt-4 gap-4">
                            <span className="text-sm text-muted-foreground">Questa risposta ti è stata utile?</span>
                            <Button variant="outline" size="sm" className="gap-1">
                              <ThumbsUpIcon className="h-4 w-4" /> Sì
                            </Button>
                            <Button variant="outline" size="sm" className="gap-1">
                              <ThumbsDownIcon className="h-4 w-4" /> No
                            </Button>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
              
              <div className="mt-8 bg-primary/10 p-4 rounded-lg flex items-start gap-4">
                <HelpCircleIcon className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium mb-1">Non hai trovato quello che cerchi?</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Contattaci direttamente e ti risponderemo al più presto.
                  </p>
                  <Button variant="default" size="sm" className="gap-1">
                    <MailIcon className="h-4 w-4" /> Contatta il supporto
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="chat">
          <Card className="border">
            <CardContent className="pt-6">
              <div className="flex flex-col h-[500px]">
                <div className="flex-1 overflow-y-auto mb-4 p-4 bg-accent/20 rounded-lg space-y-4">
                  {chatMessages.map((message, index) => (
                    <div 
                      key={index}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.type === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-accent'
                        }`}
                      >
                        {message.content}
                      </div>
                    </div>
                  ))}
                </div>
                
                <form onSubmit={handleSendChatMessage} className="flex gap-2">
                  <Input 
                    placeholder="Scrivi un messaggio..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-1"
                  />
                  <Button type="submit" className="gap-2">
                    <SendIcon className="h-4 w-4" /> Invia
                  </Button>
                </form>
                
                <div className="mt-4 text-sm text-muted-foreground">
                  <p className="text-center">
                    Questo è un chatbot dimostrativo. Per assistenza reale, contatta il supporto via email.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="email">
          <Card>
            <CardContent className="pt-6">
              <form onSubmit={handleSupportFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-1">
                      Nome *
                    </label>
                    <Input
                      id="name"
                      value={supportForm.name}
                      onChange={handleSupportFormChange}
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      Email *
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={supportForm.email}
                      onChange={handleSupportFormChange}
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-1">
                    Oggetto *
                  </label>
                  <Input
                    id="subject"
                    value={supportForm.subject}
                    onChange={handleSupportFormChange}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-1">
                    Messaggio *
                  </label>
                  <Textarea
                    id="message"
                    rows={6}
                    value={supportForm.message}
                    onChange={handleSupportFormChange}
                    required
                  />
                </div>
                
                <div className="text-sm text-muted-foreground">
                  * Campi obbligatori
                </div>
                
                <Button type="submit" className="w-full">Invia Richiesta</Button>
                
                <div className="bg-accent/20 p-4 rounded-lg mt-4">
                  <h3 className="font-medium text-lg mb-2">Tempi di Risposta</h3>
                  <p className="text-sm text-muted-foreground">
                    Di solito rispondiamo entro 24 ore lavorative. Per questioni urgenti, ti consigliamo di contattare
                    direttamente il nostro servizio clienti telefonico.
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="contact">
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-semibold text-lg mb-4">Contatti Diretti</h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-start gap-3">
                      <PhoneIcon className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <h4 className="font-medium">Supporto Telefonico</h4>
                        <p className="text-muted-foreground mb-1">+39 02 1234567</p>
                        <p className="text-sm text-muted-foreground">
                          Lun-Ven: 9:00-18:00<br />
                          Sab: 9:00-13:00
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <MailIcon className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <h4 className="font-medium">Email</h4>
                        <a href="mailto:supporto@ristobarmanager.it" className="text-primary hover:underline">
                          supporto@ristobarmanager.it
                        </a>
                        <p className="text-sm text-muted-foreground mt-1">
                          Risposta entro 24 ore lavorative
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <MessagesSquareIcon className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <h4 className="font-medium">Chat dal Vivo</h4>
                        <p className="text-muted-foreground mb-1">Disponibile nell'area clienti</p>
                        <p className="text-sm text-muted-foreground">
                          Lun-Ven: 9:00-17:00
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <h3 className="font-semibold text-lg mb-4">Ufficio Commerciale</h3>
                    
                    <div className="flex items-start gap-3">
                      <MailIcon className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <h4 className="font-medium">Informazioni Commerciali</h4>
                        <a href="mailto:sales@ristobarmanager.it" className="text-primary hover:underline">
                          sales@ristobarmanager.it
                        </a>
                        <p className="text-sm text-muted-foreground mt-1">
                          Per preventivi personalizzati e demo
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-4">Sede Principale</h3>
                  
                  <div className="rounded-lg overflow-hidden mb-4" style={{height: "200px"}}>
                    <div className="w-full h-full bg-accent/50 flex items-center justify-center">
                      <p className="text-muted-foreground">Mappa dell'ufficio</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="font-medium">RistoBar Manager S.r.l.</p>
                    <p className="text-muted-foreground">Via dell'Innovazione, 42</p>
                    <p className="text-muted-foreground">20129 Milano (MI)</p>
                    <p className="text-muted-foreground">Italia</p>
                  </div>
                  
                  <div className="mt-6">
                    <Button className="gap-2">
                      <ArrowRightIcon className="h-4 w-4" /> Indicazioni Stradali
                    </Button>
                  </div>
                  
                  <div className="mt-8 p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Orari di Apertura</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Lunedì - Venerdì</span>
                        <span>9:00 - 18:00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Sabato</span>
                        <span>9:00 - 13:00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Domenica</span>
                        <span>Chiuso</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="text-center mt-12">
        <h3 className="text-xl font-semibold mb-3">Marketing & Comunicazione</h3>
        <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
          Questa demo include una pagina "Coming Soon", email marketing, post social, guida rapida e sistema di supporto clienti.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button asChild variant="outline">
            <a href="/coming-soon">
              Visualizza Coming Soon
            </a>
          </Button>
          <Button variant="secondary">
            Scarica Marketing Kit
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CustomerSupport;
