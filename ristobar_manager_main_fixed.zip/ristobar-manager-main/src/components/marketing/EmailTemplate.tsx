
import React from 'react';

interface EmailTemplateProps {
  recipientName?: string;
  launchDate?: string;
  orderNumber?: string;
  planName?: string;
  planPrice?: string;
  paymentStatus?: 'success' | 'failed';
  isSubscriptionEmail?: boolean;
  isOrderConfirmation?: boolean;
}

const EmailTemplate: React.FC<EmailTemplateProps> = ({ 
  recipientName = "[Nome]", 
  launchDate = "30 Aprile 2024",
  orderNumber,
  planName,
  planPrice,
  paymentStatus = 'success',
  isSubscriptionEmail = false,
  isOrderConfirmation = false
}) => {
  // Template di base per email di marketing
  if (!isSubscriptionEmail && !isOrderConfirmation) {
    return (
      <div className="p-8 max-w-2xl mx-auto border rounded-lg bg-background">
        <h2 className="text-2xl font-bold mb-6">Email Marketing per Lancio RistoBar Manager</h2>
        
        <div className="border p-6 rounded-lg bg-white">
          <div className="mb-8 text-center">
            <h3 className="font-bold text-xl text-primary">RistoBar Manager</h3>
            <p className="text-muted-foreground text-sm">La rivoluzione nella gestione della ristorazione</p>
          </div>
          
          <p className="mb-4">Gentile {recipientName},</p>
          
          <p className="mb-4">
            Siamo lieti di annunciarti che il {launchDate} lanceremo ufficialmente <strong>RistoBar Manager 4.0</strong>, 
            la piattaforma all-in-one che rivoluzionerà la gestione del tuo ristorante.
          </p>
          
          <h4 className="font-bold mt-6 mb-3">Perché scegliere RistoBar Manager?</h4>
          <ul className="list-disc pl-5 mb-4 space-y-2">
            <li>Gestione completa del tuo locale da un'unica dashboard</li>
            <li>Prenotazioni online integrate con il gestionale</li>
            <li>Sistema di inventario intelligente con alert automatici</li>
            <li>Analisi delle performance e suggerimenti per aumentare i profitti</li>
            <li>Integrazione con i principali sistemi di pagamento</li>
          </ul>
          
          <div className="bg-primary/10 p-4 rounded-lg my-6 text-center">
            <p className="font-semibold mb-2">Offerta di lancio esclusiva!</p>
            <p className="mb-4">Iscriviti prima del lancio e ottieni:</p>
            <ul className="text-left inline-block">
              <li>✅ 30 giorni di prova gratuita</li>
              <li>✅ 50% di sconto sul primo anno di abbonamento</li>
              <li>✅ Supporto prioritario personalizzato</li>
            </ul>
          </div>
          
          <div className="text-center my-6">
            <a href="#" className="inline-block px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 transition-colors">
              Iscriviti Ora
            </a>
          </div>
          
          <p className="mb-4">
            Non perdere questa opportunità di trasformare la gestione del tuo ristorante. 
            Siamo sicuri che RistoBar Manager diventerà uno strumento indispensabile per la tua attività.
          </p>
          
          <p className="mt-6">
            Cordiali saluti,<br />
            Il Team di RistoBar Manager
          </p>
          
          <div className="mt-8 pt-6 border-t text-sm text-muted-foreground text-center">
            <p>© 2024 RistoBar Manager. Tutti i diritti riservati.</p>
            <p className="mt-2">
              <a href="#" className="text-primary">Cancellati</a> • 
              <a href="#" className="text-primary ml-2">Privacy Policy</a> • 
              <a href="#" className="text-primary ml-2">Contattaci</a>
            </p>
          </div>
        </div>
        
        <div className="mt-6 text-sm text-muted-foreground">
          <p><strong>Note per l'implementazione:</strong></p>
          <ul className="list-disc pl-5 mt-2">
            <li>Personalizzare con il nome del destinatario quando disponibile</li>
            <li>Inserire link effettivi per i CTA e i link nel footer</li>
            <li>Aggiungere immagini del prodotto nella versione HTML completa</li>
            <li>Configurare il tracciamento delle aperture e dei clic</li>
            <li>Pianificare invii in più fasi: teaser, annuncio, reminder</li>
          </ul>
        </div>
      </div>
    );
  }

  // Template per conferma abbonamento
  if (isSubscriptionEmail) {
    return (
      <div className="p-8 max-w-2xl mx-auto border rounded-lg bg-background">
        <h2 className="text-2xl font-bold mb-6">{paymentStatus === 'success' ? 'Conferma Abbonamento' : 'Problema con il Pagamento'}</h2>
        
        <div className="border p-6 rounded-lg bg-white">
          <div className="mb-8 text-center">
            <h3 className="font-bold text-xl text-primary">RistoBar Manager</h3>
            <p className="text-muted-foreground text-sm">La rivoluzione nella gestione della ristorazione</p>
          </div>
          
          <p className="mb-4">Gentile {recipientName},</p>
          
          {paymentStatus === 'success' ? (
            <>
              <p className="mb-4">
                Grazie per aver sottoscritto il piano <strong>{planName}</strong> di RistoBar Manager.
                La tua sottoscrizione è ora attiva e puoi iniziare a utilizzare tutte le funzionalità del piano.
              </p>
              
              <div className="bg-green-50 border border-green-200 p-4 rounded-lg my-6">
                <h4 className="font-bold text-green-700 mb-2">Dettagli Abbonamento</h4>
                <ul className="space-y-1 text-green-700">
                  <li><strong>Piano:</strong> {planName}</li>
                  <li><strong>Prezzo:</strong> €{planPrice}/mese</li>
                  <li><strong>Stato:</strong> Attivo</li>
                  <li><strong>Data attivazione:</strong> {new Date().toLocaleDateString('it-IT')}</li>
                </ul>
              </div>
            </>
          ) : (
            <>
              <p className="mb-4">
                Abbiamo riscontrato un problema con il pagamento del tuo abbonamento al piano <strong>{planName}</strong>.
                Per evitare interruzioni del servizio, ti preghiamo di verificare il metodo di pagamento nel tuo account.
              </p>
              
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg my-6">
                <h4 className="font-bold text-red-700 mb-2">Problema Rilevato</h4>
                <p className="text-red-700">Il pagamento non è andato a buon fine. Per favore verifica i dettagli della tua carta di credito o contatta la tua banca.</p>
              </div>
              
              <div className="text-center my-6">
                <a href="#" className="inline-block px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 transition-colors">
                  Aggiorna Metodo di Pagamento
                </a>
              </div>
            </>
          )}
          
          <p className="mb-4">
            Per qualsiasi domanda o assistenza, non esitare a contattare il nostro team di supporto.
          </p>
          
          <p className="mt-6">
            Cordiali saluti,<br />
            Il Team di RistoBar Manager
          </p>
          
          <div className="mt-8 pt-6 border-t text-sm text-muted-foreground text-center">
            <p>© 2024 RistoBar Manager. Tutti i diritti riservati.</p>
            <p className="mt-2">
              <a href="#" className="text-primary">Gestisci Abbonamento</a> • 
              <a href="#" className="text-primary ml-2">Privacy Policy</a> • 
              <a href="#" className="text-primary ml-2">Supporto</a>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Template per conferma ordine
  if (isOrderConfirmation) {
    return (
      <div className="p-8 max-w-2xl mx-auto border rounded-lg bg-background">
        <h2 className="text-2xl font-bold mb-6">Conferma del tuo Ordine #{orderNumber}</h2>
        
        <div className="border p-6 rounded-lg bg-white">
          <div className="mb-8 text-center">
            <h3 className="font-bold text-xl text-primary">RistoBar Manager</h3>
            <p className="text-muted-foreground text-sm">La rivoluzione nella gestione della ristorazione</p>
          </div>
          
          <p className="mb-4">Gentile {recipientName},</p>
          
          <p className="mb-4">
            Grazie per il tuo ordine. La tua transazione è stata completata con successo.
          </p>
          
          <div className="bg-green-50 border border-green-200 p-4 rounded-lg my-6">
            <h4 className="font-bold text-green-700 mb-2">Dettagli Ordine</h4>
            <ul className="space-y-1 text-green-700">
              <li><strong>Numero Ordine:</strong> #{orderNumber}</li>
              <li><strong>Data:</strong> {new Date().toLocaleDateString('it-IT')}</li>
              <li><strong>Stato Pagamento:</strong> Completato</li>
              <li><strong>Totale:</strong> €{planPrice}</li>
            </ul>
          </div>
          
          <p className="mb-4">
            Riceverai presto una fattura dettagliata via email. Il tuo ordine è in fase di elaborazione e ti aggiorneremo sullo stato.
          </p>
          
          <div className="text-center my-6">
            <a href="#" className="inline-block px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 transition-colors">
              Visualizza Dettagli Ordine
            </a>
          </div>
          
          <p className="mt-6">
            Cordiali saluti,<br />
            Il Team di RistoBar Manager
          </p>
          
          <div className="mt-8 pt-6 border-t text-sm text-muted-foreground text-center">
            <p>© 2024 RistoBar Manager. Tutti i diritti riservati.</p>
            <p className="mt-2">
              <a href="#" className="text-primary">I Miei Ordini</a> • 
              <a href="#" className="text-primary ml-2">Privacy Policy</a> • 
              <a href="#" className="text-primary ml-2">Supporto</a>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default EmailTemplate;
