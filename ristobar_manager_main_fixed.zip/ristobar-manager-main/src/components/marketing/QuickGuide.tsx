
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2Icon, HelpCircleIcon, BookOpenIcon, AlertCircleIcon } from "lucide-react";

const QuickGuide = () => {
  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <BookOpenIcon className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Guida Rapida per Ristoratori</h2>
      </div>
      
      <p className="text-muted-foreground mb-8">
        Questa guida è stata progettata per aiutarti a iniziare rapidamente con RistoBar Manager. 
        Segui questi semplici passaggi per configurare e ottimizzare la tua esperienza.
      </p>
      
      <Tabs defaultValue="start">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="start">Iniziare</TabsTrigger>
          <TabsTrigger value="setup">Configurazione</TabsTrigger>
          <TabsTrigger value="daily">Uso Quotidiano</TabsTrigger>
          <TabsTrigger value="advanced">Funzioni Avanzate</TabsTrigger>
        </TabsList>
        
        <TabsContent value="start">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">I Primi Passi con RistoBar Manager</h3>
              
              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Crea il tuo Account</h4>
                    <p className="text-muted-foreground mb-3">
                      Registrati su ristobarmanager.it fornendo i dati della tua attività. Riceverai un'email di conferma
                      per attivare il tuo account e accedere alla piattaforma.
                    </p>
                    <div className="bg-accent/30 p-3 rounded-md flex gap-2">
                      <AlertCircleIcon className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm">
                        Assicurati di utilizzare un indirizzo email che controlli regolarmente e una password sicura.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Esplora la Dashboard</h4>
                    <p className="text-muted-foreground mb-3">
                      Familiarizza con l'interfaccia principale. La dashboard ti offre una panoramica delle prenotazioni,
                      degli ordini attivi e delle statistiche chiave della tua attività in tempo reale.
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Visualizza il flusso di clienti previsto per la giornata</li>
                      <li>Controlla lo stato dei tavoli e delle sale</li>
                      <li>Monitora le vendite in tempo reale</li>
                      <li>Ricevi notifiche importanti</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Configura il Profilo del Ristorante</h4>
                    <p className="text-muted-foreground">
                      Completa il profilo del tuo ristorante aggiungendo informazioni essenziali come orari di apertura,
                      indirizzo, contatti, logo e immagini. Questi dati saranno utilizzati in tutta la piattaforma.
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Accedi alla Formazione Iniziale</h4>
                    <p className="text-muted-foreground">
                      Partecipa alla sessione di formazione gratuita inclusa nel tuo abbonamento. Un nostro esperto
                      ti guiderà attraverso le funzionalità principali e risponderà alle tue domande.
                    </p>
                    <div className="bg-primary/10 p-3 rounded-md flex gap-2 mt-3">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <p className="text-sm">
                        Consiglio: Invita anche il tuo staff alla sessione di formazione per garantire che tutto il team
                        possa sfruttare al meglio la piattaforma fin da subito.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="setup">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Configurazione del Sistema</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center">
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-2">A</span>
                    Configurazione delle Sale e dei Tavoli
                  </h4>
                  <div className="ml-10">
                    <ol className="list-decimal space-y-2 mb-4">
                      <li>Vai alla sezione "Sale e Tavoli" dal menu laterale</li>
                      <li>Clicca su "Aggiungi Sala" e definisci nome e capienza</li>
                      <li>All'interno di ogni sala, aggiungi i tavoli specificando numero, posti e posizione</li>
                      <li>Utilizza l'editor visuale per posizionare i tavoli come nel tuo locale reale</li>
                      <li>Salva la configurazione</li>
                    </ol>
                    <div className="bg-accent/30 p-3 rounded-md text-sm">
                      Ricorda di specificare se alcuni tavoli possono essere uniti per gruppi numerosi.
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center">
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-2">B</span>
                    Creazione del Menu
                  </h4>
                  <div className="ml-10">
                    <ol className="list-decimal space-y-2 mb-4">
                      <li>Accedi alla sezione "Menu" dal menu laterale</li>
                      <li>Crea le categorie del tuo menu (Antipasti, Primi, Secondi, ecc.)</li>
                      <li>Per ogni categoria, aggiungi i piatti con nome, descrizione, prezzo e allergeni</li>
                      <li>Carica immagini dei piatti per migliorare il menu digitale</li>
                      <li>Indica eventuali varianti o opzioni personalizzabili</li>
                    </ol>
                    <div className="bg-primary/10 p-3 rounded-md text-sm flex gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0" />
                      <p>
                        Pro Tip: Crea menu speciali per occasioni particolari (weekend, festività) e pianificali in anticipo.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center">
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-2">C</span>
                    Configurazione Inventario
                  </h4>
                  <div className="ml-10">
                    <ol className="list-decimal space-y-2 mb-4">
                      <li>Vai alla sezione "Inventario"</li>
                      <li>Aggiungi le categorie di prodotti (Ingredienti, Bevande, Materiali di consumo)</li>
                      <li>Inserisci i prodotti con dettagli su unità di misura, scorta minima e fornitori</li>
                      <li>Collega gli ingredienti alle ricette del menu per il calcolo automatico delle scorte</li>
                      <li>Imposta le regole per gli alert di scorta minima</li>
                    </ol>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-lg mb-3 flex items-center">
                    <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary mr-2">D</span>
                    Configurazione Personale
                  </h4>
                  <div className="ml-10">
                    <ol className="list-decimal space-y-2">
                      <li>Accedi alla sezione "Personale"</li>
                      <li>Aggiungi i membri del team con i rispettivi ruoli (cameriere, chef, manager)</li>
                      <li>Configura i permessi di accesso per ogni ruolo</li>
                      <li>Crea i turni di lavoro standard</li>
                      <li>Invita i dipendenti a scaricare l'app mobile per accedere al proprio profilo</li>
                    </ol>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="daily">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Operazioni Quotidiane</h3>
              
              <div className="space-y-6">
                <div className="bg-primary/5 p-4 rounded-lg">
                  <h4 className="font-semibold text-lg mb-2">All'Apertura</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Controlla le prenotazioni del giorno dalla dashboard</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Verifica disponibilità di tavoli e assegnali alle prenotazioni</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Registra le presenze del personale in turno</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Controlla gli alert dell'inventario per eventuali prodotti in esaurimento</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Aggiorna il menu del giorno se necessario (piatti non disponibili)</span>
                    </li>
                  </ul>
                </div>
                
                <div className="bg-primary/5 p-4 rounded-lg">
                  <h4 className="font-semibold text-lg mb-2">Durante il Servizio</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Gestisci gli ordini in tempo reale con la funzione "Ordini Attivi"</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Monitora lo stato dei tavoli nella mappa interattiva</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Utilizza la funzione "Comanda Rapida" per tavoli con elevato turnover</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Gestisci le prenotazioni last-minute e aggiorna la disponibilità</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Utilizza la cassa per gestire i pagamenti e generare scontrini</span>
                    </li>
                  </ul>
                </div>
                
                <div className="bg-primary/5 p-4 rounded-lg">
                  <h4 className="font-semibold text-lg mb-2">Alla Chiusura</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Esegui la chiusura di cassa con il riepilogo giornaliero</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Controlla il report delle vendite e delle performance</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Aggiorna l'inventario in base ai consumi della giornata</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Verifica le prenotazioni per il giorno successivo</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Controlla eventuali segnalazioni o feedback dei clienti</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="advanced">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-semibold mb-4">Funzionalità Avanzate</h3>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <HelpCircleIcon className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Analisi e Reportistica</h4>
                    <p className="text-muted-foreground mb-3">
                      Sfrutta al massimo i dati raccolti dal sistema per ottimizzare la tua attività:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Report settimanali e mensili sulle vendite</li>
                      <li>Analisi dei piatti più venduti e margini di guadagno</li>
                      <li>Statistiche sui picchi di affluenza</li>
                      <li>Monitoraggio delle performance del personale</li>
                      <li>Previsioni basate sui trend storici</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <HelpCircleIcon className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Fidelizzazione Clienti</h4>
                    <p className="text-muted-foreground mb-3">
                      Utilizza gli strumenti di marketing integrati:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Gestione del database clienti con preferenze e storico</li>
                      <li>Campagne email personalizzate per eventi speciali</li>
                      <li>Programma fedeltà con punti e premi</li>
                      <li>Sondaggi di soddisfazione automatizzati</li>
                      <li>Comunicazioni personalizzate per compleanni e anniversari</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <HelpCircleIcon className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Integrazione con Servizi di Terze Parti</h4>
                    <p className="text-muted-foreground mb-3">
                      Espandi le funzionalità connettendo altri servizi:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Portali di prenotazione online (TheFork, OpenTable)</li>
                      <li>Piattaforme di delivery (Deliveroo, Just Eat, Glovo)</li>
                      <li>Sistemi di pagamento digitale</li>
                      <li>Software di contabilità</li>
                      <li>Canali social per la gestione della reputazione online</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <HelpCircleIcon className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">Menu Digitale e Ordini da Tavolo</h4>
                    <p className="text-muted-foreground mb-3">
                      Offri un'esperienza moderna ai tuoi clienti:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>QR code per accedere al menu digitale interattivo</li>
                      <li>Possibilità per i clienti di ordinare direttamente dal proprio smartphone</li>
                      <li>Visualizzazione di immagini e descrizioni dettagliate dei piatti</li>
                      <li>Filtri per allergeni e preferenze alimentari</li>
                      <li>Possibilità di richiedere il conto digitalmente</li>
                    </ul>
                  </div>
                </div>
                
                <div className="p-4 border rounded-lg mt-6">
                  <h4 className="font-semibold mb-2 flex items-center">
                    <BookOpenIcon className="h-5 w-5 mr-2 text-primary" />
                    Risorse Aggiuntive
                  </h4>
                  <ul className="space-y-2">
                    <li>
                      <a href="#" className="text-primary hover:underline">Video tutorial completi</a> - Libreria di guide passo-passo su tutte le funzionalità
                    </li>
                    <li>
                      <a href="#" className="text-primary hover:underline">Community dei ristoratori</a> - Forum per scambiare consigli e best practices
                    </li>
                    <li>
                      <a href="#" className="text-primary hover:underline">Webinar mensili</a> - Sessioni di formazione su temi specifici della ristorazione
                    </li>
                    <li>
                      <a href="#" className="text-primary hover:underline">Supporto tecnico dedicato</a> - Disponibile 7 giorni su 7 per risolvere qualsiasi problematica
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QuickGuide;
