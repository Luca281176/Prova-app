
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LinkedinIcon, TwitterIcon, InstagramIcon, CopyIcon } from "lucide-react";
import { toast } from "sonner";

const SocialMediaPosts = () => {
  const copyToClipboard = (text: string, platform: string) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        toast.success(`Post per ${platform} copiato negli appunti!`);
      })
      .catch(() => {
        toast.error(`Impossibile copiare il testo. Prova a selezionarlo manualmente.`);
      });
  };

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Post di Lancio per i Social Media</h2>
      
      <Tabs defaultValue="linkedin">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="linkedin" className="flex items-center gap-2">
            <LinkedinIcon className="h-4 w-4" /> LinkedIn
          </TabsTrigger>
          <TabsTrigger value="twitter" className="flex items-center gap-2">
            <TwitterIcon className="h-4 w-4" /> Twitter
          </TabsTrigger>
          <TabsTrigger value="instagram" className="flex items-center gap-2">
            <InstagramIcon className="h-4 w-4" /> Instagram
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="linkedin">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                    RM
                  </div>
                  <div>
                    <p className="font-semibold">RistoBar Manager</p>
                    <p className="text-sm text-muted-foreground">Piattaforma di gestione per ristoranti • Lancio</p>
                  </div>
                </div>
                
                <div className="linkedin-post">
                  <p className="mb-4">
                    🚀 <strong>GRANDE ANNUNCIO</strong>: Siamo entusiasti di annunciare il lancio ufficiale di RistoBar Manager 4.0! 🎉
                  </p>
                  
                  <p className="mb-4">
                    Dopo mesi di sviluppo e test con i nostri partner della ristorazione, abbiamo creato la soluzione definitiva per la gestione dei ristoranti e bar italiani.
                  </p>
                  
                  <p className="mb-4">
                    RistoBar Manager è una piattaforma all-in-one che integra:
                  </p>
                  
                  <ul className="list-disc pl-5 mb-4">
                    <li>✅ Gestione delle prenotazioni</li>
                    <li>✅ Punto cassa digitale</li>
                    <li>✅ Gestione del personale</li>
                    <li>✅ Inventario intelligente</li>
                    <li>✅ Menu digitale e ordinazioni da tavolo</li>
                    <li>✅ Analytics e reportistica avanzata</li>
                  </ul>
                  
                  <p className="mb-4">
                    La nostra missione è semplice: rendere la gestione del tuo locale più efficiente, permettendoti di concentrarti su ciò che ami fare - offrire un'esperienza eccezionale ai tuoi clienti.
                  </p>
                  
                  <p className="mb-4">
                    🎁 <strong>Offerta di lancio</strong>: I primi 100 ristoratori che si iscriveranno riceveranno uno sconto del 50% sul piano annuale e supporto prioritario personalizzato.
                  </p>
                  
                  <p className="mb-4">
                    Visita il nostro sito per saperne di più e iniziare la tua prova gratuita: www.ristobarmanager.it
                  </p>
                  
                  <p>
                    #Ristorazione #Innovazione #DigitalTransformation #RistoratoriItaliani #BarManager #GestioneRistoranti
                  </p>
                </div>
                
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={() => copyToClipboard(document.querySelector('.linkedin-post')?.textContent || '', 'LinkedIn')}
                  >
                    <CopyIcon className="h-4 w-4" /> 
                    Copia Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="twitter">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-400 flex items-center justify-center text-white font-bold">
                    RM
                  </div>
                  <div>
                    <p className="font-semibold">RistoBar Manager</p>
                    <p className="text-sm text-muted-foreground">@ristobarmanager</p>
                  </div>
                </div>
                
                <div className="twitter-post">
                  <p className="mb-4">
                    🚀 È ufficiale! RistoBar Manager 4.0 è qui per rivoluzionare il modo in cui gestisci il tuo ristorante o bar!
                  </p>
                  
                  <p className="mb-4">
                    Prenotazioni, cassa, personale, inventario e menu digitale in un'unica piattaforma pensata per la ristorazione italiana.
                  </p>
                  
                  <p className="mb-4">
                    Prova gratuita di 30 giorni disponibile ora 👇
                    ristobarmanager.it/prova
                  </p>
                  
                  <p>
                    #RistorazioneItaliana #Innovazione
                  </p>
                </div>
                
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={() => copyToClipboard(document.querySelector('.twitter-post')?.textContent || '', 'Twitter')}
                  >
                    <CopyIcon className="h-4 w-4" /> 
                    Copia Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="instagram">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground mb-4">
                  <strong>Nota:</strong> Per Instagram, includiamo sia il testo del post che le idee per le immagini da utilizzare.
                </p>
                
                <div className="instagram-post">
                  <p className="font-semibold mb-2">Testo del Post:</p>
                  <p className="mb-4">
                    🎉 FINALMENTE DISPONIBILE! 🎉
                  </p>
                  
                  <p className="mb-4">
                    Dopo mesi di sviluppo e feedback da parte di ristoratori come te, RistoBar Manager 4.0 è ora disponibile!
                  </p>
                  
                  <p className="mb-4">
                    La piattaforma all-in-one che rivoluziona la gestione del tuo locale:
                  </p>
                  
                  <p className="mb-4">
                    ✅ Prenotazioni online<br />
                    ✅ Gestione tavoli e sale<br />
                    ✅ Menu digitale<br />
                    ✅ Cassa e pagamenti<br />
                    ✅ Gestione del personale<br />
                    ✅ Inventario intelligente<br />
                    ✅ Analisi e statistiche
                  </p>
                  
                  <p className="mb-4">
                    Progettato specificamente per ristoranti e bar italiani, RistoBar Manager ti permette di gestire ogni aspetto della tua attività da un'unica dashboard intuitiva.
                  </p>
                  
                  <p className="mb-4">
                    🔗 Link in bio per una prova gratuita di 30 giorni e un'offerta esclusiva di lancio!
                  </p>
                  
                  <p>
                    #RistorazioneItaliana #BarManager #RistorantiItaliani #DigitalTransformation #GestioneRistorante #InnovazioneRistorazione #RistoBarManager
                  </p>
                </div>
                
                <div className="mt-6">
                  <p className="font-semibold mb-2">Idee per Immagini/Video:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Schermata principale della dashboard con statistiche e grafici colorati</li>
                    <li>Video breve che mostra il flusso di gestione di una prenotazione</li>
                    <li>Immagine divisa di "prima e dopo" che mostra la differenza tra gestione tradizionale e con RistoBar Manager</li>
                    <li>Animazione del logo con countdown al lancio</li>
                    <li>Testimonianze dei ristoratori che hanno testato la versione beta</li>
                  </ul>
                </div>
                
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={() => copyToClipboard(document.querySelector('.instagram-post')?.textContent || '', 'Instagram')}
                  >
                    <CopyIcon className="h-4 w-4" /> 
                    Copia Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SocialMediaPosts;
