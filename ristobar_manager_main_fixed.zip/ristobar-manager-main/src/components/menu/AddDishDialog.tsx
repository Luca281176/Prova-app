
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Upload } from "lucide-react";
import { Category, addDish, loadMenuData } from "@/services/menuService";

interface AddDishDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category: Category;
}

const allergies = [
  { id: "glutine", name: "Glutine" },
  { id: "lattosio", name: "Lattosio" },
  { id: "uova", name: "Uova" },
  { id: "pesce", name: "Pesce" },
  { id: "crostacei", name: "Crostacei" },
  { id: "frutta_secca", name: "Frutta a guscio" },
  { id: "soia", name: "Soia" },
  { id: "sedano", name: "Sedano" },
  { id: "senape", name: "Senape" },
  { id: "sesamo", name: "Sesamo" },
  { id: "solfiti", name: "Solfiti" },
  { id: "lupini", name: "Lupini" },
  { id: "molluschi", name: "Molluschi" }
];

const AddDishDialog = ({ open, onOpenChange, category }: AddDishDialogProps) => {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [available, setAvailable] = useState(true);
  const [visible, setVisible] = useState(true); // Add state for visibility
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // State for image handling
  const [image, setImage] = useState("");
  const [imagePreview, setImagePreview] = useState("");

  // Handle image input
  const handleImageInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setImagePreview(result);
        setImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!name.trim()) {
      toast({
        title: "Errore",
        description: "Il nome del piatto è obbligatorio",
        variant: "destructive",
      });
      return;
    }

    if (isNaN(parseFloat(price)) || parseFloat(price) <= 0) {
      toast({
        title: "Errore",
        description: "Inserisci un prezzo valido",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Use the uploaded image or fallback to default
      const dishImage = image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300";
      
      const newDish = addDish(category.id, {
        name: name.trim(),
        price: parseFloat(price),
        description: description.trim(),
        available,
        visible, // Add the visible property
        allergies: selectedAllergies,
        image: dishImage
      });

      if (newDish) {
        toast({
          title: "Piatto aggiunto",
          description: `${name} è stato aggiunto alla categoria ${category.name}`,
        });
        onOpenChange(false);
      } else {
        throw new Error("Impossibile aggiungere il piatto");
      }
    } catch (error) {
      console.error('Errore durante l\'aggiunta del piatto:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta del piatto",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleAllergy = (allergyId: string) => {
    if (selectedAllergies.includes(allergyId)) {
      setSelectedAllergies(selectedAllergies.filter(id => id !== allergyId));
    } else {
      setSelectedAllergies([...selectedAllergies, allergyId]);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(newOpen) => {
      if (!isSubmitting) {
        onOpenChange(newOpen);
      }
    }}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Aggiungi nuovo piatto</DialogTitle>
          <DialogDescription>
            Inserisci i dettagli del piatto da aggiungere al menu.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-5 py-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome piatto</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                placeholder="Nome del piatto" 
                disabled={isSubmitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Prezzo (€)</Label>
              <Input 
                id="price" 
                value={price} 
                onChange={(e) => setPrice(e.target.value)}
                placeholder="10.00" 
                type="number" 
                step="0.01" 
                min="0" 
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrizione</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descrizione del piatto..."
              rows={3}
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="image" className="block mb-2">Immagine</Label>
            <div className="flex items-center gap-4">
              {imagePreview && (
                <div className="relative h-20 w-20 rounded overflow-hidden border">
                  <img src={imagePreview} alt="Anteprima" className="h-full w-full object-cover" />
                </div>
              )}
              <div className="flex-1">
                <Input 
                  id="image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageInput}
                  className="hidden"
                  disabled={isSubmitting}
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full"
                  onClick={() => document.getElementById('image')?.click()}
                  disabled={isSubmitting}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Carica immagine
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Categoria</Label>
            <Select defaultValue={category.id} disabled>
              <SelectTrigger>
                <SelectValue placeholder="Seleziona categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={category.id}>{category.name}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label>Allergeni</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {allergies.map((allergy) => (
                <div key={allergy.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`allergy-${allergy.id}`} 
                    checked={selectedAllergies.includes(allergy.id)}
                    onCheckedChange={() => toggleAllergy(allergy.id)}
                    disabled={isSubmitting}
                  />
                  <Label 
                    htmlFor={`allergy-${allergy.id}`}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {allergy.name}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="available" 
                checked={available}
                onCheckedChange={(checked) => setAvailable(!!checked)}
                disabled={isSubmitting}
              />
              <Label htmlFor="available" className="cursor-pointer">Disponibile nel menu</Label>
            </div>
            
            {/* Add visibility checkbox */}
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="visible" 
                checked={visible}
                onCheckedChange={(checked) => setVisible(!!checked)}
                disabled={isSubmitting}
              />
              <Label htmlFor="visible" className="cursor-pointer">Visibile nel Menu Digitale</Label>
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvataggio...
                </>
              ) : "Aggiungi Piatto"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddDishDialog;
