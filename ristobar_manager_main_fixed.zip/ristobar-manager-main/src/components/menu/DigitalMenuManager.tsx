import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { QrCode, Smartphone, Download, Share2, Settings, Eye, Palette, Save } from 'lucide-react';
import QRCode from 'qrcode.react';
import { useToast } from '@/hooks/use-toast';
import { loadMenuSettings, updateMenuSettings } from '@/services/menuService';
import { getRestaurantInfoSync } from '@/components/cashier/bill/RestaurantInfoProvider';
import { UserSubscription } from '@/services/subscriptions/types';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';
import { hasSubscriptionLevel, FeatureAccessLevel } from '@/services/subscriptions';
import { useUser } from '@/contexts/user';

interface DigitalMenuManagerProps {
  userSubscription: UserSubscription | null;
}

const DigitalMenuManager = ({ userSubscription }: DigitalMenuManagerProps) => {
  const restaurantInfo = getRestaurantInfoSync();
  const { user } = useUser();
  const { toast } = useToast();
  const [menuUrl, setMenuUrl] = useState(() => {
    if (user?.id) {
      const baseUrl = window.location.origin;
      const slug = restaurantInfo.name
        .toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9-]/g, '');
      
      return `${baseUrl}/menu/${slug}?id=${user.id}`;
    }
    return '';
  });
  
  const [activeTab, setActiveTab] = useState('qrcode');
  const [menuSettings, setMenuSettings] = useState(() => loadMenuSettings());
  const canAccessProFeatures = hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO);
  
  const [primaryColor, setPrimaryColor] = useState('#6e59a5');
  const [accentColor, setAccentColor] = useState('#d6bcfa');
  
  const [customTitle, setCustomTitle] = useState('');
  const [customAddress, setCustomAddress] = useState('');
  const [customPhone, setCustomPhone] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [customWebsite, setCustomWebsite] = useState('');
  const [customVat, setCustomVat] = useState('');
  const [customDescription, setCustomDescription] = useState('');
  const [customOpeningHours, setCustomOpeningHours] = useState('');
  
  const [showLogo, setShowLogo] = useState(true);
  const [showPrices, setShowPrices] = useState(true);
  const [showDescriptions, setShowDescriptions] = useState(true);
  const [showAllergens, setShowAllergens] = useState(true);
  const [showUnavailable, setShowUnavailable] = useState(false);
  
  const [showAddress, setShowAddress] = useState(true);
  const [showPhone, setShowPhone] = useState(true);
  const [showEmail, setShowEmail] = useState(true);
  const [showWebsite, setShowWebsite] = useState(true);
  const [showVat, setShowVat] = useState(true);
  const [showDescription, setShowDescription] = useState(true);
  const [showOpeningHours, setShowOpeningHours] = useState(true);

  useEffect(() => {
    if (menuSettings.customization) {
      const customization = menuSettings.customization;
      
      setPrimaryColor(customization.primaryColor || '#6e59a5');
      setAccentColor(customization.accentColor || '#d6bcfa');
      
      setCustomTitle(customization.title || '');
      setCustomAddress(customization.address || '');
      setCustomPhone(customization.phone || '');
      setCustomEmail(customization.email || '');
      setCustomWebsite(customization.website || '');
      setCustomVat(customization.vat || '');
      setCustomDescription(customization.description || '');
      setCustomOpeningHours(customization.openingHours || '');
      
      setShowLogo(customization.showLogo !== false);
      
      if (customization.headerVisibility) {
        setShowAddress(customization.headerVisibility.address !== false);
        setShowPhone(customization.headerVisibility.phone !== false);
        setShowEmail(customization.headerVisibility.email !== false);
        setShowWebsite(customization.headerVisibility.website !== false);
        setShowVat(customization.headerVisibility.vat !== false);
        setShowDescription(customization.headerVisibility.description !== false);
        setShowOpeningHours(customization.headerVisibility.openingHours !== false);
      }
      
      if (customization.visibility) {
        setShowPrices(customization.visibility.prices !== false);
        setShowDescriptions(customization.visibility.descriptions !== false);
        setShowAllergens(customization.visibility.allergens !== false);
        setShowUnavailable(customization.visibility.unavailable === true);
      }
      
      console.log("Loaded customization settings in manager:", customization);
    }
  }, [menuSettings]);
  
  const handleSaveQrSettings = () => {
    const updatedSettings = updateMenuSettings({
      qrSettings: {
        ...menuSettings.qrSettings,
        generated: true,
        url: menuUrl
      }
    });
    
    setMenuSettings(updatedSettings);
    
    toast({
      title: 'Impostazioni salvate',
      description: 'Le impostazioni del QR Code sono state salvate con successo',
    });
  };
  
  const handleDownloadQR = () => {
    const canvas = document.getElementById('menu-qrcode') as HTMLCanvasElement;
    if (!canvas) return;
    
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = `${restaurantInfo.name.replace(/\s+/g, '-')}-menu-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'QR Code scaricato',
      description: 'Il QR Code è stato scaricato con successo',
    });
  };
  
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Menu di ${restaurantInfo.name}`,
          text: 'Dai un\'occhiata al nostro menu digitale!',
          url: menuUrl,
        });
        
        toast({
          title: 'Menu condiviso',
          description: 'Il link al menu è stato condiviso con successo',
        });
      } catch (error) {
        console.error('Errore durante la condivisione:', error);
        toast({
          title: 'Errore',
          description: 'Non è stato possibile condividere il menu',
          variant: 'destructive',
        });
      }
    } else {
      navigator.clipboard.writeText(menuUrl);
      toast({
        title: 'Link copiato',
        description: 'Il link al menu è stato copiato negli appunti',
      });
    }
  };

  const handleSaveCustomizations = () => {
    const customization = {
      primaryColor,
      accentColor,
      
      title: customTitle,
      address: customAddress,
      phone: customPhone,
      email: customEmail,
      website: customWebsite,
      vat: customVat,
      description: customDescription,
      openingHours: customOpeningHours,
      
      showLogo,
      
      headerVisibility: {
        address: showAddress,
        phone: showPhone,
        email: showEmail,
        website: showWebsite,
        vat: showVat,
        description: showDescription,
        openingHours: showOpeningHours,
      },
      
      visibility: {
        prices: showPrices,
        descriptions: showDescriptions,
        allergens: showAllergens,
        unavailable: showUnavailable
      }
    };
    
    console.log("Saving customization settings:", customization);
    
    const updatedSettings = updateMenuSettings({
      customization
    });
    
    setMenuSettings(updatedSettings);
    
    toast({
      title: 'Personalizzazioni salvate',
      description: 'Le personalizzazioni del menu digitale sono state salvate con successo',
    });
  };
  
  const handleToggleVisibility = (dishId: string, visible: boolean) => {
    toast({
      title: `Piatto ${visible ? 'mostrato' : 'nascosto'}`,
      description: `Il piatto è stato ${visible ? 'aggiunto al' : 'rimosso dal'} menu digitale`,
    });
  };
  
  return (
    <div className="space-y-6 mt-2">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Menu Digitale</CardTitle>
            <CardDescription>
              Condividi il tuo menu con i clienti tramite QR Code o link diretto
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex flex-col items-center justify-center p-6 border rounded-lg bg-muted">
                <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
                  <div className="p-4 bg-primary text-primary-foreground">
                    <div className="flex items-center justify-between">
                      {restaurantInfo.logo && (
                        <img 
                          src={restaurantInfo.logo} 
                          alt={restaurantInfo.name} 
                          className="h-12 w-auto object-contain"
                        />
                      )}
                      <h2 className="text-xl font-bold">{restaurantInfo.name}</h2>
                    </div>
                    {restaurantInfo.description && (
                      <p className="text-sm mt-1 opacity-90">{restaurantInfo.description}</p>
                    )}
                    {restaurantInfo.address && (
                      <p className="text-xs mt-2">{restaurantInfo.address}</p>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium mb-2">Anteprima Menu</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Antipasto Misto</span>
                        <span>€8.00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pasta al Pomodoro</span>
                        <span>€10.00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tiramisù</span>
                        <span>€5.00</span>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="mt-4 text-sm text-muted-foreground text-center">
                  Questa è un'anteprima semplificata. Il menu reale includerà tutte le categorie e i prodotti configurati.
                </p>
              </div>
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <Button variant="outline" onClick={handleShare}>
                  <Share2 className="mr-2 h-4 w-4" />
                  Condividi Menu
                </Button>
                <Button onClick={() => window.open(menuUrl, '_blank')}>
                  <Eye className="mr-2 h-4 w-4" />
                  Anteprima Menu Completo
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>QR Code e Link</CardTitle>
            <CardDescription>
              Genera e scarica il QR Code per il tuo menu digitale
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="qrcode">
                  <QrCode className="h-4 w-4 mr-2" />
                  QR Code
                </TabsTrigger>
                <TabsTrigger value="link">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Link Diretto
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="qrcode" className="space-y-4">
                <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                  <QRCode
                    id="menu-qrcode"
                    value={menuUrl}
                    size={200}
                    level="H"
                    includeMargin={true}
                    renderAs="canvas"
                  />
                </div>
                
                <Button onClick={handleDownloadQR} className="w-full">
                  <Download className="h-4 w-4 mr-2" />
                  Scarica QR Code
                </Button>
                
                <p className="text-sm text-muted-foreground">
                  Stampa questo QR Code e posizionalo sui tavoli per permettere ai clienti di visualizzare il menu.
                </p>
              </TabsContent>
              
              <TabsContent value="link" className="space-y-4">
                <div className="p-3 bg-muted rounded-md overflow-x-auto">
                  <code className="text-sm break-all">{menuUrl}</code>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    navigator.clipboard.writeText(menuUrl);
                    toast({
                      title: 'Link copiato',
                      description: 'Il link al menu è stato copiato negli appunti',
                    });
                  }}
                >
                  Copia link
                </Button>
                
                <p className="text-sm text-muted-foreground">
                  Condividi questo link sui social media o via email per permettere ai clienti di visualizzare il menu.
                </p>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Visibilità Prodotti</CardTitle>
          <CardDescription>
            Gestisci quali prodotti saranno visibili nel menu digitale
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Puoi scegliere quali prodotti mostrare nel menu digitale. Per impostazione predefinita, tutti i prodotti attivi sono visibili.
          </p>
          
          <div className="space-y-2">
            <h3 className="font-medium">Impostazioni della Visibilità</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="show-prices">Mostra prezzi</Label>
                <Switch 
                  id="show-prices" 
                  checked={showPrices}
                  onCheckedChange={setShowPrices}
                />
              </div>
              
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="show-descriptions">Mostra descrizioni</Label>
                <Switch 
                  id="show-descriptions" 
                  checked={showDescriptions}
                  onCheckedChange={setShowDescriptions}
                />
              </div>
              
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="show-allergens">Mostra allergeni</Label>
                <Switch 
                  id="show-allergens" 
                  checked={showAllergens}
                  onCheckedChange={setShowAllergens}
                />
              </div>
              
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="show-unavailable">Mostra piatti non disponibili</Label>
                <Switch 
                  id="show-unavailable" 
                  checked={showUnavailable}
                  onCheckedChange={setShowUnavailable}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Personalizzazione</CardTitle>
          <CardDescription>
            Personalizza l'aspetto del tuo menu digitale
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-medium">Colori e Stile</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="primary-color">Colore primario</Label>
                  <Input 
                    id="primary-color" 
                    type="color" 
                    className="h-10" 
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accent-color">Colore secondario</Label>
                  <Input 
                    id="accent-color" 
                    type="color" 
                    className="h-10" 
                    value={accentColor}
                    onChange={(e) => setAccentColor(e.target.value)}
                  />
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-medium">Visibilità Elementi Header</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-logo" 
                    checked={showLogo}
                    onCheckedChange={setShowLogo}
                  />
                  <Label htmlFor="show-logo">Mostra logo del ristorante</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-description" 
                    checked={showDescription}
                    onCheckedChange={setShowDescription}
                  />
                  <Label htmlFor="show-description">Mostra descrizione</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-address" 
                    checked={showAddress}
                    onCheckedChange={setShowAddress}
                  />
                  <Label htmlFor="show-address">Mostra indirizzo</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-phone" 
                    checked={showPhone}
                    onCheckedChange={setShowPhone}
                  />
                  <Label htmlFor="show-phone">Mostra telefono</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-email" 
                    checked={showEmail}
                    onCheckedChange={setShowEmail}
                  />
                  <Label htmlFor="show-email">Mostra email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-website" 
                    checked={showWebsite}
                    onCheckedChange={setShowWebsite}
                  />
                  <Label htmlFor="show-website">Mostra sito web</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-vat" 
                    checked={showVat}
                    onCheckedChange={setShowVat}
                  />
                  <Label htmlFor="show-vat">Mostra P.IVA</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="show-openingHours" 
                    checked={showOpeningHours}
                    onCheckedChange={setShowOpeningHours}
                  />
                  <Label htmlFor="show-openingHours">Mostra orari di apertura</Label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border rounded-lg p-4">
            <h3 className="font-medium mb-4">Intestazione Menu</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="menu-title">Titolo personalizzato</Label>
                <Input 
                  id="menu-title" 
                  placeholder="Menu di [nome ristorante]" 
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="restaurant-address">Indirizzo</Label>
                <Input 
                  id="restaurant-address" 
                  placeholder="Indirizzo del ristorante" 
                  value={customAddress}
                  onChange={(e) => setCustomAddress(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="restaurant-phone">Telefono</Label>
                <Input 
                  id="restaurant-phone" 
                  placeholder="Numero di telefono" 
                  value={customPhone}
                  onChange={(e) => setCustomPhone(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="restaurant-email">Email</Label>
                <Input 
                  id="restaurant-email" 
                  placeholder="Indirizzo email" 
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="restaurant-website">Sito Web</Label>
                <Input 
                  id="restaurant-website" 
                  placeholder="URL del sito web" 
                  value={customWebsite}
                  onChange={(e) => setCustomWebsite(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="restaurant-vat">P.IVA</Label>
                <Input 
                  id="restaurant-vat" 
                  placeholder="Partita IVA" 
                  value={customVat}
                  onChange={(e) => setCustomVat(e.target.value)}
                />
              </div>
              
              <div className="space-y-2 col-span-1 md:col-span-2">
                <Label htmlFor="restaurant-description">Descrizione</Label>
                <Input 
                  id="restaurant-description" 
                  placeholder="Breve descrizione del ristorante" 
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                />
              </div>
              
              <div className="space-y-2 col-span-1 md:col-span-2">
                <Label htmlFor="restaurant-hours">Orari di Apertura</Label>
                <Input 
                  id="restaurant-hours" 
                  placeholder="Es. Lun-Ven: 12:00-15:00, 19:00-23:00" 
                  value={customOpeningHours}
                  onChange={(e) => setCustomOpeningHours(e.target.value)}
                />
              </div>
            </div>
          </div>
          
          <Button onClick={handleSaveCustomizations} className="w-full">
            <Save className="h-4 w-4 mr-2" />
            Salva Personalizzazioni
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default DigitalMenuManager;
