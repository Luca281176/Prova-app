
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Upload, Eye, EyeOff } from "lucide-react";
import { Category, Dish, updateDish } from "@/services/menuService";

interface EditDishDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dish: Dish;
  category: Category;
}

const allergies = [
  { id: "glutine", name: "Glutine" },
  { id: "lattosio", name: "Lattosio" },
  { id: "uova", name: "Uova" },
  { id: "pesce", name: "Pesce" },
  { id: "crostacei", name: "Crostacei" },
  { id: "frutta_secca", name: "Frutta a guscio" },
  { id: "soia", name: "Soia" },
  { id: "sedano", name: "Sedano" },
  { id: "senape", name: "Senape" },
  { id: "sesamo", name: "Sesamo" },
  { id: "solfiti", name: "Solfiti" },
  { id: "lupini", name: "Lupini" },
  { id: "molluschi", name: "Molluschi" }
];

const EditDishDialog = ({ open, onOpenChange, dish, category }: EditDishDialogProps) => {
  const [name, setName] = useState(dish.name);
  const [price, setPrice] = useState(dish.price.toString());
  const [description, setDescription] = useState(dish.description);
  const [available, setAvailable] = useState(dish.available);
  const [visible, setVisible] = useState(dish.visible !== false); // Default to true if not set
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>(dish.allergies);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  // State for image handling
  const [image, setImage] = useState(dish.image);
  const [imagePreview, setImagePreview] = useState(dish.image);

  // Handle image input
  const handleImageInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setImagePreview(result);
        setImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!name.trim()) {
      toast({
        title: "Errore",
        description: "Il nome del piatto è obbligatorio",
        variant: "destructive",
      });
      return;
    }

    if (isNaN(parseFloat(price)) || parseFloat(price) <= 0) {
      toast({
        title: "Errore",
        description: "Inserisci un prezzo valido",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const updatedDish = updateDish(category.id, dish.id, {
        name: name.trim(),
        price: parseFloat(price),
        description: description.trim(),
        available,
        visible,
        allergies: selectedAllergies,
        image
      });

      if (updatedDish) {
        toast({
          title: "Piatto aggiornato",
          description: `${name} è stato aggiornato con successo`,
        });
        onOpenChange(false);
      } else {
        throw new Error("Impossibile aggiornare il piatto");
      }
    } catch (error) {
      console.error('Errore durante l\'aggiornamento del piatto:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento del piatto",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleAllergy = (allergyId: string) => {
    if (selectedAllergies.includes(allergyId)) {
      setSelectedAllergies(selectedAllergies.filter(id => id !== allergyId));
    } else {
      setSelectedAllergies([...selectedAllergies, allergyId]);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(newOpen) => {
      if (!isSubmitting) {
        onOpenChange(newOpen);
      }
    }}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Modifica piatto: {dish.name}</DialogTitle>
          <DialogDescription>
            Modifica i dettagli del piatto.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-5 py-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome piatto</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)}
                placeholder="Nome del piatto"
                disabled={isSubmitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Prezzo (€)</Label>
              <Input 
                id="price" 
                value={price} 
                onChange={(e) => setPrice(e.target.value)}
                placeholder="10.00" 
                type="number" 
                step="0.01" 
                min="0"
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrizione</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descrizione del piatto..."
              rows={3}
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-image" className="block mb-2">Immagine</Label>
            <div className="flex items-center gap-4">
              {imagePreview && (
                <div className="relative h-20 w-20 rounded overflow-hidden border">
                  <img src={imagePreview} alt={name} className="h-full w-full object-cover" />
                </div>
              )}
              <div className="flex-1">
                <Input 
                  id="edit-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageInput}
                  className="hidden"
                  disabled={isSubmitting}
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full"
                  onClick={() => document.getElementById('edit-image')?.click()}
                  disabled={isSubmitting}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Carica immagine
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Categoria</Label>
            <Select defaultValue={category.id} disabled>
              <SelectTrigger>
                <SelectValue placeholder="Seleziona categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={category.id}>{category.name}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label>Allergeni</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {allergies.map((allergy) => (
                <div key={allergy.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`allergy-${allergy.id}`} 
                    checked={selectedAllergies.includes(allergy.id)}
                    onCheckedChange={() => toggleAllergy(allergy.id)}
                    disabled={isSubmitting}
                  />
                  <Label 
                    htmlFor={`allergy-${allergy.id}`}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {allergy.name}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="available" 
                checked={available}
                onCheckedChange={(checked) => setAvailable(!!checked)}
                disabled={isSubmitting}
              />
              <Label htmlFor="available" className="cursor-pointer">Disponibile nel menu</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="visible" 
                checked={visible}
                onCheckedChange={(checked) => setVisible(!!checked)}
                disabled={isSubmitting}
              />
              <Label htmlFor="visible" className="cursor-pointer flex items-center">
                {visible ? (
                  <>
                    <Eye className="h-4 w-4 mr-2" />
                    Visibile nel Menu Digitale
                  </>
                ) : (
                  <>
                    <EyeOff className="h-4 w-4 mr-2" />
                    Nascosto nel Menu Digitale
                  </>
                )}
              </Label>
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvataggio...
                </>
              ) : "Salva Modifiche"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditDishDialog;
