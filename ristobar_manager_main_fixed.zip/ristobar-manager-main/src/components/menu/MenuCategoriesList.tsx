import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Plus, Edit, Trash2, ChevronUp, ChevronDown } from 'lucide-react';
import MenuDishCard from './MenuDishCard';
import AddDishDialog from './AddDishDialog';
import EditCategoryDialog from './EditCategoryDialog';
import { useToast } from '@/hooks/use-toast';
import { Category, loadMenuData, saveMenuData, moveCategory, deleteCategory } from '@/services/menuService';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

// Static variable to persist category open states across renders but not navigation
let persistentOpenCategories: string[] = [];

const MenuCategoriesList = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedDish, setSelectedDish] = useState<any>(null);
  const [showAddDishDialog, setShowAddDishDialog] = useState(false);
  const [showEditCategoryDialog, setShowEditCategoryDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [openCategories, setOpenCategories] = useState<string[]>(persistentOpenCategories);
  const { toast } = useToast();

  // Caricamento dati iniziale
  useEffect(() => {
    const loadData = () => {
      const data = loadMenuData();
      setCategories(data);
    };

    loadData();

    // Sincronizzazione tra tabs del browser
    const handleDataUpdate = () => loadData();
    window.addEventListener('menu-data-updated', handleDataUpdate);

    return () => {
      window.removeEventListener('menu-data-updated', handleDataUpdate);
      // Save open categories state when component unmounts
      persistentOpenCategories = openCategories;
    };
  }, [openCategories]);

  // Toggle category open/close state
  const toggleCategory = (categoryId: string) => {
    setOpenCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId) 
        : [...prev, categoryId]
    );
  };

  // Check if category is open
  const isCategoryOpen = (categoryId: string) => {
    return openCategories.includes(categoryId);
  };

  const handleCategoryUp = (categoryId: string) => {
    setIsLoading(true);
    const success = moveCategory(categoryId, 'up');
    if (success) {
      setCategories(loadMenuData());
      toast({
        title: "Categoria spostata",
        description: "L'ordine delle categorie è stato aggiornato",
      });
    }
    setIsLoading(false);
  };

  const handleCategoryDown = (categoryId: string) => {
    setIsLoading(true);
    const success = moveCategory(categoryId, 'down');
    if (success) {
      setCategories(loadMenuData());
      toast({
        title: "Categoria spostata",
        description: "L'ordine delle categorie è stato aggiornato",
      });
    }
    setIsLoading(false);
  };

  const handleAddDish = (categoryId: string) => {
    const category = categories.find(c => c.id === categoryId);
    if (category) {
      setSelectedCategory(category);
      setShowAddDishDialog(true);
    }
  };

  const handleEditCategory = (category: Category) => {
    setSelectedCategory(category);
    setShowEditCategoryDialog(true);
  };

  const confirmDeleteCategory = (category: Category) => {
    setSelectedCategory(category);
    setShowDeleteDialog(true);
  };

  const handleDeleteCategory = async () => {
    if (!selectedCategory) return;
    
    const success = deleteCategory(selectedCategory.id);
    if (success) {
      setCategories(loadMenuData());
      toast({
        title: "Categoria eliminata",
        description: "La categoria è stata eliminata con successo",
      });
    } else {
      toast({
        title: "Errore",
        description: "Impossibile eliminare la categoria",
        variant: "destructive"
      });
    }
  };

  const filteredCategories = categories.filter(category => 
    category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.dishes.some(dish => 
      dish.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Cerca categorie o piatti..."
          className="pl-8"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid gap-6">
        {filteredCategories.map((category) => (
          <Card key={category.id} className="overflow-hidden">
            <Collapsible 
              open={isCategoryOpen(category.id)}
              onOpenChange={() => toggleCategory(category.id)}
            >
              <CardHeader className="bg-muted/50 py-3">
                <div className="flex items-center justify-between">
                  <CollapsibleTrigger asChild>
                    <div className="flex items-center gap-2 cursor-pointer">
                      <CardTitle className="text-xl">{category.name}</CardTitle>
                      {isCategoryOpen(category.id) ? (
                        <ChevronUp className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                  </CollapsibleTrigger>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleCategoryUp(category.id)} 
                      disabled={category.order === 1 || isLoading}
                    >
                      <ChevronUp className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleCategoryDown(category.id)}
                      disabled={category.order === categories.length || isLoading}
                    >
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleEditCategory(category)}
                      disabled={isLoading}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => confirmDeleteCategory(category)}
                      disabled={isLoading}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => handleAddDish(category.id)}
                      disabled={isLoading}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Aggiungi Piatto
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CollapsibleContent>
                <CardContent className="p-0">
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
                    {category.dishes.map((dish) => (
                      <MenuDishCard 
                        key={dish.id} 
                        dish={dish} 
                        category={category} 
                        onEdit={(dish) => setSelectedDish(dish)} 
                      />
                    ))}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        ))}
      </div>

      {showAddDishDialog && selectedCategory && (
        <AddDishDialog 
          open={showAddDishDialog} 
          onOpenChange={setShowAddDishDialog} 
          category={selectedCategory} 
        />
      )}

      {showEditCategoryDialog && selectedCategory && (
        <EditCategoryDialog 
          open={showEditCategoryDialog} 
          onOpenChange={setShowEditCategoryDialog} 
          category={selectedCategory} 
        />
      )}

      {showDeleteDialog && selectedCategory && (
        <ConfirmDialog
          open={showDeleteDialog}
          onOpenChange={setShowDeleteDialog}
          onConfirm={handleDeleteCategory}
          title="Elimina categoria"
          description={`Sei sicuro di voler eliminare la categoria "${selectedCategory.name}"? Questa azione eliminerà anche tutti i piatti associati.`}
          confirmText="Elimina"
          cancelText="Annulla"
          variant="destructive"
        />
      )}
    </div>
  );
};

export default MenuCategoriesList;
