
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Edit, Trash2, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import EditDishDialog from "./EditDishDialog";
import { useToast } from "@/hooks/use-toast";
import { Category, Dish, deleteDish, loadMenuData, updateDish } from "@/services/menuService";
import { ConfirmDialog } from "@/components/ConfirmDialog";

interface MenuDishCardProps {
  dish: Dish;
  category: Category;
  onEdit: (dish: Dish) => void;
}

const allergyLabels: Record<string, string> = {
  glutine: "Glutine",
  lattosio: "Lattosio",
  uova: "Uova",
  pesce: "Pesce",
  crostacei: "Crostacei",
  frutta_secca: "Frutta a guscio",
  soia: "Soia",
  sedano: "Sedano",
  senape: "Senape",
  sesamo: "Sesamo",
  solfiti: "Solfiti",
  lupini: "Lupini",
  molluschi: "Molluschi"
};

const MenuDishCard = ({ dish, category, onEdit }: MenuDishCardProps) => {
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isAvailable, setIsAvailable] = useState(dish.available);
  const [isVisible, setIsVisible] = useState(dish.visible !== false); // Default to true if not set
  const { toast } = useToast();

  const handleDeleteDish = async () => {
    try {
      const success = deleteDish(category.id, dish.id);
      if (success) {
        toast({
          title: "Piatto eliminato",
          description: `${dish.name} è stato eliminato dal menu`,
        });
      } else {
        throw new Error("Impossibile eliminare il piatto");
      }
    } catch (error) {
      console.error('Errore durante l\'eliminazione del piatto:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'eliminazione del piatto",
        variant: "destructive",
      });
    }
  };

  const toggleAvailability = (available: boolean) => {
    try {
      const updatedDish = updateDish(category.id, dish.id, { available });
      if (updatedDish) {
        setIsAvailable(available);
        toast({
          title: available ? "Piatto disponibile" : "Piatto non disponibile",
          description: `${dish.name} è ${available ? "ora disponibile" : "non più disponibile"} nel menu`,
        });
      } else {
        throw new Error("Impossibile aggiornare la disponibilità del piatto");
      }
    } catch (error) {
      console.error('Errore durante l\'aggiornamento della disponibilità:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento della disponibilità",
        variant: "destructive",
      });
    }
  };

  const toggleVisibility = (visible: boolean) => {
    try {
      const updatedDish = updateDish(category.id, dish.id, { visible });
      if (updatedDish) {
        setIsVisible(visible);
        toast({
          title: visible ? "Piatto visibile" : "Piatto nascosto",
          description: `${dish.name} è ${visible ? "ora visibile" : "ora nascosto"} nel menu digitale`,
        });
      } else {
        throw new Error("Impossibile aggiornare la visibilità del piatto");
      }
    } catch (error) {
      console.error('Errore durante l\'aggiornamento della visibilità:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento della visibilità",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className={`overflow-hidden h-full flex flex-col ${!isAvailable ? 'opacity-60' : ''}`}>
      <div className="relative h-40 overflow-hidden">
        <img
          src={dish.image}
          alt={dish.name}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        {!isAvailable && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Badge variant="destructive" className="text-sm">Non Disponibile</Badge>
          </div>
        )}
        {!isVisible && (
          <div className="absolute top-2 right-2">
            <Badge variant="outline" className="bg-background/80 text-xs">
              <EyeOff className="h-3 w-3 mr-1" />
              Nascosto
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="py-4 flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium text-lg truncate">{dish.name}</h3>
          <Badge variant="secondary" className="text-sm">€{dish.price.toFixed(2)}</Badge>
        </div>
        <p className="text-muted-foreground text-sm line-clamp-2 mb-2">{dish.description}</p>
        {dish.allergies.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {dish.allergies.map((allergy) => (
              <Badge key={allergy} variant="outline" className="text-xs">
                {allergyLabels[allergy] || allergy}
              </Badge>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between mt-3">
          <span className="text-sm text-muted-foreground">
            {isAvailable ? "Disponibile" : "Non disponibile"}
          </span>
          <Switch 
            checked={isAvailable}
            onCheckedChange={toggleAvailability}
          />
        </div>
        
        <div className="flex items-center justify-between mt-3 border-t pt-3">
          <span className="text-sm text-muted-foreground flex items-center">
            {isVisible ? (
              <>
                <Eye className="h-3 w-3 mr-1" />
                Visibile nel Menu Digitale
              </>
            ) : (
              <>
                <EyeOff className="h-3 w-3 mr-1" />
                Nascosto nel Menu Digitale
              </>
            )}
          </span>
          <Switch 
            checked={isVisible}
            onCheckedChange={toggleVisibility}
          />
        </div>
      </CardContent>
      <CardFooter className="pt-0 pb-4 flex justify-end gap-2">
        <Button variant="ghost" size="icon" onClick={() => setShowEditDialog(true)}>
          <Edit className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setShowDeleteDialog(true)}>
          <Trash2 className="h-4 w-4" />
        </Button>
      </CardFooter>

      {showEditDialog && (
        <EditDishDialog 
          open={showEditDialog} 
          onOpenChange={setShowEditDialog} 
          dish={dish} 
          category={category} 
        />
      )}

      {showDeleteDialog && (
        <ConfirmDialog 
          open={showDeleteDialog}
          onOpenChange={setShowDeleteDialog}
          onConfirm={handleDeleteDish}
          title="Elimina piatto"
          description={`Sei sicuro di voler eliminare il piatto "${dish.name}"?`}
          confirmText="Elimina"
          cancelText="Annulla"
          variant="destructive"
        />
      )}
    </Card>
  );
};

export default MenuDishCard;
