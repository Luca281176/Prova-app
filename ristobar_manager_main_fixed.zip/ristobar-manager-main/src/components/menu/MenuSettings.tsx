import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useUser } from '@/contexts/user/UserProvider';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription, FeatureAccessLevel } from '@/services/subscriptions/types';
import { hasSubscriptionLevel } from '@/services/subscriptions';

interface MenuSettingsProps {
  userSubscription?: UserSubscription | null;
}

const MenuSettings: React.FC<MenuSettingsProps> = ({ userSubscription: propSubscription }) => {
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(propSubscription || null);
  const [isLoadingSubscription, setIsLoadingSubscription] = useState(!propSubscription);
  const { user } = useUser();

  const canAccessProFeatures = hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO);
  
  useEffect(() => {
    if (propSubscription) {
      setUserSubscription(propSubscription);
      setIsLoadingSubscription(false);
      return;
    }
    
    const fetchSubscription = async () => {
      if (user?.id) {
        try {
          const subscription = await getUserSubscription(user.id);
          setUserSubscription(subscription);
        } catch (error) {
          console.error("Error fetching subscription:", error);
          setUserSubscription(null);
        }
      }
      setIsLoadingSubscription(false);
    };
    
    fetchSubscription();
  }, [user?.id, propSubscription]);
  
  if (isLoadingSubscription) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 mt-2">
      <Card>
        <CardHeader>
          <CardTitle>Impostazioni Menu</CardTitle>
          <CardDescription>
            Configura le opzioni generali del menu del tuo ristorante
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="basic">Menu Standard e Digitale</TabsTrigger>
              <TabsTrigger value="advanced" disabled={!canAccessProFeatures}>
                Menu Avanzati
              </TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium">Menu Standard</h3>
                    <p className="text-sm text-muted-foreground">
                      Configura il menu standard del tuo ristorante
                    </p>
                  </div>
                  <div>
                    <Switch id="standard-menu" defaultChecked />
                    <Label htmlFor="standard-menu" className="ml-2">Attivo</Label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium">Menu Digitale</h3>
                    <p className="text-sm text-muted-foreground">
                      Attiva il menu digitale con QR code per il tuo ristorante
                    </p>
                  </div>
                  <div>
                    <Switch id="digital-menu" defaultChecked />
                    <Label htmlFor="digital-menu" className="ml-2">Attivo</Label>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="advanced" className="space-y-6">
              {canAccessProFeatures ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium">Menu Pranzo/Cena</h3>
                      <p className="text-sm text-muted-foreground">
                        Configura menu specifici per pranzo e cena
                      </p>
                    </div>
                    <div>
                      <Switch id="lunch-dinner-menu" />
                      <Label htmlFor="lunch-dinner-menu" className="ml-2">Attivo</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium">Menu Personalizzati</h3>
                      <p className="text-sm text-muted-foreground">
                        Crea menu personalizzati per eventi speciali
                      </p>
                    </div>
                    <div>
                      <Switch id="custom-menus" />
                      <Label htmlFor="custom-menus" className="ml-2">Attivo</Label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium">Integrazione Magazzino</h3>
                      <p className="text-sm text-muted-foreground">
                        Collega il menu al sistema di gestione del magazzino
                      </p>
                    </div>
                    <div>
                      <Switch id="inventory-integration" />
                      <Label htmlFor="inventory-integration" className="ml-2">Attivo</Label>
                    </div>
                  </div>
                </div>
              ) : (
                <PlanFeatureAlert
                  title="Menu avanzati non disponibili"
                  description="Le funzionalità avanzate del menu sono disponibili solo per gli abbonamenti Pro e Ultimate."
                  availableInPlans={['Pro', 'Ultimate']}
                  buttonText="Aggiorna il tuo piano"
                  buttonLink="/subscriptions"
                />
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default MenuSettings;
