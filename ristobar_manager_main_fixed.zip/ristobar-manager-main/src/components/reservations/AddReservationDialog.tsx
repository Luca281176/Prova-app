
import { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { addReservation, updateReservation } from '@/services/reservationService';
import { Reservation } from '@/types/reservations';
import { ReservationFormData, SpecialRequestsState, AddReservationDialogProps } from './types';
import { toast } from 'sonner';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

// Import our component parts
import ReservationCustomerForm from './ReservationCustomerForm';
import ReservationDateTimePicker from './ReservationDateTimePicker';
import TableAssignmentSection from './TableAssignmentSection';
import ReservationStatusSelect from './ReservationStatusSelect';
import NotesAndSpecialRequests from './NotesAndSpecialRequests';
import SendConfirmationCheckbox from './SendConfirmationCheckbox';

const AddReservationDialog = ({ 
  open, 
  onOpenChange,
  onSuccess,
  preselectedDate,
  isEditing = false,
  existingReservation,
  preselectedTable = '',
  preselectedTableName = ''
}: AddReservationDialogProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<ReservationFormData>({
    name: '',
    phone: '',
    email: '',
    date: preselectedDate || new Date(),
    time: '',
    partySize: '2',
    table: preselectedTable,
    notes: '',
    specialRequests: {
      window: false,
      highChair: false,
      kidsMenu: false,
      birthday: false,
      quiet: false,
    },
    status: 'confirmed',
    sendConfirmation: true,
    isManualAssignment: !!preselectedTable
  });

  useEffect(() => {
    if (isEditing && existingReservation) {
      const reservation = existingReservation;
      
      const specialRequests: SpecialRequestsState = {
        window: false,
        highChair: false,
        kidsMenu: false,
        birthday: false,
        quiet: false,
      };
      
      if (reservation.specialRequests) {
        reservation.specialRequests.forEach(req => {
          if (req.includes('finestra')) specialRequests.window = true;
          if (req.includes('seggiolone')) specialRequests.highChair = true;
          if (req.includes('bambini')) specialRequests.kidsMenu = true;
          if (req.includes('compleanno') || req.includes('anniversario')) specialRequests.birthday = true;
          if (req.includes('tranquilla')) specialRequests.quiet = true;
        });
      }
      
      setFormData({
        name: reservation.customerName,
        phone: reservation.phone,
        email: reservation.email || '',
        date: new Date(reservation.date),
        time: reservation.time,
        partySize: String(reservation.partySize),
        table: reservation.tableId || '',
        notes: reservation.notes || '',
        specialRequests,
        status: reservation.status,
        sendConfirmation: false,
        isManualAssignment: !!reservation.tableId
      });
    } else if (preselectedTable) {
      setFormData(prev => ({
        ...prev,
        table: preselectedTable,
        isManualAssignment: true
      }));
    }
  }, [isEditing, existingReservation, preselectedTable]);

  const handleFormChange = <K extends keyof ReservationFormData>(
    field: K, 
    value: ReservationFormData[K]
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error message when form is changed
    if (error) setError(null);
  };

  const handleSpecialRequestChange = (key: keyof SpecialRequestsState, value: boolean) => {
    setFormData(prev => ({
      ...prev,
      specialRequests: {
        ...prev.specialRequests,
        [key]: value
      }
    }));
  };
  
  const handleManualAssignmentChange = (isManual: boolean) => {
    setFormData(prev => ({
      ...prev,
      isManualAssignment: isManual
    }));
    // Clear error when changing assignment mode
    if (error) setError(null);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      phone: '',
      email: '',
      date: preselectedDate || new Date(),
      time: '',
      partySize: '2',
      table: '',
      notes: '',
      specialRequests: {
        window: false,
        highChair: false,
        kidsMenu: false,
        birthday: false,
        quiet: false,
      },
      status: 'confirmed',
      sendConfirmation: true,
      isManualAssignment: false
    });
    setError(null);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    try {
      if (!formData.name || !formData.phone || !formData.time || !formData.partySize) {
        toast.error("Compila tutti i campi obbligatori");
        setIsSubmitting(false);
        return;
      }
      
      const specialRequestsArray = Object.entries(formData.specialRequests)
        .filter(([_, value]) => value)
        .map(([key]) => {
          switch(key) {
            case 'window': return 'Vicino alla finestra';
            case 'highChair': return 'Seggiolone per bambini';
            case 'kidsMenu': return 'Menù bambini';
            case 'birthday': return 'Compleanno/Anniversario';
            case 'quiet': return 'Zona tranquilla';
            default: return key;
          }
        });
      
      const reservationData: Omit<Reservation, 'id' | 'createdAt' | 'updatedAt'> = {
        customerName: formData.name,
        phone: formData.phone,
        email: formData.email || undefined,
        date: formData.date,
        time: formData.time,
        partySize: parseInt(formData.partySize, 10),
        tableId: formData.isManualAssignment ? formData.table : undefined,
        status: formData.status as Reservation['status'],
        notes: formData.notes || undefined,
        specialRequests: specialRequestsArray.length ? specialRequestsArray : undefined
      };
      
      console.log(isEditing ? 'Updating reservation...' : 'Saving reservation...', reservationData);
      
      let result;
      
      if (isEditing && existingReservation) {
        result = await updateReservation(existingReservation.id, reservationData);
      } else {
        result = await addReservation(reservationData);
      }
      
      if (result.error) {
        setError(result.error);
        setIsSubmitting(false);
        return;
      }
      
      if (isEditing) {
        toast.success("Prenotazione aggiornata con successo");
      } else {
        toast.success("Prenotazione aggiunta con successo");
      }
      
      resetForm();
      onOpenChange(false);
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("Error saving reservation:", error);
      setError(`Si è verificato un errore: ${error instanceof Error ? error.message : 'Errore sconosciuto'}`);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const showTableAssignment = !preselectedTable;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[650px] max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>{isEditing ? 'Modifica Prenotazione' : 'Aggiungi Prenotazione'}</DialogTitle>
            <DialogDescription>
              {preselectedTableName 
                ? `Prenotazione per il tavolo ${preselectedTableName}. Tutti i campi con * sono obbligatori.` 
                : 'Inserisci i dettagli della prenotazione. Tutti i campi con * sono obbligatori.'}
            </DialogDescription>
          </DialogHeader>
          
          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid gap-6 py-4">
            <ReservationCustomerForm 
              formData={formData} 
              onChange={(field, value) => handleFormChange(field, value)}
            />
            
            <ReservationDateTimePicker 
              date={formData.date}
              time={formData.time}
              partySize={formData.partySize}
              onDateChange={(date) => date && handleFormChange('date', date)}
              onTimeChange={(time) => handleFormChange('time', time)}
              onPartySizeChange={(size) => handleFormChange('partySize', size)}
            />
            
            {showTableAssignment && (
              <TableAssignmentSection 
                isManualAssignment={formData.isManualAssignment}
                table={formData.table}
                time={formData.time}
                partySize={formData.partySize}
                onTableChange={(tableId) => handleFormChange('table', tableId)}
                onManualAssignmentChange={handleManualAssignmentChange}
              />
            )}
            
            <ReservationStatusSelect 
              status={formData.status}
              onStatusChange={(status) => handleFormChange('status', status)}
            />
            
            <NotesAndSpecialRequests 
              notes={formData.notes}
              specialRequests={formData.specialRequests}
              onNotesChange={(notes) => handleFormChange('notes', notes)}
              onSpecialRequestChange={(key, value) => handleSpecialRequestChange(key, value)}
            />
            
            <SendConfirmationCheckbox 
              sendConfirmation={formData.sendConfirmation}
              onSendConfirmationChange={(value) => handleFormChange('sendConfirmation', value)}
            />
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Annulla
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvataggio...' : isEditing ? 'Aggiorna Prenotazione' : 'Salva Prenotazione'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddReservationDialog;
