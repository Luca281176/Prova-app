
import { useState, useEffect } from 'react';
import { Reservation } from '@/types/reservations';
import { toast } from '@/hooks/use-toast';
import { getReservations, updateReservationStatus } from '@/services/reservationService';
import AddReservationDialog from './AddReservationDialog';
import ReservationList from './ReservationList';
import { Spinner } from '@/components/ui/spinner';

// Group time slots
const timeGroups = {
  'lunch': ['12:00', '12:30', '13:00', '13:30', '14:00', '14:30'],
  'dinner': ['19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00']
};

interface DailyReservationsProps {
  date: Date;
  timeSlotFilter: string;
  statusFilter: string;
}

const DailyReservations = ({ date, timeSlotFilter, statusFilter }: DailyReservationsProps) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [showAddReservationDialog, setShowAddReservationDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Load reservations on initial load and when filters change
    loadReservations();
  }, [date, timeSlotFilter, statusFilter]);
  
  const loadReservations = async () => {
    setIsLoading(true);
    try {
      // Get all reservations from Supabase
      const result = await getReservations();
      if (result.error) {
        console.error("Error loading reservations:", result.error);
        toast({
          title: "Errore",
          description: "Impossibile caricare le prenotazioni",
          variant: "destructive"
        });
        setReservations([]);
      } else {
        setReservations(result.data);
      }
    } catch (error) {
      console.error("Error loading reservations:", error);
      toast({
        title: "Errore",
        description: "Impossibile caricare le prenotazioni",
        variant: "destructive"
      });
      setReservations([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleUpdateStatus = async (id: string, newStatus: Reservation['status']) => {
    // Update reservation status
    console.log(`Updating reservation ${id} to status ${newStatus}`);
    const updated = await updateReservationStatus(id, newStatus);
    
    if (updated) {
      // Show confirmation message
      toast({
        title: "Stato aggiornato",
        description: `La prenotazione è stata aggiornata a "${getStatusLabel(newStatus)}"`,
      });
      
      // Reload reservations
      await loadReservations();
    }
  };
  
  const handleSendReminder = (id: string) => {
    // In a real app, this would send a reminder to the customer
    console.log(`Sending reminder for reservation ${id}`);
    
    toast({
      title: "Promemoria inviato",
      description: "Il promemoria è stato inviato al cliente",
    });
  };
  
  const getStatusLabel = (status: Reservation['status']) => {
    switch (status) {
      case 'confirmed': return 'Confermata';
      case 'pending': return 'In attesa';
      case 'arrived': return 'Arrivato';
      case 'cancelled': return 'Annullata';
      case 'no-show': return 'No-show';
      default: return 'Sconosciuto';
    }
  };
  
  // Function to convert string date to Date object if needed
  const ensureDate = (dateValue: Date | string): Date => {
    return typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
  };
  
  // Filter reservations based on selected filters
  const filteredReservations = reservations.filter(res => {
    // Convert res.date to Date object if it's a string
    const resDate = ensureDate(res.date);
    
    // Filter by date
    const sameDate = 
      resDate.getFullYear() === date.getFullYear() &&
      resDate.getMonth() === date.getMonth() &&
      resDate.getDate() === date.getDate();
      
    if (!sameDate) return false;
    
    // Filter by time slot
    if (timeSlotFilter !== 'all') {
      if (timeSlotFilter === 'lunch' && !timeGroups.lunch.includes(res.time)) {
        return false;
      }
      if (timeSlotFilter === 'dinner' && !timeGroups.dinner.includes(res.time)) {
        return false;
      }
      if (timeSlotFilter !== 'lunch' && timeSlotFilter !== 'dinner' && res.time !== timeSlotFilter) {
        return false;
      }
    }
    
    // Filter by status
    if (statusFilter !== 'all' && res.status !== statusFilter) {
      return false;
    }
    
    return true;
  });
  
  // Sort by time
  const sortedReservations = [...filteredReservations].sort((a, b) => {
    return a.time.localeCompare(b.time);
  });
  
  const handleAddReservationSuccess = () => {
    loadReservations();
    toast({
      title: "Prenotazione aggiunta",
      description: "La prenotazione è stata aggiunta con successo",
    });
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" />
        <span className="ml-2">Caricamento prenotazioni...</span>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <ReservationList
        reservations={sortedReservations}
        onUpdateStatus={handleUpdateStatus}
        onSendReminder={handleSendReminder}
        onAddReservation={() => setShowAddReservationDialog(true)}
      />
      
      {showAddReservationDialog && (
        <AddReservationDialog
          open={showAddReservationDialog}
          onOpenChange={setShowAddReservationDialog}
          onSuccess={handleAddReservationSuccess}
          preselectedDate={date}
        />
      )}
    </div>
  );
};

export default DailyReservations;
