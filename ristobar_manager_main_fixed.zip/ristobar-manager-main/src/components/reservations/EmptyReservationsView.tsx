
import { Button } from '@/components/ui/button';

interface EmptyReservationsViewProps {
  onAddReservation: () => void;
}

const EmptyReservationsView = ({ onAddReservation }: EmptyReservationsViewProps) => {
  return (
    <div className="flex flex-col items-center justify-center h-64 bg-muted/30 rounded-lg border-2 border-dashed">
      <p className="text-muted-foreground">Nessuna prenotazione per questa data</p>
      <Button 
        variant="outline" 
        className="mt-4"
        onClick={onAddReservation}
      >
        Aggiungi Prenotazione
      </Button>
    </div>
  );
};

export default EmptyReservationsView;
