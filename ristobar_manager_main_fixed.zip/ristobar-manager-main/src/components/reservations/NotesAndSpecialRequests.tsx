
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { SpecialRequestsState } from './types';

interface NotesAndSpecialRequestsProps {
  notes: string;
  specialRequests: SpecialRequestsState;
  onNotesChange: (notes: string) => void;
  onSpecialRequestChange: (key: keyof SpecialRequestsState, value: boolean) => void;
}

const NotesAndSpecialRequests = ({
  notes,
  specialRequests,
  onNotesChange,
  onSpecialRequestChange
}: NotesAndSpecialRequestsProps) => {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="notes">Note</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e) => onNotesChange(e.target.value)}
          placeholder="Aggiungi note o richieste speciali..."
          className="min-h-[80px]"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Richieste speciali</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="window" 
              checked={specialRequests.window}
              onCheckedChange={(checked) => 
                onSpecialRequestChange('window', checked === true)
              }
            />
            <label htmlFor="window" className="text-sm cursor-pointer">Vicino alla finestra</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="highChair" 
              checked={specialRequests.highChair}
              onCheckedChange={(checked) => 
                onSpecialRequestChange('highChair', checked === true)
              }
            />
            <label htmlFor="highChair" className="text-sm cursor-pointer">Seggiolone per bambini</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="kidsMenu" 
              checked={specialRequests.kidsMenu}
              onCheckedChange={(checked) => 
                onSpecialRequestChange('kidsMenu', checked === true)
              }
            />
            <label htmlFor="kidsMenu" className="text-sm cursor-pointer">Menù bambini</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="birthday" 
              checked={specialRequests.birthday}
              onCheckedChange={(checked) => 
                onSpecialRequestChange('birthday', checked === true)
              }
            />
            <label htmlFor="birthday" className="text-sm cursor-pointer">Compleanno/Anniversario</label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="quiet" 
              checked={specialRequests.quiet}
              onCheckedChange={(checked) => 
                onSpecialRequestChange('quiet', checked === true)
              }
            />
            <label htmlFor="quiet" className="text-sm cursor-pointer">Zona tranquilla</label>
          </div>
        </div>
      </div>
    </>
  );
};

export default NotesAndSpecialRequests;
