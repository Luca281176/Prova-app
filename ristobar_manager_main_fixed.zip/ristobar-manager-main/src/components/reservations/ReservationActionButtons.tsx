
import { Button } from '@/components/ui/button';
import { 
  CheckIcon, 
  UsersIcon, 
  XIcon, 
  MoreHorizontalIcon, 
  PenIcon, 
  MessageSquareIcon, 
  AlertCircleIcon 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Reservation } from '@/types/reservations';
import { updateTableStatus } from '@/services/roomsService';
import { toast } from '@/hooks/use-toast';

interface ReservationActionButtonsProps {
  reservation: Reservation;
  onUpdateStatus: (id: string, status: Reservation['status']) => void;
  onSendReminder: (id: string) => void;
}

const ReservationActionButtons = ({ 
  reservation, 
  onUpdateStatus, 
  onSendReminder 
}: ReservationActionButtonsProps) => {
  
  const handleCancelReservation = async () => {
    try {
      // First update the reservation status
      onUpdateStatus(reservation.id, 'cancelled');
      
      // Then update the table status if a tableId exists
      if (reservation.tableId) {
        await updateTableStatus(reservation.tableId, 'available');
        toast({
          title: "Tavolo liberato",
          description: `La prenotazione è stata annullata e il tavolo è stato liberato.`
        });
      }
    } catch (error) {
      console.error("Error cancelling reservation:", error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'annullamento della prenotazione.",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="flex sm:flex-col justify-end gap-2">
      {reservation.status === 'pending' && (
        <Button 
          size="sm" 
          className="w-full"
          onClick={() => onUpdateStatus(reservation.id, 'confirmed')}
        >
          <CheckIcon className="h-4 w-4 mr-2" />
          Conferma
        </Button>
      )}
      
      {reservation.status === 'confirmed' && (
        <Button 
          size="sm" 
          className="w-full"
          onClick={() => onUpdateStatus(reservation.id, 'arrived')}
        >
          <UsersIcon className="h-4 w-4 mr-2" />
          Arrivato
        </Button>
      )}
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="w-10 px-0">
            <MoreHorizontalIcon className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => console.log('Modify reservation', reservation.id)}>
            <PenIcon className="h-4 w-4 mr-2" />
            Modifica
          </DropdownMenuItem>
          
          {reservation.status !== 'arrived' && reservation.status !== 'cancelled' && (
            <DropdownMenuItem onClick={() => onSendReminder(reservation.id)}>
              <MessageSquareIcon className="h-4 w-4 mr-2" />
              Invia promemoria
            </DropdownMenuItem>
          )}
          
          {reservation.status !== 'cancelled' && reservation.status !== 'no-show' && (
            <DropdownMenuItem onClick={handleCancelReservation}>
              <XIcon className="h-4 w-4 mr-2" />
              Annulla
            </DropdownMenuItem>
          )}
          
          {reservation.status === 'confirmed' && (
            <DropdownMenuItem onClick={() => onUpdateStatus(reservation.id, 'no-show')}>
              <AlertCircleIcon className="h-4 w-4 mr-2" />
              Segna come no-show
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default ReservationActionButtons;
