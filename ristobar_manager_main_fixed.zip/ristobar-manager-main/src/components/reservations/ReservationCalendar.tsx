
import { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  ChevronLeftIcon, 
  ChevronRightIcon, 
  CalendarIcon,
  ClockIcon,
  UsersIcon,
  CalendarCheckIcon,
  CalendarXIcon,
  AlertCircleIcon
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DayClickEventHandler } from 'react-day-picker';
import { format, isToday, addDays } from 'date-fns';
import { it } from 'date-fns/locale';
import DailyReservations from './DailyReservations';

// Mock data for demonstration purposes
const mockTimeSlots = [
  '12:00', '12:30', '13:00', '13:30', '14:00', 
  '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00'
];

export interface Reservation {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  date: Date;
  time: string;
  partySize: number;
  tableId?: string;
  status: 'confirmed' | 'pending' | 'arrived' | 'cancelled' | 'no-show';
  notes?: string;
  specialRequests?: string[];
  createdAt: Date;
  updatedAt: Date;
}

const ReservationCalendar = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [timeSlotFilter, setTimeSlotFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const handleDayClick: DayClickEventHandler = (day) => {
    setSelectedDate(day);
  };
  
  const nextDay = () => {
    setSelectedDate(addDays(selectedDate, 1));
  };
  
  const prevDay = () => {
    setSelectedDate(addDays(selectedDate, -1));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left sidebar with calendar and filters */}
      <div className="lg:col-span-1 space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">Calendario</h3>
              <Button variant="outline" size="sm" onClick={() => setSelectedDate(new Date())}>
                Oggi
              </Button>
            </div>
            <Calendar
              mode="single"
              selected={selectedDate}
              onDayClick={handleDayClick}
              className="rounded-md border"
              locale={it}
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 space-y-4">
            <h3 className="font-medium">Filtri</h3>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Orario</label>
              <Select value={timeSlotFilter} onValueChange={setTimeSlotFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Tutti gli orari" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti gli orari</SelectItem>
                  <SelectItem value="lunch">Pranzo (12:00 - 15:00)</SelectItem>
                  <SelectItem value="dinner">Cena (19:00 - 23:00)</SelectItem>
                  {mockTimeSlots.map(time => (
                    <SelectItem key={time} value={time}>{time}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Stato</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Tutti gli stati" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti gli stati</SelectItem>
                  <SelectItem value="confirmed">
                    <div className="flex items-center">
                      <CalendarCheckIcon className="h-4 w-4 mr-2 text-green-500" />
                      Confermata
                    </div>
                  </SelectItem>
                  <SelectItem value="pending">
                    <div className="flex items-center">
                      <ClockIcon className="h-4 w-4 mr-2 text-yellow-500" />
                      In attesa
                    </div>
                  </SelectItem>
                  <SelectItem value="arrived">
                    <div className="flex items-center">
                      <UsersIcon className="h-4 w-4 mr-2 text-blue-500" />
                      Arrivato
                    </div>
                  </SelectItem>
                  <SelectItem value="cancelled">
                    <div className="flex items-center">
                      <CalendarXIcon className="h-4 w-4 mr-2 text-red-500" />
                      Annullata
                    </div>
                  </SelectItem>
                  <SelectItem value="no-show">
                    <div className="flex items-center">
                      <AlertCircleIcon className="h-4 w-4 mr-2 text-gray-500" />
                      No-show
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <h3 className="font-medium mb-3">Riepilogo</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Prenotazioni totali:</span>
                <span className="font-medium">24</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Coperti:</span>
                <span className="font-medium">68</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Confermati:</span>
                <span className="font-medium text-green-600">19</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">In attesa:</span>
                <span className="font-medium text-yellow-600">5</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main content with daily reservations */}
      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-4">
              <Button variant="outline" size="sm" onClick={prevDay}>
                <ChevronLeftIcon className="h-4 w-4" />
              </Button>
              
              <h2 className="text-xl font-semibold flex items-center">
                <CalendarIcon className="h-5 w-5 mr-2" />
                {isToday(selectedDate) ? (
                  <span>Oggi</span>
                ) : (
                  format(selectedDate, 'EEEE d MMMM yyyy', { locale: it })
                )}
              </h2>
              
              <Button variant="outline" size="sm" onClick={nextDay}>
                <ChevronRightIcon className="h-4 w-4" />
              </Button>
            </div>
            
            <DailyReservations 
              date={selectedDate} 
              timeSlotFilter={timeSlotFilter}
              statusFilter={statusFilter}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReservationCalendar;
