
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ReservationFormData } from './types';

interface ReservationCustomerFormProps {
  formData: Pick<ReservationFormData, 'name' | 'phone' | 'email'>;
  onChange: (field: keyof Pick<ReservationFormData, 'name' | 'phone' | 'email'>, value: string) => void;
}

const ReservationCustomerForm = ({ formData, onChange }: ReservationCustomerFormProps) => {
  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Nome Cliente *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => onChange('name', e.target.value)}
            placeholder="Mario Rossi"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Telefono *</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => onChange('phone', e.target.value)}
            placeholder="333-1234567"
            required
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={formData.email}
          onChange={(e) => onChange('email', e.target.value)}
          placeholder="mario.rossi@example.com"
        />
      </div>
    </div>
  );
};

export default ReservationCustomerForm;
