
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { it } from 'date-fns/locale';
import { ReservationFormData } from './types';

interface ReservationDateTimePickerProps {
  date: Date;
  time: string;
  partySize: string;
  onDateChange: (date: Date | undefined) => void;
  onTimeChange: (time: string) => void;
  onPartySizeChange: (size: string) => void;
}

const ReservationDateTimePicker = ({ 
  date, 
  time, 
  partySize,
  onDateChange,
  onTimeChange,
  onPartySizeChange
}: ReservationDateTimePickerProps) => {
  // Gestisce il cambiamento dell'orario manuale
  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onTimeChange(e.target.value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <Label>Data *</Label>
        <Card className="overflow-hidden p-0">
          <Calendar
            mode="single"
            selected={date}
            onSelect={onDateChange}
            disabled={{ before: new Date() }}
            locale={it}
            className="mx-auto [&_.rdp-day]:text-sm [&_.rdp-nav]:relative [&_.rdp-caption]:px-8 [&_.rdp-head_div]:text-xs"
          />
        </Card>
      </div>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="time">Orario *</Label>
          <Input
            id="time"
            type="time"
            value={time}
            onChange={handleTimeChange}
            className="w-full"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="partySize">Numero di persone *</Label>
          <select 
            id="partySize"
            value={partySize} 
            onChange={(e) => onPartySizeChange(e.target.value)}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            required
          >
            <option value="" disabled>Seleziona numero di persone</option>
            {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20].map(size => (
              <option key={size} value={size.toString()}>{size}</option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

export default ReservationDateTimePicker;
