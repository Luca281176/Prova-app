
import { 
  ClockIcon, 
  UsersIcon, 
  PhoneIcon, 
  MessageSquareIcon 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Reservation } from '@/types/reservations';
import ReservationStatusBadge from './ReservationStatusBadge';
import ReservationActionButtons from './ReservationActionButtons';

interface ReservationItemProps {
  reservation: Reservation;
  onUpdateStatus: (id: string, status: Reservation['status']) => void;
  onSendReminder: (id: string) => void;
}

const ReservationItem = ({ 
  reservation, 
  onUpdateStatus, 
  onSendReminder 
}: ReservationItemProps) => {
  return (
    <div 
      className={`p-4 rounded-lg border ${
        reservation.status === 'arrived' ? 'bg-blue-50 border-blue-200' :
        reservation.status === 'confirmed' ? 'bg-green-50 border-green-200' :
        reservation.status === 'pending' ? 'bg-yellow-50 border-yellow-200' :
        reservation.status === 'cancelled' ? 'bg-red-50 border-red-200' :
        'bg-gray-50 border-gray-200'
      } transition-all duration-200 hover:shadow-md`}
    >
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center">
            <h3 className="font-semibold text-lg">{reservation.customerName}</h3>
            <div className="ml-3">
              <ReservationStatusBadge status={reservation.status} />
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center text-muted-foreground">
              <ClockIcon className="h-4 w-4 mr-1" />
              {reservation.time}
            </div>
            
            <div className="flex items-center text-muted-foreground">
              <UsersIcon className="h-4 w-4 mr-1" />
              {reservation.partySize} {reservation.partySize === 1 ? 'persona' : 'persone'}
            </div>
            
            {reservation.tableId && (
              <div className="text-muted-foreground">
                Tavolo: {reservation.tableId}
              </div>
            )}
            
            {reservation.phone && (
              <div className="flex items-center text-muted-foreground">
                <PhoneIcon className="h-4 w-4 mr-1" />
                {reservation.phone}
              </div>
            )}
          </div>
          
          {(reservation.notes || reservation.specialRequests?.length) && (
            <div className="text-sm text-muted-foreground mt-2 flex items-start">
              <MessageSquareIcon className="h-4 w-4 mr-1 mt-0.5" />
              <div>
                {reservation.notes && <p>{reservation.notes}</p>}
                {reservation.specialRequests && reservation.specialRequests.length > 0 && (
                  <div className="mt-1 flex flex-wrap gap-1">
                    {reservation.specialRequests.map((req, idx) => (
                      <Badge variant="outline" key={idx}>{req}</Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        <ReservationActionButtons 
          reservation={reservation}
          onUpdateStatus={onUpdateStatus}
          onSendReminder={onSendReminder}
        />
      </div>
    </div>
  );
};

export default ReservationItem;
