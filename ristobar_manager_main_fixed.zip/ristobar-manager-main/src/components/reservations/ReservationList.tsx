
import { Reservation } from '@/types/reservations';
import ReservationItem from './ReservationItem';
import EmptyReservationsView from './EmptyReservationsView';

interface ReservationListProps {
  reservations: Reservation[];
  onUpdateStatus: (id: string, status: Reservation['status']) => void;
  onSendReminder: (id: string) => void;
  onAddReservation: () => void;
}

const ReservationList = ({ 
  reservations, 
  onUpdateStatus, 
  onSendReminder,
  onAddReservation
}: ReservationListProps) => {
  if (reservations.length === 0) {
    return <EmptyReservationsView onAddReservation={onAddReservation} />;
  }
  
  return (
    <div className="space-y-4">
      {reservations.map(reservation => (
        <ReservationItem
          key={reservation.id}
          reservation={reservation}
          onUpdateStatus={onUpdateStatus}
          onSendReminder={onSendReminder}
        />
      ))}
    </div>
  );
};

export default ReservationList;
