
import { Table } from '@/components/RoomGrid';
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
  SheetFooter
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import AddReservationDialog from './AddReservationDialog';
import { useState } from 'react';
import { updateTableStatus } from '@/services/roomsService';
import { toast } from 'sonner';

interface ReservationSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  table: Table;
  onSuccess?: () => void;
}

export function ReservationSheet({ 
  open, 
  onOpenChange, 
  table, 
  onSuccess 
}: ReservationSheetProps) {
  const [showDialog, setShowDialog] = useState(false);
  
  const handleSuccess = async () => {
    try {
      // Get current time
      const now = new Date();
      
      // Get reservation time (user selected date will be used in AddReservationDialog)
      // We respect the user's date selection completely
      
      if (onSuccess) {
        onSuccess();
      }
      
      // Important: We DON'T update the table status here at all
      // The table will be marked as reserved by the automatic check in TableComponent
      // when it's within 3 hours of the reservation time
      toast("Prenotazione confermata", {
        description: `La prenotazione è stata registrata. Il tavolo verrà riservato automaticamente 3 ore prima dell'orario stabilito.`
      });
      
      onOpenChange(false);
    } catch (error) {
      console.error("Error processing reservation:", error);
      toast.error("Errore", {
        description: "Si è verificato un problema nel processare la prenotazione."
      });
    }
  };
  
  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="w-[90%] sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>Prenota tavolo {table.name}</SheetTitle>
            <SheetDescription>
              Inserisci i dettagli della prenotazione per il tavolo {table.name} ({table.seats} posti).
            </SheetDescription>
          </SheetHeader>
          
          <div className="py-6">
            <Button 
              onClick={() => setShowDialog(true)} 
              className="w-full h-16 text-lg"
            >
              Nuova prenotazione
            </Button>
          </div>
          
          <SheetFooter>
            <SheetClose asChild>
              <Button variant="outline">Annulla</Button>
            </SheetClose>
          </SheetFooter>
        </SheetContent>
      </Sheet>
      
      <AddReservationDialog 
        open={showDialog}
        onOpenChange={setShowDialog}
        onSuccess={handleSuccess}
        preselectedDate={new Date()} // This will be overridden by user selection
        isEditing={false}
        preselectedTable={table.id}
        preselectedTableName={table.name}
      />
    </>
  );
}

export default ReservationSheet;
