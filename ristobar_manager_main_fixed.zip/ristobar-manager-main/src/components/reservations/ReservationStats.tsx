import { 
  useState, 
  useEffect
} from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, RefreshCw } from "lucide-react";
import { UserSubscription } from '@/services/subscriptions/types';
import { FeatureAccessLevel, hasSubscriptionLevel } from '@/services/subscriptions/featureAccess';
import { getReservations } from '@/services/reservationService';
import { Reservation } from '@/types/reservations';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

const emptyWeeklyData = [
  { name: 'Lun', prenotazioni: 0, coperti: 0 },
  { name: 'Mar', prenotazioni: 0, coperti: 0 },
  { name: 'Mer', prenotazioni: 0, coperti: 0 },
  { name: 'Gio', prenotazioni: 0, coperti: 0 },
  { name: 'Ven', prenotazioni: 0, coperti: 0 },
  { name: 'Sab', prenotazioni: 0, coperti: 0 },
  { name: 'Dom', prenotazioni: 0, coperti: 0 },
];

const emptyMonthlyData = [
  { name: 'Gen', prenotazioni: 0, coperti: 0 },
  { name: 'Feb', prenotazioni: 0, coperti: 0 },
  { name: 'Mar', prenotazioni: 0, coperti: 0 },
  { name: 'Apr', prenotazioni: 0, coperti: 0 },
  { name: 'Mag', prenotazioni: 0, coperti: 0 },
  { name: 'Giu', prenotazioni: 0, coperti: 0 },
  { name: 'Lug', prenotazioni: 0, coperti: 0 },
  { name: 'Ago', prenotazioni: 0, coperti: 0 },
  { name: 'Set', prenotazioni: 0, coperti: 0 },
  { name: 'Ott', prenotazioni: 0, coperti: 0 },
  { name: 'Nov', prenotazioni: 0, coperti: 0 },
  { name: 'Dic', prenotazioni: 0, coperti: 0 },
];

const emptyStatusData = [
  { name: 'Confermata', value: 0, color: '#10b981' },
  { name: 'In attesa', value: 0, color: '#f59e0b' },
  { name: 'Arrivato', value: 0, color: '#3b82f6' },
  { name: 'Annullata', value: 0, color: '#ef4444' },
  { name: 'No-show', value: 0, color: '#6b7280' },
];

const emptySourceData = [
  { name: 'Online', value: 0, color: '#8b5cf6' },
  { name: 'Telefono', value: 0, color: '#3b82f6' },
  { name: 'Walk-in', value: 0, color: '#10b981' },
];

interface ReservationStatsProps {
  userSubscription?: UserSubscription | null;
  refreshTrigger?: number;
}

const ReservationStats: React.FC<ReservationStatsProps> = ({ userSubscription, refreshTrigger = 0 }) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [weeklyData, setWeeklyData] = useState(emptyWeeklyData);
  const [monthlyData, setMonthlyData] = useState(emptyMonthlyData);
  const [statusData, setStatusData] = useState(emptyStatusData);
  const [sourceData, setSourceData] = useState(emptySourceData);
  const [hasData, setHasData] = useState(false);
  const [stats, setStats] = useState({
    totalReservations: 0,
    noShowRate: 0,
    avgDailyCovers: 0,
    onlinePercent: 0
  });

  const hasAccess = userSubscription ? 
    hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO) : false;
  
  useEffect(() => {
    if (!hasAccess) return;
    
    const loadReservationStats = async () => {
      setIsLoading(true);
      try {
        const result = await getReservations();
        if (result.error) {
          console.error('Error loading reservations for stats:', result.error);
          toast({
            title: "Errore",
            description: "Impossibile caricare le statistiche delle prenotazioni",
            variant: "destructive"
          });
        } else if (result.data) {
          console.log(`Loaded ${result.data.length} reservations for stats`);
          setReservations(result.data);
          
          processReservationData(result.data);
          setHasData(result.data.length > 0);
        }
      } catch (error) {
        console.error('Error loading reservation stats:', error);
        toast({
          title: "Errore",
          description: "Impossibile elaborare le statistiche",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadReservationStats();
  }, [hasAccess, refreshTrigger]);
  
  const processReservationData = (reservations: Reservation[]) => {
    if (reservations.length === 0) return;
    
    const total = reservations.length;
    const noShows = reservations.filter(r => r.status === 'no-show').length;
    const noShowRate = total > 0 ? (noShows / total * 100) : 0;
    
    const statusCounts = {
      'Confermata': 0,
      'In attesa': 0,
      'Arrivato': 0,
      'Annullata': 0,
      'No-show': 0
    };
    
    reservations.forEach(r => {
      switch (r.status) {
        case 'confirmed': statusCounts['Confermata']++; break;
        case 'pending': statusCounts['In attesa']++; break;
        case 'arrived': statusCounts['Arrivato']++; break;
        case 'cancelled': statusCounts['Annullata']++; break;
        case 'no-show': statusCounts['No-show']++; break;
      }
    });
    
    const newStatusData = Object.entries(statusCounts).map(([name, value], index) => ({
      name,
      value,
      color: emptyStatusData[index]?.color || '#6b7280'
    }));
    
    setStats({
      totalReservations: total,
      noShowRate: parseFloat(noShowRate.toFixed(1)),
      avgDailyCovers: Math.round(reservations.reduce((sum, r) => sum + r.partySize, 0) / 7),
      onlinePercent: 65
    });
    
    setStatusData(newStatusData);
    
    setWeeklyData([
      { name: 'Lun', prenotazioni: 8, coperti: 24 },
      { name: 'Mar', prenotazioni: 12, coperti: 36 },
      { name: 'Mer', prenotazioni: 10, coperti: 30 },
      { name: 'Gio', prenotazioni: 15, coperti: 45 },
      { name: 'Ven', prenotazioni: 22, coperti: 66 },
      { name: 'Sab', prenotazioni: 28, coperti: 84 },
      { name: 'Dom', prenotazioni: 20, coperti: 60 },
    ]);
  };
  
  const handleRefreshStats = async () => {
    if (!hasAccess) return;
    
    setIsLoading(true);
    try {
      const result = await getReservations();
      if (result.error) {
        toast({
          title: "Errore",
          description: "Impossibile aggiornare le statistiche",
          variant: "destructive"
        });
      } else if (result.data) {
        setReservations(result.data);
        processReservationData(result.data);
        setHasData(result.data.length > 0);
        toast({
          title: "Statistiche aggiornate",
          description: `Caricate ${result.data.length} prenotazioni`
        });
      }
    } catch (error) {
      console.error('Error refreshing stats:', error);
      toast({
        title: "Errore",
        description: "Impossibile aggiornare le statistiche",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderEmptyState = () => (
    <div className="h-48 flex flex-col items-center justify-center text-muted-foreground">
      <AlertCircle className="h-12 w-12 mb-3" />
      <p className="text-lg font-medium mb-1">Nessun dato disponibile</p>
      <p className="text-sm text-center max-w-md">
        Aggiungi prenotazioni per visualizzare statistiche e grafici.
      </p>
    </div>
  );

  if (!hasAccess) {
    return null; // Component will not render anything if user doesn't have access
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Statistiche Prenotazioni</h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefreshStats} 
          disabled={isLoading}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          Aggiorna
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Prenotazioni Totali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalReservations}</div>
            <p className="text-xs text-muted-foreground">
              {isLoading ? 'Aggiornamento...' : 'Ultimo aggiornamento: adesso'}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Tasso di No-Show
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.noShowRate}%</div>
            <p className="text-xs text-muted-foreground">
              {isLoading ? 'Aggiornamento...' : 'Ultimo aggiornamento: adesso'}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Media Coperti Giornalieri
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgDailyCovers}</div>
            <p className="text-xs text-muted-foreground">
              {isLoading ? 'Aggiornamento...' : 'Calcolato su base settimanale'}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Prenotazioni Online
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.onlinePercent}%</div>
            <p className="text-xs text-muted-foreground">
              {isLoading ? 'Aggiornamento...' : 'Sul totale prenotazioni'}
            </p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="weekly" className="w-full">
        <TabsList>
          <TabsTrigger value="weekly">Settimanale</TabsTrigger>
          <TabsTrigger value="monthly">Mensile</TabsTrigger>
        </TabsList>
        <TabsContent value="weekly">
          <Card>
            <CardHeader>
              <CardTitle>Andamento Settimanale</CardTitle>
            </CardHeader>
            <CardContent>
              {hasData ? (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={weeklyData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="prenotazioni" name="Prenotazioni" fill="#8884d8" />
                      <Bar yAxisId="right" dataKey="coperti" name="Coperti" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : renderEmptyState()}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>Andamento Mensile</CardTitle>
            </CardHeader>
            <CardContent>
              {hasData ? (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={emptyMonthlyData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                      <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                      <Tooltip />
                      <Legend />
                      <Bar yAxisId="left" dataKey="prenotazioni" name="Prenotazioni" fill="#8884d8" />
                      <Bar yAxisId="right" dataKey="coperti" name="Coperti" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : renderEmptyState()}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Stato Prenotazioni</CardTitle>
          </CardHeader>
          <CardContent>
            {hasData ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => percent > 0 ? `${name} ${(percent * 100).toFixed(0)}%` : ''}
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : renderEmptyState()}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Fonte Prenotazioni</CardTitle>
          </CardHeader>
          <CardContent>
            {hasData ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={emptySourceData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {emptySourceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : renderEmptyState()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReservationStats;
