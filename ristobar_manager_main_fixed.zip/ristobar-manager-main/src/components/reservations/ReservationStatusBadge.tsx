
import { Badge } from '@/components/ui/badge';
import { 
  CalendarCheckIcon, 
  ClockIcon, 
  UsersIcon, 
  CalendarXIcon, 
  AlertCircleIcon 
} from 'lucide-react';
import { Reservation } from '@/types/reservations';

interface ReservationStatusBadgeProps {
  status: Reservation['status'];
}

const ReservationStatusBadge = ({ status }: ReservationStatusBadgeProps) => {
  switch (status) {
    case 'confirmed':
      return <Badge className="bg-green-500 hover:bg-green-700"><CalendarCheckIcon className="h-3 w-3 mr-1" /> Confermata</Badge>;
    case 'pending':
      return <Badge variant="outline" className="text-yellow-600 border-yellow-600"><ClockIcon className="h-3 w-3 mr-1" /> In attesa</Badge>;
    case 'arrived':
      return <Badge className="bg-blue-500 hover:bg-blue-700"><UsersIcon className="h-3 w-3 mr-1" /> Arrivato</Badge>;
    case 'cancelled':
      return <Badge variant="destructive"><CalendarXIcon className="h-3 w-3 mr-1" /> Annullata</Badge>;
    case 'no-show':
      return <Badge variant="outline" className="text-gray-500 border-gray-500"><AlertCircleIcon className="h-3 w-3 mr-1" /> No-show</Badge>;
    default:
      return <Badge variant="outline">Sconosciuto</Badge>;
  }
};

export default ReservationStatusBadge;
