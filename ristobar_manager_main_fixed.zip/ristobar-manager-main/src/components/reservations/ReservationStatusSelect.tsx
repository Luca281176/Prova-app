
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface ReservationStatusSelectProps {
  status: string;
  onStatusChange: (status: string) => void;
}

const ReservationStatusSelect = ({ status, onStatusChange }: ReservationStatusSelectProps) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="status">Stato prenotazione</Label>
      <Select value={status} onValueChange={onStatusChange}>
        <SelectTrigger>
          <SelectValue placeholder="Seleziona stato" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="confirmed">Confermata</SelectItem>
          <SelectItem value="pending">In attesa</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default ReservationStatusSelect;
