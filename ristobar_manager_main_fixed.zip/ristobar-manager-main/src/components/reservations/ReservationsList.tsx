
import React, { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowUpDown, Search, Filter, MoreHorizontal, PenIcon, CheckIcon, XIcon, AlertCircleIcon, TrashIcon } from 'lucide-react';
import { Reservation } from '@/types/reservations';
import { getReservations, updateReservationStatus, deleteReservation } from '@/services/reservationService';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from '@/hooks/use-toast';
import ConfirmDialog from '@/components/ConfirmDialog';
import { Spinner } from '@/components/ui/spinner';
import AddReservationDialog from './AddReservationDialog';

const ReservationsList = ({ refreshTrigger = 0 }) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState('date');
  const [sortDirection, setSortDirection] = useState('asc');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [reservationToDelete, setReservationToDelete] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [editingReservation, setEditingReservation] = useState<Reservation | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);

  useEffect(() => {
    loadReservations();
  }, [refreshTrigger]);

  const loadReservations = async () => {
    setIsLoading(true);
    try {
      const result = await getReservations();
      if (result.error) {
        console.error('Error loading reservations:', result.error);
        toast({
          title: "Errore",
          description: "Impossibile caricare le prenotazioni",
          variant: "destructive",
        });
        setReservations([]);
      } else {
        setReservations(result.data);
        console.log('Reservations loaded:', result.data.length);
      }
    } catch (error) {
      console.error('Error loading reservations:', error);
      toast({
        title: "Errore",
        description: "Impossibile caricare le prenotazioni",
        variant: "destructive",
      });
      setReservations([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Sort handler
  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // Filter reservations based on search term
  const filteredReservations = reservations.filter(res => 
    res.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    res.phone.includes(searchTerm) ||
    (res.notes && res.notes.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Update reservation status handler
  const handleUpdateStatus = async (id: string, newStatus: Reservation['status']) => {
    const updated = await updateReservationStatus(id, newStatus);
    if (updated) {
      toast({
        title: "Stato aggiornato",
        description: `La prenotazione è stata aggiornata a "${getStatusLabel(newStatus)}"`,
      });
      loadReservations(); // Reload reservations to get the latest data
    }
  };

  // Edit reservation handler
  const handleEditClick = (reservation: Reservation) => {
    setEditingReservation(reservation);
    setShowEditDialog(true);
  };

  const handleEditSuccess = () => {
    loadReservations();
    setShowEditDialog(false);
    setEditingReservation(null);
    toast({
      title: "Prenotazione aggiornata",
      description: "La prenotazione è stata aggiornata con successo",
    });
  };

  // Delete reservation handler
  const handleDeleteClick = (id: string) => {
    setReservationToDelete(id);
    setDeleteConfirmOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (reservationToDelete) {
      const success = await deleteReservation(reservationToDelete);
      if (success) {
        toast({
          title: "Prenotazione eliminata",
          description: "La prenotazione è stata eliminata con successo",
        });
      } else {
        toast({
          title: "Errore",
          description: "Impossibile eliminare la prenotazione",
          variant: "destructive",
        });
      }
      setDeleteConfirmOpen(false);
      setReservationToDelete(null);
      loadReservations();
    }
  };

  // Get status badge color
  const getStatusBadge = (status) => {
    switch (status) {
      case 'confirmed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Confermata</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">In attesa</Badge>;
      case 'arrived':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Arrivato</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Annullata</Badge>;
      case 'no-show':
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">No-show</Badge>;
      default:
        return <Badge variant="outline">Sconosciuto</Badge>;
    }
  };

  const getStatusLabel = (status: Reservation['status']) => {
    switch (status) {
      case 'confirmed': return 'Confermata';
      case 'pending': return 'In attesa';
      case 'arrived': return 'Arrivato';
      case 'cancelled': return 'Annullata';
      case 'no-show': return 'No-show';
      default: return 'Sconosciuto';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Spinner size="lg" />
        <span className="ml-2">Caricamento prenotazioni...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca prenotazioni..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-8"
          />
        </div>
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" />
          Filtri
        </Button>
      </div>

      <div className="border rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead onClick={() => handleSort('name')} className="cursor-pointer">
                Nome
                <ArrowUpDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead onClick={() => handleSort('date')} className="cursor-pointer">
                Data e Ora
                <ArrowUpDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead onClick={() => handleSort('guests')} className="cursor-pointer">
                Persone
                <ArrowUpDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead onClick={() => handleSort('status')} className="cursor-pointer">
                Stato
                <ArrowUpDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead onClick={() => handleSort('phone')} className="cursor-pointer">
                Telefono
                <ArrowUpDown className="ml-1 h-4 w-4 inline" />
              </TableHead>
              <TableHead>Note</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredReservations.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  Nessuna prenotazione trovata
                </TableCell>
              </TableRow>
            ) : (
              filteredReservations.map((reservation) => (
                <TableRow key={reservation.id}>
                  <TableCell className="font-medium">{reservation.customerName}</TableCell>
                  <TableCell>
                    {format(new Date(reservation.date), 'dd/MM/yyyy')} - {reservation.time}
                  </TableCell>
                  <TableCell>{reservation.partySize}</TableCell>
                  <TableCell>{getStatusBadge(reservation.status)}</TableCell>
                  <TableCell>{reservation.phone}</TableCell>
                  <TableCell>{reservation.notes || '-'}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditClick(reservation)}>
                          <PenIcon className="h-4 w-4 mr-2" /> Modifica
                        </DropdownMenuItem>
                        
                        {reservation.status === 'pending' && (
                          <DropdownMenuItem onClick={() => handleUpdateStatus(reservation.id, 'confirmed')}>
                            <CheckIcon className="h-4 w-4 mr-2" /> Conferma
                          </DropdownMenuItem>
                        )}
                        
                        {reservation.status !== 'cancelled' && (
                          <DropdownMenuItem onClick={() => handleUpdateStatus(reservation.id, 'cancelled')}>
                            <XIcon className="h-4 w-4 mr-2" /> Annulla
                          </DropdownMenuItem>
                        )}
                        
                        {(reservation.status === 'confirmed' || reservation.status === 'pending') && (
                          <DropdownMenuItem onClick={() => handleUpdateStatus(reservation.id, 'arrived')}>
                            <CheckIcon className="h-4 w-4 mr-2" /> Segna come arrivato
                          </DropdownMenuItem>
                        )}
                        
                        {reservation.status === 'confirmed' && (
                          <DropdownMenuItem onClick={() => handleUpdateStatus(reservation.id, 'no-show')}>
                            <AlertCircleIcon className="h-4 w-4 mr-2" /> Segna come no-show
                          </DropdownMenuItem>
                        )}

                        <DropdownMenuItem onClick={() => handleDeleteClick(reservation.id)}>
                          <TrashIcon className="h-4 w-4 mr-2" /> Elimina
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <ConfirmDialog 
        open={deleteConfirmOpen}
        onOpenChange={setDeleteConfirmOpen}
        onConfirm={handleDeleteConfirm}
        title="Elimina prenotazione"
        description="Sei sicuro di voler eliminare questa prenotazione? Questa azione non può essere annullata."
        confirmText="Elimina"
        cancelText="Annulla"
        variant="destructive"
      />

      {showEditDialog && editingReservation && (
        <AddReservationDialog
          open={showEditDialog}
          onOpenChange={setShowEditDialog}
          onSuccess={handleEditSuccess}
          isEditing={true}
          existingReservation={editingReservation}
        />
      )}
    </div>
  );
};

export default ReservationsList;
