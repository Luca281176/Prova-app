
import { Checkbox } from '@/components/ui/checkbox';

interface SendConfirmationCheckboxProps {
  sendConfirmation: boolean;
  onSendConfirmationChange: (value: boolean) => void;
}

const SendConfirmationCheckbox = ({ 
  sendConfirmation, 
  onSendConfirmationChange 
}: SendConfirmationCheckboxProps) => {
  return (
    <div className="flex items-center space-x-2">
      <Checkbox 
        id="sendConfirmation" 
        checked={sendConfirmation}
        onCheckedChange={(checked) => 
          onSendConfirmationChange(checked === true)
        }
      />
      <label 
        htmlFor="sendConfirmation" 
        className="text-sm cursor-pointer"
      >
        Invia email di conferma al cliente
      </label>
    </div>
  );
};

export default SendConfirmationCheckbox;
