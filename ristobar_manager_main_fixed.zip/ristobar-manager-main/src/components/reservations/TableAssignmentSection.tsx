
import { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { fetchRooms } from '@/services/roomsService';
import { getActiveReservationForTable, isTableAlreadyBooked } from '@/services/reservationService';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CalendarIcon } from 'lucide-react';
import { Spinner } from '@/components/ui/spinner';

interface TableAssignmentSectionProps {
  isManualAssignment: boolean;
  table: string;
  time: string;
  partySize: string;
  onTableChange: (tableId: string) => void;
  onManualAssignmentChange: (isManual: boolean) => void;
}

interface AvailableTable {
  id: string;
  name: string;
  capacity: number;
  hasReservation?: boolean;
  reservationInfo?: string;
  isBooked?: boolean;
}

const TableAssignmentSection = ({
  isManualAssignment,
  table,
  time,
  partySize,
  onTableChange,
  onManualAssignmentChange
}: TableAssignmentSectionProps) => {
  const [availableTables, setAvailableTables] = useState<AvailableTable[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  
  useEffect(() => {
    if (isManualAssignment && time && partySize) {
      loadAvailableTables();
    }
  }, [time, partySize, isManualAssignment, selectedDate]);
  
  const loadAvailableTables = async () => {
    setIsLoading(true);
    try {
      // Fetch rooms and their tables
      const rooms = await fetchRooms();
      
      // Build a list of tables to check
      const tablesToCheck = rooms.flatMap(room => 
        room.tables
          .filter(table => 
            table.status === 'available' && 
            table.seats >= parseInt(partySize, 10)
          )
          .map(table => ({
            id: table.id,
            name: `${table.name} (${room.name} - ${table.seats} posti)`,
            capacity: table.seats
          }))
      );
      
      // Check reservations for each table in parallel
      const tablesWithReservations = await Promise.all(
        tablesToCheck.map(async (table) => {
          const activeReservation = await getActiveReservationForTable(table.id);
          
          // Check if table is already booked for this specific date and time
          const isBooked = await isTableAlreadyBooked(
            table.id,
            selectedDate, 
            time
          );
          
          return {
            ...table,
            hasReservation: !!activeReservation,
            reservationInfo: activeReservation 
              ? `${activeReservation.customerName} - ${activeReservation.time}` 
              : undefined,
            isBooked: isBooked
          };
        })
      );
      
      setAvailableTables(tablesWithReservations);
    } catch (error) {
      console.error('Error loading available tables:', error);
      setAvailableTables([]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label htmlFor="table">Tavolo</Label>
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="manualAssignment" 
            checked={isManualAssignment}
            onCheckedChange={(checked) => {
              const isChecked = checked === true;
              onManualAssignmentChange(isChecked);
              if (isChecked) {
                loadAvailableTables();
              }
            }}
          />
          <label 
            htmlFor="manualAssignment" 
            className="text-sm text-muted-foreground cursor-pointer"
          >
            Assegnazione manuale
          </label>
        </div>
      </div>
      
      {isManualAssignment ? (
        <>
          {isLoading ? (
            <div className="flex items-center justify-center p-2">
              <Spinner size="sm" />
              <span className="ml-2 text-sm">Caricamento tavoli...</span>
            </div>
          ) : availableTables.length > 0 ? (
            <Select value={table} onValueChange={onTableChange}>
              <SelectTrigger>
                <SelectValue placeholder="Seleziona tavolo disponibile" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Assegnazione automatica</SelectItem>
                {availableTables.map(table => (
                  <SelectItem 
                    key={table.id} 
                    value={table.id}
                    disabled={table.isBooked}
                    className={table.isBooked ? "text-muted-foreground" : ""}
                  >
                    {table.name}
                    {table.isBooked && (
                      <span className="ml-2 text-red-500 text-xs">
                        (non disponibile: orario già prenotato o troppo vicino ad altra prenotazione)
                      </span>
                    )}
                    {!table.isBooked && table.hasReservation && (
                      <span className="ml-2 text-amber-500 text-xs">
                        (prenotato in altra data: {table.reservationInfo})
                      </span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <div className="p-2 rounded-md bg-amber-50 border border-amber-200 text-sm text-amber-600">
              {!time || !partySize ? 
                "Seleziona prima l'orario e il numero di persone" : 
                "Nessun tavolo disponibile per questo orario e numero di persone"
              }
            </div>
          )}
        </>
      ) : (
        <div className="p-2 rounded-md bg-muted text-sm">
          Assegnazione automatica in base alla disponibilità
        </div>
      )}
      
      <div className="text-xs text-muted-foreground">
        Nota: Non è possibile prenotare un tavolo entro 1 ora prima o 3 ore dopo una prenotazione esistente.
      </div>
    </div>
  );
};

export default TableAssignmentSection;
