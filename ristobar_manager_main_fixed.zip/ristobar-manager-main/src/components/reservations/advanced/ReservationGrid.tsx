import { useState, useEffect } from 'react';
import { format, addDays, startOfWeek, isToday, isSameDay } from 'date-fns';
import { it } from 'date-fns/locale';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, CalendarDays, PlusCircle } from 'lucide-react';
import { getReservations } from '@/services/reservationService';
import { Reservation } from '@/types/reservations';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useReservationStore } from '@/stores/reservationStore';
import { motion } from 'framer-motion';
import ReservationQuickView from './ReservationQuickView';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface ReservationGridProps {
  locationId: string;
}

const timeSlots = [
  '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', 
  '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00',
  '22:30', '23:00', '23:30', '00:00', '00:30', '01:00', 
  '01:30', '02:00', '02:30', '03:00', '03:30', '04:00'
];

export default function ReservationGrid({ locationId }: ReservationGridProps) {
  const [startDate, setStartDate] = useState<Date>(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [isLoading, setIsLoading] = useState(true);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);
  const [quickViewOpen, setQuickViewOpen] = useState(false);
  const { setActiveReservation } = useReservationStore();

  const days = Array.from({ length: 7 }, (_, i) => addDays(startDate, i));

  useEffect(() => {
    loadReservations();
    
    // Set up realtime subscription
    const channel = supabase
      .channel('reservations-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'reservations'
      }, (payload) => {
        console.log('Realtime reservation update:', payload);
        loadReservations();
        
        if (payload.eventType === 'INSERT') {
          toast.success('Nuova prenotazione aggiunta');
        } else if (payload.eventType === 'UPDATE') {
          toast.success('Prenotazione aggiornata');
        } else if (payload.eventType === 'DELETE') {
          toast.success('Prenotazione eliminata');
        }
      })
      .subscribe();
      
    return () => {
      supabase.removeChannel(channel);
    };
  }, [locationId, startDate]);
  
  const loadReservations = async () => {
    setIsLoading(true);
    try {
      const result = await getReservations();
      if (result.error) {
        console.error('Error loading reservations:', result.error);
        setReservations([]);
      } else {
        setReservations(result.data);
      }
    } catch (error) {
      console.error('Error loading reservations:', error);
      setReservations([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrevWeek = () => {
    setStartDate(prevDate => addDays(prevDate, -7));
  };

  const handleNextWeek = () => {
    setStartDate(prevDate => addDays(prevDate, 7));
  };
  
  const handleReservationClick = (reservation: Reservation) => {
    setSelectedReservation(reservation);
    setActiveReservation(reservation);
    setQuickViewOpen(true);
  };
  
  const handleAddReservation = (day: Date, time: string) => {
    toast.info(`Aggiungi prenotazione per ${format(day, 'EEEE d MMMM', { locale: it })} alle ${time}`);
    // Here you would typically open your add reservation dialog
  };

  const getReservationsByDayAndTime = (day: Date, time: string) => {
    return reservations.filter(res => {
      const resDate = new Date(res.date);
      return isSameDay(resDate, day) && res.time === time;
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5 text-purple-500" />
          <h2 className="text-xl font-semibold">
            {format(startDate, "'Settimana del' d MMMM yyyy", { locale: it })}
          </h2>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handlePrevWeek}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setStartDate(startOfWeek(new Date(), { weekStartsOn: 1 }))}
          >
            Oggi
          </Button>
          <Button variant="outline" size="sm" onClick={handleNextWeek}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="overflow-auto rounded-lg border shadow">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-muted/50">
              <th className="border-r p-2 w-24"></th>
              {days.map((day, i) => (
                <th 
                  key={i} 
                  className={`p-2 text-center border-r ${isToday(day) ? 'bg-purple-100 dark:bg-purple-900/20' : ''}`}
                >
                  <div className="font-medium">{format(day, 'EEEE', { locale: it })}</div>
                  <div className={`text-sm ${isToday(day) ? 'text-purple-700 dark:text-purple-300 font-semibold' : 'text-muted-foreground'}`}>
                    {format(day, 'd MMM', { locale: it })}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {timeSlots.map((time, timeIndex) => (
              <tr key={time} className={timeIndex % 2 === 0 ? 'bg-muted/20' : ''}>
                <td className="border-r p-2 text-center text-sm font-medium">{time}</td>
                {days.map((day, dayIndex) => {
                  const dayReservations = getReservationsByDayAndTime(day, time);
                  
                  return (
                    <td 
                      key={dayIndex}
                      className={`border-r border-b p-1 relative ${isToday(day) ? 'bg-purple-50 dark:bg-purple-900/10' : ''}`}
                    >
                      {isLoading ? (
                        <Skeleton className="h-12 w-full" />
                      ) : (
                        <>
                          {dayReservations.length > 0 ? (
                            <div className="space-y-1">
                              {dayReservations.map(reservation => (
                                <motion.div
                                  initial={{ opacity: 0, y: 5 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  key={reservation.id}
                                  onClick={() => handleReservationClick(reservation)}
                                  className="cursor-pointer"
                                >
                                  <Card className={`border-l-4 shadow-sm hover:shadow-md transition-shadow ${
                                    reservation.status === 'confirmed' ? 'border-l-green-500' :
                                    reservation.status === 'pending' ? 'border-l-amber-500' :
                                    reservation.status === 'arrived' ? 'border-l-blue-500' :
                                    reservation.status === 'cancelled' ? 'border-l-red-500' : 'border-l-gray-500'
                                  }`}>
                                    <CardContent className="p-2 text-xs">
                                      <div className="font-medium truncate">{reservation.customerName}</div>
                                      <div className="flex justify-between items-center">
                                        <span>{reservation.partySize} persone</span>
                                        <Badge variant="outline" className="text-[10px] px-1 h-4">
                                          {reservation.status === 'confirmed' ? 'Confermato' :
                                           reservation.status === 'pending' ? 'In attesa' :
                                           reservation.status === 'arrived' ? 'Arrivato' :
                                           reservation.status === 'cancelled' ? 'Cancellato' : 'No-show'}
                                        </Badge>
                                      </div>
                                    </CardContent>
                                  </Card>
                                </motion.div>
                              ))}
                            </div>
                          ) : (
                            <div 
                              onClick={() => handleAddReservation(day, time)}
                              className="h-12 w-full flex items-center justify-center text-muted-foreground hover:bg-muted/50 rounded-md cursor-pointer transition-colors"
                            >
                              <PlusCircle className="h-4 w-4 opacity-30 hover:opacity-70" />
                            </div>
                          )}
                        </>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {quickViewOpen && selectedReservation && (
        <ReservationQuickView 
          reservation={selectedReservation}
          open={quickViewOpen}
          onOpenChange={setQuickViewOpen}
        />
      )}
    </div>
  );
}

