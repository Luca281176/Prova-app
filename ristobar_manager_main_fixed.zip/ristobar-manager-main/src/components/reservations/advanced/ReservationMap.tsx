
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { fetchRooms } from '@/services/roomsService';
import { getActiveReservationForTable } from '@/services/reservationService';
import { Room, Table } from '@/components/RoomGrid';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LayoutGrid, Loader2, Users, Clock, CircleAlert } from 'lucide-react';
import { motion } from 'framer-motion';
import { useReservationStore } from '@/stores/reservationStore';
import { TableReservation } from '@/components/tables/TableReservation';
import { Skeleton } from '@/components/ui/skeleton';
import { Reservation } from '@/types/reservations';
import ReservationQuickView from './ReservationQuickView';

interface RoomMapProps {
  locationId: string;
}

export default function ReservationMap({ locationId }: RoomMapProps) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');
  const [tableReservations, setTableReservations] = useState<Record<string, Reservation | null>>({});
  const [loadingTables, setLoadingTables] = useState<Record<string, boolean>>({});
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);
  const [quickViewOpen, setQuickViewOpen] = useState(false);
  const { setActiveReservation } = useReservationStore();

  useEffect(() => {
    loadRooms();
  }, [locationId]);

  const loadRooms = async () => {
    setIsLoading(true);
    try {
      const roomsData = await fetchRooms(locationId);
      setRooms(roomsData);
      
      if (roomsData.length > 0) {
        setSelectedRoomId(roomsData[0].id);
      }
    } catch (error) {
      console.error('Error loading rooms:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (selectedRoomId) {
      const room = rooms.find(r => r.id === selectedRoomId);
      if (room) {
        const tableIds = room.tables.map(table => table.id);
        const newLoadingTables: Record<string, boolean> = {};
        
        tableIds.forEach(id => {
          newLoadingTables[id] = true;
          loadTableReservation(id);
        });
        
        setLoadingTables(newLoadingTables);
      }
    }
  }, [selectedRoomId, rooms]);

  const loadTableReservation = async (tableId: string) => {
    try {
      const reservation = await getActiveReservationForTable(tableId);
      setTableReservations(prev => ({
        ...prev,
        [tableId]: reservation
      }));
    } catch (error) {
      console.error(`Error loading reservation for table ${tableId}:`, error);
    } finally {
      setLoadingTables(prev => ({
        ...prev,
        [tableId]: false
      }));
    }
  };

  const handleTableClick = (tableId: string) => {
    setSelectedTable(prevTable => prevTable === tableId ? null : tableId);
    
    const reservation = tableReservations[tableId];
    if (reservation) {
      setSelectedReservation(reservation);
      setActiveReservation(reservation);
      setQuickViewOpen(true);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (rooms.length === 0) {
    return (
      <div className="text-center py-12">
        <CircleAlert className="h-12 w-12 mx-auto text-amber-500 mb-4" />
        <h3 className="text-lg font-medium">Nessuna sala configurata</h3>
        <p className="text-muted-foreground mb-4">
          Per visualizzare la mappa dei tavoli, aggiungi prima delle sale nella sezione Rooms.
        </p>
        <Button variant="outline">Vai alla gestione sale</Button>
      </div>
    );
  }

  const currentRoom = rooms.find(room => room.id === selectedRoomId);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <LayoutGrid className="h-5 w-5 text-purple-500" />
          <span>Mappa Tavoli e Prenotazioni</span>
        </h2>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-9/12 space-y-4">
          <Tabs value={selectedRoomId} onValueChange={setSelectedRoomId}>
            <TabsList className="mb-4">
              {rooms.map(room => (
                <TabsTrigger key={room.id} value={room.id}>
                  {room.name}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {rooms.map(room => (
              <TabsContent key={room.id} value={room.id} className="m-0">
                <Card className="border shadow-sm">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
                      {room.tables.map(table => {
                        const reservation = tableReservations[table.id];
                        const isLoading = loadingTables[table.id];
                        const isSelected = selectedTable === table.id;
                        
                        return (
                          <motion.div
                            key={table.id}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            className={`cursor-pointer ${isSelected ? 'ring-2 ring-purple-500' : ''}`}
                            onClick={() => handleTableClick(table.id)}
                          >
                            <Card className={`overflow-hidden ${
                              reservation ? 
                                reservation.status === 'confirmed' ? 'border-green-300 shadow-green-100 dark:border-green-700 dark:shadow-none' :
                                reservation.status === 'pending' ? 'border-amber-300 shadow-amber-100 dark:border-amber-700 dark:shadow-none' : 
                                'border-blue-300 shadow-blue-100 dark:border-blue-700 dark:shadow-none'
                              : 'border-gray-200'
                            }`}>
                              <CardContent className="p-4">
                                <div className="flex justify-between items-start mb-2">
                                  <h3 className="font-medium">{table.name}</h3>
                                  <div className="flex items-center gap-1 text-sm">
                                    <Users className="h-4 w-4 text-muted-foreground" />
                                    <span>{table.seats} posti</span>
                                  </div>
                                </div>
                                
                                {isLoading ? (
                                  <div className="space-y-2">
                                    <Skeleton className="h-4 w-full" />
                                    <Skeleton className="h-4 w-3/4" />
                                    <Skeleton className="h-4 w-1/2" />
                                  </div>
                                ) : (
                                  <>
                                    {reservation ? (
                                      <div className="text-sm space-y-1">
                                        <div className="font-medium">{reservation.customerName}</div>
                                        <div className="flex items-center gap-1 text-muted-foreground">
                                          <Clock className="h-3 w-3" />
                                          <span>{reservation.time}</span>
                                        </div>
                                        <div className="flex items-center gap-1 text-muted-foreground">
                                          <Users className="h-3 w-3" />
                                          <span>{reservation.partySize} persone</span>
                                        </div>
                                        <div className={`mt-2 text-xs inline-flex items-center px-2 py-1 rounded-full ${
                                          reservation.status === 'confirmed' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200' :
                                          reservation.status === 'pending' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-200' :
                                          'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200'
                                        }`}>
                                          {reservation.status === 'confirmed' ? 'Confermato' :
                                           reservation.status === 'pending' ? 'In attesa' : 'Arrivato'}
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="flex items-center justify-center h-16 text-sm text-muted-foreground">
                                        Tavolo disponibile
                                      </div>
                                    )}
                                  </>
                                )}
                              </CardContent>
                            </Card>
                          </motion.div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
        
        <div className="w-full md:w-3/12">
          <Card className="border shadow-sm h-full">
            <CardContent className="p-4">
              <h3 className="font-medium text-lg mb-4">Dettagli Tavolo</h3>
              
              {selectedTable ? (
                currentRoom?.tables.map(table => {
                  if (table.id === selectedTable) {
                    return (
                      <div key={table.id} className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground">Informazioni tavolo</h4>
                          <p className="font-semibold text-lg">{table.name}</p>
                          <div className="flex items-center gap-1 text-sm">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{table.seats} posti</span>
                          </div>
                        </div>
                        
                        <div className="border-t pt-3">
                          <h4 className="text-sm font-medium text-muted-foreground mb-2">Prenotazione attiva</h4>
                          
                          {loadingTables[table.id] ? (
                            <div className="animate-pulse space-y-2">
                              <div className="h-4 bg-muted rounded w-3/4"></div>
                              <div className="h-4 bg-muted rounded w-1/2"></div>
                            </div>
                          ) : tableReservations[table.id] ? (
                            <div>
                              <TableReservation 
                                reservation={tableReservations[table.id]} 
                                isLoading={false} 
                              />
                              <Button 
                                className="w-full mt-4"
                                size="sm"
                                onClick={() => {
                                  if (tableReservations[table.id]) {
                                    setSelectedReservation(tableReservations[table.id]);
                                    setActiveReservation(tableReservations[table.id]!);
                                    setQuickViewOpen(true);
                                  }
                                }}
                              >
                                Visualizza dettagli
                              </Button>
                            </div>
                          ) : (
                            <div className="text-sm text-muted-foreground py-2">
                              Nessuna prenotazione attiva
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })
              ) : (
                <div className="flex flex-col items-center justify-center h-48 text-center">
                  <LayoutGrid className="h-12 w-12 text-muted-foreground opacity-20 mb-2" />
                  <p className="text-muted-foreground">Seleziona un tavolo per vedere i dettagli</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {quickViewOpen && selectedReservation && (
        <ReservationQuickView 
          reservation={selectedReservation}
          open={quickViewOpen}
          onOpenChange={setQuickViewOpen}
        />
      )}
    </div>
  );
}
