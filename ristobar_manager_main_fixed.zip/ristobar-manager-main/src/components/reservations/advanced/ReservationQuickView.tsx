
import React from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter
} from '@/components/ui/sheet';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Reservation } from '@/types/reservations';
import { User, Calendar, Clock, Phone, Mail, StickyNote, Menu, Check, X, UserCheck, RotateCcw } from 'lucide-react';
import { updateReservationStatus, deleteReservation } from '@/services/reservationService';
import { toast } from 'sonner';
import { useReservationStore } from '@/stores/reservationStore';

interface ReservationQuickViewProps {
  reservation: Reservation;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ReservationQuickView({ 
  reservation, 
  open, 
  onOpenChange 
}: ReservationQuickViewProps) {
  const { clearActiveReservation } = useReservationStore();
  
  const handleStatusChange = async (newStatus: Reservation['status']) => {
    try {
      await updateReservationStatus(reservation.id, newStatus);
      toast.success(`Stato prenotazione aggiornato a "${getStatusLabel(newStatus)}"`);
      onOpenChange(false);
      clearActiveReservation();
    } catch (error) {
      console.error('Error updating reservation status:', error);
      toast.error('Errore nell\'aggiornamento dello stato della prenotazione');
    }
  };
  
  const handleDeleteReservation = async () => {
    if (confirm('Sei sicuro di voler eliminare questa prenotazione? Questa azione non può essere annullata.')) {
      try {
        await deleteReservation(reservation.id);
        toast.success('Prenotazione eliminata con successo');
        onOpenChange(false);
        clearActiveReservation();
      } catch (error) {
        console.error('Error deleting reservation:', error);
        toast.error('Errore nell\'eliminazione della prenotazione');
      }
    }
  };
  
  const getStatusLabel = (status: Reservation['status']) => {
    switch (status) {
      case 'confirmed': return 'Confermata';
      case 'pending': return 'In attesa';
      case 'arrived': return 'Arrivato';
      case 'cancelled': return 'Annullata';
      case 'no-show': return 'No-show';
      default: return 'Sconosciuto';
    }
  };
  
  const getStatusBadge = (status: Reservation['status']) => {
    switch (status) {
      case 'confirmed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Confermata</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">In attesa</Badge>;
      case 'arrived':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Arrivato</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Annullata</Badge>;
      case 'no-show':
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">No-show</Badge>;
      default:
        return <Badge variant="outline">Sconosciuto</Badge>;
    }
  };
  
  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return format(dateObj, 'EEEE d MMMM yyyy', { locale: it });
  };

  return (
    <Sheet open={open} onOpenChange={(isOpen) => {
      onOpenChange(isOpen);
      if (!isOpen) clearActiveReservation();
    }}>
      <SheetContent className="sm:max-w-md overflow-y-auto">
        <SheetHeader className="pb-4">
          <SheetTitle className="text-xl">{reservation.customerName}</SheetTitle>
          <SheetDescription className="flex items-center justify-between">
            <span>Prenotazione #{reservation.id.slice(0, 8)}</span>
            {getStatusBadge(reservation.status)}
          </SheetDescription>
        </SheetHeader>
        
        <div className="space-y-4 my-4">
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-purple-500" />
                <span>{formatDate(reservation.date)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-purple-500" />
                <span>Ore {reservation.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-purple-500" />
                <span>{reservation.partySize} persone</span>
              </div>
              {reservation.tableId && (
                <div className="flex items-center gap-2">
                  <Menu className="h-4 w-4 text-purple-500" />
                  <span>Tavolo {reservation.tableId}</span>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Separator />
          
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Informazioni cliente</h3>
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-gray-500" />
              <span>{reservation.customerName}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-gray-500" />
              <span>{reservation.phone}</span>
            </div>
            {reservation.email && (
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-gray-500" />
                <span>{reservation.email}</span>
              </div>
            )}
          </div>
          
          {(reservation.notes || (reservation.specialRequests && reservation.specialRequests.length > 0)) && (
            <>
              <Separator />
              
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Note e richieste speciali</h3>
                
                {reservation.notes && (
                  <div className="flex gap-2">
                    <StickyNote className="h-4 w-4 text-gray-500 mt-1 flex-shrink-0" />
                    <span className="text-sm">{reservation.notes}</span>
                  </div>
                )}
                
                {reservation.specialRequests && reservation.specialRequests.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {reservation.specialRequests.map((request, index) => (
                      <Badge key={index} variant="secondary">{request}</Badge>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
        
        <Separator />
        
        <div className="mt-4 space-y-4">
          <h3 className="font-medium">Azioni</h3>
          
          <div className="grid grid-cols-2 gap-2">
            {reservation.status === 'pending' && (
              <Button onClick={() => handleStatusChange('confirmed')} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
                <Check className="h-4 w-4" />
                <span>Conferma</span>
              </Button>
            )}
            
            {reservation.status !== 'cancelled' && (
              <Button onClick={() => handleStatusChange('cancelled')} variant="destructive" className="flex items-center gap-2">
                <X className="h-4 w-4" />
                <span>Annulla</span>
              </Button>
            )}
            
            {(reservation.status === 'confirmed' || reservation.status === 'pending') && (
              <Button onClick={() => handleStatusChange('arrived')} variant="default" className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
                <UserCheck className="h-4 w-4" />
                <span>Arrivato</span>
              </Button>
            )}
            
            {reservation.status === 'confirmed' && (
              <Button onClick={() => handleStatusChange('no-show')} variant="outline" className="flex items-center gap-2 border-red-200 text-red-700 hover:bg-red-50">
                <RotateCcw className="h-4 w-4" />
                <span>No-show</span>
              </Button>
            )}
          </div>
        </div>
        
        <SheetFooter className="mt-6">
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            className="w-full sm:w-auto"
          >
            Chiudi
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleDeleteReservation}
            className="w-full sm:w-auto"
          >
            Elimina prenotazione
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
