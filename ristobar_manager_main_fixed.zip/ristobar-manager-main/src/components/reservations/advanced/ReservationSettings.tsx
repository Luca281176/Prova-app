
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, BellRing, Calendar, Settings2 } from 'lucide-react';

interface ReservationSettingsProps {
  locationId: string;
}

const ReservationSettings: React.FC<ReservationSettingsProps> = ({ locationId }) => {
  const [settings, setSettings] = useState({
    // Orari di prenotazione
    openingTime: "11:00",
    closingTime: "23:00",
    intervalMinutes: "30",
    
    // Notifiche
    enableSmsNotifications: false,
    enableEmailNotifications: true,
    reminderHours: "2",
    
    // Regole di prenotazione
    maxPartySize: "12",
    minAdvanceHours: "1",
    maxAdvanceDays: "30",
    requirePhoneNumber: true,
    requireEmail: false,
    
    // Personalizzazione
    confirmationMessage: "Grazie per la tua prenotazione! Ti confermiamo che abbiamo ricevuto la tua richiesta."
  });

  const handleChange = (key: string, value: string | boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSave = () => {
    // Qui in futuro si salveranno le impostazioni per la sede specifica
    console.log(`Saving settings for location ${locationId}:`, settings);
    toast.success("Impostazioni salvate con successo");
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="timing">
        <TabsList className="mb-4">
          <TabsTrigger value="timing" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>Orari</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <BellRing className="h-4 w-4" />
            <span>Notifiche</span>
          </TabsTrigger>
          <TabsTrigger value="rules" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>Regole</span>
          </TabsTrigger>
          <TabsTrigger value="customization" className="flex items-center gap-2">
            <Settings2 className="h-4 w-4" />
            <span>Personalizzazione</span>
          </TabsTrigger>
        </TabsList>
      
        <TabsContent value="timing">
          <Card>
            <CardHeader>
              <CardTitle>Orari di Prenotazione</CardTitle>
              <CardDescription>
                Configura gli orari disponibili per le prenotazioni
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="openingTime">Orario di apertura</Label>
                  <Input
                    id="openingTime"
                    type="time"
                    value={settings.openingTime}
                    onChange={(e) => handleChange('openingTime', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="closingTime">Orario di chiusura</Label>
                  <Input
                    id="closingTime"
                    type="time"
                    value={settings.closingTime}
                    onChange={(e) => handleChange('closingTime', e.target.value)}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="intervalMinutes">Intervallo tra prenotazioni (minuti)</Label>
                <Select 
                  value={settings.intervalMinutes}
                  onValueChange={(value) => handleChange('intervalMinutes', value)}
                >
                  <SelectTrigger id="intervalMinutes">
                    <SelectValue placeholder="Seleziona intervallo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minuti</SelectItem>
                    <SelectItem value="30">30 minuti</SelectItem>
                    <SelectItem value="60">1 ora</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notifiche</CardTitle>
              <CardDescription>
                Configura le notifiche per le prenotazioni
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="smsNotifications">Notifiche SMS</Label>
                  <div className="text-sm text-muted-foreground">
                    Invia notifiche SMS per conferme e promemoria
                  </div>
                </div>
                <Switch
                  id="smsNotifications"
                  checked={settings.enableSmsNotifications}
                  onCheckedChange={(value) => handleChange('enableSmsNotifications', value)}
                />
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotifications">Notifiche Email</Label>
                  <div className="text-sm text-muted-foreground">
                    Invia notifiche email per conferme e promemoria
                  </div>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={settings.enableEmailNotifications}
                  onCheckedChange={(value) => handleChange('enableEmailNotifications', value)}
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label htmlFor="reminderHours">Ore di anticipo per i promemoria</Label>
                <Select 
                  value={settings.reminderHours}
                  onValueChange={(value) => handleChange('reminderHours', value)}
                >
                  <SelectTrigger id="reminderHours">
                    <SelectValue placeholder="Seleziona ore" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 ora prima</SelectItem>
                    <SelectItem value="2">2 ore prima</SelectItem>
                    <SelectItem value="4">4 ore prima</SelectItem>
                    <SelectItem value="24">1 giorno prima</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      
        <TabsContent value="rules">
          <Card>
            <CardHeader>
              <CardTitle>Regole di Prenotazione</CardTitle>
              <CardDescription>
                Configura i limiti e i requisiti per le prenotazioni
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="maxPartySize">Numero massimo di persone</Label>
                  <Input
                    id="maxPartySize"
                    type="number"
                    value={settings.maxPartySize}
                    onChange={(e) => handleChange('maxPartySize', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="minAdvanceHours">Ore minime di anticipo</Label>
                  <Input
                    id="minAdvanceHours"
                    type="number"
                    value={settings.minAdvanceHours}
                    onChange={(e) => handleChange('minAdvanceHours', e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="maxAdvanceDays">Giorni massimi di anticipo</Label>
                  <Input
                    id="maxAdvanceDays"
                    type="number"
                    value={settings.maxAdvanceDays}
                    onChange={(e) => handleChange('maxAdvanceDays', e.target.value)}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="requirePhoneNumber">Richiedi numero di telefono</Label>
                  <div className="text-sm text-muted-foreground">
                    Obbliga i clienti a fornire un numero di telefono
                  </div>
                </div>
                <Switch
                  id="requirePhoneNumber"
                  checked={settings.requirePhoneNumber}
                  onCheckedChange={(value) => handleChange('requirePhoneNumber', value)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="requireEmail">Richiedi email</Label>
                  <div className="text-sm text-muted-foreground">
                    Obbliga i clienti a fornire un indirizzo email
                  </div>
                </div>
                <Switch
                  id="requireEmail"
                  checked={settings.requireEmail}
                  onCheckedChange={(value) => handleChange('requireEmail', value)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      
        <TabsContent value="customization">
          <Card>
            <CardHeader>
              <CardTitle>Personalizzazione</CardTitle>
              <CardDescription>
                Personalizza messaggi e aspetto delle prenotazioni
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="confirmationMessage">Messaggio di conferma</Label>
                <Input
                  id="confirmationMessage"
                  value={settings.confirmationMessage}
                  onChange={(e) => handleChange('confirmationMessage', e.target.value)}
                />
                <p className="text-sm text-muted-foreground">
                  Questo messaggio verrà mostrato ai clienti quando confermano una prenotazione
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="flex justify-end">
        <Button onClick={handleSave}>
          Salva impostazioni
        </Button>
      </div>
    </div>
  );
};

export default ReservationSettings;
