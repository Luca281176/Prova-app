
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { useReservationStore } from '@/stores/reservationStore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, Calendar, Phone, Search, PlusCircle, ArrowDownAZ, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format, isToday, isTomorrow } from 'date-fns';
import { it } from 'date-fns/locale';
import { Reservation } from '@/types/reservations';
import { getReservations } from '@/services/reservationService';
import { motion, AnimatePresence } from 'framer-motion';
import AddReservationDialog from '@/components/reservations/AddReservationDialog';

interface ReservationSidePanelProps {
  locationId: string;
  activeTab: string;
}

export default function ReservationSidePanel({ locationId, activeTab }: ReservationSidePanelProps) {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [tabView, setTabView] = useState<'upcoming' | 'search'>('upcoming');
  const { activeReservation, setActiveReservation } = useReservationStore();
  const [showAddDialog, setShowAddDialog] = useState(false);

  useEffect(() => {
    loadReservations();
  }, [locationId]);

  const loadReservations = async () => {
    setIsLoading(true);
    try {
      const result = await getReservations();
      if (result.error) {
        console.error('Error loading reservations:', result.error);
        setReservations([]);
      } else {
        setReservations(result.data);
      }
    } catch (error) {
      console.error('Error loading reservations:', error);
      setReservations([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Filter and sort reservations
  const filteredReservations = reservations
    .filter(res => {
      // Status filter
      if (statusFilter !== 'all' && res.status !== statusFilter) {
        return false;
      }
      
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        return (
          res.customerName.toLowerCase().includes(searchLower) ||
          res.phone.includes(searchTerm) ||
          (res.email && res.email.toLowerCase().includes(searchLower)) ||
          (res.notes && res.notes.toLowerCase().includes(searchLower))
        );
      }
      
      return true;
    })
    .sort((a, b) => {
      // First by date
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      
      if (dateA.getTime() !== dateB.getTime()) {
        return sortOrder === 'asc' ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
      }
      
      // Then by time
      const [hoursA, minutesA] = a.time.split(':').map(Number);
      const [hoursB, minutesB] = b.time.split(':').map(Number);
      
      const timeA = hoursA * 60 + minutesA;
      const timeB = hoursB * 60 + minutesB;
      
      return sortOrder === 'asc' ? timeA - timeB : timeB - timeA;
    });

  // Get today's reservations
  const todayReservations = filteredReservations.filter(res => {
    const resDate = new Date(res.date);
    return isToday(resDate);
  });

  // Get tomorrow's reservations
  const tomorrowReservations = filteredReservations.filter(res => {
    const resDate = new Date(res.date);
    return isTomorrow(resDate);
  });

  // Get future reservations (after tomorrow)
  const futureReservations = filteredReservations.filter(res => {
    const resDate = new Date(res.date);
    return !isToday(resDate) && !isTomorrow(resDate) && resDate > new Date();
  });

  const getStatusBadge = (status: Reservation['status']) => {
    switch (status) {
      case 'confirmed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Confermata</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">In attesa</Badge>;
      case 'arrived':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">Arrivato</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Annullata</Badge>;
      case 'no-show':
        return <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">No-show</Badge>;
      default:
        return <Badge variant="outline">Sconosciuto</Badge>;
    }
  };

  const formatDate = (date: Date | string) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (isToday(dateObj)) {
      return 'Oggi';
    } else if (isTomorrow(dateObj)) {
      return 'Domani';
    } else {
      return format(dateObj, 'd MMM', { locale: it });
    }
  };

  const renderReservationCard = (reservation: Reservation) => {
    const isActive = activeReservation?.id === reservation.id;
    
    return (
      <motion.div
        key={reservation.id}
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.2 }}
        onClick={() => setActiveReservation(reservation)}
      >
        <Card className={`cursor-pointer transition-all ${
          isActive ? 'ring-2 ring-purple-500 shadow-md' : 'hover:shadow-md'
        }`}>
          <CardContent className="p-3 space-y-2">
            <div className="flex justify-between items-start">
              <div className="font-medium">{reservation.customerName}</div>
              {getStatusBadge(reservation.status)}
            </div>
            <div className="flex items-center text-sm text-muted-foreground gap-1">
              <Calendar className="h-3 w-3" />
              <span>{formatDate(reservation.date)}</span>
              <Clock className="h-3 w-3 ml-2" />
              <span>{reservation.time}</span>
            </div>
            <div className="flex items-center text-sm text-muted-foreground gap-1">
              <Phone className="h-3 w-3" />
              <span>{reservation.phone}</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  return (
    <Card className="border shadow">
      <CardContent className="p-4 pt-6 h-[calc(100vh-200px)] flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-lg">Prenotazioni</h3>
          <Button 
            size="sm" 
            onClick={() => setShowAddDialog(true)}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
          >
            <PlusCircle className="h-4 w-4 mr-1" />
            Nuova
          </Button>
        </div>
        
        <Tabs value={tabView} onValueChange={(v) => setTabView(v as 'upcoming' | 'search')} className="mb-2">
          <TabsList className="grid grid-cols-2 w-full">
            <TabsTrigger value="upcoming">Prossime</TabsTrigger>
            <TabsTrigger value="search">Cerca</TabsTrigger>
          </TabsList>
        </Tabs>
        
        <TabsContent value="upcoming" className="flex-1 overflow-hidden m-0 p-0">
          <ScrollArea className="h-full pr-3">
            <AnimatePresence>
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-3 space-y-2">
                        <div className="h-5 bg-muted rounded w-3/4"></div>
                        <div className="h-4 bg-muted rounded w-1/2"></div>
                        <div className="h-4 bg-muted rounded w-2/3"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {todayReservations.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Oggi</h4>
                      <div className="space-y-2">
                        {todayReservations.map(reservation => renderReservationCard(reservation))}
                      </div>
                    </div>
                  )}
                  
                  {tomorrowReservations.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Domani</h4>
                      <div className="space-y-2">
                        {tomorrowReservations.map(reservation => renderReservationCard(reservation))}
                      </div>
                    </div>
                  )}
                  
                  {futureReservations.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium text-muted-foreground">Prossimamente</h4>
                      <div className="space-y-2">
                        {futureReservations.map(reservation => renderReservationCard(reservation))}
                      </div>
                    </div>
                  )}
                  
                  {filteredReservations.length === 0 && (
                    <div className="text-center py-12 text-muted-foreground">
                      Nessuna prenotazione da mostrare
                    </div>
                  )}
                </div>
              )}
            </AnimatePresence>
          </ScrollArea>
        </TabsContent>
        
        <TabsContent value="search" className="flex-1 flex flex-col overflow-hidden m-0 p-0">
          <div className="space-y-2 mb-4">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cerca prenotazioni..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="flex-1 h-8">
                  <Filter className="h-3 w-3 mr-1" />
                  <SelectValue placeholder="Stato" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tutti gli stati</SelectItem>
                  <SelectItem value="pending">In attesa</SelectItem>
                  <SelectItem value="confirmed">Confermate</SelectItem>
                  <SelectItem value="arrived">Arrivati</SelectItem>
                  <SelectItem value="cancelled">Cancellate</SelectItem>
                  <SelectItem value="no-show">No-show</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="flex items-center h-8"
              >
                <ArrowDownAZ className={`h-4 w-4 ${sortOrder === 'desc' ? 'rotate-180' : ''} transition-transform`} />
              </Button>
            </div>
          </div>
          
          <ScrollArea className="flex-1 pr-3">
            <AnimatePresence>
              {isLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-3 space-y-2">
                        <div className="h-5 bg-muted rounded w-3/4"></div>
                        <div className="h-4 bg-muted rounded w-1/2"></div>
                        <div className="h-4 bg-muted rounded w-2/3"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredReservations.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      Nessuna prenotazione corrisponde ai criteri di ricerca
                    </div>
                  ) : (
                    filteredReservations.map(reservation => renderReservationCard(reservation))
                  )}
                </div>
              )}
            </AnimatePresence>
          </ScrollArea>
        </TabsContent>
        
        <div className="mt-4 text-center text-xs text-muted-foreground">
          {reservations.length} prenotazioni totali
        </div>
        
        {showAddDialog && (
          <AddReservationDialog 
            open={showAddDialog} 
            onOpenChange={setShowAddDialog}
            onSuccess={() => {
              loadReservations();
              setShowAddDialog(false);
            }}
          />
        )}
      </CardContent>
    </Card>
  );
}
