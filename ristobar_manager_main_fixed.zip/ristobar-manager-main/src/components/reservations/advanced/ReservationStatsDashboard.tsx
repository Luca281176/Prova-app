
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getReservations } from '@/services/reservationService';
import { Reservation } from '@/types/reservations';
import { format, parseISO, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay } from 'date-fns';
import { it } from 'date-fns/locale';
import { Spinner } from '@/components/ui/spinner';

interface ReservationStatsDashboardProps {
  locationId: string;
}

const ReservationStatsDashboard: React.FC<ReservationStatsDashboardProps> = ({ locationId }) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('daily');

  useEffect(() => {
    const fetchReservations = async () => {
      setIsLoading(true);
      try {
        const response = await getReservations();
        if (response.data) {
          // Filter reservations for this location (if location data becomes available)
          setReservations(response.data);
        }
      } catch (error) {
        console.error('Error fetching reservations for stats:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchReservations();
  }, [locationId]);

  // Prepare data for charts
  const prepareChartData = () => {
    if (reservations.length === 0) return [];

    const today = new Date();
    const startDate = startOfWeek(today, { locale: it });
    const endDate = endOfWeek(today, { locale: it });
    
    const daysInWeek = eachDayOfInterval({ start: startDate, end: endDate });
    
    const data = daysInWeek.map(day => {
      const dayReservations = reservations.filter(res => {
        const resDate = typeof res.date === 'string' ? parseISO(res.date) : res.date;
        return isSameDay(resDate, day);
      });
      
      return {
        name: format(day, 'EEE', { locale: it }),
        reservations: dayReservations.length,
        guests: dayReservations.reduce((sum, res) => sum + res.partySize, 0)
      };
    });
    
    return data;
  };

  const getStatusCounts = () => {
    const counts = {
      confirmed: 0,
      pending: 0,
      arrived: 0,
      cancelled: 0,
      'no-show': 0
    };
    
    reservations.forEach(res => {
      if (counts[res.status] !== undefined) {
        counts[res.status]++;
      }
    });
    
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  };

  const chartData = prepareChartData();
  const statusData = getStatusCounts();
  
  const COLORS = ['#0088FE', '#FFBB28', '#00C49F', '#FF8042', '#8884D8'];
  const STATUS_LABELS = {
    confirmed: 'Confermate',
    pending: 'In attesa',
    arrived: 'Arrivati',
    cancelled: 'Annullate',
    'no-show': 'No-show'
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Spinner size="lg" />
        <span className="ml-2">Caricamento statistiche...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="daily">Statistiche Giornaliere</TabsTrigger>
          <TabsTrigger value="status">Stato Prenotazioni</TabsTrigger>
        </TabsList>
        
        <TabsContent value="daily" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Prenotazioni Settimanali</CardTitle>
              <CardDescription>Andamento delle prenotazioni nella settimana corrente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="reservations" name="Prenotazioni" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Ospiti Attesi</CardTitle>
              <CardDescription>Numero di ospiti previsti per giorno</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="guests" name="Ospiti" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="status">
          <Card>
            <CardHeader>
              <CardTitle>Distribuzione Stato Prenotazioni</CardTitle>
              <CardDescription>Ripartizione per stato delle prenotazioni</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex flex-col items-center justify-center">
                <ResponsiveContainer width="100%" height="80%">
                  <PieChart>
                    <Pie 
                      data={statusData} 
                      cx="50%" 
                      cy="50%" 
                      labelLine={true}
                      label={({ name, percent }) => 
                        `${STATUS_LABELS[name] || name}: ${(percent * 100).toFixed(0)}%`
                      }
                      outerRadius={80} 
                      fill="#8884d8" 
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value, name) => [value, STATUS_LABELS[name] || name]} />
                  </PieChart>
                </ResponsiveContainer>
                
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-4">
                  {statusData.map((entry, index) => (
                    <div key={index} className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-2" 
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <span className="text-xs">{STATUS_LABELS[entry.name] || entry.name}: {entry.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ReservationStatsDashboard;
