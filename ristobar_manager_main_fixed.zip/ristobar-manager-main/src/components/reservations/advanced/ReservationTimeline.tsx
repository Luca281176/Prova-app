import { useState, useEffect, useRef } from 'react';
import { format, addDays, parseISO, isSameDay, isToday } from 'date-fns';
import { it } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight, Calendar, Clock, Users, Info } from 'lucide-react';
import { Reservation } from '@/types/reservations';
import { getReservations } from '@/services/reservationService';
import { useReservationStore } from '@/stores/reservationStore';
import { Skeleton } from '@/components/ui/skeleton';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface ReservationTimelineProps {
  locationId: string;
}

// Updated hourSlots to include hours from 12 to 4 AM (next day)
const hourSlots = Array.from({ length: 17 }, (_, i) => (i + 12) % 24);

export default function ReservationTimeline({ locationId }: ReservationTimelineProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [filteredReservations, setFilteredReservations] = useState<Reservation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [view, setView] = useState<'hourly' | 'status'>('hourly');
  const timelineRef = useRef<HTMLDivElement>(null);
  const { setActiveReservation } = useReservationStore();

  useEffect(() => {
    loadReservations();
  }, [locationId, selectedDate]);

  useEffect(() => {
    if (reservations.length > 0) {
      const filtered = reservations.filter(res => {
        const resDate = typeof res.date === 'string' ? parseISO(res.date) : res.date;
        return isSameDay(resDate, selectedDate);
      });
      setFilteredReservations(filtered);
    }
  }, [reservations, selectedDate]);

  // Scroll to current time on load
  useEffect(() => {
    if (timelineRef.current && isToday(selectedDate)) {
      const now = new Date();
      const currentHour = now.getHours();
      const scrollElement = document.getElementById(`hour-${currentHour}`);
      
      if (scrollElement) {
        timelineRef.current.scrollLeft = scrollElement.offsetLeft - 100;
      }
    }
  }, [filteredReservations, selectedDate]);

  const loadReservations = async () => {
    setIsLoading(true);
    try {
      const result = await getReservations();
      if (result.error) {
        console.error('Error loading reservations:', result.error);
        toast.error('Impossibile caricare le prenotazioni');
        setReservations([]);
      } else {
        setReservations(result.data);
      }
    } catch (error) {
      console.error('Error loading reservations:', error);
      toast.error('Errore nel caricamento delle prenotazioni');
      setReservations([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrevDay = () => {
    setSelectedDate(prevDate => addDays(prevDate, -1));
  };

  const handleNextDay = () => {
    setSelectedDate(prevDate => addDays(prevDate, 1));
  };

  const handleReservationClick = (reservation: Reservation) => {
    setActiveReservation(reservation);
    toast.info(`Selezionata prenotazione di ${reservation.customerName}`);
  };

  const getReservationsByHour = (hour: number) => {
    return filteredReservations.filter(res => {
      const [h] = res.time.split(':').map(Number);
      return h === hour;
    });
  };

  const getReservationsByStatus = (status: string) => {
    return filteredReservations.filter(res => res.status === status);
  };

  const renderHourlyView = () => {
    if (isLoading) {
      return (
        <div className="space-y-2 w-full">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-28 w-full" />
          <Skeleton className="h-28 w-full" />
        </div>
      );
    }

    return (
      <div className="overflow-x-auto pb-4" ref={timelineRef}>
        <div className="min-w-max flex space-x-4">
          {hourSlots.map(hour => {
            const hourReservations = getReservationsByHour(hour);
            const now = new Date();
            const isCurrentHour = isToday(selectedDate) && now.getHours() === hour;
            
            return (
              <div 
                key={hour} 
                id={`hour-${hour}`}
                className={`w-64 shrink-0 ${isCurrentHour ? 'bg-purple-50 dark:bg-purple-900/10 rounded-lg' : ''}`}
              >
                <div className={`text-center py-1 sticky top-0 ${isCurrentHour ? 'text-purple-600 font-semibold' : ''}`}>
                  {hour}:00 - {hour+1}:00
                  {isCurrentHour && <div className="text-xs font-normal text-purple-500">(Ora attuale)</div>}
                </div>
                
                <div className="border-l-2 border-dashed border-muted-foreground/20 h-full ml-4 pl-4 py-2 space-y-2">
                  {hourReservations.length === 0 ? (
                    <div className="text-center text-sm text-muted-foreground py-2">
                      Nessuna prenotazione
                    </div>
                  ) : (
                    hourReservations.map(reservation => (
                      <motion.div
                        key={reservation.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                        className="cursor-pointer"
                        onClick={() => handleReservationClick(reservation)}
                      >
                        <div className={`p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 ${
                          reservation.status === 'confirmed' ? 'border-l-green-500 bg-green-50 dark:bg-green-900/10' :
                          reservation.status === 'pending' ? 'border-l-amber-500 bg-amber-50 dark:bg-amber-900/10' :
                          reservation.status === 'arrived' ? 'border-l-blue-500 bg-blue-50 dark:bg-blue-900/10' :
                          reservation.status === 'cancelled' ? 'border-l-red-500 bg-red-50 dark:bg-red-900/10' : 'border-l-gray-500'
                        }`}>
                          <div className="font-medium">{reservation.customerName}</div>
                          <div className="flex items-center space-x-2 text-sm">
                            <Clock className="h-3 w-3" /> 
                            <span>{reservation.time}</span>
                          </div>
                          <div className="flex items-center space-x-2 text-sm">
                            <Users className="h-3 w-3" /> 
                            <span>{reservation.partySize} persone</span>
                          </div>
                          {reservation.tableId && (
                            <div className="mt-1 text-xs text-muted-foreground">
                              Tavolo: {reservation.tableId}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderStatusView = () => {
    if (isLoading) {
      return (
        <div className="space-y-4 w-full">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      );
    }

    const statusGroups = [
      { status: 'pending', label: 'In attesa', color: 'bg-amber-100 dark:bg-amber-900/20' },
      { status: 'confirmed', label: 'Confermate', color: 'bg-green-100 dark:bg-green-900/20' },
      { status: 'arrived', label: 'Arrivati', color: 'bg-blue-100 dark:bg-blue-900/20' },
      { status: 'cancelled', label: 'Cancellate', color: 'bg-red-100 dark:bg-red-900/20' }
    ];

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {statusGroups.map((group) => {
          const statusReservations = getReservationsByStatus(group.status);
          
          return (
            <div key={group.status} className={`rounded-lg p-4 ${group.color}`}>
              <h3 className="text-lg font-semibold mb-2">{group.label} ({statusReservations.length})</h3>
              
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                {statusReservations.length === 0 ? (
                  <div className="text-center text-sm text-muted-foreground py-4">
                    Nessuna prenotazione {group.label.toLowerCase()}
                  </div>
                ) : (
                  statusReservations.map(reservation => (
                    <motion.div
                      key={reservation.id}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-white dark:bg-gray-800 p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleReservationClick(reservation)}
                    >
                      <div className="font-medium">{reservation.customerName}</div>
                      <div className="flex justify-between text-sm">
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" /> 
                          <span>{reservation.time}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users className="h-3 w-3" /> 
                          <span>{reservation.partySize}</span>
                        </div>
                      </div>
                      {(reservation.notes || reservation.specialRequests?.length) && (
                        <div className="mt-1 text-xs flex items-center text-muted-foreground">
                          <Info className="h-3 w-3 mr-1" />
                          {reservation.notes ? 'Note' : 'Richieste speciali'}
                        </div>
                      )}
                    </motion.div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 mb-6">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-purple-500" />
          <h2 className="text-xl font-semibold">
            {format(selectedDate, "EEEE d MMMM yyyy", { locale: it })}
          </h2>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePrevDay}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setSelectedDate(new Date())}
              className={isToday(selectedDate) ? "bg-purple-100 text-purple-700 hover:bg-purple-200 dark:bg-purple-900/20 dark:text-purple-300" : ""}
            >
              Oggi
            </Button>
            <Button variant="outline" size="sm" onClick={handleNextDay}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <Select value={view} onValueChange={(value: 'hourly' | 'status') => setView(value)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Visualizzazione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hourly">Oraria</SelectItem>
              <SelectItem value="status">Per stato</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {view === 'hourly' ? renderHourlyView() : renderStatusView()}
      
      <div className="text-right text-sm text-muted-foreground mt-6">
        {filteredReservations.length} prenotazioni per {format(selectedDate, "d MMMM", { locale: it })}
      </div>
    </div>
  );
}
