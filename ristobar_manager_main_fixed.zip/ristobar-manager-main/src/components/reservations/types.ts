
import { Reservation } from '@/types/reservations';

export interface SpecialRequestsState {
  window: boolean;
  highChair: boolean;
  kidsMenu: boolean;
  birthday: boolean;
  quiet: boolean;
}

export interface ReservationFormData {
  name: string;
  phone: string;
  email: string;
  date: Date;
  time: string;
  partySize: string;
  table: string;
  notes: string;
  specialRequests: SpecialRequestsState;
  status: string;
  sendConfirmation: boolean;
  isManualAssignment: boolean;
}

export interface AddReservationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  preselectedDate?: Date;
  isEditing?: boolean;
  existingReservation?: Reservation;
  preselectedTable?: string;
  preselectedTableName?: string;
}
