
import React, { useState, useEffect } from 'react';
import { Bell, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Order, getAllOrders } from '@/services/ordersService';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface ActiveOrdersNotificationProps {
  locationId?: string;
}

const ActiveOrdersNotification: React.FC<ActiveOrdersNotificationProps> = ({ locationId }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  
  const loadOrders = async () => {
    try {
      const allOrders = await getAllOrders();
      // Filter orders by location if provided
      const filteredOrders = allOrders.filter(order => 
        (!locationId || order.locationId === locationId)
      );
      setOrders(filteredOrders);
      console.log(`ActiveOrdersNotification: Loaded ${filteredOrders.length} orders for location ${locationId || 'all'}`);
    } catch (error) {
      console.error('Error loading orders:', error);
    }
  };
  
  useEffect(() => {
    loadOrders();
    
    const handleOrdersUpdated = () => {
      console.log("ActiveOrdersNotification: orders-updated event received");
      loadOrders();
    };
    
    window.addEventListener('orders-updated', handleOrdersUpdated);
    
    return () => {
      window.removeEventListener('orders-updated', handleOrdersUpdated);
    };
  }, [locationId]);
  
  const getOrderStatusLabel = (status: 'pending' | 'completed' | 'paid' | 'cancelled'): string => {
    switch (status) {
      case 'pending': return 'In corso';
      case 'completed': return 'Completato';
      case 'paid': return 'Pagato';
      case 'cancelled': return 'Annullato';
      default: return status;
    }
  };
  
  const getOrderStatusColor = (status: 'pending' | 'completed' | 'paid' | 'cancelled'): string => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'paid': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Count active orders (pending and completed) for the badge
  const activeOrdersCount = orders.filter(order => 
    order.status === 'pending' || order.status === 'completed'
  ).length;

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="relative"
        >
          <Bell className="h-4 w-4 mr-1" />
          <span>Ordini</span>
          {activeOrdersCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-[10px]"
            >
              {activeOrdersCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="bg-primary text-primary-foreground px-4 py-2 font-medium flex items-center justify-between">
          <div className="flex items-center">
            <AlertCircle className="h-4 w-4 mr-2" /> 
            Ordini
          </div>
          <Badge variant="outline" className="bg-white/20 text-white border-white/40">
            {orders.length}
          </Badge>
        </div>
        <ScrollArea className="h-[300px]">
          {orders.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              Nessun ordine
            </div>
          ) : (
            <div className="p-2">
              {orders.map(order => (
                <div 
                  key={order.id} 
                  className="mb-2 p-2 border rounded-md hover:bg-accent/50 transition-colors"
                >
                  <div className="flex justify-between items-center mb-1">
                    <div className="font-medium">
                      Tavolo: {order.tableName}
                    </div>
                    <Badge className={getOrderStatusColor(order.status)}>
                      {getOrderStatusLabel(order.status)}
                    </Badge>
                  </div>
                  <div className="text-sm flex justify-between">
                    <span>#{order.id.substring(0, 6)}</span>
                    <span>{format(new Date(order.timestamp), 'dd/MM HH:mm', { locale: it })}</span>
                  </div>
                  <div className="text-sm font-semibold mt-1 text-right">
                    Totale: €{order.total.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
};

export default ActiveOrdersNotification;
