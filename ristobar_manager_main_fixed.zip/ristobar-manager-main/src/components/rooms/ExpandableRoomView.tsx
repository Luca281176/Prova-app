
import React, { useState, useEffect } from 'react';
import { Room, Table, TableStatus } from '@/components/RoomGrid';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import TableComponent from '@/components/tables/TableComponent';
import { 
  PenSquareIcon, 
  Trash2Icon, 
  PlusCircleIcon,
  Users2Icon,
  ArrowLeftRight,
  Grid2X2,
  HomeIcon,
  EyeOff,
  Eye
} from 'lucide-react';

interface ExpandableRoomViewProps {
  room: Room;
  isSelected: boolean;
  onRoomSelect: (room: Room) => void;
  onEditRoom: (room: Room) => void;
  onDeleteRoom: (room: Room) => void;
  onAddTable: () => void;
  onEditTable: (table: Table) => void;
  onDeleteTable: (table: Table) => void;
  onTableStatusChange: (tableId: string, status: TableStatus) => Promise<void>;
}

const getRoomGradient = (roomId: string) => {
  const gradients = [
    'from-blue-500 to-purple-600',
    'from-green-400 to-cyan-500',
    'from-purple-500 to-pink-600',
    'from-amber-400 to-orange-500',
    'from-sky-400 to-indigo-500',
    'from-rose-400 to-red-500',
    'from-teal-400 to-emerald-500',
    'from-fuchsia-500 to-pink-600'
  ];
  
  const charCode = roomId.charCodeAt(roomId.length - 1) || roomId.charCodeAt(0);
  const index = charCode % gradients.length;
  return gradients[index];
};

const ExpandableRoomView: React.FC<ExpandableRoomViewProps> = ({
  room,
  isSelected,
  onRoomSelect,
  onEditRoom,
  onDeleteRoom,
  onAddTable,
  onEditTable,
  onDeleteTable,
  onTableStatusChange
}) => {
  const [isExpanded, setIsExpanded] = useState(isSelected);
  const [tablesVisible, setTablesVisible] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [animate, setAnimate] = useState(false);
  
  const gradientClasses = getRoomGradient(room.id);
  
  const handleRoomHeaderClick = () => {
    setIsExpanded(!isExpanded);
    setAnimate(true);
    setTimeout(() => setAnimate(false), 500);
    
    if (!isSelected) {
      onRoomSelect(room);
    }
  };

  useEffect(() => {
    setIsExpanded(isSelected);
  }, [isSelected]);
  
  useEffect(() => {
    console.log(`Room ${room.name} (${room.id}) data:`, room);
    console.log(`Room ${room.name} has tables array:`, Array.isArray(room.tables));
    console.log(`Room ${room.name} has ${room.tables?.length || 0} tables:`, room.tables);
  }, [room]);

  const getStatusCounts = () => {
    const counts = {
      available: 0,
      occupied: 0,
      reserved: 0,
      cleaning: 0,
      maintenance: 0,
      waiting: 0
    };
    
    if (Array.isArray(room.tables)) {
      room.tables.forEach(table => {
        if (table.status && counts[table.status] !== undefined) {
          counts[table.status]++;
        } else {
          counts.available++;
        }
      });
    }
    
    return counts;
  };

  const statusCounts = getStatusCounts();

  return (
    <Card 
      className={`transition-all duration-500 ease-in-out w-full 
      ${animate ? 'scale-[1.01]' : ''}
      ${isExpanded ? 'h-[calc(100vh-280px)]' : 'h-[180px]'}
      border border-primary/10 backdrop-blur-sm hover:shadow-lg
      hover:border-primary/30 overflow-hidden`}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${gradientClasses} opacity-5 z-0`}></div>
      
      <CardHeader 
        className={`relative z-10 pb-2 ${isExpanded ? 'border-b' : ''} transition-all duration-500 cursor-pointer`}
        onClick={handleRoomHeaderClick}
      >
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 bg-gradient-to-br ${gradientClasses} text-white`}>
              <HomeIcon className="h-5 w-5" />
            </div>
            <CardTitle className="text-xl">{room.name}</CardTitle>
          </div>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={(e) => {
                e.stopPropagation();
                setTablesVisible(!tablesVisible);
              }}
              title={tablesVisible ? "Nascondi tavoli" : "Mostra tavoli"}
              className="hover:bg-muted z-20"
            >
              {tablesVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
            {isExpanded && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={(e) => {
                  e.stopPropagation();
                  setViewMode(viewMode === 'grid' ? 'list' : 'grid');
                }}
                title={viewMode === 'grid' ? "Vista lista" : "Vista griglia"}
                className="hover:bg-muted z-20"
              >
                {viewMode === 'grid' ? <ArrowLeftRight className="h-4 w-4" /> : <Grid2X2 className="h-4 w-4" />}
              </Button>
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={(e) => {
                e.stopPropagation();
                onEditRoom(room);
              }}
              title="Modifica sala"
              className="hover:bg-muted z-20"
            >
              <PenSquareIcon className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={(e) => {
                e.stopPropagation();
                onDeleteRoom(room);
              }}
              title="Elimina sala"
              className="hover:bg-destructive/10 hover:text-destructive z-20"
            >
              <Trash2Icon className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={(e) => {
                e.stopPropagation();
                onRoomSelect(room);
                onAddTable();
              }}
              title="Aggiungi tavolo"
              className="hover:bg-primary/10 hover:text-primary z-20"
            >
              <PlusCircleIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <CardDescription className="mt-2">
          <div className="flex items-center space-x-2">
            <Users2Icon className="h-4 w-4 opacity-70" />
            <span>Capacità: {room.capacity} persone</span>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="outline" className={`flex items-center gap-1 bg-gradient-to-r ${gradientClasses} text-white`}>
              <Users2Icon className="h-3 w-3" />
              {Array.isArray(room.tables) ? room.tables.length : 0} tavoli
            </Badge>
            {statusCounts.available > 0 && (
              <Badge variant="outline" className="bg-gradient-to-r from-green-400 to-green-500 text-white border-none">
                {statusCounts.available} liberi
              </Badge>
            )}
            {statusCounts.occupied > 0 && (
              <Badge variant="outline" className="bg-gradient-to-r from-red-400 to-red-500 text-white border-none">
                {statusCounts.occupied} occupati
              </Badge>
            )}
            {statusCounts.reserved > 0 && (
              <Badge variant="outline" className="bg-gradient-to-r from-blue-400 to-blue-500 text-white border-none">
                {statusCounts.reserved} riservati
              </Badge>
            )}
            {statusCounts.waiting > 0 && (
              <Badge variant="outline" className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white border-none">
                {statusCounts.waiting} in attesa
              </Badge>
            )}
          </div>
        </CardDescription>
      </CardHeader>
      
      <CardContent className={`flex-grow overflow-hidden p-4 relative z-10 ${isExpanded ? 'opacity-100' : 'opacity-0 h-0 p-0'} transition-all duration-500`}>
        {tablesVisible ? (
          <ScrollArea className={`h-[calc(100vh-430px)] w-full pr-4 transition-all duration-500`}>
            {!Array.isArray(room.tables) || room.tables.length === 0 ? (
              <div className="text-center py-8 border border-dashed rounded-lg bg-gradient-to-br from-primary/5 to-primary/10">
                <p className="text-muted-foreground mb-2">Nessun tavolo</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={(e) => {
                    e.stopPropagation();
                    onRoomSelect(room);
                    onAddTable();
                  }}
                  className="bg-white/50 hover:bg-white/80 backdrop-blur-sm"
                >
                  <PlusCircleIcon className="h-4 w-4 mr-2" />
                  Aggiungi tavolo
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 py-2">
                {room.tables.map(table => {
                  console.log("Rendering table:", table);
                  return (
                    <TableComponent
                      key={table.id}
                      table={table}
                      onStatusChange={onTableStatusChange}
                      onEdit={onEditTable}
                      onDelete={onDeleteTable}
                    />
                  );
                })}
              </div>
            )}
          </ScrollArea>
        ) : (
          <div className="flex items-center justify-center h-full">
            <Button 
              variant="outline" 
              onClick={(e) => {
                e.stopPropagation();
                setTablesVisible(true);
              }}
              className="flex items-center gap-2 bg-white/50 hover:bg-white/80 backdrop-blur-sm"
            >
              <Eye className="h-4 w-4" />
              Mostra tavoli ({Array.isArray(room.tables) ? room.tables.length : 0})
            </Button>
          </div>
        )}
      </CardContent>
      
      {isExpanded && (
        <CardFooter className="pt-3 flex justify-end flex-shrink-0 relative z-10 border-t transition-all duration-500">
          <Button 
            variant="outline" 
            onClick={(e) => {
              e.stopPropagation();
              onRoomSelect(room);
              onAddTable();
            }}
            className="w-full bg-white/50 hover:bg-white/80 backdrop-blur-sm"
          >
            <PlusCircleIcon className="h-4 w-4 mr-2" />
            Aggiungi tavolo
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default ExpandableRoomView;
