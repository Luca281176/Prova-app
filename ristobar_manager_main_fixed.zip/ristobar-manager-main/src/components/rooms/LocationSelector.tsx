
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { MapPin, Settings2Icon } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LocationSelectorProps {
  locations: string[];
  selectedLocation: string;
  currentLocation?: string; // Kept for compatibility
  onLocationChange: (location: string) => void;
  onManageLocations?: () => void;
  canManageLocations?: boolean;
  className?: string;
}

const LocationSelector = ({ 
  locations, 
  selectedLocation,
  currentLocation, // Kept for compatibility
  onLocationChange,
  onManageLocations,
  canManageLocations = false,
  className = ""
}: LocationSelectorProps) => {
  // Use selectedLocation as the active location
  const activeLocation = selectedLocation;
  
  return (
    <Card className={`p-4 ${className}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-primary" />
          <span className="font-medium">Sede selezionata:</span>
          <Select value={activeLocation} onValueChange={onLocationChange}>
            <SelectTrigger className="w-[240px]">
              <SelectValue placeholder="Seleziona una sede" />
            </SelectTrigger>
            <SelectContent>
              {locations.map((location) => (
                <SelectItem key={location} value={location}>
                  {location}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {canManageLocations && onManageLocations && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onManageLocations}
            className="flex items-center"
          >
            <Settings2Icon className="h-4 w-4 mr-2" />
            Gestisci Sedi
          </Button>
        )}
      </div>
    </Card>
  );
};

export default LocationSelector;
