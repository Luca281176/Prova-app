
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  PlusCircleIcon, 
  PencilIcon, 
  TrashIcon, 
  CheckCircleIcon,
  HomeIcon
} from 'lucide-react';

interface LocationsManagerProps {
  locations: string[];
  currentLocation: string;
  onAddLocation: (name: string) => void;
  onEditLocation: (oldName: string, newName: string) => void;
  onDeleteLocation: (name: string) => void;
}

const LocationsManager = ({
  locations,
  currentLocation,
  onAddLocation,
  onEditLocation,
  onDeleteLocation
}: LocationsManagerProps) => {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [newLocationName, setNewLocationName] = useState('');
  const [editingLocation, setEditingLocation] = useState<string | null>(null);
  const [deletingLocation, setDeletingLocation] = useState<string | null>(null);
  const [editedLocationName, setEditedLocationName] = useState('');
  
  const handleAddClick = () => {
    setNewLocationName('');
    setShowAddDialog(true);
  };
  
  const handleEditClick = (location: string) => {
    setEditingLocation(location);
    setEditedLocationName(location);
    setShowEditDialog(true);
  };
  
  const handleDeleteClick = (location: string) => {
    setDeletingLocation(location);
    setShowDeleteDialog(true);
  };
  
  const handleAddSubmit = () => {
    if (newLocationName.trim()) {
      onAddLocation(newLocationName.trim());
      setShowAddDialog(false);
    }
  };
  
  const handleEditSubmit = () => {
    if (editingLocation && editedLocationName.trim() && editedLocationName !== editingLocation) {
      onEditLocation(editingLocation, editedLocationName.trim());
      setShowEditDialog(false);
    }
  };
  
  const handleDeleteSubmit = () => {
    if (deletingLocation) {
      onDeleteLocation(deletingLocation);
      setShowDeleteDialog(false);
    }
  };
  
  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Gestione Sedi</CardTitle>
              <CardDescription>Aggiungi, modifica o rimuovi le sedi del tuo ristorante</CardDescription>
            </div>
            <Button onClick={handleAddClick} className="flex items-center">
              <PlusCircleIcon className="h-4 w-4 mr-2" />
              Aggiungi Sede
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome Sede</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead className="text-right">Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {locations.map((location) => (
                <TableRow key={location}>
                  <TableCell className="font-medium flex items-center">
                    {location === currentLocation && (
                      <HomeIcon className="h-4 w-4 mr-2 text-primary" />
                    )}
                    {location}
                  </TableCell>
                  <TableCell>
                    {location === currentLocation ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        <CheckCircleIcon className="h-3 w-3 mr-1" />
                        Attiva
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-slate-50 text-slate-700">Inattiva</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleEditClick(location)}
                      >
                        <PencilIcon className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleDeleteClick(location)}
                        disabled={locations.length <= 1 || location === currentLocation}
                      >
                        <TrashIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        
        <CardFooter>
          <p className="text-sm text-muted-foreground">
            {locations.length === 1 ? (
              "Hai configurato 1 sede."
            ) : (
              `Hai configurato ${locations.length} sedi.`
            )}
          </p>
        </CardFooter>
      </Card>
      
      {/* Dialog per aggiungere una sede */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aggiungi una nuova sede</DialogTitle>
            <DialogDescription>
              Inserisci il nome della nuova sede del tuo ristorante.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Input
              placeholder="Nome della sede"
              value={newLocationName}
              onChange={(e) => setNewLocationName(e.target.value)}
              className="w-full"
            />
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Annulla</Button>
            </DialogClose>
            <Button onClick={handleAddSubmit} disabled={!newLocationName.trim()}>
              Aggiungi Sede
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog per modificare una sede */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifica sede</DialogTitle>
            <DialogDescription>
              Modifica il nome della sede "{editingLocation}".
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Input
              placeholder="Nuovo nome della sede"
              value={editedLocationName}
              onChange={(e) => setEditedLocationName(e.target.value)}
              className="w-full"
            />
          </div>
          
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Annulla</Button>
            </DialogClose>
            <Button 
              onClick={handleEditSubmit} 
              disabled={!editedLocationName.trim() || editedLocationName === editingLocation}
            >
              Salva Modifiche
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Alert Dialog per confermare l'eliminazione */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sei sicuro di voler eliminare questa sede?</AlertDialogTitle>
            <AlertDialogDescription>
              Stai per eliminare la sede "{deletingLocation}". 
              Questa azione non può essere annullata e tutti i dati associati a questa sede andranno persi.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteSubmit} className="bg-red-600 hover:bg-red-700">
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default LocationsManager;
