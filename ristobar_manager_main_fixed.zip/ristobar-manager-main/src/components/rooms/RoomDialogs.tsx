
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Room, Table } from '@/components/RoomGrid';
import RoomDialog from '@/components/RoomDialog';
import TableDialog from '@/components/TableDialog';
import ConfirmDialog from '@/components/ConfirmDialog';

interface RoomDialogsProps {
  // Room state
  selectedRoom: Room | null;
  setSelectedRoom: (room: Room | null) => void;
  
  // Table state
  selectedTable: Table | null;
  setSelectedTable: (table: Table | null) => void;
  
  // Modal state
  showNewRoomModal: boolean;
  setShowNewRoomModal: (show: boolean) => void;
  showEditRoomModal: boolean;
  setShowEditRoomModal: (show: boolean) => void;
  showNewTableModal: boolean;
  setShowNewTableModal: (show: boolean) => void;
  showEditTableModal: boolean;
  setShowEditTableModal: (show: boolean) => void;
  showDeleteRoomConfirm: boolean;
  setShowDeleteRoomConfirm: (show: boolean) => void;
  showDeleteTableConfirm: boolean;
  setShowDeleteTableConfirm: (show: boolean) => void;
  
  // Event handlers
  onAddRoom: (data: { name: string; capacity: number }) => Promise<void>;
  onEditRoom: (data: { name: string; capacity: number }) => Promise<void>;
  onDeleteRoom: () => Promise<void>;
  onAddTable: (data: any) => Promise<void>;
  onEditTable: (data: any) => Promise<void>;
  onDeleteTable: () => Promise<void>;
  
  // Location
  locationId?: string;
}

const RoomDialogs: React.FC<RoomDialogsProps> = ({
  // Room state
  selectedRoom,
  setSelectedRoom,
  
  // Table state
  selectedTable,
  setSelectedTable,
  
  // Modal state
  showNewRoomModal,
  setShowNewRoomModal,
  showEditRoomModal,
  setShowEditRoomModal,
  showNewTableModal,
  setShowNewTableModal,
  showEditTableModal,
  setShowEditTableModal,
  showDeleteRoomConfirm,
  setShowDeleteRoomConfirm,
  showDeleteTableConfirm,
  setShowDeleteTableConfirm,
  
  // Event handlers
  onAddRoom,
  onEditRoom,
  onDeleteRoom,
  onAddTable,
  onEditTable,
  onDeleteTable,
  
  // Location
  locationId
}) => {
  console.log("RoomDialogs rendering with showNewRoomModal =", showNewRoomModal);
  console.log("RoomDialogs rendering with showNewTableModal =", showNewTableModal);
  console.log("RoomDialogs selectedRoom =", selectedRoom);
  
  // Handle dialog closures
  const handleCloseRoomDialog = () => {
    console.log("Closing room dialog");
    setShowNewRoomModal(false);
    setShowEditRoomModal(false);
  };
  
  const handleCloseTableDialog = () => {
    console.log("Closing table dialog");
    setShowNewTableModal(false);
    setShowEditTableModal(false);
  };
  
  const handleCloseDeleteRoomConfirm = () => {
    setShowDeleteRoomConfirm(false);
  };
  
  const handleCloseDeleteTableConfirm = () => {
    setShowDeleteTableConfirm(false);
  };
  
  return (
    <>
      {/* Add/Edit Room Dialog */}
      <RoomDialog
        open={showNewRoomModal || showEditRoomModal}
        onOpenChange={handleCloseRoomDialog}
        onSave={showEditRoomModal ? onEditRoom : onAddRoom}
        initialData={showEditRoomModal ? selectedRoom : null}
        title={showEditRoomModal ? `Modifica sala${locationId ? ` (${locationId})` : ''}` : `Aggiungi sala${locationId ? ` (${locationId})` : ''}`}
      />
      
      {/* Add/Edit Table Dialog */}
      <TableDialog
        open={showNewTableModal || showEditTableModal}
        onOpenChange={handleCloseTableDialog}
        onSave={showEditTableModal ? onEditTable : onAddTable}
        initialData={showEditTableModal ? selectedTable : null}
        title={showEditTableModal ? `Modifica tavolo${locationId ? ` (${locationId})` : ''}` : `Aggiungi tavolo${locationId ? ` (${locationId})` : ''}`}
        roomId={selectedRoom?.id || ''}
      />
      
      {/* Delete Room Confirmation */}
      <ConfirmDialog
        open={showDeleteRoomConfirm}
        onOpenChange={handleCloseDeleteRoomConfirm}
        title="Elimina sala"
        description={`Sei sicuro di voler eliminare la sala "${selectedRoom?.name}"? Questa azione non può essere annullata e verranno eliminati anche tutti i tavoli associati.`}
        onConfirm={onDeleteRoom}
      />
      
      {/* Delete Table Confirmation */}
      <ConfirmDialog
        open={showDeleteTableConfirm}
        onOpenChange={handleCloseDeleteTableConfirm}
        title="Elimina tavolo"
        description={`Sei sicuro di voler eliminare il tavolo "${selectedTable?.name}"? Questa azione non può essere annullata.`}
        onConfirm={onDeleteTable}
      />
    </>
  );
};

export default RoomDialogs;
