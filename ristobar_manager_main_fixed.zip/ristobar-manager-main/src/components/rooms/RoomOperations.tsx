
import { useState } from 'react';
import { Room, Table } from '@/components/RoomGrid';
import { toast } from '@/hooks/use-toast';
import * as roomsService from '@/services/roomsService';

export interface RoomOperationsProps {
  onRoomUpdated: () => void;
  locationId?: string;
}

export const useRoomOperations = ({ onRoomUpdated, locationId }: RoomOperationsProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleAddRoom = async (roomData: { name: string; capacity: number }) => {
    setIsProcessing(true);
    
    try {
      await roomsService.addRoom(roomData, locationId);
      
      toast({
        title: "Sala aggiunta",
        description: `La sala "${roomData.name}" è stata aggiunta con successo`
      });
      
      onRoomUpdated();
    } catch (error) {
      console.error('Error adding room:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta della sala. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleEditRoom = async (selectedRoom: Room, roomData: { name: string; capacity: number }) => {
    setIsProcessing(true);
    
    try {
      await roomsService.updateRoom(selectedRoom.id, roomData, locationId);
      
      toast({
        title: "Sala aggiornata",
        description: `La sala "${roomData.name}" è stata aggiornata con successo`
      });
      
      onRoomUpdated();
    } catch (error) {
      console.error('Error updating room:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento della sala. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleDeleteRoom = async (selectedRoom: Room) => {
    setIsProcessing(true);
    
    try {
      await roomsService.deleteRoom(selectedRoom.id, locationId);
      
      toast({
        title: "Sala eliminata",
        description: `La sala "${selectedRoom.name}" è stata eliminata con successo`
      });
      
      onRoomUpdated();
    } catch (error) {
      console.error('Error deleting room:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'eliminazione della sala. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return {
    isProcessing,
    handleAddRoom,
    handleEditRoom,
    handleDeleteRoom
  };
};

export default useRoomOperations;
