
import React from 'react';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { PlusCircle, RefreshCw } from 'lucide-react';
import ActiveOrdersNotification from './ActiveOrdersNotification';

interface RoomsHeaderProps {
  onAddRoomClick: () => void;
  isProcessing: boolean;
  locationName?: string;
  isPro?: boolean;
  onRefreshClick?: () => void;
}

const RoomsHeader: React.FC<RoomsHeaderProps> = ({
  onAddRoomClick,
  isProcessing,
  locationName,
  isPro,
  onRefreshClick
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <div>
        <h1 className="text-2xl font-bold">
          Gestione Sale e Tavoli
          {locationName && isPro && (
            <span className="text-base font-normal ml-2 text-muted-foreground">
              | {locationName}
            </span>
          )}
        </h1>
        <p className="text-muted-foreground">
          Gestisci sale, tavoli e prenotazioni in pochi semplici passaggi.
        </p>
      </div>
      <div className="flex space-x-2 items-center">
        <ActiveOrdersNotification locationId={isPro ? locationName : undefined} />
        
        {onRefreshClick && (
          <Button
            variant="outline"
            size="icon"
            onClick={onRefreshClick}
            disabled={isProcessing}
            title="Aggiorna"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        )}
        
        <Button
          onClick={onAddRoomClick}
          disabled={isProcessing}
          className="relative"
        >
          {isProcessing ? (
            <Spinner size="sm" className="mr-2" />
          ) : (
            <PlusCircle className="h-4 w-4 mr-2" />
          )}
          Aggiungi sala
        </Button>
      </div>
    </div>
  );
};

export default RoomsHeader;
