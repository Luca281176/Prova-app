
import { useState } from 'react';
import { Room, Table } from '@/components/RoomGrid';
import { toast } from '@/hooks/use-toast';
import * as roomsService from '@/services/roomsService';

export interface TableOperationsProps {
  onTableUpdated: () => void;
  locationId?: string;
}

export const useTableOperations = ({ onTableUpdated, locationId }: TableOperationsProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleAddTable = async (selectedRoom: Room, tableData: Partial<Table>) => {
    if (!selectedRoom || !selectedRoom.id) {
      toast({
        title: "Errore",
        description: "Seleziona prima una sala per aggiungere un tavolo",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    console.log("Adding table to room:", selectedRoom.id, "with data:", tableData);
    
    try {
      // Create the table with complete data
      const completeTableData: Partial<Table> = {
        ...tableData,
        status: tableData.status || 'available',
        shape: tableData.shape || 'round',
        seats: tableData.seats || 4,
        name: tableData.name || 'Nuovo Tavolo'
      };
      
      console.log("Complete table data:", completeTableData);
      
      // Add the table to the room
      const newTable = await roomsService.addTable(selectedRoom.id, completeTableData, locationId);
      console.log("Table added successfully:", newTable);
      
      // Force a refresh of the room data
      onTableUpdated();
      
      toast({
        title: "Tavolo aggiunto",
        description: `Il tavolo "${completeTableData.name}" è stato aggiunto con successo`
      });
      
    } catch (error) {
      console.error('Error adding table:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta del tavolo. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleEditTable = async (selectedTable: Table, tableData: Partial<Table>) => {
    setIsProcessing(true);
    
    try {
      const room = await roomsService.findRoomByTableId(selectedTable.id, locationId);
      
      if (!room) {
        throw new Error("Room not found for this table");
      }
      
      await roomsService.updateTable(room.id, selectedTable.id, tableData, locationId);
      
      toast({
        title: "Tavolo aggiornato",
        description: `Il tavolo "${tableData.name}" è stato aggiornato con successo`
      });
      
      onTableUpdated();
    } catch (error) {
      console.error('Error updating table:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento del tavolo. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleDeleteTable = async (selectedTable: Table) => {
    setIsProcessing(true);
    
    try {
      const room = await roomsService.findRoomByTableId(selectedTable.id, locationId);
      
      if (!room) {
        throw new Error("Room not found for this table");
      }
      
      await roomsService.deleteTable(room.id, selectedTable.id, locationId);
      
      toast({
        title: "Tavolo eliminato",
        description: `Il tavolo "${selectedTable.name}" è stato eliminato con successo`
      });
      
      onTableUpdated();
    } catch (error) {
      console.error('Error deleting table:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'eliminazione del tavolo. Riprova più tardi.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return {
    isProcessing,
    handleAddTable,
    handleEditTable,
    handleDeleteTable
  };
};

export default useTableOperations;
