
import { useState } from 'react';
import { Room, Table } from '@/components/RoomGrid';

export const useRoomDialogs = () => {
  const [showNewRoomModal, setShowNewRoomModal] = useState(false);
  const [showNewTableModal, setShowNewTableModal] = useState(false);
  const [showEditRoomModal, setShowEditRoomModal] = useState(false);
  const [showEditTableModal, setShowEditTableModal] = useState(false);
  const [showDeleteRoomConfirm, setShowDeleteRoomConfirm] = useState(false);
  const [showDeleteTableConfirm, setShowDeleteTableConfirm] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);

  const openEditRoomDialog = (room: Room) => {
    console.log("Opening edit room dialog for:", room);
    setSelectedRoom(room);
    setShowEditRoomModal(true);
    // Make sure other modals are closed
    setShowNewRoomModal(false);
    setShowNewTableModal(false);
    setShowEditTableModal(false);
    setShowDeleteRoomConfirm(false);
    setShowDeleteTableConfirm(false);
  };
  
  const openDeleteRoomConfirm = (room: Room) => {
    console.log("Opening delete room confirmation for:", room);
    setSelectedRoom(room);
    setShowDeleteRoomConfirm(true);
    // Make sure other modals are closed
    setShowNewRoomModal(false);
    setShowEditRoomModal(false);
    setShowNewTableModal(false);
    setShowEditTableModal(false);
  };

  const openEditTableDialog = (table: Table) => {
    console.log("Opening edit table dialog for:", table);
    setSelectedTable(table);
    setShowEditTableModal(true);
    // Make sure other modals are closed
    setShowNewTableModal(false);
    setShowNewRoomModal(false);
    setShowEditRoomModal(false);
    setShowDeleteRoomConfirm(false);
    setShowDeleteTableConfirm(false);
  };
  
  const openDeleteTableConfirm = (table: Table) => {
    console.log("Opening delete table confirmation for:", table);
    setSelectedTable(table);
    setShowDeleteTableConfirm(true);
    // Make sure other modals are closed
    setShowNewTableModal(false);
    setShowEditTableModal(false);
    setShowNewRoomModal(false);
    setShowEditRoomModal(false);
    setShowDeleteRoomConfirm(false);
  };
  
  // New method specifically for opening the new table modal with a selected room
  const openNewTableDialog = (room: Room) => {
    console.log("Opening new table dialog for room:", room);
    // CRITICAL: Make sure we set the selected room before opening the dialog
    setSelectedRoom(room);
    setShowNewTableModal(true);
    // Make sure other modals are closed
    setShowNewRoomModal(false);
    setShowEditRoomModal(false);
    setShowEditTableModal(false);
    setShowDeleteRoomConfirm(false);
    setShowDeleteTableConfirm(false);
  };

  return {
    showNewRoomModal,
    setShowNewRoomModal,
    showNewTableModal,
    setShowNewTableModal,
    showEditRoomModal,
    setShowEditRoomModal,
    showEditTableModal,
    setShowEditTableModal,
    showDeleteRoomConfirm,
    setShowDeleteRoomConfirm,
    showDeleteTableConfirm,
    setShowDeleteTableConfirm,
    selectedRoom,
    setSelectedRoom,
    selectedTable,
    setSelectedTable,
    openEditRoomDialog,
    openDeleteRoomConfirm,
    openEditTableDialog,
    openDeleteTableConfirm,
    openNewTableDialog
  };
};

export default useRoomDialogs;
