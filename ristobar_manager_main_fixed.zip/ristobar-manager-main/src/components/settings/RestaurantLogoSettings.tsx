import React, { useState, useEffect } from 'react';
import { getRestaurantInfoSync, deleteRestaurantLogo } from '@/components/cashier/bill/RestaurantInfoProvider';
import { useUser } from '@/contexts/user/UserProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Upload, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { saveUserDataToStorage } from '@/contexts/user/storageUtils';

const RestaurantLogoSettings = () => {
  const { user } = useUser();
  const restaurantInfo = getRestaurantInfoSync();
  const [logo, setLogo] = useState<string | null>(restaurantInfo.logo);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    setLogo(restaurantInfo.logo);
  }, [restaurantInfo.logo]);

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || !event.target.files[0]) return;
    if (!user?.id) {
      toast.error("Devi essere autenticato per caricare un logo");
      return;
    }

    const file = event.target.files[0];
    
    // Check file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Il file è troppo grande. La dimensione massima è 2MB.");
      return;
    }
    
    // Check file type
    if (!file.type.match('image.*')) {
      toast.error("Il file deve essere un'immagine (JPEG, PNG, GIF).");
      return;
    }

    setIsUploading(true);
    
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const base64Logo = e.target?.result as string;
        
        // Save to user-specific storage
        await saveUserDataToStorage(user.id, 'restaurantLogo', base64Logo);
        
        setLogo(base64Logo);
        toast.success("Logo caricato con successo");
        
        // Dispatch an event to notify other components
        window.dispatchEvent(new CustomEvent('restaurant-info-updated'));
      } catch (error) {
        console.error("Error uploading logo:", error);
        toast.error("Errore durante il caricamento del logo");
      } finally {
        setIsUploading(false);
      }
    };
    
    reader.onerror = () => {
      toast.error("Errore durante la lettura del file");
      setIsUploading(false);
    };
    
    reader.readAsDataURL(file);
  };

  const handleLogoDelete = async () => {
    if (!user?.id) {
      toast.error("Devi essere autenticato per eliminare il logo");
      return;
    }
    
    try {
      const success = deleteRestaurantLogo(user.id);
      if (success) {
        setLogo(null);
        toast.success("Logo eliminato con successo");
      } else {
        toast.error("Errore durante l'eliminazione del logo");
      }
    } catch (error) {
      console.error("Error deleting logo:", error);
      toast.error("Errore durante l'eliminazione del logo");
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Logo del Ristorante</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col items-center space-y-4">
          {logo ? (
            <div className="relative w-48 h-48 border rounded-md overflow-hidden">
              <img 
                src={logo} 
                alt="Logo del ristorante" 
                className="w-full h-full object-contain"
              />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={handleLogoDelete}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="w-48 h-48 border rounded-md flex items-center justify-center bg-muted">
              <p className="text-sm text-muted-foreground">Nessun logo caricato</p>
            </div>
          )}
          
          <div className="w-full">
            <Label htmlFor="logo-upload" className="block mb-2">
              {logo ? "Cambia logo" : "Carica logo"}
            </Label>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                className="w-full"
                disabled={isUploading}
                onClick={() => document.getElementById('logo-upload')?.click()}
              >
                {isUploading ? (
                  <div className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Caricamento...
                  </div>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Seleziona file
                  </>
                )}
              </Button>
              <input
                id="logo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleLogoUpload}
                disabled={isUploading}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Formati supportati: JPEG, PNG, GIF. Dimensione massima: 2MB.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RestaurantLogoSettings;
