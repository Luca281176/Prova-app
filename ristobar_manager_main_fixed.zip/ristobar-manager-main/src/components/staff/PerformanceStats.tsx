
import { useState, useEffect } from "react";
import { useStaff } from "@/contexts/StaffContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";
import { format, subDays, subMonths } from "date-fns";
import { it } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { UserCog, Users, ShoppingCart, Clock, DollarSign, Star, CalendarDays } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { PerformanceTable } from "@/components/staff/PerformanceTable";

export const PerformanceStats = () => {
  const { staff, performance } = useStaff();
  const [timeRange, setTimeRange] = useState<"week" | "month" | "year">("month");
  const [selectedMetric, setSelectedMetric] = useState<"tablesServed" | "ordersProcessed" | "sales" | "rating">("sales");
  const [selectedStaffId, setSelectedStaffId] = useState<string>("all");
  
  // Get time filtered performance data
  const getTimeFilteredData = () => {
    const today = new Date();
    let startDate: Date;
    
    switch (timeRange) {
      case "week":
        startDate = subDays(today, 7);
        break;
      case "month":
        startDate = subMonths(today, 1);
        break;
      case "year":
        startDate = subMonths(today, 12);
        break;
      default:
        startDate = subMonths(today, 1);
    }
    
    return performance.filter(record => {
      const recordDate = new Date(record.date);
      return recordDate >= startDate && recordDate <= today;
    });
  };
  
  // Filter by staff member if selected
  const getStaffFilteredData = (data: typeof performance) => {
    if (selectedStaffId === "all") return data;
    return data.filter(record => record.staffId === selectedStaffId);
  };
  
  const filteredData = getStaffFilteredData(getTimeFilteredData());
  
  // Calculate averages for the overview metrics
  const calculateAverages = () => {
    if (filteredData.length === 0) {
      return {
        avgTablesServed: 0,
        avgOrdersProcessed: 0,
        avgOrderTime: 0,
        totalSales: 0,
        avgRating: 0,
      };
    }
    
    const totals = filteredData.reduce((acc, curr) => {
      return {
        tablesServed: acc.tablesServed + curr.tablesServed,
        ordersProcessed: acc.ordersProcessed + curr.ordersProcessed,
        orderTime: acc.orderTime + curr.averageOrderTime,
        sales: acc.sales + curr.sales,
        rating: acc.rating + curr.rating,
      };
    }, { tablesServed: 0, ordersProcessed: 0, orderTime: 0, sales: 0, rating: 0 });
    
    return {
      avgTablesServed: Math.round(totals.tablesServed / filteredData.length),
      avgOrdersProcessed: Math.round(totals.ordersProcessed / filteredData.length),
      avgOrderTime: (totals.orderTime / filteredData.length).toFixed(1),
      totalSales: totals.sales,
      avgRating: (totals.rating / filteredData.length).toFixed(1),
    };
  };
  
  const averages = calculateAverages();
  
  // Prepare chart data grouped by staff member
  const prepareChartData = () => {
    const staffMap = new Map();
    
    filteredData.forEach(record => {
      const staffMember = staff.find(s => s.id === record.staffId);
      if (!staffMember) return;
      
      const staffName = `${staffMember.firstName} ${staffMember.lastName}`;
      
      if (staffMap.has(staffName)) {
        const existing = staffMap.get(staffName);
        staffMap.set(staffName, {
          ...existing,
          [selectedMetric]: existing[selectedMetric] + record[selectedMetric],
          count: existing.count + 1,
        });
      } else {
        staffMap.set(staffName, {
          name: staffName,
          [selectedMetric]: record[selectedMetric],
          count: 1,
        });
      }
    });
    
    // Calculate averages if needed (for rating)
    return Array.from(staffMap.values()).map(item => {
      if (selectedMetric === "rating") {
        return {
          ...item,
          [selectedMetric]: parseFloat((item[selectedMetric] / item.count).toFixed(1)),
        };
      }
      return item;
    });
  };
  
  const chartData = prepareChartData();
  
  // Prepare trend data (by date)
  const prepareTrendData = () => {
    const dateMap = new Map();
    
    filteredData.forEach(record => {
      const dateStr = record.date;
      
      if (dateMap.has(dateStr)) {
        const existing = dateMap.get(dateStr);
        dateMap.set(dateStr, {
          ...existing,
          [selectedMetric]: existing[selectedMetric] + record[selectedMetric],
          count: existing.count + 1,
        });
      } else {
        dateMap.set(dateStr, {
          date: dateStr,
          [selectedMetric]: record[selectedMetric],
          count: 1,
        });
      }
    });
    
    // Sort by date and calculate averages if needed
    return Array.from(dateMap.values())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(item => {
        const formattedDate = format(new Date(item.date), "dd/MM", { locale: it });
        
        if (selectedMetric === "rating") {
          return {
            ...item,
            date: formattedDate,
            [selectedMetric]: parseFloat((item[selectedMetric] / item.count).toFixed(1)),
          };
        }
        
        return {
          ...item,
          date: formattedDate,
        };
      });
  };
  
  const trendData = prepareTrendData();
  
  // Get metric display info
  const getMetricInfo = (metric: string) => {
    switch (metric) {
      case "tablesServed":
        return { label: "Tavoli serviti", color: "#4f46e5", formatter: (value: number) => `${value} tavoli` };
      case "ordersProcessed":
        return { label: "Ordini processati", color: "#06b6d4", formatter: (value: number) => `${value} ordini` };
      case "sales":
        return { label: "Vendite (€)", color: "#10b981", formatter: (value: number) => `€${value}` };
      case "rating":
        return { label: "Valutazione", color: "#f59e0b", formatter: (value: number) => `${value}/5` };
      default:
        return { label: "Valore", color: "#6b7280", formatter: (value: number) => `${value}` };
    }
  };
  
  const metricInfo = getMetricInfo(selectedMetric);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 md:flex gap-2">
          <Select value={selectedStaffId} onValueChange={setSelectedStaffId}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Dipendente" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tutti i dipendenti</SelectItem>
              {staff.map(member => (
                <SelectItem key={member.id} value={member.id}>
                  {member.firstName} {member.lastName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedMetric} onValueChange={setSelectedMetric as any}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Metrica" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tablesServed">Tavoli serviti</SelectItem>
              <SelectItem value="ordersProcessed">Ordini processati</SelectItem>
              <SelectItem value="sales">Vendite (€)</SelectItem>
              <SelectItem value="rating">Valutazione</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex">
            <Button
              variant={timeRange === "week" ? "default" : "outline"}
              className="rounded-r-none"
              onClick={() => setTimeRange("week")}
            >
              Settimana
            </Button>
            <Button
              variant={timeRange === "month" ? "default" : "outline"}
              className="rounded-none border-x-0"
              onClick={() => setTimeRange("month")}
            >
              Mese
            </Button>
            <Button
              variant={timeRange === "year" ? "default" : "outline"}
              className="rounded-l-none"
              onClick={() => setTimeRange("year")}
            >
              Anno
            </Button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Tavoli serviti
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averages.avgTablesServed}</div>
            <p className="text-xs text-muted-foreground">
              Media {timeRange === "week" ? "settimanale" : timeRange === "month" ? "mensile" : "annuale"}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Ordini processati
            </CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averages.avgOrdersProcessed}</div>
            <p className="text-xs text-muted-foreground">
              Media {timeRange === "week" ? "settimanale" : timeRange === "month" ? "mensile" : "annuale"}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Tempo medio ordine
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averages.avgOrderTime} min</div>
            <p className="text-xs text-muted-foreground">
              Media {timeRange === "week" ? "settimanale" : timeRange === "month" ? "mensile" : "annuale"}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Vendite totali
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">€{averages.totalSales.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Totale {timeRange === "week" ? "settimanale" : timeRange === "month" ? "mensile" : "annuale"}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Valutazione media
            </CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averages.avgRating}/5</div>
            <p className="text-xs text-muted-foreground">
              Media {timeRange === "week" ? "settimanale" : timeRange === "month" ? "mensile" : "annuale"}
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Performance del personale</CardTitle>
            <CardDescription>
              Confronto delle metriche tra i membri dello staff
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                <YAxis />
                <Tooltip 
                  formatter={(value: number) => metricInfo.formatter(value)}
                  labelFormatter={(label) => `Dipendente: ${label}`}
                />
                <Legend />
                <Bar dataKey={selectedMetric} name={metricInfo.label} fill={metricInfo.color} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Trend temporale</CardTitle>
            <CardDescription>
              Andamento nel periodo selezionato
            </CardDescription>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  formatter={(value: number) => metricInfo.formatter(value)}
                  labelFormatter={(label) => `Data: ${label}`}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey={selectedMetric} 
                  name={metricInfo.label} 
                  stroke={metricInfo.color} 
                  activeDot={{ r: 8 }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex justify-between items-center">
            <span>Dettaglio performance</span>
            <Badge variant="outline" className="ml-2">
              <CalendarDays className="mr-1 h-3 w-3" />
              {timeRange === "week" ? "Ultima settimana" : timeRange === "month" ? "Ultimo mese" : "Ultimo anno"}
            </Badge>
          </CardTitle>
          <CardDescription>
            Registro dettagliato delle performance del personale
          </CardDescription>
        </CardHeader>
        <CardContent>
          <PerformanceTable 
            data={filteredData} 
            staff={staff}
          />
        </CardContent>
      </Card>
    </div>
  );
};
