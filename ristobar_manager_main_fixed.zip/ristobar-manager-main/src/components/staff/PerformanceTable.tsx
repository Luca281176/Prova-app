
import { useState } from "react";
import { PerformanceRecord, StaffMember } from "@/contexts/StaffContext";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { ChevronDown, ChevronUp, Search, Star } from "lucide-react";

interface PerformanceTableProps {
  data: PerformanceRecord[];
  staff: StaffMember[];
}

export const PerformanceTable = ({ data, staff }: PerformanceTableProps) => {
  const [sortField, setSortField] = useState<keyof PerformanceRecord>("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;
  
  // Sort and filter data
  const sortedData = [...data].sort((a, b) => {
    if (sortField === "date") {
      return sortDirection === "asc"
        ? new Date(a.date).getTime() - new Date(b.date).getTime()
        : new Date(b.date).getTime() - new Date(a.date).getTime();
    }
    
    if (typeof a[sortField] === "number" && typeof b[sortField] === "number") {
      return sortDirection === "asc"
        ? (a[sortField] as number) - (b[sortField] as number)
        : (b[sortField] as number) - (a[sortField] as number);
    }
    
    return 0;
  });
  
  const filteredData = sortedData.filter(record => {
    const staffMember = staff.find(s => s.id === record.staffId);
    if (!staffMember) return false;
    
    const searchString = `${staffMember.firstName} ${staffMember.lastName}`.toLowerCase();
    return searchString.includes(searchQuery.toLowerCase());
  });
  
  // Pagination
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = filteredData.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );
  
  // Handle sort
  const handleSort = (field: keyof PerformanceRecord) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };
  
  // Render sort indicator
  const renderSortIndicator = (field: keyof PerformanceRecord) => {
    if (sortField !== field) return null;
    
    return sortDirection === "asc"
      ? <ChevronUp className="ml-1 h-4 w-4" />
      : <ChevronDown className="ml-1 h-4 w-4" />;
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd MMMM yyyy", { locale: it });
    } catch (error) {
      return dateString;
    }
  };
  
  // Render star rating
  const renderRating = (rating: number) => {
    return (
      <div className="flex items-center">
        {rating.toFixed(1)}
        <Star className="ml-1 h-4 w-4 text-yellow-400 fill-yellow-400" />
      </div>
    );
  };
  
  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca personale..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead
                className="w-[180px] cursor-pointer"
                onClick={() => handleSort("date")}
              >
                <div className="flex items-center">
                  Data
                  {renderSortIndicator("date")}
                </div>
              </TableHead>
              <TableHead className="w-[200px]">Dipendente</TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("tablesServed")}
              >
                <div className="flex items-center">
                  Tavoli
                  {renderSortIndicator("tablesServed")}
                </div>
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("ordersProcessed")}
              >
                <div className="flex items-center">
                  Ordini
                  {renderSortIndicator("ordersProcessed")}
                </div>
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("averageOrderTime")}
              >
                <div className="flex items-center">
                  Tempo medio
                  {renderSortIndicator("averageOrderTime")}
                </div>
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("sales")}
              >
                <div className="flex items-center">
                  Vendite
                  {renderSortIndicator("sales")}
                </div>
              </TableHead>
              <TableHead
                className="cursor-pointer"
                onClick={() => handleSort("rating")}
              >
                <div className="flex items-center">
                  Valutazione
                  {renderSortIndicator("rating")}
                </div>
              </TableHead>
              <TableHead>Note</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedData.length > 0 ? (
              paginatedData.map((record) => {
                const staffMember = staff.find(s => s.id === record.staffId);
                return (
                  <TableRow key={record.id}>
                    <TableCell>{formatDate(record.date)}</TableCell>
                    <TableCell>
                      {staffMember ? `${staffMember.firstName} ${staffMember.lastName}` : 'N/A'}
                    </TableCell>
                    <TableCell>{record.tablesServed}</TableCell>
                    <TableCell>{record.ordersProcessed}</TableCell>
                    <TableCell>{record.averageOrderTime} min</TableCell>
                    <TableCell>€{record.sales}</TableCell>
                    <TableCell>{renderRating(record.rating)}</TableCell>
                    <TableCell className="max-w-[200px] truncate" title={record.notes}>
                      {record.notes || '-'}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="h-24 text-center">
                  Nessun dato trovato.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-end space-x-2 py-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page > 1 ? page - 1 : 1)}
            disabled={page === 1}
          >
            Precedente
          </Button>
          <div className="text-sm">
            Pagina {page} di {totalPages}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page < totalPages ? page + 1 : totalPages)}
            disabled={page === totalPages}
          >
            Successiva
          </Button>
        </div>
      )}
    </div>
  );
};
