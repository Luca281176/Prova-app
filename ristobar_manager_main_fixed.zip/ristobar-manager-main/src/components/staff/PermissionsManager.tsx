
import { useState, useEffect } from "react";
import { useStaff } from "@/contexts/StaffContext";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Search, Filter, Save } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/hooks/use-toast";

// Define the type for custom permissions to ensure consistency
type CustomPermissions = {
  orders: boolean;
  tables: boolean;
  kitchen: boolean;
  cash: boolean;
  staff: boolean;
  inventory: boolean;
  reports: boolean;
};

export const PermissionsManager = () => {
  const { staff, updateStaffMember } = useStaff();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [editedPermissions, setEditedPermissions] = useState<Record<string, CustomPermissions>>({});
  const [hasChanges, setHasChanges] = useState(false);

  // Initialize permissions when component mounts
  useEffect(() => {
    const initialPermissions: Record<string, CustomPermissions> = {};
    staff.forEach(member => {
      if (member.permissionLevel === 'custom' && member.customPermissions) {
        initialPermissions[member.id] = {
          orders: member.customPermissions.orders || false,
          tables: member.customPermissions.tables || false,
          kitchen: member.customPermissions.kitchen || false,
          cash: member.customPermissions.cash || false,
          staff: member.customPermissions.staff || false,
          inventory: member.customPermissions.inventory || false,
          reports: member.customPermissions.reports || false
        };
      } else {
        initialPermissions[member.id] = {
          orders: false,
          tables: false,
          kitchen: false,
          cash: false,
          staff: false,
          inventory: false,
          reports: false
        };
      }
    });
    setEditedPermissions(initialPermissions);
  }, [staff]);

  const uniqueRoles = Array.from(new Set(staff.map(member => member.role)));
  
  const filteredStaff = staff.filter(member => {
    const fullName = `${member.firstName} ${member.lastName}`.toLowerCase();
    const role = member.role.toLowerCase();
    const query = searchQuery.toLowerCase();
    
    const matchesSearch = fullName.includes(query) || role.includes(query);
    const matchesRole = roleFilter === "all" || member.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });

  const handlePermissionChange = (staffId: string, permissionLevel: string) => {
    const defaultPermissions: CustomPermissions = {
      orders: false,
      tables: false,
      kitchen: false,
      cash: false,
      staff: false,
      inventory: false,
      reports: false
    };

    if (permissionLevel === 'custom') {
      setEditedPermissions(prev => ({
        ...prev,
        [staffId]: prev[staffId] || defaultPermissions
      }));
    }

    updateStaffMember(staffId, { 
      permissionLevel: permissionLevel as any,
      customPermissions: permissionLevel === 'custom' ? 
        editedPermissions[staffId] || defaultPermissions : undefined
    });
  };

  const handlePermissionToggle = (staffId: string, permission: keyof CustomPermissions, checked: boolean) => {
    setEditedPermissions(prev => ({
      ...prev,
      [staffId]: {
        ...(prev[staffId] || {
          orders: false,
          tables: false,
          kitchen: false,
          cash: false,
          staff: false,
          inventory: false,
          reports: false
        }),
        [permission]: checked
      }
    }));
    setHasChanges(true);
  };

  const saveCustomPermissions = () => {
    const promises = Object.entries(editedPermissions).map(([staffId, permissions]) => {
      const staffMember = staff.find(s => s.id === staffId);
      if (!staffMember) return Promise.resolve();
      
      if (staffMember.permissionLevel === 'custom') {
        return updateStaffMember(staffId, { customPermissions: permissions });
      }
      return Promise.resolve();
    });

    Promise.all(promises)
      .then(() => {
        toast({
          title: "Permessi salvati",
          description: "I permessi personalizzati sono stati aggiornati con successo."
        });
        setHasChanges(false);
      })
      .catch(error => {
        console.error("Errore durante il salvataggio dei permessi:", error);
        toast({
          title: "Errore",
          description: "Si è verificato un errore durante il salvataggio dei permessi.",
          variant: "destructive"
        });
      });
  };

  // Function to determine if checkbox should be checked based on permission level
  const isPermissionChecked = (member: any, permission: keyof CustomPermissions) => {
    if (member.permissionLevel === 'custom') {
      return editedPermissions[member.id]?.[permission] || false;
    }
    // Manager has all permissions
    return member.permissionLevel === 'manager';
  };

  // Function to determine if checkbox should be disabled
  const isPermissionDisabled = (member: any) => {
    return member.permissionLevel !== 'custom';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative md:w-1/2">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca dipendente per nome o ruolo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filtra per ruolo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti i ruoli</SelectItem>
                {uniqueRoles.map(role => (
                  <SelectItem key={role} value={role}>{role}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {hasChanges && (
            <Button onClick={saveCustomPermissions} size="sm">
              <Save className="h-4 w-4 mr-2" />
              Salva modifiche
            </Button>
          )}
        </div>
      </div>

      <ScrollArea className="h-[calc(100vh-350px)] rounded-md border">
        <Table>
          <TableHeader className="sticky top-0 bg-background">
            <TableRow>
              <TableHead className="w-[250px]">Dipendente</TableHead>
              <TableHead className="w-[150px]">Ruolo</TableHead>
              <TableHead className="w-[180px]">Livello permessi</TableHead>
              <TableHead>Ordini</TableHead>
              <TableHead>Tavoli</TableHead>
              <TableHead>Cucina</TableHead>
              <TableHead>Cassa</TableHead>
              <TableHead>Personale</TableHead>
              <TableHead>Magazzino</TableHead>
              <TableHead>Report</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStaff.map((member) => (
              <TableRow key={member.id}>
                <TableCell className="font-medium">
                  {member.firstName} {member.lastName}
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{member.role}</Badge>
                </TableCell>
                <TableCell>
                  <Select
                    value={member.permissionLevel}
                    onValueChange={(value) => handlePermissionChange(member.id, value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Permessi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="waiter">Cameriere</SelectItem>
                      <SelectItem value="chef">Chef</SelectItem>
                      <SelectItem value="cashier">Cassiere</SelectItem>
                      <SelectItem value="bartender">Barista</SelectItem>
                      <SelectItem value="custom">Personalizzato</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "orders")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "orders", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "tables")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "tables", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "kitchen")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "kitchen", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "cash")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "cash", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "staff")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "staff", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "inventory")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "inventory", checked === true)
                    }
                  />
                </TableCell>
                
                <TableCell>
                  <Checkbox
                    checked={isPermissionChecked(member, "reports")}
                    disabled={isPermissionDisabled(member)}
                    onCheckedChange={(checked) => 
                      handlePermissionToggle(member.id, "reports", checked === true)
                    }
                  />
                </TableCell>
              </TableRow>
            ))}
            
            {filteredStaff.length === 0 && (
              <TableRow>
                <TableCell colSpan={10} className="h-24 text-center">
                  Nessun dipendente trovato.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>
    </div>
  );
};
