
import { useState } from "react";
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isToday } from "date-fns";
import { it } from "date-fns/locale";
import { useStaff } from "@/contexts/StaffContext";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogTitle, DialogHeader } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ShiftForm } from "@/components/staff/ShiftForm";
import { ShiftDetails } from "@/components/staff/ShiftDetails";

export const ShiftCalendar = () => {
  const { staff, shifts } = useStaff();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<"day" | "week">("week");
  const [addShiftOpen, setAddShiftOpen] = useState(false);
  const [shiftDetailsOpen, setShiftDetailsOpen] = useState(false);
  const [selectedShiftId, setSelectedShiftId] = useState<string | null>(null);

  // Determine the date range for the current view
  const startDate = viewMode === "week" ? startOfWeek(selectedDate, { weekStartsOn: 1 }) : selectedDate;
  const endDate = viewMode === "week" ? endOfWeek(selectedDate, { weekStartsOn: 1 }) : selectedDate;
  const dateRange = eachDayOfInterval({ start: startDate, end: endDate });

  // Function to navigate to previous/next day or week
  const navigatePrevious = () => {
    const days = viewMode === "week" ? 7 : 1;
    setSelectedDate(prev => addDays(prev, -days));
  };

  const navigateNext = () => {
    const days = viewMode === "week" ? 7 : 1;
    setSelectedDate(prev => addDays(prev, days));
  };

  // Filter shifts for the current date range
  const visibleShifts = shifts.filter(shift => {
    const shiftDate = new Date(shift.date);
    const shiftStartDate = new Date(shiftDate.getFullYear(), shiftDate.getMonth(), shiftDate.getDate());
    
    return dateRange.some(date => 
      date.getFullYear() === shiftStartDate.getFullYear() &&
      date.getMonth() === shiftStartDate.getMonth() &&
      date.getDate() === shiftStartDate.getDate()
    );
  });

  // Group shifts by date and staff member
  const shiftsByDateAndStaff = dateRange.map(date => {
    const dateString = format(date, "yyyy-MM-dd");
    const shiftsForDate = visibleShifts.filter(shift => shift.date === dateString);
    
    return {
      date,
      shifts: shiftsForDate
    };
  });

  const openShiftDetails = (shiftId: string) => {
    setSelectedShiftId(shiftId);
    setShiftDetailsOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="icon"
            onClick={navigatePrevious}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                <span>
                  {viewMode === "week"
                    ? `${format(startDate, "d MMM", { locale: it })} - ${format(endDate, "d MMM", { locale: it })}`
                    : format(selectedDate, "d MMMM yyyy", { locale: it })}
                </span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Button
            variant="outline"
            size="icon"
            onClick={navigateNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === "day" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("day")}
            className="text-xs h-9"
          >
            Giorno
          </Button>
          <Button
            variant={viewMode === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("week")}
            className="text-xs h-9"
          >
            Settimana
          </Button>
          <Button onClick={() => setAddShiftOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nuovo turno
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {shiftsByDateAndStaff.map(({ date, shifts }) => (
          <Card key={date.toString()} className={cn(
            "overflow-hidden",
            isToday(date) && "border-primary"
          )}>
            <div className="bg-secondary/50 p-4">
              <h3 className="font-medium">
                {format(date, "EEEE d MMMM", { locale: it })}
                {isToday(date) && (
                  <span className="ml-2 text-sm bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                    Oggi
                  </span>
                )}
              </h3>
            </div>
            
            <CardContent className="p-4">
              {shifts.length > 0 ? (
                <div className="space-y-4">
                  {shifts.map(shift => {
                    const staffMember = staff.find(s => s.id === shift.staffId);
                    return (
                      <div 
                        key={shift.id} 
                        className="flex items-center justify-between p-3 bg-background rounded-md border"
                      >
                        <div>
                          <div className="font-medium">
                            {staffMember?.firstName} {staffMember?.lastName}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {staffMember?.role} • {shift.startTime} - {shift.endTime}
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => openShiftDetails(shift.id)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  Nessun turno programmato per questo giorno
                </div>
              )}
            </CardContent>
            
            <CardFooter className="bg-secondary/30 p-4 flex justify-end">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  setSelectedDate(date);
                  setAddShiftOpen(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Aggiungi turno
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {/* Add shift dialog */}
      <Dialog open={addShiftOpen} onOpenChange={setAddShiftOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aggiungi nuovo turno</DialogTitle>
          </DialogHeader>
          <ShiftForm 
            initialDate={format(selectedDate, "yyyy-MM-dd")}
            onClose={() => setAddShiftOpen(false)} 
          />
        </DialogContent>
      </Dialog>
      
      {/* Shift details dialog */}
      <Dialog open={shiftDetailsOpen} onOpenChange={setShiftDetailsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dettagli turno</DialogTitle>
          </DialogHeader>
          {selectedShiftId && (
            <ShiftDetails 
              shiftId={selectedShiftId}
              onClose={() => setShiftDetailsOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
