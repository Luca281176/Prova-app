
import { useState } from "react";
import { useStaff, Shift } from "@/contexts/StaffContext";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { it } from "date-fns/locale";
import { DialogFooter } from "@/components/ui/dialog";
import { Pencil, Trash2, CheckCircle, XCircle, AlertCircle, Clock } from "lucide-react";
import { ShiftForm } from "@/components/staff/ShiftForm";
import { Separator } from "@/components/ui/separator";

interface ShiftDetailsProps {
  shiftId: string;
  onClose: () => void;
}

export const ShiftDetails = ({ shiftId, onClose }: ShiftDetailsProps) => {
  const { shifts, staff, removeShift } = useStaff();
  const [isEditing, setIsEditing] = useState(false);
  
  const shift = shifts.find(s => s.id === shiftId);
  const staffMember = shift ? staff.find(s => s.id === shift.staffId) : null;
  
  if (!shift || !staffMember) {
    return (
      <div className="p-6 text-center">
        <p>Turno non trovato</p>
        <Button onClick={onClose} className="mt-4">Chiudi</Button>
      </div>
    );
  }

  const handleDelete = () => {
    if (window.confirm("Sei sicuro di voler eliminare questo turno?")) {
      removeShift(shiftId);
      onClose();
    }
  };

  // Function to format date
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "EEEE d MMMM yyyy", { locale: it });
    } catch (error) {
      return dateString;
    }
  };

  // Function to get status label and icon
  const getStatusInfo = (status: Shift['status']) => {
    switch (status) {
      case 'scheduled':
        return { label: 'Programmato', icon: Clock, color: 'text-blue-500' };
      case 'confirmed':
        return { label: 'Confermato', icon: CheckCircle, color: 'text-green-500' };
      case 'in-progress':
        return { label: 'In corso', icon: Clock, color: 'text-yellow-500' };
      case 'completed':
        return { label: 'Completato', icon: CheckCircle, color: 'text-green-500' };
      case 'absent':
        return { label: 'Assente', icon: XCircle, color: 'text-red-500' };
      default:
        return { label: 'Sconosciuto', icon: AlertCircle, color: 'text-gray-500' };
    }
  };

  const statusInfo = getStatusInfo(shift.status);
  const StatusIcon = statusInfo.icon;

  if (isEditing) {
    return (
      <ShiftForm
        shiftId={shiftId}
        onClose={() => setIsEditing(false)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">
          {staffMember.firstName} {staffMember.lastName}
        </h3>
        <p className="text-muted-foreground">{staffMember.role}</p>
      </div>
      
      <Separator />
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="font-medium">Data</div>
          <div>{formatDate(shift.date)}</div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="font-medium">Orario</div>
          <div>{shift.startTime} - {shift.endTime}</div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="font-medium">Stato</div>
          <div className="flex items-center">
            <StatusIcon className={`h-4 w-4 mr-2 ${statusInfo.color}`} />
            {statusInfo.label}
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="font-medium">Conferma dipendente</div>
          <div>
            {shift.confirmed ? (
              <div className="flex items-center text-green-500">
                <CheckCircle className="h-4 w-4 mr-2" />
                Confermato
              </div>
            ) : (
              <div className="flex items-center text-yellow-500">
                <Clock className="h-4 w-4 mr-2" />
                In attesa
              </div>
            )}
          </div>
        </div>
      </div>
      
      <DialogFooter className="flex-col sm:flex-row gap-2">
        <Button variant="destructive" size="sm" onClick={handleDelete}>
          <Trash2 className="h-4 w-4 mr-2" />
          Elimina
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose}>
            Chiudi
          </Button>
          <Button onClick={() => setIsEditing(true)}>
            <Pencil className="h-4 w-4 mr-2" />
            Modifica
          </Button>
        </div>
      </DialogFooter>
    </div>
  );
};
