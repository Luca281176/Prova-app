
import { useState } from "react";
import { useStaff } from "@/contexts/StaffContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";

interface ShiftFormProps {
  shiftId?: string;
  initialDate?: string;
  onClose: () => void;
}

export const ShiftForm = ({ shiftId, initialDate, onClose }: ShiftFormProps) => {
  const { staff, shifts, addShift, updateShift } = useStaff();
  const existingShift = shiftId ? shifts.find(s => s.id === shiftId) : null;
  
  const [formData, setFormData] = useState({
    staffId: existingShift?.staffId || "",
    date: existingShift?.date || initialDate || new Date().toISOString().split('T')[0],
    startTime: existingShift?.startTime || "08:00",
    endTime: existingShift?.endTime || "16:00",
    confirmed: existingShift?.confirmed || false,
    status: existingShift?.status || "scheduled",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSwitchChange = (checked: boolean) => {
    setFormData({
      ...formData,
      confirmed: checked,
    });
  };

  const handleSelectChange = (name: string, value: any) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (existingShift) {
      updateShift(existingShift.id, formData);
    } else {
      addShift(formData);
    }
    
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="staffId">Dipendente</Label>
        <Select
          value={formData.staffId}
          onValueChange={(value) => handleSelectChange("staffId", value)}
          required
        >
          <SelectTrigger>
            <SelectValue placeholder="Seleziona dipendente" />
          </SelectTrigger>
          <SelectContent>
            {staff.map((member) => (
              <SelectItem key={member.id} value={member.id}>
                {member.firstName} {member.lastName} ({member.role})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="date">Data</Label>
        <Input
          id="date"
          name="date"
          type="date"
          value={formData.date}
          onChange={handleChange}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startTime">Ora inizio</Label>
          <Input
            id="startTime"
            name="startTime"
            type="time"
            value={formData.startTime}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="endTime">Ora fine</Label>
          <Input
            id="endTime"
            name="endTime"
            type="time"
            value={formData.endTime}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="status">Stato</Label>
        <Select
          value={formData.status}
          onValueChange={(value) => handleSelectChange("status", value)}
          required
        >
          <SelectTrigger>
            <SelectValue placeholder="Seleziona stato" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="scheduled">Programmato</SelectItem>
            <SelectItem value="confirmed">Confermato</SelectItem>
            <SelectItem value="in-progress">In corso</SelectItem>
            <SelectItem value="completed">Completato</SelectItem>
            <SelectItem value="absent">Assente</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="confirmed"
          checked={formData.confirmed}
          onCheckedChange={handleSwitchChange}
        />
        <Label htmlFor="confirmed">Turno confermato dal dipendente</Label>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>
          Annulla
        </Button>
        <Button type="submit">
          {existingShift ? "Aggiorna" : "Aggiungi"} turno
        </Button>
      </DialogFooter>
    </form>
  );
};
