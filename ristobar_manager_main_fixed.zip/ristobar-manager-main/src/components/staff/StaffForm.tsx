
import { useState, useEffect } from "react";
import { useStaff, StaffMember } from "@/contexts/StaffContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DialogFooter } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";

interface StaffFormProps {
  staffMember?: StaffMember;
  onClose: () => void;
}

export const StaffForm = ({ staffMember, onClose }: StaffFormProps) => {
  const { addStaffMember, updateStaffMember } = useStaff();
  const [formData, setFormData] = useState<Omit<StaffMember, 'id'> & { id?: string }>({
    firstName: "",
    lastName: "",
    role: "",
    email: "",
    phone: "",
    hireDate: new Date().toISOString().split('T')[0],
    contractType: "full-time",
    salary: 0,
    permissionLevel: "waiter",
    customPermissions: {
      orders: false,
      tables: false,
      kitchen: false,
      cash: false,
      staff: false,
      inventory: false,
      reports: false
    }
  });
  const [hasCustomPermissions, setHasCustomPermissions] = useState(false);

  useEffect(() => {
    if (staffMember) {
      setFormData(staffMember);
      setHasCustomPermissions(staffMember.permissionLevel === 'custom');
    }
  }, [staffMember]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'number' ? parseFloat(value) : value,
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === "permissionLevel") {
      setHasCustomPermissions(value === "custom");
    }
    
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handlePermissionChange = (permission: string, checked: boolean) => {
    setFormData({
      ...formData,
      customPermissions: {
        ...formData.customPermissions,
        [permission]: checked
      }
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!hasCustomPermissions) {
      // If not using custom permissions, remove the customPermissions object
      const { customPermissions, ...dataWithoutCustom } = formData;
      
      if (staffMember) {
        updateStaffMember(staffMember.id, dataWithoutCustom);
      } else {
        addStaffMember(dataWithoutCustom);
      }
    } else {
      if (staffMember) {
        updateStaffMember(staffMember.id, formData);
      } else {
        addStaffMember(formData);
      }
    }
    
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstName">Nome</Label>
          <Input
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Cognome</Label>
          <Input
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="role">Ruolo</Label>
        <Input
          id="role"
          name="role"
          value={formData.role}
          onChange={handleChange}
          placeholder="es. Cameriere, Cuoco, Manager, etc."
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Telefono</Label>
          <Input
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="hireDate">Data di assunzione</Label>
          <Input
            id="hireDate"
            name="hireDate"
            type="date"
            value={formData.hireDate}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contractType">Tipo di contratto</Label>
          <Select
            value={formData.contractType}
            onValueChange={(value) => handleSelectChange("contractType", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Seleziona tipo di contratto" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="full-time">Tempo pieno</SelectItem>
              <SelectItem value="part-time">Part-time</SelectItem>
              <SelectItem value="extra">Extra</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="salary">Stipendio mensile (€)</Label>
        <Input
          id="salary"
          name="salary"
          type="number"
          min="0"
          step="100"
          value={formData.salary}
          onChange={handleChange}
          required
        />
      </div>

      <Separator />

      <div className="space-y-4">
        <div>
          <Label htmlFor="permissionLevel">Livello di permessi</Label>
          <Select
            value={formData.permissionLevel}
            onValueChange={(value) => handleSelectChange("permissionLevel", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Seleziona livello di permessi" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="manager">Manager (accesso completo)</SelectItem>
              <SelectItem value="waiter">Cameriere (ordini e tavoli)</SelectItem>
              <SelectItem value="chef">Cuoco (cucina e comande)</SelectItem>
              <SelectItem value="cashier">Cassiere (pagamenti)</SelectItem>
              <SelectItem value="bartender">Barista (bar e comande)</SelectItem>
              <SelectItem value="custom">Personalizzato</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {hasCustomPermissions && (
          <div className="space-y-2 bg-secondary/50 p-4 rounded-md">
            <h4 className="font-medium mb-3">Configura permessi personalizzati</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="orders"
                  checked={formData.customPermissions?.orders}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("orders", checked === true)
                  }
                />
                <Label htmlFor="orders">Gestione ordini</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="tables"
                  checked={formData.customPermissions?.tables}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("tables", checked === true)
                  }
                />
                <Label htmlFor="tables">Gestione tavoli</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="kitchen"
                  checked={formData.customPermissions?.kitchen}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("kitchen", checked === true)
                  }
                />
                <Label htmlFor="kitchen">Gestione cucina</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="cash"
                  checked={formData.customPermissions?.cash}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("cash", checked === true)
                  }
                />
                <Label htmlFor="cash">Gestione cassa</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="staff"
                  checked={formData.customPermissions?.staff}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("staff", checked === true)
                  }
                />
                <Label htmlFor="staff">Gestione personale</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="inventory"
                  checked={formData.customPermissions?.inventory}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("inventory", checked === true)
                  }
                />
                <Label htmlFor="inventory">Gestione magazzino</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="reports"
                  checked={formData.customPermissions?.reports}
                  onCheckedChange={(checked) => 
                    handlePermissionChange("reports", checked === true)
                  }
                />
                <Label htmlFor="reports">Accesso report</Label>
              </div>
            </div>
          </div>
        )}
      </div>

      <DialogFooter>
        <Button variant="outline" type="button" onClick={onClose}>
          Annulla
        </Button>
        <Button type="submit">
          {staffMember ? "Aggiorna" : "Aggiungi"} dipendente
        </Button>
      </DialogFooter>
    </form>
  );
};
