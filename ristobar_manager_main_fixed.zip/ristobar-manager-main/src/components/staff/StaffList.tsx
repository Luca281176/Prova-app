
import { useState } from "react";
import { 
  UserPlus, 
  Pencil, 
  Trash2, 
  Search,
  User,
  Calendar,
  Phone,
  Mail,
  DollarSign
} from "lucide-react";
import { useStaff, StaffMember } from "@/contexts/StaffContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { StaffForm } from "@/components/staff/StaffForm";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { it } from "date-fns/locale";

export const StaffList = () => {
  const { staff, removeStaffMember } = useStaff();
  const [searchQuery, setSearchQuery] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [showActiveOnly, setShowActiveOnly] = useState(false);

  // Filter staff based on search query
  const filteredStaff = staff.filter(member => {
    const fullName = `${member.firstName} ${member.lastName}`.toLowerCase();
    const role = member.role.toLowerCase();
    const query = searchQuery.toLowerCase();
    
    return fullName.includes(query) || role.includes(query);
  });

  const handleEdit = (staffMember: StaffMember) => {
    setSelectedStaff(staffMember);
    setEditDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Sei sicuro di voler rimuovere questo dipendente?")) {
      removeStaffMember(id);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd MMMM yyyy", { locale: it });
    } catch (error) {
      return dateString;
    }
  };

  const formatContractType = (type: string) => {
    switch (type) {
      case 'full-time': return 'Tempo pieno';
      case 'part-time': return 'Part-time';
      case 'extra': return 'Extra';
      default: return type;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div className="relative md:w-1/2">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cerca dipendente per nome o ruolo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <Switch 
              id="active-filter" 
              checked={showActiveOnly}
              onCheckedChange={setShowActiveOnly}
            />
            <Label htmlFor="active-filter">Solo attivi</Label>
          </div>
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="whitespace-nowrap">
                <UserPlus className="mr-2 h-4 w-4" />
                Aggiungi dipendente
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Aggiungi nuovo dipendente</DialogTitle>
              </DialogHeader>
              <StaffForm onClose={() => setAddDialogOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {filteredStaff.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStaff.map((member) => (
            <Card key={member.id} className="overflow-hidden">
              <div className="p-6 flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex flex-col">
                    <h3 className="font-bold text-lg">{member.firstName} {member.lastName}</h3>
                    <span className="text-muted-foreground">{member.role}</span>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(member)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(member.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <CardContent className="p-0 space-y-3">
                  <div className="flex items-center text-sm">
                    <User className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>Permessi: {member.permissionLevel}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{member.email}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Phone className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>{member.phone}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>Assunzione: {formatDate(member.hireDate)}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <DollarSign className="mr-2 h-4 w-4 text-muted-foreground" />
                    <span>€{member.salary}/mese - {formatContractType(member.contractType)}</span>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-10 bg-muted/20 rounded-lg">
          <User className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">Nessun dipendente</h3>
          <p className="text-muted-foreground mb-6">
            Non ci sono dipendenti registrati. Aggiungi il tuo primo dipendente per iniziare.
          </p>
          <Button onClick={() => setAddDialogOpen(true)}>
            <UserPlus className="mr-2 h-4 w-4" />
            Aggiungi dipendente
          </Button>
        </div>
      )}

      {/* Edit staff dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Modifica dipendente</DialogTitle>
          </DialogHeader>
          {selectedStaff && (
            <StaffForm 
              staffMember={selectedStaff} 
              onClose={() => setEditDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
