
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ClockIcon, ShieldCheckIcon, CheckIcon, Loader2, AlertCircle } from 'lucide-react';
import { 
  type SubscriptionPlan,
  type UserSubscription
} from '@/services/subscriptions';
import { getCustomerPortalSession, cancelSubscription } from '@/services/stripeCheckout';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface CurrentSubscriptionCardProps {
  userSubscription: UserSubscription;
  currentPlan: SubscriptionPlan;
  isActive: boolean;
}

const CurrentSubscriptionCard = ({ 
  userSubscription, 
  currentPlan, 
  isActive 
}: CurrentSubscriptionCardProps) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  
  const handleManageSubscription = async () => {
    try {
      setIsLoading(true);
      
      // Get the Stripe customer ID
      const stripeCustomerId = userSubscription.stripeCustomerId;
      
      if (!stripeCustomerId) {
        toast.error("Informazioni cliente non disponibili");
        return;
      }
      
      // Get customer portal session from our backend
      const portalSession = await getCustomerPortalSession(stripeCustomerId);
      
      if (portalSession && portalSession.url) {
        // Redirect to Stripe Customer Portal
        window.location.href = portalSession.url;
      } else {
        throw new Error("Impossibile creare la sessione del portale cliente");
      }
    } catch (error) {
      console.error('Error managing subscription:', error);
      toast.error("Si è verificato un errore nell'accesso al portale abbonamenti");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelSubscription = async () => {
    try {
      setIsCancelling(true);
      
      await cancelSubscription(userSubscription.id);
      
      // Reload the page to show updated subscription status
      setTimeout(() => {
        window.location.reload();
      }, 1500);
      
    } catch (error) {
      console.error('Error cancelling subscription:', error);
      toast.error("Si è verificato un errore nell'annullamento dell'abbonamento");
    } finally {
      setIsCancelling(false);
      setShowCancelDialog(false);
    }
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('it-IT', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };
  
  return (
    <>
      <Card className="glass-panel">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Il tuo abbonamento attuale</CardTitle>
              <CardDescription>Dettagli del tuo piano e stato dell'abbonamento</CardDescription>
            </div>
            <Badge 
              variant={isActive ? 'default' : 'destructive'}
              className="capitalize"
            >
              {userSubscription.status === 'active' ? 'Attivo' : 
               userSubscription.status === 'past_due' ? 'Pagamento in ritardo' :
               userSubscription.status === 'trialing' ? 'Periodo di prova' :
               userSubscription.status === 'canceled' ? 'Annullato' : 'Inattivo'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label className="text-muted-foreground">Piano</Label>
                <div className="text-2xl font-bold">{currentPlan.name}</div>
                <p className="text-sm text-muted-foreground">{currentPlan.description}</p>
              </div>
              
              <div>
                <Label className="text-muted-foreground">Costo</Label>
                <div className="text-xl font-bold">€{currentPlan.price.toFixed(2)}/mese</div>
              </div>
              
              <div>
                <Label className="text-muted-foreground">Funzionalità incluse</Label>
                <ul className="mt-2 space-y-2">
                  {currentPlan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckIcon className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 border rounded-lg bg-accent/20">
                <div className="flex items-center">
                  <ClockIcon className="h-5 w-5 text-primary mr-2" />
                  <Label className="text-muted-foreground">Periodo corrente</Label>
                </div>
                <div className="mt-2">
                  <div className="text-sm font-medium">Scade il: <span className="font-bold">{formatDate(userSubscription.currentPeriodEnd)}</span></div>
                  {userSubscription.cancelAtPeriodEnd && (
                    <div className="text-sm text-destructive mt-2">
                      * Il tuo abbonamento non si rinnoverà automaticamente alla fine del periodo.
                    </div>
                  )}
                </div>
              </div>
              
              <div className="p-4 border rounded-lg bg-accent/20">
                <div className="flex items-center">
                  <ShieldCheckIcon className="h-5 w-5 text-primary mr-2" />
                  <Label className="text-muted-foreground">Gestione Abbonamento</Label>
                </div>
                <div className="mt-2">
                  <p className="text-sm mb-2">Gestisci facilmente il tuo abbonamento tramite il portale clienti Stripe.</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleManageSubscription}
                    disabled={isLoading}
                    className="w-full"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Caricamento...
                      </>
                    ) : (
                      'Gestisci abbonamento'
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-4 sm:justify-between">
          <Button 
            variant="outline" 
            className="w-full sm:w-auto"
            onClick={() => window.location.href = '#piano-abbonamento'}
          >
            Cambia piano
          </Button>
          
          {!userSubscription.cancelAtPeriodEnd && userSubscription.status === 'active' && (
            <Button 
              variant="destructive" 
              className="w-full sm:w-auto"
              onClick={() => setShowCancelDialog(true)}
              disabled={isCancelling}
            >
              {isCancelling ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Annullamento...
                </>
              ) : (
                <>
                  <AlertCircle className="mr-2 h-4 w-4" />
                  Annulla abbonamento
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>

      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sei sicuro di voler annullare l'abbonamento?</AlertDialogTitle>
            <AlertDialogDescription>
              L'abbonamento rimarrà attivo fino alla fine del periodo di fatturazione corrente.
              Dopo tale data, perderai l'accesso alle funzionalità premium.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleCancelSubscription}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isCancelling ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Annullamento...
                </>
              ) : (
                'Conferma annullamento'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default CurrentSubscriptionCard;
