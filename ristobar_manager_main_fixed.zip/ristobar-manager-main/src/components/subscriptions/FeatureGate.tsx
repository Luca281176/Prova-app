
import { PropsWithChildren } from 'react';
import { useUser } from '@/contexts/user';
import { hasAccess } from '@/services/subscriptions/featureAccess';

interface FeatureGateProps extends PropsWithChildren {
  /**
   * Nome della feature richiesta
   */
  feature: string;
  
  /**
   * Componente da mostrare quando l'utente non ha accesso alla feature
   */
  fallback?: React.ReactNode;
}

/**
 * Componente che controlla l'accesso a specifiche feature in base all'abbonamento
 */
const FeatureGate = ({ children, feature, fallback }: FeatureGateProps) => {
  const { user } = useUser();
  
  // Verifica se l'utente ha accesso alla feature
  const canAccess = hasAccess(user?.subscription, feature);
  
  console.log(`FeatureGate for feature "${feature}" - Access:`, canAccess, "Subscription:", user?.subscription?.planId);
  
  if (!canAccess) {
    // Se non ha accesso, mostra il fallback o nulla
    return fallback ? <>{fallback}</> : null;
  }
  
  // Se ha accesso, mostra i children
  return <>{children}</>;
};

export default FeatureGate;
