
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { ArrowUpCircle } from 'lucide-react';

interface FeatureUpsellProps {
  title: string;
  description: string;
  requiredPlan: string;
  icon?: React.ReactNode;
  buttonText?: string;
  buttonLink?: string;
}

const FeatureUpsell = ({
  title,
  description,
  requiredPlan,
  icon = <ArrowUpCircle className="h-5 w-5 text-muted-foreground" />,
  buttonText = "Aggiorna piano",
  buttonLink = "/subscriptions"
}: FeatureUpsellProps) => {
  const navigate = useNavigate();
  
  const handleUpgrade = () => {
    navigate(buttonLink);
  };
  
  return (
    <Card className="bg-muted/50 border-dashed border-muted-foreground/20">
      <CardContent className="p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          {icon && (
            <div className="flex-shrink-0">
              {icon}
            </div>
          )}
          <div className="flex-grow">
            <h4 className="text-sm font-medium">{title}</h4>
            <p className="text-sm text-muted-foreground mt-1">{description}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Disponibile nel piano <span className="font-medium">{requiredPlan}</span>
            </p>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-2 sm:mt-0"
            onClick={handleUpgrade}
          >
            {buttonText}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default FeatureUpsell;
