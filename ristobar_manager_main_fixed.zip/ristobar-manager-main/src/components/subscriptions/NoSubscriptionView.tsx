
import { AlertCircleIcon } from 'lucide-react';
import SubscriptionPlansGrid from './SubscriptionPlansGrid';

const NoSubscriptionView = () => {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <AlertCircleIcon className="h-12 w-12 text-muted-foreground mb-4" />
      <h2 className="text-2xl font-bold">Nessun abbonamento attivo</h2>
      <p className="text-muted-foreground mt-2">Scegli un piano sotto per attivare un abbonamento.</p>
      
      {/* Show plans for new subscribers */}
      <div className="w-full max-w-5xl mt-12">
        <h3 className="text-xl font-bold mb-6">Scegli un Piano</h3>
        <SubscriptionPlansGrid showHeader={false} />
      </div>
    </div>
  );
};

export default NoSubscriptionView;
