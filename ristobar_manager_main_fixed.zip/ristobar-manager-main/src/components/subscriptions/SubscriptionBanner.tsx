
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useUser } from '@/contexts/user';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, X, ArrowUpRight } from 'lucide-react';
import { isSubscriptionActive, getDaysRemaining } from '@/services/subscriptions';

const SubscriptionBanner = () => {
  const { user } = useUser();
  const [dismissed, setDismissed] = useState(false);
  const [showBanner, setShowBanner] = useState(false);
  
  useEffect(() => {
    // Don't show if user dismissed it in this session
    if (dismissed) return;
    
    // Check if we need to show the banner
    if (user?.subscription) {
      const isActive = isSubscriptionActive(user.subscription);
      const daysRemaining = getDaysRemaining(user.subscription);
      
      // Show for: inactive, canceled or expiring soon (10 days or less)
      setShowBanner(!isActive || 
        user.subscription.cancelAtPeriodEnd || 
        (isActive && daysRemaining <= 10));
    } else {
      // No subscription - show banner
      setShowBanner(true);
    }
  }, [user, dismissed]);
  
  if (!showBanner) return null;
  
  // Determine banner type and content
  let alertType: 'default' | 'destructive' = 'default';
  let title = 'Abbonamento';
  let description = 'Attiva un abbonamento per accedere a tutte le funzionalità.';
  
  if (user?.subscription) {
    const daysRemaining = getDaysRemaining(user.subscription);
    const isActive = isSubscriptionActive(user.subscription);
    
    if (!isActive) {
      alertType = 'destructive';
      title = 'Abbonamento scaduto';
      description = 'Il tuo abbonamento è scaduto. Rinnova ora per continuare a utilizzare tutte le funzionalità.';
    } else if (user.subscription.cancelAtPeriodEnd) {
      alertType = 'default';
      title = 'Abbonamento in scadenza';
      description = `Il tuo abbonamento non si rinnoverà automaticamente e scadrà tra ${daysRemaining} giorni.`;
    } else if (daysRemaining <= 10) {
      alertType = 'default';
      title = 'Rinnovo abbonamento';
      description = `Il tuo abbonamento si rinnoverà automaticamente tra ${daysRemaining} giorni.`;
    }
  }
  
  return (
    <Alert variant={alertType} className="mb-4">
      <div className="flex items-center justify-between w-full">
        <div className="flex items-start">
          <AlertCircle className="h-4 w-4 mt-0.5 mr-2" />
          <div>
            <AlertTitle>{title}</AlertTitle>
            <AlertDescription>{description}</AlertDescription>
          </div>
        </div>
        
        <div className="flex items-center gap-2 ml-4">
          <Button variant="outline" size="sm" asChild>
            <Link to="/subscriptions" className="flex items-center">
              Gestisci abbonamento
              <ArrowUpRight className="ml-1 h-3 w-3" />
            </Link>
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setDismissed(true)}
            aria-label="Dismiss"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Alert>
  );
};

export default SubscriptionBanner;
