
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckIcon, LeafIcon, RocketIcon, StarIcon, CrownIcon } from 'lucide-react';
import { type SubscriptionPlan } from '@/services/subscriptions';

interface SubscriptionPlanCardProps {
  plan: SubscriptionPlan;
  isCurrentPlan: boolean;
  onSelectPlan: (planId: string) => void;
  isLoading: boolean;
}

const SubscriptionPlanCard = ({ 
  plan, 
  isCurrentPlan, 
  onSelectPlan, 
  isLoading 
}: SubscriptionPlanCardProps) => {
  const getPlanColor = () => {
    switch (plan.id) {
      case 'starter':
        return 'bg-[#F2FCE2]';
      case 'pro':
        return 'bg-[#FEF7CD]';
      case 'ultimate':
        return 'bg-[#D3E4FD]';
      default:
        return 'bg-primary/20';
    }
  };

  const getPlanIcon = () => {
    switch (plan.id) {
      case 'starter':
        return <LeafIcon className="h-5 w-5 text-green-500 mr-2" />;
      case 'pro':
        return <RocketIcon className="h-5 w-5 text-blue-500 mr-2" />;
      case 'ultimate':
        return <CrownIcon className="h-5 w-5 text-amber-500 mr-2" fill="currentColor" />;
      default:
        return null;
    }
  };

  const getButtonText = (planId: string, isCurrentPlan: boolean, isLoading: boolean): string => {
    if (isLoading) return "Elaborazione...";
    if (isCurrentPlan) return "Piano attuale";
    return "Abbonati";
  };

  return (
    <Card 
      key={plan.id} 
      className={`relative ${isCurrentPlan ? 'border-primary shadow-lg ring-2 ring-primary/30' : plan.isRecommended ? 'border-primary' : ''}`}
    >
      {plan.isPopular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-primary text-white text-xs font-medium rounded-full">
          Più popolare
        </div>
      )}
      
      {isCurrentPlan && (
        <div className={`absolute -top-3 right-4 px-3 py-1 ${getPlanColor()} text-foreground text-xs font-medium rounded-full flex items-center`}>
          <StarIcon className="h-3 w-3 mr-1" fill="currentColor" />
          Piano attuale
        </div>
      )}
      
      <CardHeader>
        <div className="flex items-center">
          {getPlanIcon()}
          <CardTitle>{plan.name}</CardTitle>
        </div>
        <CardDescription>{plan.description}</CardDescription>
        <div className="mt-2">
          <span className="text-2xl font-bold">€{plan.price.toFixed(2)}</span>
          <span className="text-muted-foreground">/mese</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <ul className="space-y-2">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <CheckIcon className="h-4 w-4 text-primary mr-2 shrink-0" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button 
          variant={isCurrentPlan ? "outline" : "default"} 
          className={`w-full ${isCurrentPlan ? getPlanColor() : ''}`}
          disabled={isLoading || isCurrentPlan}
          onClick={() => onSelectPlan(plan.id)}
        >
          {getButtonText(plan.id, isCurrentPlan, isLoading)}
        </Button>
      </CardFooter>
      
      {plan.id === 'starter' && (
        <div className="mt-3 text-center text-xs text-muted-foreground">
          14 giorni di prova gratuita, nessuna carta di credito richiesta
        </div>
      )}
    </Card>
  );
};

export default SubscriptionPlanCard;
