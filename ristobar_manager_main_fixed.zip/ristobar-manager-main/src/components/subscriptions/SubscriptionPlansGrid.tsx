
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SubscriptionPlanCard from './SubscriptionPlanCard';
import { subscriptionPlans } from '@/services/subscriptions';
import { type UserSubscription } from '@/services/subscriptions';
import { toast } from 'sonner';

interface SubscriptionPlansGridProps {
  currentSubscription?: UserSubscription | null;
  showHeader?: boolean;
}

const SubscriptionPlansGrid = ({ 
  currentSubscription,
  showHeader = true 
}: SubscriptionPlansGridProps) => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  
  const handleChangePlan = (planId: string) => {
    setIsLoading(true);
    
    // Check if this is the current plan
    if (currentSubscription && currentSubscription.planId === planId) {
      toast.info("Hai già sottoscritto questo piano");
      setIsLoading(false);
      return;
    }
    
    // Navigate to checkout with the plan ID
    console.log("Navigating to checkout with plan:", planId);
    
    // Use direct location change instead of router navigation
    const checkoutUrl = `/checkout?plan=${planId}`;
    console.log("Redirecting to:", checkoutUrl);
    window.location.href = checkoutUrl;
  };
  
  return (
    <div id="piano-abbonamento" className={showHeader ? "pt-8 mt-8 border-t" : ""}>
      {showHeader && (
        <h2 className="text-xl font-bold mb-6">Cambia Piano</h2>
      )}
      <div className="grid md:grid-cols-3 gap-6">
        {subscriptionPlans.map((plan) => (
          <SubscriptionPlanCard
            key={plan.id}
            plan={plan}
            isCurrentPlan={currentSubscription?.planId === plan.id}
            onSelectPlan={handleChangePlan}
            isLoading={isLoading && currentSubscription?.planId !== plan.id}
          />
        ))}
      </div>
    </div>
  );
};

export default SubscriptionPlansGrid;
