
import { toast } from '@/hooks/use-toast';
import { getOrdersForTable } from '@/services/ordersService';
import { getRestaurantInfoSync } from '@/components/cashier/bill/RestaurantInfoProvider';
import { loadCashierSettings } from '@/services/settingsService';

export async function printPreBill(tableId: string, tableName: string) {
  return new Promise<boolean>(async (resolve, reject) => {
    try {
      console.log(`Printing pre-bill for table: ${tableName} (${tableId})`);
      
      // Get orders for table
      const orders = await getOrdersForTable(tableId);
      console.log(`Found ${orders.length} orders for the table`);
      
      const completedOrders = orders.filter(order => order.status === 'completed');
      console.log(`${completedOrders.length} of them are completed`);
      
      if (completedOrders.length === 0) {
        toast({
          title: "Nessun ordine da stampare",
          description: "Non ci sono ordini completati per questo tavolo.",
          variant: "destructive"
        });
        resolve(false);
        return;
      }
      
      // Use the most recent completed order
      const order = completedOrders[completedOrders.length - 1];
      console.log(`Using order: ${order.id} with ${order.items.length} items`);
      
      // Get restaurant info and settings
      const restaurantInfo = getRestaurantInfoSync();
      const cashierSettings = loadCashierSettings();
      
      console.log('Restaurant Info:', restaurantInfo);
      console.log('Print Logo Setting:', cashierSettings?.printLogo);
      
      // Create an invisible iframe for printing
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);
      
      if (!iframe.contentWindow) {
        console.error('Failed to access iframe content window');
        toast({
          title: "Errore di stampa",
          description: "Errore nell'inizializzazione della stampa",
          variant: "destructive"
        });
        document.body.removeChild(iframe);
        resolve(false);
        return;
      }
      
      // Write the HTML to the iframe
      iframe.contentDocument?.open();
      iframe.contentDocument?.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Preconto ${order.tableName}</title>
            <style>
              @page {
                size: 80mm auto;
                margin: 0;
              }
              
              body {
                font-family: 'Courier New', monospace;
                width: 80mm;
                margin: 0;
                padding: 5mm;
                font-size: 10pt;
              }
              
              .bill-content {
                width: 70mm;
                margin: 0 auto;
              }
              
              .restaurant-name {
                font-size: 14pt;
                font-weight: bold;
                text-align: center;
                margin-bottom: 2mm;
              }
              
              .logo-container {
                text-align: center;
                margin-bottom: 2mm;
              }
              
              .restaurant-logo {
                max-width: 60mm;
                max-height: 20mm;
                margin: 0 auto;
                display: block;
              }
              
              .restaurant-info {
                text-align: center;
                font-size: 8pt;
                margin-bottom: 3mm;
              }
              
              .bill-title {
                text-align: center;
                font-size: 12pt;
                font-weight: bold;
                margin: 3mm 0;
                text-decoration: underline;
              }
              
              .info-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 1mm;
                font-size: 9pt;
              }
              
              .divider {
                border-top: 1px dashed #000;
                margin: 3mm 0;
              }
              
              .item-row {
                margin-bottom: 1mm;
              }
              
              .item-details {
                display: flex;
                justify-content: space-between;
              }
              
              .item-notes {
                font-style: italic;
                font-size: 8pt;
                padding-left: 3mm;
              }
              
              .total-row {
                display: flex;
                justify-content: space-between;
                font-weight: bold;
                margin-top: 2mm;
              }
              
              .footer {
                text-align: center;
                font-size: 8pt;
                margin-top: 5mm;
              }
              
              @media print {
                body {
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                
                .no-print {
                  display: none;
                }
              }
            </style>
          </head>
          <body>
            <div class="bill-content">
              <div class="header">
                ${cashierSettings?.printLogo && restaurantInfo.logo ? `
                <div class="logo-container">
                  <img src="${restaurantInfo.logo}" alt="Logo Ristorante" class="restaurant-logo" />
                </div>
                ` : ''}
                <h2 class="restaurant-name">${restaurantInfo.name || 'Ristorante'}</h2>
                <div class="restaurant-info">
                  ${restaurantInfo.address ? `<p>${restaurantInfo.address}</p>` : ''}
                  ${restaurantInfo.phone ? `<p>${restaurantInfo.phone}</p>` : ''}
                  ${restaurantInfo.vat ? `<p>P.IVA: ${restaurantInfo.vat}</p>` : ''}
                </div>
                <h3 class="bill-title">PRECONTO</h3>
              </div>
              
              <div class="info-row">
                <span>Data:</span>
                <span>${new Date(order.timestamp).toLocaleDateString('it-IT')}</span>
              </div>
              <div class="info-row">
                <span>Ora:</span>
                <span>${new Date(order.timestamp).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div class="info-row">
                <span>Tavolo:</span>
                <span>${order.tableName}</span>
              </div>
              <div class="info-row">
                <span>Operatore:</span>
                <span>${order.operatorName}</span>
              </div>
              <div class="info-row">
                <span>Comanda:</span>
                <span>#${order.id.substring(0, 6)}</span>
              </div>
              
              <div class="divider"></div>
              
              ${order.items.map(item => `
                <div class="item-row">
                  <div class="item-details">
                    <span>${item.quantity}x ${item.name}</span>
                    <span>€${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                  ${item.notes ? `<div class="item-notes">→ ${item.notes}</div>` : ''}
                </div>
              `).join('')}
              
              <div class="divider"></div>
              
              <div class="total-row">
                <span>Totale:</span>
                <span>€${order.total.toFixed(2)}</span>
              </div>
              
              <div class="footer">
                <p>${cashierSettings?.receiptFooter || 'Grazie per averci scelto!'}</p>
              </div>
              
              <div class="no-print" style="text-align: center; margin-top: 20px;">
                <button onclick="window.print();return false;">Stampa</button>
                <button onclick="window.close();return false;">Chiudi</button>
              </div>
            </div>
          </body>
        </html>
      `);
      iframe.contentDocument?.close();
      
      // Wait a bit for resources to load, then print
      console.log('Waiting for iframe to load before printing');
      setTimeout(() => {
        try {
          if (iframe.contentWindow) {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
            console.log('Print dialog opened');
            
            // Remove iframe after a delay
            setTimeout(() => {
              document.body.removeChild(iframe);
              console.log('Print iframe removed');
              resolve(true);
            }, 1000);
          } else {
            throw new Error('Iframe content window not available');
          }
        } catch (printError) {
          console.error('Error during print operation:', printError);
          document.body.removeChild(iframe);
          reject(printError);
        }
      }, 500);
      
    } catch (error) {
      console.error('Error in print pre-bill function:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la stampa del preconto.",
        variant: "destructive"
      });
      reject(error);
    }
  });
}
