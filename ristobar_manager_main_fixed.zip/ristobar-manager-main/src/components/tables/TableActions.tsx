
import React from 'react';
import { Button } from '@/components/ui/button';
import { TableStatus } from '@/components/RoomGrid';
import { CheckIcon, UserIcon, CalendarIcon, ClockIcon, Settings, Trash2Icon } from 'lucide-react';

export interface TableActionsProps {
  open: boolean;
  onClose: () => void;
  onStatusChange: (newStatus: TableStatus) => void;
  currentStatus: TableStatus;
}

export const TableActions: React.FC<TableActionsProps> = ({
  open,
  onClose,
  onStatusChange,
  currentStatus
}) => {
  if (!open) return null;
  
  const handleStatusChange = (status: TableStatus) => {
    // Prevent changing to the same status
    if (status === currentStatus) return;
    
    onStatusChange(status);
    onClose();
  };
  
  // Handle clicking outside to close
  const handleBackdropClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClose();
  };
  
  // Prevent clicks inside the menu from closing
  const handleMenuClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div 
      className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center backdrop-blur-sm"
      onClick={handleBackdropClick}
    >
      <div 
        className="bg-white rounded-lg shadow-xl p-5 w-80 transform transition-all"
        onClick={handleMenuClick}
      >
        <h3 className="font-medium mb-4 text-center text-lg">Cambia stato tavolo</h3>
        
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant={currentStatus === 'available' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'available' ? "bg-green-600 hover:bg-green-700" : "border-green-600 text-green-700 hover:bg-green-50"}`}
            onClick={() => handleStatusChange('available')}
          >
            <CheckIcon className="h-4 w-4 mr-2" />
            Libero
          </Button>
          
          <Button
            variant={currentStatus === 'occupied' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'occupied' ? "bg-red-600 hover:bg-red-700" : "border-red-600 text-red-700 hover:bg-red-50"}`}
            onClick={() => handleStatusChange('occupied')}
          >
            <UserIcon className="h-4 w-4 mr-2" />
            Occupato
          </Button>
          
          <Button
            variant={currentStatus === 'reserved' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'reserved' ? "bg-blue-600 hover:bg-blue-700" : "border-blue-600 text-blue-700 hover:bg-blue-50"}`}
            onClick={() => handleStatusChange('reserved')}
          >
            <CalendarIcon className="h-4 w-4 mr-2" />
            Prenotato
          </Button>
          
          <Button
            variant={currentStatus === 'waiting' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'waiting' ? "bg-yellow-600 hover:bg-yellow-700" : "border-yellow-600 text-yellow-700 hover:bg-yellow-50"}`}
            onClick={() => handleStatusChange('waiting')}
          >
            <ClockIcon className="h-4 w-4 mr-2" />
            In attesa
          </Button>
          
          <Button
            variant={currentStatus === 'maintenance' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'maintenance' ? "bg-orange-600 hover:bg-orange-700" : "border-orange-600 text-orange-700 hover:bg-orange-50"}`}
            onClick={() => handleStatusChange('maintenance')}
          >
            <Settings className="h-4 w-4 mr-2" />
            Manutenzione
          </Button>
          
          <Button
            variant={currentStatus === 'cleaning' ? "default" : "outline"}
            className={`h-12 ${currentStatus === 'cleaning' ? "bg-purple-600 hover:bg-purple-700" : "border-purple-600 text-purple-700 hover:bg-purple-50"}`}
            onClick={() => handleStatusChange('cleaning')}
          >
            <Trash2Icon className="h-4 w-4 mr-2" />
            Pulizia
          </Button>
        </div>
        
        <div className="mt-5 text-center">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
          >
            Annulla
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TableActions;
