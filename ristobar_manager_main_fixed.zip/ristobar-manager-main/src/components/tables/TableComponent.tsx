import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableStatus } from '@/components/RoomGrid';
import { TableHeader } from './TableHeader';
import { ShoppingCart, Calendar, X, PenSquare, Trash2, ClipboardEdit, Users, Unlock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getOrdersForTable, Order } from '@/services/ordersService';
import { toast } from '@/hooks/use-toast';
import { printPreBill } from './BillPrintService';
import TableOrderDialog from './TableOrderDialog';
import OrderDialog from '@/components/OrderDialog';
import { updateTableStatus } from '@/services/roomsService';
import AddReservationDialog from '@/components/reservations/AddReservationDialog';
import { getReservationByTableId } from '@/services/reservationService';
import { Reservation } from '@/types/reservations';
import { TableReservation } from './TableReservation';

interface TableComponentProps {
  table: Table;
  onStatusChange: (tableId: string, status: TableStatus) => Promise<void>;
  onEdit: (table: Table) => void;
  onDelete: (table: Table) => void;
}

const TableComponent: React.FC<TableComponentProps> = ({ 
  table, 
  onStatusChange,
  onEdit,
  onDelete
}) => {
  const [tableOrders, setTableOrders] = useState<Order[]>([]);
  const [hasActiveOrders, setHasActiveOrders] = useState(false);
  const [hasCompletedOrders, setHasCompletedOrders] = useState(false);
  const [isLoadingPrint, setIsLoadingPrint] = useState(false);
  const [showOrderDialog, setShowOrderDialog] = useState(false);
  const [showEditOrderDialog, setShowEditOrderDialog] = useState(false);
  const [showReservationDialog, setShowReservationDialog] = useState(false);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [showButtons, setShowButtons] = useState(false);
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [isLoadingReservation, setIsLoadingReservation] = useState(false);
  const [lastReservationCheck, setLastReservationCheck] = useState<Date>(new Date());
  const navigate = useNavigate();

  const getLocationId = () => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('locationId') || undefined;
  };

  const checkTableOrders = async () => {
    try {
      console.log(`Checking orders for table ${table.id} with status ${table.status}`);
      const orders = await getOrdersForTable(table.id);
      setTableOrders(orders);
      
      const pendingOrders = orders.filter(order => order.status === 'pending');
      const completedOrders = orders.filter(order => order.status === 'completed');
      
      console.log(`Table ${table.name} has ${pendingOrders.length} pending orders and ${completedOrders.length} completed orders`);
      
      setHasActiveOrders(pendingOrders.length > 0);
      setHasCompletedOrders(completedOrders.length > 0);
      
      if (pendingOrders.length > 0) {
        setActiveOrder(pendingOrders[0]);
      } else {
        setActiveOrder(null);
      }

      if (completedOrders.length > 0) {
        if (table.status !== 'waiting') {
          console.log(`Table ${table.name} has completed orders but status is ${table.status}. Updating to waiting...`);
          await onStatusChange(table.id, 'waiting');
        }
      }
      else if (pendingOrders.length > 0) {
        if (table.status !== 'occupied') {
          console.log(`Table ${table.name} has pending orders but status is ${table.status}. Updating to occupied...`);
          await onStatusChange(table.id, 'occupied');
        }
      }
    } catch (error) {
      console.error("Error checking table orders:", error);
    }
  };

  const fetchReservation = async () => {
    if (table.status !== 'reserved') {
      setReservation(null);
      return;
    }
    
    setIsLoadingReservation(true);
    try {
      const reservationData = await getReservationByTableId(table.id);
      console.log(`Fetched reservation for table ${table.id}:`, reservationData);
      setReservation(reservationData);
    } catch (error) {
      console.error(`Error fetching reservation for table ${table.id}:`, error);
    } finally {
      setIsLoadingReservation(false);
    }
  };

  const checkReservationStatus = async () => {
    try {
      if (table.status === 'occupied' || table.status === 'waiting') {
        return;
      }
      
      const reservation = await getReservationByTableId(table.id);
      console.log(`Checking reservation status for table ${table.id}:`, reservation);
      
      if (!reservation) {
        console.log(`No reservation found for table ${table.id}`);
        return;
      }
      
      const now = new Date();
      
      const reservationDate = typeof reservation.date === 'string' 
        ? new Date(reservation.date) 
        : new Date(reservation.date);
      
      const [hours, minutes] = reservation.time.split(':').map(Number);
      reservationDate.setHours(hours, minutes, 0, 0);
      
      const diffMs = reservationDate.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);
      
      console.log(`Table ${table.id} reservation time check:`, {
        now: now.toISOString(),
        reservationTime: reservationDate.toISOString(),
        diffHours,
        currentStatus: table.status
      });
      
      if (diffHours <= 3 && diffHours > -24 && table.status !== 'reserved') {
        console.log(`Table ${table.id} should be reserved now (${diffHours.toFixed(2)} hours to reservation)`);
        await onStatusChange(table.id, 'reserved');
      }
      else if ((diffHours > 3 && table.status === 'reserved') || 
               (diffHours <= -24 && table.status === 'reserved')) {
        console.log(`Table ${table.id} shouldn't be reserved yet or reservation expired, freeing table`);
        await onStatusChange(table.id, 'available');
      }
    } catch (error) {
      console.error(`Error checking reservation status for table ${table.id}:`, error);
    } finally {
      setLastReservationCheck(new Date());
    }
  };

  useEffect(() => {
    checkTableOrders();
    fetchReservation();
    checkReservationStatus();
    
    const handleOrdersUpdated = () => {
      console.log("Orders updated event received, checking table orders");
      checkTableOrders();
    };
    
    const handleReservationsUpdated = () => {
      console.log("Reservations updated event received, fetching reservation");
      fetchReservation();
      checkReservationStatus();
    };
    
    const handleOrderCompleted = (event: CustomEvent<{tableId: string, status: string, locationId?: string}>) => {
      const { tableId, status, locationId } = event.detail || {};
      console.log(`Order completed event received for table ${tableId}, status ${status}, locationId ${locationId}`);
      
      if (tableId === table.id) {
        console.log(`Refreshing orders for table ${table.id}`);
        checkTableOrders();
        
        if (status === 'waiting') {
          console.log(`Forcing table ${table.id} status to waiting`);
          onStatusChange(table.id, 'waiting');
        }
      }
    };
    
    const handleRoomsUpdated = (event: CustomEvent<{locationId?: string, tableId?: string, forceUpdate?: boolean}>) => {
      const { locationId, tableId, forceUpdate } = event.detail || {};
      console.log(`Rooms updated event received, locationId: ${locationId}, tableId: ${tableId}, forceUpdate: ${forceUpdate}, checking table orders`);
      
      const currentLocationId = getLocationId();
      
      const isForOurTable = tableId === table.id;
      const isLocationMatch = !locationId || !currentLocationId || locationId === currentLocationId;
      
      if ((isForOurTable || forceUpdate === true) && isLocationMatch) {
        console.log(`Refreshing orders for table ${table.id} due to rooms-updated event`);
        checkTableOrders();
        fetchReservation();
      }
    };
    
    const reservationCheckInterval = setInterval(() => {
      checkReservationStatus();
    }, 60000);
    
    window.addEventListener('orders-updated', handleOrdersUpdated);
    window.addEventListener('order-completed', handleOrderCompleted as EventListener);
    window.addEventListener('rooms-updated', handleRoomsUpdated as EventListener);
    window.addEventListener('reservations-updated', handleReservationsUpdated);
    
    return () => {
      clearInterval(reservationCheckInterval);
      window.removeEventListener('orders-updated', handleOrdersUpdated);
      window.removeEventListener('order-completed', handleOrderCompleted as EventListener);
      window.removeEventListener('rooms-updated', handleRoomsUpdated as EventListener);
      window.removeEventListener('reservations-updated', handleReservationsUpdated);
    };
  }, [table.id, table.status]);

  const formatSeats = (seats: number): string => {
    return `${seats} ${seats === 1 ? 'posto' : 'posti'}`;
  };

  const getStatusColor = (status: TableStatus): string => {
    switch (status) {
      case 'available':
        return 'border-green-300 shadow-green-200/50';
      case 'occupied':
        return 'border-red-300 shadow-red-200/50';
      case 'reserved':
        return 'border-blue-300 shadow-blue-200/50';
      case 'cleaning':
        return 'border-purple-300 shadow-purple-200/50';
      case 'maintenance':
        return 'border-orange-300 shadow-orange-200/50';
      case 'waiting':
        return 'border-yellow-300 shadow-yellow-200/50';
      default:
        return 'border-gray-300 shadow-gray-200/50';
    }
  };
  
  const getStatusText = (status: TableStatus): string => {
    switch (status) {
      case 'available':
        return 'Libero';
      case 'occupied':
        return 'Occupato';
      case 'reserved':
        return 'Prenotato';
      case 'cleaning':
        return 'Pulizia';
      case 'maintenance':
        return 'Manutenzione';
      case 'waiting':
        return 'In attesa';
      default:
        return 'Sconosciuto';
    }
  };
  
  const getTableShapeElement = (shape: string) => {
    const commonClassNames = "flex items-center justify-center mx-auto shadow-md border-2 border-gray-200 bg-white";
    
    switch (shape) {
      case 'round':
        return (
          <div className={`${commonClassNames} w-10 h-10 rounded-full`}>
            <span className="text-lg">⭕</span>
          </div>
        );
      case 'square':
        return (
          <div className={`${commonClassNames} w-10 h-10 rounded-md`}>
            <span className="text-lg">◼️</span>
          </div>
        );
      case 'rectangle':
        return (
          <div className={`${commonClassNames} w-14 h-8 rounded-md`}>
            <span className="text-lg">▬</span>
          </div>
        );
      default:
        return (
          <div className={`${commonClassNames} w-10 h-10 rounded-md`}>
            <span className="text-lg">❓</span>
          </div>
        );
    }
  };

  const handleEditClick = () => {
    onEdit(table);
  };

  const handleDeleteClick = () => {
    onDelete(table);
  };

  const handleCardClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowButtons(!showButtons);
  };

  const getStatusGradient = (status: TableStatus): string => {
    switch (status) {
      case 'available':
        return 'from-green-50 to-green-100';
      case 'occupied':
        return 'from-red-50 to-red-100';
      case 'reserved':
        return 'from-blue-50 to-blue-100';
      case 'cleaning':
        return 'from-purple-50 to-purple-100';
      case 'maintenance':
        return 'from-orange-50 to-orange-100';
      case 'waiting':
        return 'from-yellow-50 to-yellow-100';
      default:
        return 'from-gray-50 to-gray-100';
    }
  };
  
  const handleCreateOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowOrderDialog(true);
    setShowButtons(false);
  };
  
  const handleBookTable = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowReservationDialog(true);
    setShowButtons(false);
  };

  const handleOrderSubmit = (values: any) => {
    console.log("Order submitted:", values);
    
    toast({
      title: "Ordine inviato",
      description: `Ordine per il tavolo ${table.name} inviato con successo.`,
    });
    
    setShowOrderDialog(false);
    
    if (table.status === 'available' || table.status === 'reserved') {
      onStatusChange(table.id, 'occupied');
    }
  };

  const handlePrintPreBill = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsLoadingPrint(true);
    try {
      await printPreBill(table.id, table.name);
      toast({
        title: "Stampa preconto inviata",
        description: `Il preconto per il tavolo ${table.name} è stato inviato alla stampante.`
      });
    } catch (error) {
      console.error("Error printing pre-bill:", error);
      toast({
        title: "Errore di stampa",
        description: "Si è verificato un errore durante la stampa del preconto.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingPrint(false);
    }
  };

  const handleViewOrders = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/orders?tableId=${table.id}&tableName=${table.name}`);
  };

  const handleManageOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (activeOrder) {
      setShowEditOrderDialog(true);
    } else {
      navigate(`/orders?tableId=${table.id}&tableName=${table.name}`);
    }
  };

  const handleOrderDialogComplete = async () => {
    console.log(`Order dialog completed for table ${table.name} with status ${table.status}`);
    setShowEditOrderDialog(false);
    
    try {
      await checkTableOrders();
      
      if (hasCompletedOrders && !hasActiveOrders) {
        console.log(`Forcing table ${table.id} status to waiting after order dialog close`);
        await onStatusChange(table.id, 'waiting');
      }
    } catch (error) {
      console.error("Error refreshing table orders:", error);
    }
  };

  const handleReservationSuccess = () => {
    toast({
      title: "Prenotazione completata",
      description: `La prenotazione per il tavolo ${table.name} è stata completata con successo.`
    });
    
    if (table.status === 'available') {
      onStatusChange(table.id, 'reserved');
    }
    
    fetchReservation();
  };

  const handleCustomerArrived = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await onStatusChange(table.id, 'available');
      toast({
        title: "Cliente arrivato",
        description: `Il tavolo ${table.name} è stato aggiornato come disponibile`
      });
    } catch (error) {
      console.error("Error updating table status:", error);
      toast({
        title: "Errore",
        description: "Impossibile aggiornare lo stato del tavolo",
        variant: "destructive"
      });
    }
  };

  const handleFreeTable = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await onStatusChange(table.id, 'available');
      toast({
        title: "Tavolo liberato",
        description: `Il tavolo ${table.name} è stato liberato`
      });
    } catch (error) {
      console.error("Error updating table status:", error);
      toast({
        title: "Errore",
        description: "Impossibile liberare il tavolo",
        variant: "destructive"
      });
    }
  };

  const renderOverlayButtons = () => {
    if (table.status === 'reserved') {
      return (
        <>
          <Button 
            size="sm" 
            variant="secondary" 
            className="w-full bg-green-100 hover:bg-green-200 text-green-800"
            onClick={handleCustomerArrived}
          >
            <Users className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">Arrivato</span>
          </Button>
          
          <Button 
            size="sm" 
            variant="secondary" 
            className="w-full bg-blue-100 hover:bg-blue-200 text-blue-800"
            onClick={handleFreeTable}
          >
            <Unlock className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">Libera il tavolo</span>
          </Button>
          
          <Button 
            size="icon" 
            variant="ghost" 
            className="absolute top-1 right-1 h-6 w-6 bg-white/10 hover:bg-white/20"
            onClick={(e) => {
              e.stopPropagation();
              setShowButtons(false);
            }}
          >
            <X className="h-3 w-3" />
          </Button>
        </>
      );
    }
    
    if (hasActiveOrders || table.status === 'occupied') {
      return (
        <>
          <Button 
            size="sm" 
            variant="secondary" 
            className="w-full bg-blue-100 hover:bg-blue-200 text-blue-800"
            onClick={handleManageOrder}
          >
            <ClipboardEdit className="h-4 w-4 mr-1" />
            <span className="text-xs font-medium">Gestisci ordine</span>
          </Button>
          
          <Button 
            size="icon" 
            variant="ghost" 
            className="absolute top-1 right-1 h-6 w-6 bg-white/10 hover:bg-white/20"
            onClick={(e) => {
              e.stopPropagation();
              setShowButtons(false);
            }}
          >
            <X className="h-3 w-3" />
          </Button>
        </>
      );
    }
    
    if (table.status === 'waiting' || hasCompletedOrders) {
      return (
        <>
          <Button 
            size="sm" 
            variant="secondary" 
            className="w-full bg-yellow-100 hover:bg-yellow-200 text-yellow-800"
            onClick={handlePrintPreBill}
            disabled={isLoadingPrint}
          >
            <span className="text-xs font-medium">Stampa preconto</span>
          </Button>
          
          <Button 
            size="icon" 
            variant="ghost" 
            className="absolute top-1 right-1 h-6 w-6 bg-white/10 hover:bg-white/20"
            onClick={(e) => {
              e.stopPropagation();
              setShowButtons(false);
            }}
          >
            <X className="h-3 w-3" />
          </Button>
        </>
      );
    }
    
    return (
      <>
        <Button 
          size="sm" 
          variant="secondary" 
          className="w-full bg-green-100 hover:bg-green-200 text-green-800"
          onClick={handleCreateOrder}
        >
          <ShoppingCart className="h-4 w-4 mr-1" />
          <span className="text-xs font-medium">Ordina</span>
        </Button>
        
        <Button 
          size="sm" 
          variant="secondary" 
          className="w-full bg-blue-100 hover:bg-blue-200 text-blue-800"
          onClick={handleBookTable}
        >
          <Calendar className="h-4 w-4 mr-1" />
          <span className="text-xs font-medium">Prenota</span>
        </Button>
        
        <Button 
          size="icon" 
          variant="ghost" 
          className="absolute top-1 right-1 h-6 w-6 bg-white/10 hover:bg-white/20"
          onClick={(e) => {
            e.stopPropagation();
            setShowButtons(false);
          }}
        >
          <X className="h-3 w-3" />
        </Button>
      </>
    );
  };

  return (
    <>
      <Card 
        className={`p-2 border-2 cursor-pointer transform transition-all duration-200 
          ${getStatusColor(table.status)} relative overflow-hidden
          bg-gradient-to-br ${getStatusGradient(table.status)}
          shadow-md flex flex-col justify-between
        `}
        onClick={handleCardClick}
        data-table-id={table.id}
        style={{ width: '6cm', height: '6cm' }}
      >
        <div className="absolute top-2 left-2 flex gap-1 z-20">
          <Button
            size="icon"
            variant="secondary"
            className="h-7 w-7 bg-white/70 hover:bg-white"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(table);
            }}
            title="Modifica tavolo"
          >
            <PenSquare className="h-3 w-3" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-7 w-7 bg-white/70 hover:bg-red-100"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(table);
            }}
            title="Elimina tavolo"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>

        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="text-lg font-bold">{table.name}</div>
          <div className="text-xs font-medium">{formatSeats(table.seats)}</div>
          <div className={`text-xs py-1 px-2 rounded-full inline-block font-medium
            ${table.status === 'available' ? 'bg-green-200 text-green-800' : 
              table.status === 'occupied' ? 'bg-red-200 text-red-800' :
                table.status === 'reserved' ? 'bg-blue-200 text-blue-800' :
                  table.status === 'waiting' ? 'bg-yellow-200 text-yellow-800' :
                    table.status === 'cleaning' ? 'bg-purple-200 text-purple-800' :
                      table.status === 'maintenance' ? 'bg-orange-200 text-orange-800' :
                        'bg-gray-200 text-gray-800'
            }`}
          >
            {getStatusText(table.status)}
          </div>
          
          {table.status === 'reserved' && (
            <TableReservation
              reservation={reservation}
              isLoading={isLoadingReservation}
            />
          )}
        </div>

        {showButtons && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2 p-2 animate-in fade-in">
            {renderOverlayButtons()}
          </div>
        )}
      </Card>

      <TableOrderDialog
        table={table}
        open={showOrderDialog}
        onOpenChange={setShowOrderDialog}
        onSubmit={handleOrderSubmit}
      />

      {activeOrder && (
        <OrderDialog
          open={showEditOrderDialog}
          onOpenChange={setShowEditOrderDialog}
          table={table}
          orderId={activeOrder.id}
          onOrderComplete={handleOrderDialogComplete}
        />
      )}

      <AddReservationDialog
        open={showReservationDialog}
        onOpenChange={setShowReservationDialog}
        onSuccess={handleReservationSuccess}
        preselectedDate={new Date()}
        isEditing={false}
        preselectedTable={table.id}
        preselectedTableName={table.name}
      />
    </>
  );
};

export default TableComponent;
