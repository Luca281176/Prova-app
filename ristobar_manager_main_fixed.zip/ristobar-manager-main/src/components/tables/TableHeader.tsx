
import React from 'react';
import { Table } from '@/components/RoomGrid';
import { Button } from '@/components/ui/button';
import { PencilIcon, TrashIcon } from 'lucide-react';

interface TableHeaderProps {
  table: Table;
  onEditClick: () => void;
  onDeleteClick: () => void;
}

export const TableHeader: React.FC<TableHeaderProps> = ({
  table,
  onEditClick,
  onDeleteClick
}) => {
  return (
    <div className="flex justify-between items-center mb-2">
      <div className="font-bold text-base truncate max-w-[70%]" title={table.name}>{table.name}</div>
      <div className="flex items-center space-x-1">
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0 hover:bg-gray-200/70"
          onClick={(e) => {
            e.stopPropagation();
            onEditClick();
          }}
          title="Modifica tavolo"
        >
          <PencilIcon className="h-3.5 w-3.5" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 w-7 p-0 hover:bg-red-100 hover:text-red-500"
          onClick={(e) => {
            e.stopPropagation();
            onDeleteClick();
          }}
          title="Elimina tavolo"
        >
          <TrashIcon className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
};
