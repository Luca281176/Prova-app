import React, { useEffect, useState } from 'react';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { 
  Form, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormControl, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Table } from '@/components/RoomGrid';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { 
  ShoppingCart, 
  User, 
  Utensils, 
  List, 
  Clock,
  Plus,
  Minus,
  Trash2,
  PrinterIcon
} from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { loadMenuData, Category, Dish } from '@/services/menuService';
import { useStaff } from '@/contexts/StaffContext';
import { useToast } from '@/hooks/use-toast';
import { addOrder, OrderItem as ServiceOrderItem, Order } from '@/services/ordersService';

const orderSchema = z.object({
  covers: z.string().min(1, { message: "Inserisci il numero di coperti" }),
  operator: z.string().min(1, { message: "Seleziona un operatore" }),
  items: z.string().min(1, { message: "Inserisci almeno un articolo" }),
  notes: z.string().optional()
});

type OrderFormValues = z.infer<typeof orderSchema>;

interface TableOrderDialogProps {
  table: Table | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: OrderFormValues) => void;
  existingOrder?: Order;
}

interface OrderItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  priority: string;
  notes: string;
  price: number;
}

const priorities = [
  { id: '1', name: '1° uscita' },
  { id: '2', name: '2° uscita' },
  { id: '3', name: '3° uscita' },
  { id: '4', name: '4° uscita' },
  { id: '5', name: '5° uscita' }
];

const TableOrderDialog: React.FC<TableOrderDialogProps> = ({
  table,
  open,
  onOpenChange,
  onSubmit,
  existingOrder
}) => {
  const [menuCategories, setMenuCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedPriority, setSelectedPriority] = useState('1');
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  
  const { staff, loading: staffLoading } = useStaff();
  const { toast } = useToast();

  const form = useForm<OrderFormValues>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      covers: "1",
      operator: "",
      items: "",
      notes: ""
    }
  });

  useEffect(() => {
    if (existingOrder && open) {
      const convertedItems: OrderItem[] = existingOrder.items.map(item => ({
        id: `${item.menuItemId || 'unknown'}-${Date.now() + Math.random()}`,
        name: item.name,
        category: item.category || 'Sconosciuta',
        quantity: item.quantity,
        priority: item.priority || '1° uscita',
        notes: item.notes || '',
        price: item.price
      }));
      
      setOrderItems(convertedItems);
      updateItemsField(convertedItems);
      
      form.reset({
        covers: existingOrder.covers?.toString() || "1",
        operator: existingOrder.operatorId || "",
        items: convertedItems.map(item => 
          `${item.quantity}x ${item.name} (${item.category}) - Priorità: ${item.priority}${item.notes ? ` - Note: ${item.notes}` : ''}`
        ).join('\n'),
        notes: existingOrder.notes || ""
      });
    }
  }, [existingOrder, open, form]);

  useEffect(() => {
    if (open) {
      try {
        const menuData = loadMenuData();
        setMenuCategories(menuData);
        
        if (menuData.length > 0) {
          setSelectedCategory(menuData[0]);
          setDishes(menuData[0].dishes.filter(dish => dish.available));
        }
        
        if (!existingOrder) {
          form.reset({
            covers: "1",
            operator: "",
            items: "",
            notes: ""
          });
          setOrderItems([]);
        }
      } catch (error) {
        console.error('Error loading menu data:', error);
        toast({
          title: "Errore",
          description: "Impossibile caricare i dati del menu",
          variant: "destructive"
        });
      }
    }
  }, [open, form, toast, existingOrder]);

  useEffect(() => {
    if (selectedCategory) {
      setDishes(selectedCategory.dishes.filter(dish => dish.available));
    } else {
      setDishes([]);
    }
  }, [selectedCategory]);

  const handleCategorySelect = (category: Category) => {
    setSelectedCategory(category);
  };
  
  const handlePrioritySelect = (priority: string) => {
    setSelectedPriority(priority);
  };

  const handleDishSelect = (dish: Dish) => {
    const priorityName = priorities.find(p => p.id === selectedPriority)?.name || '1° uscita';
    const categoryName = selectedCategory?.name || 'Sconosciuta';
    
    const existingItemIndex = orderItems.findIndex(
      item => item.name === dish.name && item.priority === priorityName
    );
    
    if (existingItemIndex >= 0) {
      const updatedItems = [...orderItems];
      updatedItems[existingItemIndex].quantity += 1;
      setOrderItems(updatedItems);
      updateItemsField(updatedItems);
    } else {
      const newItem: OrderItem = {
        id: `${dish.id}-${Date.now()}`,
        name: dish.name,
        category: categoryName,
        quantity: 1,
        priority: priorityName,
        notes: '',
        price: dish.price
      };
      
      const newItems = [...orderItems, newItem];
      setOrderItems(newItems);
      updateItemsField(newItems);
    }
  };

  const handleOperatorSelect = (operatorId: string) => {
    form.setValue("operator", operatorId);
  };

  const handleQuantityChange = (itemId: string, change: number, event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    
    const newItems = orderItems.map(item => {
      if (item.id === itemId) {
        const newQuantity = item.quantity + change;
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : item;
      }
      return item;
    }).filter(item => item.quantity > 0);
    
    setOrderItems(newItems);
    updateItemsField(newItems);
  };

  const handleRemoveItem = (itemId: string, event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    
    const newItems = orderItems.filter(item => item.id !== itemId);
    setOrderItems(newItems);
    updateItemsField(newItems);
  };

  const handleUpdateNotes = (itemId: string, notes: string) => {
    const newItems = orderItems.map(item => 
      item.id === itemId ? { ...item, notes } : item
    );
    setOrderItems(newItems);
    updateItemsField(newItems);
  };

  const updateItemsField = (items: OrderItem[]) => {
    const itemsText = items.map(item => 
      `${item.quantity}x ${item.name} (${item.category}) - Priorità: ${item.priority}${item.notes ? ` - Note: ${item.notes}` : ''}`
    ).join('\n');
    
    form.setValue("items", itemsText);
  };

  const handlePrintKitchenOrder = (orderItems: OrderItem[]) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Errore di stampa",
        description: "Non è stato possibile aprire la finestra di stampa. Controllare le impostazioni del browser.",
        variant: "destructive"
      });
      return;
    }

    const now = new Date();
    const dateFormatted = now.toLocaleDateString('it-IT');
    const timeFormatted = now.toLocaleTimeString('it-IT');
    
    const groupedItems = {};
    orderItems.forEach(item => {
      if (!groupedItems[item.priority]) {
        groupedItems[item.priority] = [];
      }
      groupedItems[item.priority].push(item);
    });
    
    const sortedPriorities = Object.keys(groupedItems).sort((a, b) => {
      if (a === 'non-specificato') return 1;
      if (b === 'non-specificato') return -1;
      return parseInt(a) - parseInt(b);
    });

    const operatorId = form.getValues("operator");
    const operatorName = staff.find(s => s.id === operatorId)
      ? `${staff.find(s => s.id === operatorId)?.firstName || ''} ${staff.find(s => s.id === operatorId)?.lastName || ''}`
      : 'Non specificato';

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Comanda - Tavolo ${table?.name || ''}</title>
        <style>
          body {
            font-family: 'Courier New', monospace;
            width: 300px;
            margin: 0 auto;
            padding: 10px;
          }
          .header, .footer {
            text-align: center;
            margin-bottom: 10px;
          }
          .divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
          }
          .item {
            margin-bottom: 5px;
          }
          .notes {
            font-style: italic;
            font-size: 0.9em;
            margin-left: 10px;
          }
          .priority-header {
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 5px;
            text-decoration: underline;
          }
          .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
          }
          @media print {
            body {
              width: 100%;
              max-width: 300px;
            }
            button {
              display: none;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h2>COMANDA PER CUCINA</h2>
        </div>
        
        <div class="info-row">
          <span>Data:</span>
          <span>${dateFormatted}</span>
        </div>
        <div class="info-row">
          <span>Ora:</span>
          <span>${timeFormatted}</span>
        </div>
        <div class="info-row">
          <span>Tavolo:</span>
          <span>${table?.name || ''}</span>
        </div>
        <div class="info-row">
          <span>Operatore:</span>
          <span>${operatorName}</span>
        </div>
        
        <div class="divider"></div>
    `);
    
    sortedPriorities.forEach(priority => {
      const priorityLabel = priority === 'non-specificato' 
        ? 'Senza priorità' 
        : `${priority}`;
      
      printWindow.document.write(`
        <div class="priority-header">${priorityLabel}</div>
      `);
      
      groupedItems[priority].forEach(item => {
        printWindow.document.write(`
          <div class="item">
            <strong>${item.quantity}x ${item.name}</strong>
          </div>
        `);
        
        if (item.notes) {
          printWindow.document.write(`
            <div class="notes">→ ${item.notes}</div>
          `);
        }
      });
    });
    
    printWindow.document.write(`
        <div class="divider"></div>
        <div class="footer">
          <p>Comanda per cucina</p>
        </div>
        
        <div style="text-align: center; margin-top: 20px;">
          <button onclick="window.print();return false;">Stampa</button>
          <button onclick="window.close();return false;">Chiudi</button>
        </div>
      </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => { printWindow.print(); }, 500);
  };

  const handleSubmit = async (values: OrderFormValues) => {
    if (orderItems.length === 0) {
      toast({
        title: "Errore",
        description: "Aggiungi almeno un articolo all'ordine",
        variant: "destructive"
      });
      return;
    }
    
    handlePrintKitchenOrder(orderItems);
    
    if (table) {
      try {
        const operatorId = values.operator;
        const operatorName = staff.find(s => s.id === operatorId)
          ? `${staff.find(s => s.id === operatorId)?.firstName || ''} ${staff.find(s => s.id === operatorId)?.lastName || ''}`
          : 'Non specificato';
        
        const serviceItems: ServiceOrderItem[] = orderItems.map(item => ({
          menuItemId: item.id.split('-')[0],
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          notes: item.notes,
          priority: item.priority
        }));
        
        const total = serviceItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        await addOrder({
          tableId: table.id,
          tableName: table.name,
          items: serviceItems,
          total,
          timestamp: new Date().toISOString(),
          status: 'pending',
          operatorName
        });
        
        console.log("Order saved successfully");
        toast({
          title: "Ordine salvato",
          description: `L'ordine per il tavolo ${table.name} è stato salvato con successo.`,
        });
      } catch (error) {
        console.error("Error saving order:", error);
        toast({
          title: "Errore",
          description: "Si è verificato un errore durante il salvataggio dell'ordine.",
          variant: "destructive"
        });
      }
    }
    
    onSubmit(values);
    form.reset();
    setOrderItems([]);
  };

  const groupedItems: Record<string, OrderItem[]> = {};
  orderItems.forEach(item => {
    if (!groupedItems[item.priority]) {
      groupedItems[item.priority] = [];
    }
    groupedItems[item.priority].push(item);
  });

  const sortedPriorities = Object.keys(groupedItems).sort((a, b) => {
    if (a === 'non-specificato') return 1;
    if (b === 'non-specificato') return -1;
    return parseInt(a) - parseInt(b);
  });

  const isViewingExistingOrder = !!existingOrder;

  const handleIncrementCover = () => {
    const current = parseInt(form.getValues("covers"), 10) || 1;
    form.setValue("covers", (current + 1).toString());
  };

  const handleDecrementCover = () => {
    const current = parseInt(form.getValues("covers"), 10) || 1;
    if (current > 1) {
      form.setValue("covers", (current - 1).toString());
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-blue-600" />
            {isViewingExistingOrder ? "Dettagli Ordine" : "Nuovo Ordine"} {table && `- Tavolo ${table.name}`}
          </DialogTitle>
          <DialogDescription>
            {isViewingExistingOrder 
              ? `Visualizza o modifica l'ordine per il tavolo ${table?.name || ''}`
              : `Inserisci i dettagli dell'ordine per il tavolo ${table?.name || ''}`
            }
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[70vh]">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 px-1">
              {/* Coperti con pulsanti + e - */}
              <div className="flex items-center gap-4 bg-muted/30 p-4 rounded-md border">
                <FormLabel className="flex items-center gap-1 whitespace-nowrap">
                  <Utensils className="h-4 w-4" /> Coperti
                </FormLabel>
                <div className="flex items-center">
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="icon" 
                    className="h-10 w-10"
                    onClick={handleDecrementCover}
                  >
                    <Minus className="h-5 w-5" />
                  </Button>
                  <FormField
                    control={form.control}
                    name="covers"
                    render={({ field }) => (
                      <FormControl>
                        <Input 
                          className="w-16 text-center mx-2 text-lg font-bold" 
                          {...field} 
                          readOnly 
                        />
                      </FormControl>
                    )}
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="icon" 
                    className="h-10 w-10"
                    onClick={handleIncrementCover}
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Operatori come pulsanti */}
              <div className="bg-muted/30 p-4 rounded-md border">
                <FormLabel className="flex items-center gap-1 mb-2">
                  <User className="h-4 w-4" /> Operatori
                </FormLabel>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {staffLoading ? (
                    <div className="col-span-full text-center py-2">Caricamento operatori...</div>
                  ) : staff.length === 0 ? (
                    <div className="col-span-full text-center py-2">Nessun operatore disponibile</div>
                  ) : (
                    staff.map(member => (
                      <Button
                        key={member.id}
                        type="button"
                        variant={form.getValues("operator") === member.id ? "default" : "outline"}
                        className="h-auto py-2 px-3 justify-start"
                        onClick={() => handleOperatorSelect(member.id)}
                      >
                        <div className="flex flex-col items-start">
                          <span className="text-sm font-medium">{member.firstName} {member.lastName}</span>
                          <span className="text-xs opacity-70">{member.role}</span>
                        </div>
                      </Button>
                    ))
                  )}
                </div>
              </div>

              {/* Categorie come pulsanti */}
              <div className="bg-muted/30 p-4 rounded-md border">
                <FormLabel className="flex items-center gap-1 mb-2">
                  <List className="h-4 w-4" /> Categorie
                </FormLabel>
                <ScrollArea className="h-[70px] pr-2">
                  <div className="flex flex-wrap gap-2">
                    {menuCategories.map(category => (
                      <Button
                        key={category.id}
                        type="button"
                        variant={selectedCategory?.id === category.id ? "default" : "outline"}
                        className="h-auto py-2 px-3"
                        onClick={() => handleCategorySelect(category)}
                      >
                        {category.name}
                      </Button>
                    ))}
                  </div>
                </ScrollArea>
              </div>
              
              {/* Priorità come pulsanti */}
              <div className="bg-muted/30 p-4 rounded-md border">
                <FormLabel className="flex items-center gap-1 mb-2">
                  <Clock className="h-4 w-4" /> Priorità di uscita
                </FormLabel>
                <div className="flex flex-wrap gap-2">
                  {priorities.map(priority => (
                    <Button
                      key={priority.id}
                      type="button"
                      variant={selectedPriority === priority.id ? "default" : "outline"}
                      className="h-auto py-2 px-3"
                      onClick={() => handlePrioritySelect(priority.id)}
                    >
                      {priority.name}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Piatti come pulsanti */}
              <div className="bg-muted/30 p-4 rounded-md border">
                <FormLabel className="mb-2">Piatti disponibili</FormLabel>
                {dishes.length === 0 ? (
                  <div className="py-4 text-center text-muted-foreground">
                    Nessun piatto disponibile in questa categoria
                  </div>
                ) : (
                  <ScrollArea className="h-[200px] pr-2">
                    <div className="grid grid-cols-2 gap-2">
                      {dishes.filter(dish => dish.available).map(dish => (
                        <Button
                          key={dish.id}
                          type="button"
                          variant="outline"
                          className="h-auto py-2 px-3 justify-start"
                          onClick={() => handleDishSelect(dish)}
                        >
                          <div className="flex flex-col items-start">
                            <span className="font-medium">{dish.name}</span>
                            <span className="text-xs text-muted-foreground">€{dish.price.toFixed(2)}</span>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </div>

              {/* Articoli ordinati */}
              {orderItems.length > 0 && (
                <div className="bg-muted/30 p-4 rounded-md space-y-4 border">
                  <h3 className="text-lg font-medium">Articoli ordinati</h3>
                  
                  {Object.entries(groupedItems).map(([priority, items]) => (
                    <div key={priority} className="space-y-2">
                      <h4 className="text-md font-semibold">{priority}</h4>
                      
                      {items.map((item) => (
                        <div key={item.id} className="border-b last:border-0 pb-3 mb-3">
                          <div className="flex justify-between items-center">
                            <div className="font-medium text-lg">{item.name}</div>
                            <div className="flex items-center gap-2">
                              <Button 
                                type="button" 
                                variant="outline" 
                                size="icon" 
                                className="h-10 w-10"
                                onClick={(e) => handleQuantityChange(item.id, -1, e)}
                              >
                                <Minus className="h-5 w-5" />
                              </Button>
                              <span className="w-8 text-center text-lg font-bold">{item.quantity}</span>
                              <Button 
                                type="button"
                                variant="outline" 
                                size="icon" 
                                className="h-10 w-10"
                                onClick={(e) => handleQuantityChange(item.id, 1, e)}
                              >
                                <Plus className="h-5 w-5" />
                              </Button>
                              <Button 
                                type="button"
                                variant="ghost" 
                                size="icon" 
                                className="h-10 w-10 text-destructive"
                                onClick={(e) => handleRemoveItem(item.id, e)}
                              >
                                <Trash2 className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                          
                          {item.notes && (
                            <div className="mt-1 text-sm italic text-gray-600">
                              Note: {item.notes}
                            </div>
                          )}
                          
                          <div className="mt-2">
                            <Input
                              placeholder="Aggiungi note..."
                              className="h-9 text-sm"
                              value={item.notes}
                              onChange={(e) => handleUpdateNotes(item.id, e.target.value)}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}

              {/* Campo nascosto per items */}
              <FormField
                control={form.control}
                name="items"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <Textarea {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter className="pb-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => onOpenChange(false)}
                  className="px-6 py-6 text-lg"
                >
                  Annulla
                </Button>
                <Button 
                  type="submit"
                  className="px-6 py-6 text-lg"
                  disabled={orderItems.length === 0 || !form.getValues("operator")}
                >
                  <PrinterIcon className="mr-2 h-5 w-5" />
                  {isViewingExistingOrder ? "Ristampa e Aggiorna" : "Stampa e Conferma"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default TableOrderDialog;
