
import { CalendarIcon, ClockIcon, PhoneIcon } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import { Reservation } from "@/types/reservations";
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { useEffect, useState } from "react";

interface TableReservationProps {
  reservation: Reservation | null;
  isLoading: boolean;
}

export function TableReservation({ reservation, isLoading }: TableReservationProps) {
  const [isWithinThreeHours, setIsWithinThreeHours] = useState<boolean>(false);
  
  useEffect(() => {
    if (!reservation) return;
    
    // Check if the reservation time is within 3 hours
    const checkReservationTime = () => {
      if (!reservation || !reservation.time) return false;
      
      const now = new Date();
      const [hours, minutes] = reservation.time.split(':').map(Number);
      
      // Create a date object with the reservation time
      // Ensure we're using the actual reservation date, not today's date
      const reservationDate = typeof reservation.date === 'string' 
        ? new Date(reservation.date) 
        : new Date(reservation.date);
      
      reservationDate.setHours(hours, minutes, 0, 0);
      
      // Calculate time difference in milliseconds
      const diffMs = reservationDate.getTime() - now.getTime();
      const diffHours = diffMs / (1000 * 60 * 60);
      
      console.log(`Reservation time check for ${reservation.customerName}:`, {
        reservationTime: reservationDate.toLocaleString(),
        currentTime: now.toLocaleString(),
        diffHours,
        shouldShow: diffHours <= 3 && diffHours > -24
      });
      
      // Return true if reservation is within 3 hours
      return diffHours <= 3 && diffHours > -24; // Show if within 3 hours and not more than 24 hours past
    };
    
    const updateTimeCheck = () => {
      const shouldShow = checkReservationTime();
      console.log(`Should show reservation for ${reservation.customerName}:`, shouldShow);
      setIsWithinThreeHours(shouldShow);
    };
    
    // Check immediately
    updateTimeCheck();
    
    // Set up interval to check every minute
    const intervalId = setInterval(updateTimeCheck, 60000);
    
    return () => clearInterval(intervalId);
  }, [reservation]);
  
  // Always log the current state for debugging
  useEffect(() => {
    if (reservation) {
      console.log(`TableReservation component state:`, {
        customerName: reservation.customerName,
        date: reservation.date,
        time: reservation.time,
        isLoading,
        isWithinThreeHours,
        tableId: reservation.tableId
      });
    }
  }, [reservation, isLoading, isWithinThreeHours]);
  
  if (isLoading) {
    return (
      <div className="mt-3 pt-3 border-t border-gray-100 flex justify-center">
        <Spinner size="sm" />
      </div>
    );
  }
  
  if (!reservation) {
    return null;
  }
  
  // Convert reservation.date to Date object if it's a string
  const reservationDate = typeof reservation.date === 'string' 
    ? new Date(reservation.date) 
    : reservation.date;
  
  return (
    <div className="mt-3 pt-3 border-t border-gray-100">
      <h4 className="text-xs font-medium mb-1 flex items-center">
        <CalendarIcon className="h-3 w-3 mr-1" />
        Prenotazione:
      </h4>
      <div className="space-y-1">
        <p className="text-sm font-medium">{reservation.customerName}</p>
        <div className="flex items-center text-xs text-muted-foreground">
          <CalendarIcon className="h-3 w-3 mr-1" />
          <span>
            {format(reservationDate, "EEEE d MMMM", { locale: it })}
          </span>
        </div>
        <div className="flex items-center text-xs text-muted-foreground">
          <ClockIcon className="h-3 w-3 mr-1" />
          <span>
            Ore {reservation.time} • {reservation.partySize} persone
          </span>
        </div>
        <div className="flex items-center text-xs text-muted-foreground">
          <PhoneIcon className="h-3 w-3 mr-1" />
          <span>{reservation.phone}</span>
        </div>
        {reservation.status === 'confirmed' && (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Confermata
          </span>
        )}
        {reservation.status === 'pending' && (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            In attesa
          </span>
        )}
      </div>
    </div>
  );
}
