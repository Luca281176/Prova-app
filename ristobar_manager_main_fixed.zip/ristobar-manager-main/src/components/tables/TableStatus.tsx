
import { Users2Icon } from "lucide-react";
import { Table } from "../RoomGrid";

interface TableStatusProps {
  table: Table;
  status: Table['status'];
}

export function TableStatus({ table, status }: TableStatusProps) {
  const getStatusColor = (status: Table['status']) => {
    switch (status) {
      case 'available':
        return 'bg-green-500/10 text-green-600 border-green-200';
      case 'occupied':
        return 'bg-red-500/10 text-red-600 border-red-200';
      case 'reserved':
        return 'bg-blue-500/10 text-blue-600 border-blue-200';
      case 'waiting':
        return 'bg-yellow-500/10 text-yellow-600 border-yellow-200';
      case 'maintenance':
        return 'bg-gray-500/10 text-gray-600 border-gray-200';
      default:
        return 'bg-gray-500/10 text-gray-600 border-gray-200';
    }
  };

  const getStatusText = (status: Table['status']) => {
    switch (status) {
      case 'available':
        return 'Libero';
      case 'occupied':
        return 'Occupato';
      case 'reserved':
        return 'Prenotato';
      case 'waiting':
        return 'In attesa';
      case 'maintenance':
        return 'Manutenzione';
      default:
        return 'Sconosciuto';
    }
  };

  const getStatusIcon = (status: Table['status']) => {
    switch (status) {
      case 'available':
        return '🟢';
      case 'occupied':
        return '🔴';
      case 'reserved':
        return '🔵';
      case 'waiting':
        return '🟡';
      case 'maintenance':
        return '⚠️';
      default:
        return '❓';
    }
  };

  return (
    <>
      <div className="flex items-center text-sm text-foreground/70 mb-3">
        <Users2Icon className="h-4 w-4 mr-1" />
        <span>{table.seats} posti</span>
        
        {table.assignedTo && (
          <span className="ml-auto text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
            {table.assignedTo}
          </span>
        )}
      </div>
      
      <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(status)}`}>
        {getStatusIcon(status)} {getStatusText(status)}
      </div>
    </>
  );
}
