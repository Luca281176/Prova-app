
import { useEffect, useState } from 'react';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { supabase } from '@/integrations/supabase/client';

export function TenantContextInfo() {
  const { currentTenant } = useTenant();
  const [validContext, setValidContext] = useState<boolean | null>(null);
  const [isVerifying, setIsVerifying] = useState(true);
  const [verificationMessage, setVerificationMessage] = useState('Verificando il contesto tenant...');
  const [jwtTenantId, setJwtTenantId] = useState<string | null>(null);

  useEffect(() => {
    const verifyTenantContext = async () => {
      if (!currentTenant) {
        setValidContext(false);
        setVerificationMessage('Nessun tenant attivo. L\'isolamento dati potrebbe non funzionare correttamente.');
        setIsVerifying(false);
        return;
      }

      try {
        // Get tenant ID from JWT
        const { data } = await supabase.auth.getSession();
        const sessionTenantId = data.session?.user?.user_metadata?.tenant_id || 
                               data.session?.user?.app_metadata?.tenant_id;
        
        setJwtTenantId(sessionTenantId || null);
        
        // Verifica se il tenant configurato in memoria corrisponde a quello memorizzato in JWT
        if (!sessionTenantId) {
          setValidContext(false);
          setVerificationMessage('Errore: tenant_id non trovato nel JWT. Il Multi-Tenant non funzionerà correttamente.');
          console.error('Tenant context verification failed: No tenant ID in JWT');
          setIsVerifying(false);
          return;
        }
        
        // Retrieve actual info from database as well
        const supabaseTenantInfo = await tenantModule.getCurrentTenantInfo();
        
        if (!supabaseTenantInfo) {
          setValidContext(false);
          setVerificationMessage('Errore: tenant non configurato correttamente in Supabase.');
          console.error('Tenant context verification failed: No tenant in Supabase');
          setIsVerifying(false);
          return;
        }

        // Verifica che l'ID del tenant corrisponda
        if (supabaseTenantInfo.id !== currentTenant.id) {
          setValidContext(false);
          setVerificationMessage(`Errore di sincronizzazione: il tenant in memoria (${currentTenant.id}) non corrisponde a quello in Supabase (${supabaseTenantInfo.id}).`);
          console.error('Tenant context verification failed: ID mismatch', {
            memoryTenant: currentTenant.id,
            supabaseTenant: supabaseTenantInfo.id
          });
        } else if (sessionTenantId !== currentTenant.id) {
          setValidContext(false);
          setVerificationMessage(`Errore di sincronizzazione: il tenant in memoria (${currentTenant.id}) non corrisponde a quello nel JWT (${sessionTenantId}).`);
          console.error('Tenant context verification failed: JWT mismatch', {
            memoryTenant: currentTenant.id,
            jwtTenant: sessionTenantId
          });
        } else {
          setValidContext(true);
          setVerificationMessage(`Contesto tenant verificato: ${currentTenant.name} (${currentTenant.id})`);
          console.log('Tenant context verified successfully', {
            tenant: currentTenant.name,
            id: currentTenant.id,
            jwt: sessionTenantId
          });
        }
      } catch (error) {
        console.error('Error verifying tenant context:', error);
        setValidContext(false);
        setVerificationMessage('Errore durante la verifica del contesto tenant.');
      } finally {
        setIsVerifying(false);
      }
    };

    if (currentTenant) {
      verifyTenantContext();
    } else {
      setIsVerifying(false);
      setValidContext(false);
      setVerificationMessage('Nessun tenant attivo.');
    }
  }, [currentTenant]);

  if (isVerifying) {
    return (
      <Alert className="mb-4 bg-blue-50 border-blue-200">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800">Verifica del contesto in corso</AlertTitle>
        <AlertDescription className="text-blue-700">
          {verificationMessage}
        </AlertDescription>
      </Alert>
    );
  }

  if (validContext === false) {
    return (
      <Alert variant="destructive" className="mb-4">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Contesto non valido</AlertTitle>
        <AlertDescription>
          {verificationMessage}
          {jwtTenantId && currentTenant && (
            <div className="mt-2 text-xs font-mono">
              <div>JWT tenant_id: {jwtTenantId}</div>
              <div>Memory tenant_id: {currentTenant.id}</div>
            </div>
          )}
        </AlertDescription>
      </Alert>
    );
  }

  if (validContext === true) {
    return (
      <Alert className="mb-4 bg-green-50 border-green-200">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertTitle className="text-green-800">Contesto tenant verificato</AlertTitle>
        <AlertDescription className="text-green-700">
          {verificationMessage}
          {jwtTenantId && (
            <div className="mt-2 text-xs font-mono">
              <div>JWT tenant_id: {jwtTenantId}</div>
            </div>
          )}
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}
