import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { testRLSIsolation, TestResult } from '@/services/tenantIsolationTest';
import { Badge } from '@/components/ui/badge';
import { Loader2, ShieldCheck, ShieldAlert, Info, KeyRound, FileText, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Button as ButtonUi } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

export function TenantIsolationTest() {
  const { currentTenant } = useTenant();
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [jwtMetadata, setJwtMetadata] = useState<any>(null);
  const [isSyncingTenant, setSyncingTenant] = useState(false);
  const [authStatus, setAuthStatus] = useState<'checking' | 'authenticated' | 'unauthenticated'>('checking');

  useEffect(() => {
    const checkAuth = async () => {
      try {
        setAuthStatus('checking');
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          setAuthStatus('authenticated');
          setJwtMetadata(data.session.user?.user_metadata || null);
        } else {
          setAuthStatus('unauthenticated');
          setJwtMetadata(null);
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
        setAuthStatus('unauthenticated');
      }
    };

    checkAuth();
  }, [currentTenant]);

  const refreshSession = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.auth.refreshSession();
      
      if (error) {
        console.error('Error refreshing session:', error);
        toast.error('Impossibile aggiornare la sessione: ' + error.message);
        return;
      }
      
      if (data?.session) {
        setJwtMetadata(data.session.user?.user_metadata || null);
        toast.success('Sessione aggiornata con successo');
      }
    } catch (error) {
      console.error('Exception refreshing session:', error);
      toast.error('Errore durante l\'aggiornamento della sessione');
    } finally {
      setIsLoading(false);
    }
  };

  const runTest = async () => {
    if (!currentTenant) {
      toast.error("Nessun tenant attivo. Effettua il login prima di eseguire il test.");
      return;
    }

    setIsLoading(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) {
        toast.error("Sessione di autenticazione non valida. Effettua il login e riprova.");
        setIsLoading(false);
        return;
      }
      
      const tenantIdFromJwt = sessionData.session.user?.user_metadata?.tenant_id;
      
      if (!tenantIdFromJwt) {
        toast.warning("Il tenant ID non è presente nel JWT. Prova a sincronizzare prima di eseguire il test.");
      }
      
      if (tenantIdFromJwt && tenantIdFromJwt !== currentTenant.id) {
        toast.warning("Il tenant ID nel JWT non corrisponde a quello nel contesto. Sincronizzazione consigliata.");
      }
      
      setJwtMetadata(sessionData.session.user?.user_metadata || null);
      
      const result = await testRLSIsolation(currentTenant.id);
      setTestResult(result);
      
      if (result.success) {
        toast.success(result.message);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error("Errore durante il test:", error);
      toast.error("Si è verificato un errore durante il test");
    } finally {
      setIsLoading(false);
    }
  };

  const syncTenantId = async () => {
    if (!currentTenant) return;
    
    setSyncingTenant(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) {
        toast.error("Impossibile sincronizzare il tenant: sessione non trovata. Effettua il login e riprova.");
        setSyncingTenant(false);
        return;
      }
      
      const success = await tenantModule.setTenantId(currentTenant.id, currentTenant.name, currentTenant.slug);
      
      if (success) {
        toast.success("Tenant ID sincronizzato correttamente nel JWT");
        
        const { data: refreshData } = await supabase.auth.refreshSession();
        setJwtMetadata(refreshData.session?.user?.user_metadata || null);
      } else {
        setTimeout(async () => {
          const retrySuccess = await tenantModule.setTenantId(currentTenant.id, currentTenant.name, currentTenant.slug);
          
          if (retrySuccess) {
            toast.success("Tenant ID sincronizzato correttamente nel JWT (secondo tentativo)");
            
            const { data: refreshData } = await supabase.auth.refreshSession();
            setJwtMetadata(refreshData.session?.user?.user_metadata || null);
          } else {
            toast.error("Impossibile sincronizzare il Tenant ID dopo ripetuti tentativi");
          }
          
          setSyncingTenant(false);
        }, 1000);
        return;
      }
    } catch (error) {
      console.error("Errore durante la sincronizzazione:", error);
      toast.error("Si è verificato un errore durante la sincronizzazione");
    } finally {
      setSyncingTenant(false);
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">Test Isolamento Multi-Tenant</CardTitle>
          {testResult && (
            <Badge variant={testResult.success ? "success" : "destructive"} className="ml-2">
              {testResult.success ? "Successo" : "Fallito"}
            </Badge>
          )}
        </div>
        <CardDescription>
          Verifica che l'isolamento Row-Level Security (RLS) nel database Supabase stia funzionando correttamente 
          e che un tenant non possa accedere ai dati di un altro tenant.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {authStatus === 'checking' ? (
          <div className="flex items-center justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin mr-2" />
            <span>Verifica dello stato di autenticazione...</span>
          </div>
        ) : authStatus === 'unauthenticated' ? (
          <div className="p-4 rounded-md bg-yellow-50 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300">
            <div className="flex items-start gap-2">
              <Info className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="font-medium">Autenticazione richiesta</h4>
                <p className="text-sm mt-1 opacity-90">
                  Effettua il login per eseguire il test di isolamento tenant.
                </p>
              </div>
            </div>
          </div>
        ) : currentTenant ? (
          <div className="p-3 bg-primary/10 rounded-md">
            <p className="text-sm font-medium">Tenant ID corrente: <span className="font-mono">{currentTenant.id}</span></p>
            <p className="text-sm font-medium">Nome tenant: {currentTenant.name}</p>
            <div className="mt-2 flex gap-2">
              <ButtonUi 
                variant="outline" 
                size="sm"
                onClick={syncTenantId}
                disabled={isSyncingTenant}
              >
                {isSyncingTenant ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sincronizzazione...
                  </>
                ) : (
                  <>
                    <KeyRound className="mr-2 h-4 w-4" />
                    Sincronizza ID nel JWT
                  </>
                )}
              </ButtonUi>
              
              <ButtonUi
                variant="secondary"
                size="sm"
                onClick={refreshSession}
                disabled={isLoading}
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Aggiorna sessione
              </ButtonUi>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-md bg-yellow-50 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300">
            <div className="flex items-start gap-2">
              <Info className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="font-medium">Nessun tenant attivo</h4>
                <p className="text-sm mt-1 opacity-90">
                  Effettua il login per eseguire il test di isolamento tenant.
                </p>
              </div>
            </div>
          </div>
        )}
        
        {jwtMetadata && (
          <div className="p-3 bg-gray-100 rounded-md dark:bg-gray-800">
            <h4 className="text-sm font-medium mb-2">Metadati JWT:</h4>
            <pre className="text-xs overflow-x-auto p-2 bg-gray-200 rounded dark:bg-gray-700">
              {JSON.stringify(jwtMetadata, null, 2)}
            </pre>
          </div>
        )}
        
        {testResult && (
          <div className={`p-4 rounded-md ${
            testResult.success 
              ? 'bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-300' 
              : 'bg-red-50 text-red-800 dark:bg-red-900/20 dark:text-red-300'
          }`}>
            <div className="flex items-start gap-3">
              {testResult.success 
                ? <ShieldCheck className="h-5 w-5 mt-0.5" /> 
                : <ShieldAlert className="h-5 w-5 mt-0.5" />
              }
              <div>
                <h4 className="font-medium">{testResult.message}</h4>
                {testResult.details && (
                  <p className="text-sm mt-2 opacity-90">{testResult.details}</p>
                )}
              </div>
            </div>
          </div>
        )}
        
        {testResult && testResult.jwt && (
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="jwt">
              <AccordionTrigger className="text-sm font-medium">
                <div className="flex items-center gap-2">
                  <KeyRound className="h-4 w-4" />
                  Dettagli Token JWT
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <pre className="text-xs overflow-x-auto p-2 bg-gray-100 rounded dark:bg-gray-800">
                  {JSON.stringify(testResult.jwt, null, 2)}
                </pre>
              </AccordionContent>
            </AccordionItem>
            
            {testResult.policies && (
              <AccordionItem value="policies">
                <AccordionTrigger className="text-sm font-medium">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Politiche RLS Attive
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <pre className="text-xs overflow-x-auto p-2 bg-gray-100 rounded dark:bg-gray-800">
                    {JSON.stringify(testResult.policies, null, 2)}
                  </pre>
                </AccordionContent>
              </AccordionItem>
            )}
          </Accordion>
        )}
      </CardContent>
      
      <CardFooter>
        <Button 
          onClick={runTest} 
          disabled={isLoading || !currentTenant || authStatus !== 'authenticated'}
          className="w-full"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Test in corso...
            </>
          ) : (
            'Esegui Test Isolamento RLS'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
