
import { useEffect, useState } from 'react';
import { Navigate, useLocation, useParams } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { useUser } from '@/contexts/user';
import { Layout } from '@/components/ui/layout';
import { toast } from 'sonner';
import AuthService from '@/services/authService';
import { clearAllUserData } from '@/contexts/user/storageUtils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircleIcon } from 'lucide-react';
import { TenantContextInfo } from './TenantContextInfo';

interface TenantLayoutProps {
  children: React.ReactNode;
  requiresAuth?: boolean;
  requiresAdmin?: boolean;
  allowedRoles?: string[];
  showContextInfo?: boolean;
}

export function TenantLayout({ 
  children, 
  requiresAuth = true,
  requiresAdmin = false,
  allowedRoles = [],
  showContextInfo = false
}: TenantLayoutProps) {
  const { user, isLoading: isUserLoading, isAdmin } = useUser();
  const { currentTenant, isLoading: isTenantLoading, setCurrentTenant } = useTenant();
  const location = useLocation();
  const params = useParams();
  const [redirectTo, setRedirectTo] = useState<string | null>(null);
  const [securityError, setSecurityError] = useState<string | null>(null);
  
  const isLoading = isUserLoading || isTenantLoading;
  
  // Verify if user has valid token
  const checkAuth = async () => {
    try {
      return await AuthService.isAuthenticated();
    } catch (error) {
      console.error("Error checking authentication:", error);
      return false;
    }
  };

  // Validate tenant access
  const validateTenantAccess = async () => {
    if (!user || !user.id) return false;
    
    try {
      // In a real application, we would make a backend call to validate access
      if (params.tenantSlug && currentTenant) {
        // Here we should verify that the user has access to the requested tenant
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error validating tenant access:", error);
      return false;
    }
  };

  // Try to load tenant if we have tenant slug in params but no current tenant
  useEffect(() => {
    if (params.tenantSlug && !currentTenant && user && !isTenantLoading) {
      console.log("Creating tenant from user data in TenantLayout");
      
      try {
        const slug = params.tenantSlug;
        const id = user.id;
        const name = user.restaurantName || 'Restaurant';
        
        setCurrentTenant({
          id: id,
          name: name,
          slug: slug,
          schemaName: `tenant_${id}`,
          storagePath: `tenant_${id}`
        });
      } catch (error) {
        console.error("Failed to create tenant:", error);
        setSecurityError("Impossibile creare il contesto tenant. Accesso negato.");
      }
    }
  }, [params.tenantSlug, currentTenant, user, isTenantLoading, setCurrentTenant]);

  // Auth checks and redirects
  useEffect(() => {
    const runSecurityChecks = async () => {
      // Only run checks if we're not already loading
      if (!isLoading) {
        let newRedirectTo: string | null = null;
        
        // Check authentication
        const hasValidToken = await checkAuth();
        
        // If requires auth but no token or user
        if (requiresAuth && (!hasValidToken || !user)) {
          console.log("Auth required but user not authenticated, redirecting to login");
          
          // Clear all tenant data to ensure we don't have data leakage
          clearAllUserData();
          
          newRedirectTo = "/login";
        }
        // If user is auth but no tenant and not on dashboard
        else if (requiresAuth && user && !currentTenant && !params.tenantSlug && location.pathname !== "/dashboard") {
          console.log("User authenticated but no tenant context, redirecting to dashboard");
          newRedirectTo = "/dashboard";
        }
        // If route requires admin privileges and user isn't admin
        else if (requiresAdmin && !isAdmin()) {
          console.log('User is not admin, redirecting to dashboard');
          setSecurityError("Questa pagina richiede privilegi amministrativi.");
          newRedirectTo = "/dashboard";
        }
        // If specific roles required and user doesn't have one
        else if (allowedRoles.length > 0 && user && !allowedRoles.includes(user.role)) {
          console.log(`User role ${user.role} not allowed, redirecting to dashboard`);
          setSecurityError(`Accesso negato. Il tuo ruolo (${user.role}) non ha permessi sufficienti.`);
          newRedirectTo = "/dashboard";
        }
        // If tenant access validation fails
        else if (requiresAuth && currentTenant && !(await validateTenantAccess())) {
          console.log('Tenant access validation failed');
          setSecurityError("Non hai il permesso di accedere a questo tenant.");
          newRedirectTo = "/dashboard";
        }
        
        // Only update redirectTo if it's changing to avoid loops
        if (newRedirectTo !== redirectTo) {
          setRedirectTo(newRedirectTo);
        }
      }
    };

    runSecurityChecks();
  }, [isLoading, requiresAuth, user, currentTenant, params.tenantSlug, location.pathname, requiresAdmin, isAdmin, allowedRoles, redirectTo]);

  // Show loading state while checking authentication and tenant
  if (isLoading) {
    return (
      <Layout>
        <div className="flex flex-col w-full p-8 gap-4">
          <Skeleton className="h-10 w-[250px]" />
          <Skeleton className="h-6 w-[180px]" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
          <Skeleton className="h-80 w-full mt-6" />
        </div>
      </Layout>
    );
  }

  // Handle redirects
  if (redirectTo) {
    console.log(`Redirecting to: ${redirectTo}`);
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }

  // Show security error if present
  if (securityError) {
    toast.error(securityError);
    return <Navigate to="/dashboard" state={{ from: location }} replace />;
  }

  // If all checks pass, render the children
  return (
    <Layout>
      {showContextInfo && currentTenant && <TenantContextInfo />}
      {children}
    </Layout>
  );
}

export default TenantLayout;
