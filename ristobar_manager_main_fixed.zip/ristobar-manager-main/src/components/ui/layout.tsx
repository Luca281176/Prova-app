
import { ReactNode } from 'react';
import Navbar from '@/components/Navbar';
import SubscriptionBanner from '@/components/subscriptions/SubscriptionBanner';

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      
      <main className="flex-1 px-4 sm:px-6 md:px-8 py-6 pt-24">
        <SubscriptionBanner />
        {children}
      </main>
      
      <footer className="border-t py-4 px-4 sm:px-6 md:px-8">
        <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Risto Bar Manager. Tutti i diritti riservati.
          </p>
          <div className="mt-2 sm:mt-0 text-sm text-muted-foreground">
            <span className="mr-2">Versione 1.0.0</span>
            <a href="/privacy" className="hover:text-primary">Privacy</a>
            <span className="mx-2">·</span>
            <a href="/terms" className="hover:text-primary">Termini</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
