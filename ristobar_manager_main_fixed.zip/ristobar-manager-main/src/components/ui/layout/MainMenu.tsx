
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useUser } from '@/contexts/user';
import { hasAccess } from '@/services/subscriptions/featureAccess';
import { 
  HomeIcon,
  LayoutPanelLeft, 
  CalendarIcon, 
  ListOrderedIcon, 
  TruckIcon,
  UsersIcon, 
  SettingsIcon, 
  LogOutIcon, 
  HelpCircleIcon,
  ClipboardListIcon,
  BarChart2Icon,
  CreditCardIcon,
  TagIcon,
  DatabaseIcon,
  CogIcon,
  StarIcon
} from 'lucide-react';

interface MainMenuProps {
  collapsed?: boolean;
}

const MainMenu = ({ collapsed = false }: MainMenuProps) => {
  const location = useLocation();
  const { user, logout } = useUser();

  // Determine the active route
  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  // Check feature access with debugging
  const checkAccess = (feature: string) => {
    const hasFeature = hasAccess(user?.subscription, feature);
    console.log(`Menu check - Feature: ${feature}, Access: ${hasFeature}, User subscription:`, user?.subscription);
    return hasFeature;
  };

  return (
    <div className={cn(
      "px-3 flex flex-col h-full",
      collapsed ? "items-center" : "items-stretch"
    )}>
      <ScrollArea className="flex-1">
        <div className={cn(
          "space-y-1",
          collapsed ? "items-center" : "items-stretch"
        )}>
          <p className={cn(
            "text-xs uppercase text-muted-foreground pb-2 mt-3",
            collapsed ? "sr-only" : ""
          )}>
            Navigazione
          </p>
          <MenuItem 
            icon={<HomeIcon className="w-5 h-5" />} 
            label="Dashboard" 
            path="/" 
            isActive={isActive('/')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<LayoutPanelLeft className="w-5 h-5" />} 
            label="Sale e Tavoli" 
            path="/rooms" 
            isActive={isActive('/rooms')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<ClipboardListIcon className="w-5 h-5" />} 
            label="Menu" 
            path="/menu" 
            isActive={isActive('/menu')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<ListOrderedIcon className="w-5 h-5" />} 
            label="Ordini" 
            path="/orders" 
            isActive={isActive('/orders')} 
            collapsed={collapsed} 
          />
          
          {checkAccess('reservations') && (
            <MenuItem 
              icon={<CalendarIcon className="w-5 h-5" />} 
              label="Prenotazioni" 
              path="/reservations" 
              isActive={isActive('/reservations')} 
              collapsed={collapsed} 
            />
          )}
          
          {checkAccess('inventoryManagement') && (
            <MenuItem 
              icon={<TruckIcon className="w-5 h-5" />} 
              label="Magazzino" 
              path="/inventory" 
              isActive={isActive('/inventory')} 
              collapsed={collapsed} 
            />
          )}
          
          {checkAccess('staffManagement') && (
            <MenuItem 
              icon={<UsersIcon className="w-5 h-5" />} 
              label="Personale" 
              path="/staff" 
              isActive={isActive('/staff')} 
              collapsed={collapsed} 
            />
          )}
          
          {checkAccess('advancedAnalytics') && (
            <MenuItem 
              icon={<BarChart2Icon className="w-5 h-5" />} 
              label="Analisi" 
              path="/analytics" 
              isActive={isActive('/analytics')} 
              collapsed={collapsed} 
            />
          )}
          
          <p className={cn(
            "text-xs uppercase text-muted-foreground py-2 mt-2",
            collapsed ? "sr-only" : ""
          )}>
            Account
          </p>
          
          <MenuItem 
            icon={<CreditCardIcon className="w-5 h-5" />} 
            label="Abbonamento" 
            path="/subscriptions" 
            isActive={isActive('/subscriptions')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<SettingsIcon className="w-5 h-5" />} 
            label="Impostazioni" 
            path="/settings" 
            isActive={isActive('/settings')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<HelpCircleIcon className="w-5 h-5" />} 
            label="Supporto" 
            path="/support" 
            isActive={isActive('/support')} 
            collapsed={collapsed} 
          />
          
          <p className={cn(
            "text-xs uppercase text-muted-foreground py-2 mt-2",
            collapsed ? "sr-only" : ""
          )}>
            Test e Sviluppo
          </p>
          
          <MenuItem 
            icon={<StarIcon className="w-5 h-5" />} 
            label="Test Pagamenti" 
            path="/payment-test" 
            isActive={isActive('/payment-test')} 
            collapsed={collapsed} 
          />
          
          <MenuItem 
            icon={<CogIcon className="w-5 h-5" />} 
            label="Marketing" 
            path="/marketing" 
            isActive={isActive('/marketing')} 
            collapsed={collapsed} 
          />
          
          <div className="pt-4">
            <button
              onClick={logout}
              className={cn(
                "flex items-center w-full px-3 py-2 text-sm rounded-md hover:bg-muted",
                collapsed ? "justify-center" : "justify-start"
              )}
            >
              <LogOutIcon className="w-5 h-5 me-2" />
              {!collapsed && <span>Esci</span>}
            </button>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

interface MenuItemProps {
  icon: React.ReactNode;
  label: string;
  path: string;
  isActive: boolean;
  collapsed: boolean;
}

const MenuItem = ({ icon, label, path, isActive, collapsed }: MenuItemProps) => {
  return (
    <Button
      variant="ghost"
      asChild
      className={cn(
        "w-full justify-start",
        isActive ? "bg-muted" : "hover:bg-transparent",
        collapsed ? "px-2" : "px-3"
      )}
    >
      <Link to={path} className={cn(
        "flex items-center",
        collapsed ? "justify-center" : "justify-start"
      )}>
        {icon}
        {!collapsed && <span className="ml-2">{label}</span>}
      </Link>
    </Button>
  );
};

export default MainMenu;
