import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  getInventoryItems,
  getSuppliers,
  getOrders,
  getNotifications,
  addInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  addSupplier,
  updateSupplier,
  deleteSupplier,
  createOrder,
  updateOrderStatus,
  addNotification,
  markNotificationAsRead,
  setupInventorySyncListeners
} from '@/services/inventoryService';

// Define unit of measure type
export type UnitOfMeasure = 'kg' | 'g' | 'l' | 'ml' | 'pcs' | 'box';

// Define item category type
export type InventoryItemCategory = 
  | 'food-fresh' 
  | 'food-frozen' 
  | 'food-dry' 
  | 'beverages-alcoholic' 
  | 'beverages-non-alcoholic' 
  | 'cleaning' 
  | 'equipment' 
  | 'other';

// Inventory item type
export type InventoryItem = {
  id: string;
  name: string;
  category: InventoryItemCategory;
  quantity: number;
  unit: string;
  unitOfMeasure?: string; // For backward compatibility
  minStockLevel: number;
  minQuantity?: number; // For backward compatibility
  supplier: string;
  unitPrice: number;
  expiryDate?: string;
  expirationDate?: string; // For backward compatibility
  location?: string;
  barcode?: string;
  createdAt: string;
  updatedAt: string;
};

// Supplier type
export type Supplier = {
  id: string;
  name: string;
  contactName?: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
};

// Order status type
export type OrderStatus = 'pending' | 'in-transit' | 'delivered' | 'cancelled';

// Order type
export type InventoryOrder = {
  id: string;
  supplierId: string;
  supplierName: string;
  items: Array<{
    itemId: string;
    name: string;
    quantity: number;
    unitPrice: number;
  }>;
  status: OrderStatus;
  totalAmount: number;
  orderDate: string;
  expectedDeliveryDate?: string;
  actualDeliveryDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
};

// Notification type
export type NotificationType = 'low-stock' | 'expiring' | 'order-updated' | 'general';

// Notification object
export type InventoryNotification = {
  id: string;
  message: string;
  type: NotificationType;
  read: boolean;
  createdAt: string;
};

// Context type
type InventoryContextType = {
  items: InventoryItem[];
  suppliers: Supplier[];
  orders: InventoryOrder[];
  notifications: InventoryNotification[];
  loading: boolean;
  error: string | null;
  addItem: (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>) => Promise<InventoryItem>;
  updateItem: (id: string, item: Partial<InventoryItem>) => Promise<InventoryItem>;
  deleteItem: (id: string) => Promise<boolean>;
  addSupplier: (supplier: Omit<Supplier, 'id'>) => Promise<Supplier>;
  updateSupplier: (id: string, supplier: Partial<Supplier>) => Promise<Supplier>;
  deleteSupplier: (id: string) => Promise<boolean>;
  createOrder: (order: Omit<InventoryOrder, 'id' | 'createdAt' | 'updatedAt'>) => Promise<InventoryOrder>;
  updateOrderStatus: (id: string, status: OrderStatus) => Promise<InventoryOrder>;
  addNotification: (message: string, type: NotificationType) => Promise<InventoryNotification>;
  markNotificationAsRead: (id: string) => Promise<boolean>;
  getLowStockItems: () => InventoryItem[];
  getExpiringItems: () => InventoryItem[];
  refreshInventory: () => Promise<void>;
};

// Initial empty arrays for context
const initialItems: InventoryItem[] = [];
const initialSuppliers: Supplier[] = [];
const initialOrders: InventoryOrder[] = [];
const initialNotifications: InventoryNotification[] = [];

// Create context with default values
const InventoryContext = createContext<InventoryContextType>({
  items: initialItems,
  suppliers: initialSuppliers,
  orders: initialOrders,
  notifications: initialNotifications,
  loading: false,
  error: null,
  addItem: () => Promise.resolve({} as InventoryItem),
  updateItem: () => Promise.resolve({} as InventoryItem),
  deleteItem: () => Promise.resolve(false),
  addSupplier: () => Promise.resolve({} as Supplier),
  updateSupplier: () => Promise.resolve({} as Supplier),
  deleteSupplier: () => Promise.resolve(false),
  createOrder: () => Promise.resolve({} as InventoryOrder),
  updateOrderStatus: () => Promise.resolve({} as InventoryOrder),
  addNotification: () => Promise.resolve({} as InventoryNotification),
  markNotificationAsRead: () => Promise.resolve(false),
  getLowStockItems: () => [],
  getExpiringItems: () => [],
  refreshInventory: () => Promise.resolve(),
});

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<InventoryItem[]>(initialItems);
  const [suppliers, setSuppliers] = useState<Supplier[]>(initialSuppliers);
  const [orders, setOrders] = useState<InventoryOrder[]>(initialOrders);
  const [notifications, setNotifications] = useState<InventoryNotification[]>(initialNotifications);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Function to load all inventory data
  const loadInventoryData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const [loadedItems, loadedSuppliers, loadedOrders, loadedNotifications] = await Promise.all([
        getInventoryItems(initialItems),
        getSuppliers(initialSuppliers),
        getOrders(initialOrders),
        getNotifications(initialNotifications)
      ]);
      
      setItems(loadedItems);
      setSuppliers(loadedSuppliers);
      setOrders(loadedOrders);
      setNotifications(loadedNotifications);
    } catch (err) {
      console.error('Error loading inventory data:', err);
      setError('Errore durante il caricamento dei dati dell\'inventario');
    } finally {
      setLoading(false);
    }
  };

  // Initial data load
  useEffect(() => {
    loadInventoryData();
    
    // Setup listeners for cross-tab updates
    const cleanup = setupInventorySyncListeners((key) => {
      console.log('Inventory data updated in another tab, reloading...', key);
      loadInventoryData();
    });
    
    return cleanup;
  }, []);

  // Get items with stock levels below minimum
  const getLowStockItems = () => {
    return items.filter(item => 
      item.minStockLevel > 0 && item.quantity <= item.minStockLevel
    );
  };

  // Get items expiring within 14 days
  const getExpiringItems = () => {
    const today = new Date();
    const twoWeeksLater = new Date(today);
    twoWeeksLater.setDate(today.getDate() + 14);
    
    return items.filter(item => {
      // Check both expiryDate and expirationDate for backward compatibility
      const expiryDate = item.expiryDate || item.expirationDate;
      if (!expiryDate) return false;
      
      const expirationDate = new Date(expiryDate);
      return expirationDate <= twoWeeksLater && expirationDate >= today;
    });
  };

  // Handle adding item with property name normalization
  const handleAddItem = async (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      // Normalize property names
      const normalizedItem = {
        ...item,
        minStockLevel: item.minStockLevel || item.minQuantity || 0,
        unit: item.unit || item.unitOfMeasure || 'pcs',
        expiryDate: item.expiryDate || item.expirationDate,
      };
      
      const newItem = await addInventoryItem(normalizedItem);
      setItems((prevItems) => [...prevItems, newItem]);
      await handleAddNotification(
        `Nuovo prodotto aggiunto: ${newItem.name} (${newItem.quantity} ${newItem.unit})`,
        'general'
      );
      return newItem;
    } catch (err) {
      console.error('Error adding item:', err);
      setError('Errore durante l\'aggiunta del prodotto');
      throw err;
    }
  };

  // Update existing inventory item
  const handleUpdateItem = async (id: string, itemUpdate: Partial<InventoryItem>) => {
    try {
      const updatedItem = await updateInventoryItem(id, itemUpdate);
      setItems((prevItems) => 
        prevItems.map((item) => (item.id === id ? updatedItem : item))
      );
      
      // Check if quantity is updated and below min stock level
      if (
        'quantity' in itemUpdate && 
        updatedItem.minStockLevel > 0 &&
        updatedItem.quantity <= updatedItem.minStockLevel
      ) {
        await handleAddNotification(
          `Scorta bassa: ${updatedItem.name} (${updatedItem.quantity} ${updatedItem.unit})`,
          'low-stock'
        );
      }
      
      return updatedItem;
    } catch (err) {
      console.error('Error updating item:', err);
      setError('Errore durante l\'aggiornamento del prodotto');
      throw err;
    }
  };

  // Delete inventory item
  const handleDeleteItem = async (id: string) => {
    try {
      const success = await deleteInventoryItem(id);
      if (success) {
        const itemName = items.find(item => item.id === id)?.name || 'Prodotto';
        setItems((prevItems) => prevItems.filter((item) => item.id !== id));
        await handleAddNotification(
          `Prodotto eliminato: ${itemName}`,
          'general'
        );
      }
      return success;
    } catch (err) {
      console.error('Error deleting item:', err);
      setError('Errore durante l\'eliminazione del prodotto');
      throw err;
    }
  };

  // Add new supplier
  const handleAddSupplier = async (supplier: Omit<Supplier, 'id'>) => {
    try {
      const newSupplier = await addSupplier(supplier);
      setSuppliers((prevSuppliers) => [...prevSuppliers, newSupplier]);
      await handleAddNotification(
        `Nuovo fornitore aggiunto: ${newSupplier.name}`,
        'general'
      );
      return newSupplier;
    } catch (err) {
      console.error('Error adding supplier:', err);
      setError('Errore durante l\'aggiunta del fornitore');
      throw err;
    }
  };

  // Update existing supplier
  const handleUpdateSupplier = async (id: string, supplierUpdate: Partial<Supplier>) => {
    try {
      const updatedSupplier = await updateSupplier(id, supplierUpdate);
      setSuppliers((prevSuppliers) => 
        prevSuppliers.map((supplier) => (supplier.id === id ? updatedSupplier : supplier))
      );
      return updatedSupplier;
    } catch (err) {
      console.error('Error updating supplier:', err);
      setError('Errore durante l\'aggiornamento del fornitore');
      throw err;
    }
  };

  // Delete supplier
  const handleDeleteSupplier = async (id: string) => {
    try {
      const success = await deleteSupplier(id);
      if (success) {
        const supplierName = suppliers.find(supplier => supplier.id === id)?.name || 'Fornitore';
        setSuppliers((prevSuppliers) => prevSuppliers.filter((supplier) => supplier.id !== id));
        await handleAddNotification(
          `Fornitore eliminato: ${supplierName}`,
          'general'
        );
      }
      return success;
    } catch (err) {
      console.error('Error deleting supplier:', err);
      setError('Errore durante l\'eliminazione del fornitore');
      throw err;
    }
  };

  // Create new order
  const handleCreateOrder = async (order: Omit<InventoryOrder, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newOrder = await createOrder(order);
      setOrders((prevOrders) => [...prevOrders, newOrder]);
      await handleAddNotification(
        `Nuovo ordine creato: ${newOrder.supplierName} (€${newOrder.totalAmount.toFixed(2)})`,
        'general'
      );
      return newOrder;
    } catch (err) {
      console.error('Error creating order:', err);
      setError('Errore durante la creazione dell\'ordine');
      throw err;
    }
  };

  // Update order status
  const handleUpdateOrderStatus = async (id: string, status: OrderStatus) => {
    try {
      const updatedOrder = await updateOrderStatus(id, status);
      setOrders((prevOrders) => 
        prevOrders.map((order) => (order.id === id ? updatedOrder : order))
      );
      
      // Update inventory quantities if order is delivered
      if (status === 'delivered') {
        // Update inventory quantities for each item in the order
        const orderToUpdate = orders.find(order => order.id === id);
        if (orderToUpdate) {
          const itemUpdatePromises = orderToUpdate.items.map(async (orderItem) => {
            const inventoryItem = items.find(item => item.id === orderItem.itemId);
            if (inventoryItem) {
              const newQuantity = inventoryItem.quantity + orderItem.quantity;
              return handleUpdateItem(orderItem.itemId, { quantity: newQuantity });
            }
            return null;
          });
          
          await Promise.all(itemUpdatePromises.filter(Boolean));
        }
        
        await handleAddNotification(
          `Ordine consegnato: ${updatedOrder.supplierName}`,
          'order-updated'
        );
      } else if (status === 'cancelled') {
        await handleAddNotification(
          `Ordine annullato: ${updatedOrder.supplierName}`,
          'order-updated'
        );
      }
      
      return updatedOrder;
    } catch (err) {
      console.error('Error updating order status:', err);
      setError('Errore durante l\'aggiornamento dello stato dell\'ordine');
      throw err;
    }
  };

  // Add notification
  const handleAddNotification = async (message: string, type: NotificationType) => {
    try {
      const newNotification = await addNotification(message, type);
      setNotifications((prevNotifications) => [newNotification, ...prevNotifications]);
      return newNotification;
    } catch (err) {
      console.error('Error adding notification:', err);
      setError('Errore durante l\'aggiunta della notifica');
      throw err;
    }
  };

  // Mark notification as read
  const handleMarkNotificationAsRead = async (id: string) => {
    try {
      const success = await markNotificationAsRead(id);
      if (success) {
        setNotifications((prevNotifications) => 
          prevNotifications.map((notification) => 
            notification.id === id 
              ? { ...notification, read: true } 
              : notification
          )
        );
      }
      return success;
    } catch (err) {
      console.error('Error marking notification as read:', err);
      setError('Errore durante l\'aggiornamento della notifica');
      throw err;
    }
  };

  // Add the refreshInventory function that was missing
  const refreshInventory = async () => {
    return loadInventoryData();
  };

  const contextValue: InventoryContextType = {
    items,
    suppliers,
    orders,
    notifications,
    loading,
    error,
    addItem: handleAddItem,
    updateItem: handleUpdateItem,
    deleteItem: handleDeleteItem,
    addSupplier: handleAddSupplier,
    updateSupplier: handleUpdateSupplier,
    deleteSupplier: handleDeleteSupplier,
    createOrder: handleCreateOrder,
    updateOrderStatus: handleUpdateOrderStatus,
    addNotification: handleAddNotification,
    markNotificationAsRead: handleMarkNotificationAsRead,
    getLowStockItems,
    getExpiringItems,
    refreshInventory
  };

  return (
    <InventoryContext.Provider value={contextValue}>
      {children}
    </InventoryContext.Provider>
  );
};

// Custom hook to use the inventory context
export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};
