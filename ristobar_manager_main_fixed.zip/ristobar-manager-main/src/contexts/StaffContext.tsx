
import { createContext, useContext, useState, ReactNode, useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import * as staffService from '@/services/staffService';

// Staff member interface
export interface StaffMember {
  id: string;
  firstName: string;
  lastName: string;
  role: string;
  email: string;
  phone: string;
  hireDate: string;
  contractType: 'full-time' | 'part-time' | 'extra';
  salary: number;
  permissionLevel: 'manager' | 'waiter' | 'chef' | 'cashier' | 'bartender' | 'custom';
  customPermissions?: {
    orders: boolean;
    tables: boolean;
    kitchen: boolean;
    cash: boolean;
    staff: boolean;
    inventory: boolean;
    reports: boolean;
  };
}

// Shift interface with expanded status values
export interface Shift {
  id: string;
  staffId: string;
  date: string;
  startTime: string;
  endTime: string;
  confirmed: boolean;
  status: 'scheduled' | 'confirmed' | 'in-progress' | 'completed' | 'absent' | 'cancelled';
  notes?: string;
}

// Performance record interface with all required properties
export interface PerformanceRecord {
  id: string;
  staffId: string;
  date: string;
  tablesServed: number;
  ordersProcessed: number;
  averageOrderTime: number;
  sales: number;
  rating: number; // 1-5 rating
  notes?: string;
}

// Context interface
interface StaffContextType {
  staff: StaffMember[];
  shifts: Shift[];
  performance: PerformanceRecord[];
  loading: boolean;
  addStaffMember: (staffMember: Omit<StaffMember, 'id'>) => Promise<void>;
  updateStaffMember: (id: string, data: Partial<StaffMember>) => Promise<void>;
  removeStaffMember: (id: string) => Promise<void>;
  addShift: (shift: Omit<Shift, 'id'>) => Promise<void>;
  updateShift: (id: string, data: Partial<Shift>) => Promise<void>;
  removeShift: (id: string) => Promise<void>;
  addPerformanceRecord: (record: Omit<PerformanceRecord, 'id'>) => Promise<void>;
  updatePerformanceRecord: (id: string, data: Partial<PerformanceRecord>) => Promise<void>;
  refreshInventory: () => Promise<void>;
}

// Empty default data (removing all mock data)
const EMPTY_STAFF: StaffMember[] = [];
const EMPTY_SHIFTS: Shift[] = [];
const EMPTY_PERFORMANCE: PerformanceRecord[] = [];

// Create context
const StaffContext = createContext<StaffContextType | undefined>(undefined);

// Provider component
export const StaffProvider = ({ children }: { children: ReactNode }) => {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [performance, setPerformance] = useState<PerformanceRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();

  // Function to load all staff data
  const loadStaffData = useCallback(async () => {
    try {
      setLoading(true);
      
      // Use async/await syntax correctly for each service call
      const loadedStaff = await staffService.getStaffMembers(EMPTY_STAFF);
      const loadedShifts = await staffService.getShifts(EMPTY_SHIFTS);
      const loadedPerformance = await staffService.getPerformanceRecords(EMPTY_PERFORMANCE);

      console.log("Loaded staff data:", {
        staff: loadedStaff,
        shifts: loadedShifts,
        performance: loadedPerformance
      });

      setStaff(loadedStaff);
      setShifts(loadedShifts);
      setPerformance(loadedPerformance);
    } catch (error) {
      console.error('Error loading staff data:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore nel caricamento dei dati del personale.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // Function to refresh inventory data
  const refreshInventory = async () => {
    await loadStaffData();
  };

  // Load initial data from localStorage or use empty arrays as default
  useEffect(() => {
    loadStaffData();

    // Set up real-time sync between tabs/windows
    const cleanupSync = staffService.setupStaffSyncListeners((key) => {
      console.log('Storage changed, refreshing data for key:', key);
      
      if (key.includes('staff_members')) {
        staffService.getStaffMembers(EMPTY_STAFF).then(loadedStaff => {
          console.log("Synced staff members:", loadedStaff);
          setStaff(loadedStaff);
        });
      } else if (key.includes('staff_shifts')) {
        staffService.getShifts(EMPTY_SHIFTS).then(loadedShifts => {
          console.log("Synced shifts:", loadedShifts);
          setShifts(loadedShifts);
        });
      } else if (key.includes('staff_performance')) {
        staffService.getPerformanceRecords(EMPTY_PERFORMANCE).then(loadedPerformance => {
          console.log("Synced performance records:", loadedPerformance);
          setPerformance(loadedPerformance);
        });
      }
    });

    return () => cleanupSync();
  }, [loadStaffData, toast]);

  // Staff member functions
  const addStaffMember = async (staffMember: Omit<StaffMember, 'id'>) => {
    try {
      const newMember = await staffService.addStaffMember(staffMember);
      setStaff(prev => [...prev, newMember]);
      
      // Force re-save all staff to ensure persistence
      const updatedStaff = [...staff, newMember];
      await staffService.saveStaffMembers(updatedStaff);
      
      toast({
        title: "Dipendente aggiunto",
        description: `${staffMember.firstName} ${staffMember.lastName} è stato aggiunto con successo.`
      });
    } catch (error) {
      console.error('Error adding staff member:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta del dipendente.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateStaffMember = async (id: string, data: Partial<StaffMember>) => {
    try {
      const updatedMember = await staffService.updateStaffMember(id, data);
      
      setStaff(prev => 
        prev.map(member => member.id === id ? updatedMember : member)
      );
      
      toast({
        title: "Dipendente aggiornato",
        description: "Le informazioni del dipendente sono state aggiornate."
      });
    } catch (error) {
      console.error('Error updating staff member:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento del dipendente.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const removeStaffMember = async (id: string) => {
    try {
      const memberToRemove = staff.find(m => m.id === id);
      if (!memberToRemove) {
        throw new Error(`Staff member with ID ${id} not found`);
      }
      
      await staffService.deleteStaffMember(id);
      
      setStaff(prev => prev.filter(member => member.id !== id));
      // The service will handle removing related shifts and performance records
      // but we need to update our local state as well
      setShifts(prev => prev.filter(shift => shift.staffId !== id));
      setPerformance(prev => prev.filter(record => record.staffId !== id));
      
      toast({
        title: "Dipendente rimosso",
        description: `${memberToRemove.firstName} ${memberToRemove.lastName} è stato rimosso.`
      });
    } catch (error) {
      console.error('Error removing staff member:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la rimozione del dipendente.",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Shift functions
  const addShift = async (shift: Omit<Shift, 'id'>) => {
    try {
      const newShift = await staffService.addShift(shift);
      setShifts(prev => [...prev, newShift]);
      
      toast({
        title: "Turno aggiunto",
        description: "Il nuovo turno è stato aggiunto con successo."
      });
    } catch (error) {
      console.error('Error adding shift:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta del turno.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateShift = async (id: string, data: Partial<Shift>) => {
    try {
      // Ensure status is a valid value for both our types and the service
      const updatedData: Partial<Shift> = { ...data };
      
      // Make sure we send a valid status value
      if (updatedData.status && 
         !['scheduled', 'confirmed', 'in-progress', 'completed', 'absent', 'cancelled'].includes(updatedData.status)) {
        delete updatedData.status;
      }
      
      const updatedShift = await staffService.updateShift(id, updatedData);
      
      setShifts(prev => 
        prev.map(shift => shift.id === id ? updatedShift : shift)
      );
      
      toast({
        title: "Turno aggiornato",
        description: "Le informazioni del turno sono state aggiornate."
      });
    } catch (error) {
      console.error('Error updating shift:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento del turno.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const removeShift = async (id: string) => {
    try {
      await staffService.deleteShift(id);
      
      setShifts(prev => prev.filter(shift => shift.id !== id));
      
      toast({
        title: "Turno rimosso",
        description: "Il turno è stato rimosso con successo."
      });
    } catch (error) {
      console.error('Error removing shift:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la rimozione del turno.",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Performance functions
  const addPerformanceRecord = async (record: Omit<PerformanceRecord, 'id'>) => {
    try {
      // Ensure record has all the required fields for our types
      const completeRecord: Omit<PerformanceRecord, 'id'> = {
        staffId: record.staffId,
        date: record.date,
        tablesServed: record.tablesServed || 0,
        ordersProcessed: record.ordersProcessed || 0,
        averageOrderTime: record.averageOrderTime || 0,
        sales: record.sales || 0,
        rating: record.rating,
        notes: record.notes
      };
      
      const newRecord = await staffService.addPerformanceRecord(completeRecord);
      setPerformance(prev => [...prev, newRecord]);
      
      toast({
        title: "Performance registrata",
        description: "Il record di performance è stato aggiunto con successo."
      });
    } catch (error) {
      console.error('Error adding performance record:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiunta della performance.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updatePerformanceRecord = async (id: string, data: Partial<PerformanceRecord>) => {
    try {
      // Ensure we have all required fields even when updating partially
      const updatedData: Partial<PerformanceRecord> = {
        ...data,
        // Only include these fields if they're missing and we're not providing new values
        ...(data.tablesServed === undefined && !('tablesServed' in data) ? { tablesServed: 0 } : {}),
        ...(data.ordersProcessed === undefined && !('ordersProcessed' in data) ? { ordersProcessed: 0 } : {}),
        ...(data.averageOrderTime === undefined && !('averageOrderTime' in data) ? { averageOrderTime: 0 } : {}),
        ...(data.sales === undefined && !('sales' in data) ? { sales: 0 } : {})
      };
      
      const updatedRecord = await staffService.updatePerformanceRecord(id, updatedData);
      
      setPerformance(prev => 
        prev.map(record => record.id === id ? updatedRecord : record)
      );
      
      toast({
        title: "Performance aggiornata",
        description: "Il record di performance è stato aggiornato."
      });
    } catch (error) {
      console.error('Error updating performance record:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante l'aggiornamento della performance.",
        variant: "destructive"
      });
      throw error;
    }
  };

  const value = {
    staff,
    shifts,
    performance,
    loading,
    addStaffMember,
    updateStaffMember,
    removeStaffMember,
    addShift,
    updateShift,
    removeShift,
    addPerformanceRecord,
    updatePerformanceRecord,
    refreshInventory
  };

  return <StaffContext.Provider value={value}>{children}</StaffContext.Provider>;
};

// Hook to use the staff context
export const useStaff = () => {
  const context = useContext(StaffContext);
  
  if (context === undefined) {
    throw new Error('useStaff must be used within a StaffProvider');
  }
  
  return context;
};
