
// This file is maintained for backwards compatibility
// It re-exports everything from the refactored user context files
import { UserProvider, useUser } from '@/contexts/user/UserProvider';
import {
  getRegisteredUsers,
  saveRegisteredUsers,
  clearUserSpecificData,
  initializeRegisteredUsers,
  getUserStorageKey,
  saveUserDataToStorage,
  getUserData
} from '@/contexts/user/storageUtils';
import type { User, UserContextType } from '@/contexts/user/types';

export { 
  UserProvider,
  useUser,
  getRegisteredUsers,
  saveRegisteredUsers,
  clearUserSpecificData,
  initializeRegisteredUsers,
  getUserStorageKey,
  saveUserDataToStorage,
  getUserData,
  type User,
  type UserContextType
};
