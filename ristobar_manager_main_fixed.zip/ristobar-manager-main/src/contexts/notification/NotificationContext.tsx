
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/contexts/user';

export interface AdminNotification {
  id: string;
  type: 'user' | 'payment' | 'system' | 'alert';
  title: string;
  message: string;
  date: string;
  read: boolean;
  created_at?: string;
}

interface NotificationContextType {
  notifications: AdminNotification[];
  unreadCount: number;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  addNotification: (notification: Omit<AdminNotification, 'id' | 'date' | 'read' | 'created_at'>) => Promise<void>;
  isLoading: boolean;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasAttemptedFetch, setHasAttemptedFetch] = useState(false);
  const { toast } = useToast();
  const { user, isAdmin } = useUser();

  const fetchNotifications = async () => {
    // Only fetch notifications if the user is logged in and is an admin
    if (!user || !isAdmin()) {
      return;
    }

    // Prevent multiple fetch attempts if we've already tried once
    if (hasAttemptedFetch) {
      return;
    }

    try {
      setIsLoading(true);
      setHasAttemptedFetch(true);
      
      const { data, error } = await supabase
        .from('admin_notifications')
        .select('*')
        .order('date', { ascending: false });

      if (error) {
        console.error('Error fetching notifications:', error);
        // Silent error in login page, only show toast in admin pages
        if (window.location.pathname.includes('/admin')) {
          toast({
            title: "Errore",
            description: "Impossibile caricare le notifiche",
            variant: "destructive"
          });
        }
        return;
      }

      setNotifications(data || []);
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Reset hasAttemptedFetch when user changes
    if (user) {
      setHasAttemptedFetch(false);
    } else {
      // Clear notifications when user logs out
      setNotifications([]);
    }
  }, [user]);

  useEffect(() => {
    // Only fetch notifications if user is logged in and is admin
    if (user && isAdmin()) {
      fetchNotifications();
    }
  }, [user, isAdmin]);

  // Set up real-time subscription for new notifications only for admin users
  useEffect(() => {
    if (!user || !isAdmin()) return;

    const channel = supabase
      .channel('admin-notifications-changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'admin_notifications'
        }, 
        (payload) => {
          console.log('Notification change received:', payload);
          // Instead of refetching, handle the update directly based on the payload
          handleRealtimeUpdate(payload);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAdmin]);

  // Handle realtime updates directly instead of refetching all notifications
  const handleRealtimeUpdate = (payload: any) => {
    if (!payload || !payload.eventType) return;
    
    const { eventType, new: newRecord, old: oldRecord } = payload;
    
    switch (eventType) {
      case 'INSERT':
        if (newRecord) {
          setNotifications(prev => [newRecord, ...prev]);
        }
        break;
      case 'UPDATE':
        if (newRecord) {
          setNotifications(prev => 
            prev.map(item => item.id === newRecord.id ? newRecord : item)
          );
        }
        break;
      case 'DELETE':
        if (oldRecord) {
          setNotifications(prev => 
            prev.filter(item => item.id !== oldRecord.id)
          );
        }
        break;
      default:
        // For any other event, refresh the notifications
        if (user && isAdmin()) {
          setHasAttemptedFetch(false);
          fetchNotifications();
        }
    }
  };

  const markAsRead = async (id: string) => {
    if (!user || !isAdmin()) return;
    
    try {
      const { error } = await supabase
        .from('admin_notifications')
        .update({ read: true })
        .eq('id', id);

      if (error) {
        console.error('Error marking notification as read:', error);
        toast({
          title: "Errore",
          description: "Impossibile aggiornare la notifica",
          variant: "destructive"
        });
        return;
      }

      setNotifications(notifications.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      ));
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user || !isAdmin()) return;
    
    try {
      const { error } = await supabase
        .from('admin_notifications')
        .update({ read: true })
        .eq('read', false);

      if (error) {
        console.error('Error marking all notifications as read:', error);
        toast({
          title: "Errore",
          description: "Impossibile aggiornare le notifiche",
          variant: "destructive"
        });
        return;
      }

      setNotifications(notifications.map(notification => ({ ...notification, read: true })));
      toast({
        title: "Notifiche lette",
        description: "Tutte le notifiche sono state segnate come lette."
      });
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const deleteNotification = async (id: string) => {
    if (!user || !isAdmin()) return;
    
    try {
      const { error } = await supabase
        .from('admin_notifications')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting notification:', error);
        toast({
          title: "Errore",
          description: "Impossibile eliminare la notifica",
          variant: "destructive"
        });
        return;
      }

      setNotifications(notifications.filter(notification => notification.id !== id));
      toast({
        title: "Notifica eliminata",
        description: "La notifica è stata eliminata con successo."
      });
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const addNotification = async (notification: Omit<AdminNotification, 'id' | 'date' | 'read' | 'created_at'>) => {
    if (!user || !isAdmin()) return;
    
    try {
      const { error } = await supabase
        .from('admin_notifications')
        .insert({
          ...notification,
          read: false
        });

      if (error) {
        console.error('Error adding notification:', error);
        toast({
          title: "Errore",
          description: "Impossibile aggiungere la notifica",
          variant: "destructive"
        });
        return;
      }

      // The real-time subscription will update the notifications
      toast({
        title: "Notifica aggiunta",
        description: "La notifica è stata aggiunta con successo."
      });
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const unreadCount = notifications.filter(notification => !notification.read).length;

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      addNotification,
      isLoading
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
