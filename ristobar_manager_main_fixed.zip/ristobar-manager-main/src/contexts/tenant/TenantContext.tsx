
import { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { toast } from 'sonner';
import { useUser } from '@/contexts/user';
import { clearAllUserData, getUserDataSync, saveUserDataToStorage } from '@/contexts/user/storageUtils';
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  schemaName?: string;
  storagePath?: string;
}

interface TenantContextType {
  currentTenant: Tenant | null;
  isLoading: boolean;
  setCurrentTenant: (tenant: Tenant) => void;
  getTenantByUserId: (userId: string) => Tenant | null;
  getTenantSchema: () => string;
  getTenantStoragePath: () => string;
  clearTenant: () => void;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export function TenantProvider({ children }: { children: ReactNode }) {
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useUser();

  // Clear tenant when user changes to ensure data isolation
  useEffect(() => {
    if (!user) {
      clearTenant();
    }
  }, [user]);

  // Initialize tenant based on user
  useEffect(() => {
    const loadTenant = async () => {
      if (user) {
        setIsLoading(true);
        console.log("TenantProvider: Loading tenant data for user", user.id);
        
        try {
          // Check if we have existing tenant data for this user
          const tenantData = getUserDataSync(user.id, 'tenantData') as Tenant | null;
          
          if (tenantData && 'id' in tenantData && 'name' in tenantData && 'slug' in tenantData) {
            console.log(`TenantProvider: Loaded existing tenant: ${tenantData.name} (ID: ${tenantData.id})`);
            
            // Ensure we set the tenant_id in the session to maintain RLS
            const setResult = await tenantModule.setTenantId(tenantData.id, tenantData.name, tenantData.slug);
            
            if (setResult) {
              console.log(`TenantProvider: Successfully set tenant ID in JWT: ${tenantData.id}`);
              setCurrentTenant(tenantData);
            } else {
              console.warn("TenantProvider: Failed to set tenant ID in JWT, fetching updated tenant data");
              
              // Get the current tenant from auth metadata as fallback
              const { data } = await supabase.auth.getUser();
              const supabaseUser = data?.user;
              
              if (supabaseUser) {
                // Look for tenant_id in multiple places
                const userMetadata = supabaseUser.user_metadata || {};
                const appMetadata = supabaseUser.app_metadata || {};
                
                const tenantId = userMetadata.tenant_id || appMetadata.tenant_id || user.tenant_id;
                
                if (tenantId) {
                  console.log(`TenantProvider: Using tenant ID from auth metadata: ${tenantId}`);
                  const tenantName = userMetadata.tenant_name || appMetadata.tenant_name || user.restaurantName || 'Restaurant';
                  const tenantSlug = userMetadata.tenant_slug || appMetadata.tenant_slug || createSlugFromName(tenantName);
                  
                  const authTenant = {
                    id: tenantId,
                    name: tenantName,
                    slug: tenantSlug,
                    schemaName: `tenant_${tenantId}`,
                    storagePath: `tenant_${tenantId}`
                  };
                  
                  setCurrentTenant(authTenant);
                  saveUserDataToStorage(user.id, 'tenantData', authTenant);
                } else {
                  throw new Error("No tenant ID found in auth metadata");
                }
              } else {
                throw new Error("No authenticated user found");
              }
            }
          } else {
            console.log("TenantProvider: No valid tenant data in storage, checking auth metadata");
            
            // Get tenant ID from user's Supabase Auth metadata
            const { data } = await supabase.auth.getUser();
            const supabaseUser = data?.user;
            
            if (!supabaseUser) {
              console.error("TenantProvider: No authenticated user found in Supabase Auth");
              throw new Error("No authenticated user found");
            }
            
            const userMetadata = supabaseUser.user_metadata || {};
            const appMetadata = supabaseUser.app_metadata || {};
            
            // Enhanced tenant_id detection with clear logging
            const tenantId = userMetadata.tenant_id || appMetadata.tenant_id || user.tenant_id;
            
            if (!tenantId) {
              console.error("TenantProvider: No tenant_id found in metadata", { 
                userMetadata, 
                appMetadata,
                userObject: user
              });
              
              // Try to get tenant_id from database as fallback
              try {
                const { data: userData, error: dbError } = await supabase
                  .from('users')
                  .select('tenant_id')
                  .eq('id', user.id)
                  .single();
                  
                if (dbError || !userData?.tenant_id) {
                  console.error("TenantProvider: Failed to get tenant_id from database", dbError);
                  throw new Error("No tenant ID found for user. Access denied.");
                }
                
                console.log(`TenantProvider: Retrieved tenant ID from database: ${userData.tenant_id}`);
                
                // Create tenant from database info
                const dbTenant = {
                  id: userData.tenant_id,
                  name: user.restaurantName || 'Restaurant',
                  slug: createSlugFromName(user.restaurantName || 'Restaurant'),
                  schemaName: `tenant_${userData.tenant_id}`,
                  storagePath: `tenant_${userData.tenant_id}`
                };
                
                // Set the tenant ID in JWT for RLS policies
                const success = await tenantModule.setTenantId(userData.tenant_id, dbTenant.name, dbTenant.slug);
                
                if (!success) {
                  throw new Error("Failed to set tenant ID in JWT. Access denied.");
                }
                
                setCurrentTenant(dbTenant);
                saveUserDataToStorage(user.id, 'tenantData', dbTenant);
              } catch (dbError) {
                console.error("TenantProvider: Error getting tenant from database", dbError);
                toast.error("Errore di accesso al tenant. Riprova o contatta l'assistenza.");
                clearTenant();
                throw new Error("No tenant ID found for user. Access denied.");
              }
            } else {
              // Tenant ID found in auth metadata
              console.log(`TenantProvider: Found tenant ID in auth metadata: ${tenantId}`);
              
              const tenantName = userMetadata.tenant_name || appMetadata.tenant_name || user.restaurantName || 'Restaurant';
              const tenantSlug = userMetadata.tenant_slug || appMetadata.tenant_slug || createSlugFromName(tenantName);
              
              // Create tenant object from auth metadata
              const authTenant = {
                id: tenantId,
                name: tenantName,
                slug: tenantSlug,
                schemaName: `tenant_${tenantId}`,
                storagePath: `tenant_${tenantId}`
              };
              
              // Set the tenant ID in JWT for RLS
              const success = await tenantModule.setTenantId(tenantId, tenantName, tenantSlug);
              
              if (!success) {
                console.error("TenantProvider: Failed to set tenant ID in JWT");
                
                // Try one more time after a short delay
                setTimeout(async () => {
                  const retrySuccess = await tenantModule.setTenantId(tenantId, tenantName, tenantSlug);
                  if (!retrySuccess) {
                    console.error("TenantProvider: Failed to set tenant ID in JWT after retry");
                    toast.error("Errore di configurazione tenant. Riprova o contatta l'assistenza.");
                  }
                }, 1000);
              }
              
              setCurrentTenant(authTenant);
              saveUserDataToStorage(user.id, 'tenantData', authTenant);
            }
          }
        } catch (error) {
          console.error("TenantProvider: Error loading tenant:", error);
          toast.error("Errore durante il caricamento del tenant. Riprova.");
          clearTenant();
        } finally {
          setIsLoading(false);
        }
      } else {
        clearTenant();
        setIsLoading(false);
      }
    };
    
    loadTenant();
  }, [user]);

  // Sync tenant to Supabase auth metadata whenever it changes
  useEffect(() => {
    if (currentTenant && user) {
      // Store tenant in localStorage
      saveUserDataToStorage(user.id, 'tenantData', currentTenant);
      
      // Update auth metadata to maintain tenant info across sessions
      try {
        supabase.auth.updateUser({
          data: { 
            tenant_id: currentTenant.id,
            tenant_name: currentTenant.name,
            tenant_slug: currentTenant.slug
          }
        });
        console.log(`TenantProvider: Updated auth metadata with tenant: ${currentTenant.id}`);
      } catch (error) {
        console.error("TenantProvider: Failed to update auth metadata:", error);
      }
    }
  }, [currentTenant, user]);

  // Create a slug from a name
  const createSlugFromName = (name: string): string => {
    return name
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '');
  };

  // Clear tenant data
  const clearTenant = () => {
    setCurrentTenant(null);
    try {
      clearAllUserData();
    } catch (error) {
      console.error("TenantProvider: Error clearing tenant data:", error);
    }
  };

  // Create a tenant based on user ID
  const getTenantByUserId = (userId: string): Tenant | null => {
    if (!userId || !user) {
      console.warn("TenantProvider: Cannot create tenant without user ID");
      return null;
    }
    
    try {
      // Generate a unique tenant ID
      const newTenantId = crypto.randomUUID();
      console.log("TenantProvider: Generating new tenant ID:", newTenantId);
      
      // Create slug
      const slug = user.restaurantName
        ? createSlugFromName(user.restaurantName)
        : `tenant-${newTenantId.substring(0, 8)}`;
      
      const newTenant = {
        id: newTenantId,
        name: user.restaurantName || 'Restaurant',
        slug,
        schemaName: `tenant_${newTenantId}`,
        storagePath: `tenant_${newTenantId}`
      };
      
      return newTenant;
    } catch (error) {
      console.error("TenantProvider: Error creating tenant:", error);
      return null;
    }
  };

  // Get tenant database schema
  const getTenantSchema = (): string => {
    if (!currentTenant?.schemaName) {
      console.warn("TenantProvider: No tenant schema available, using public");
      return 'public';
    }
    return currentTenant.schemaName;
  };

  // Get tenant storage path
  const getTenantStoragePath = (): string => {
    if (!currentTenant?.storagePath) {
      console.warn("TenantProvider: No tenant storage path available, using public");
      return 'public';
    }
    return currentTenant.storagePath;
  };

  return (
    <TenantContext.Provider 
      value={{ 
        currentTenant, 
        isLoading, 
        setCurrentTenant, 
        getTenantByUserId,
        getTenantSchema,
        getTenantStoragePath,
        clearTenant
      }}
    >
      {children}
    </TenantContext.Provider>
  );
}

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (context === undefined) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
};
