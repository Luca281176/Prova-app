import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserContextType } from './types';
import { useAuthMethods } from './useAuthMethods';
import { useUserProfile } from './useUserProfile';
import { supabase } from '@/integrations/supabase/client';
import { hasValidSession, restoreSession, refreshSession } from './session';
import { toast } from 'sonner';
import { restoreUserData, setupDataSyncSubscription } from './storageUtils';
import { useUserSync } from './useUserSync';

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionChecked, setSessionChecked] = useState(false);
  const [dataRestored, setDataRestored] = useState(false);

  // Handle window close/unload to sync data
  useEffect(() => {
    const handleBeforeUnload = async (event: BeforeUnloadEvent) => {
      if (user && user.id) {
        console.log("Window closing, syncing final data...");
        
        try {
          // Force data sync before window closes
          const { DataSyncWorker } = await import('./storage/DataSyncWorker');
          const syncWorker = DataSyncWorker.getInstance();
          await syncWorker.forceSyncNow();
          
          console.log("Final data sync complete before window close");
        } catch (error) {
          console.error("Error syncing data before window close:", error);
        }
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [user]);

  useEffect(() => {
    const recoverUserData = async () => {
      try {
        console.log("Starting session restoration process...");
        setIsLoading(true);
        
        // Clear potentially stale session tokens
        const previousSession = localStorage.getItem('supabase.auth.token');
        if (previousSession) {
          try {
            const sessionObj = JSON.parse(previousSession);
            const expiresAt = sessionObj?.expiresAt || 0;
            
            // If token is expired, clear it
            if (expiresAt < Date.now()) {
              console.log("Found expired session, clearing it...");
              localStorage.removeItem('supabase.auth.token');
              sessionStorage.removeItem('supabase.auth.token');
            }
          } catch (e) {
            console.warn("Error parsing stored session:", e);
          }
        }
        
        const restoredUser = await restoreSession();
        
        if (restoredUser) {
          console.log("Session successfully restored for user:", restoredUser.email);
          setUser(restoredUser);
          
          // Always force full data sync from Supabase on session restore
          const restored = await restoreUserData(restoredUser.id, true);
          setDataRestored(restored);
          console.log("User data successfully restored from Supabase");
        } else {
          console.log("No active session found during initial load");
          
          const refreshSuccessful = await refreshSession();
          if (refreshSuccessful) {
            console.log("Session refresh successful, checking session again");
            const refreshedUser = await restoreSession();
            if (refreshedUser) {
              setUser(refreshedUser);
              console.log("User restored after refresh:", refreshedUser.email);
              
              // Also force full data sync after session refresh
              const restored = await restoreUserData(refreshedUser.id, true);
              setDataRestored(restored);
              console.log("User data successfully restored after refresh");
            }
          }
        }
      } catch (error) {
        console.warn("Error recovering user data:", error);
      } finally {
        setIsLoading(false);
        setSessionChecked(true);
      }
    };
    
    recoverUserData();
  }, []);

  // Use the useUserSync hook to ensure synchronization across devices
  useUserSync(user, setUser);
  
  // Setup data sync subscription when user changes
  useEffect(() => {
    if (user && user.id) {
      console.log("Setting up data sync for user:", user.id);
      
      // Start the DataSyncWorker
      import('./storage/DataSyncWorker').then(({ DataSyncWorker }) => {
        const syncWorker = DataSyncWorker.getInstance();
        console.log("Data sync worker started for user:", user.id);
        
        // Force an initial sync whenever the user changes
        syncWorker.forceSyncNow().then((success) => {
          console.log("Initial force sync completed for user:", user.id, "Success:", success);
          if (!dataRestored) {
            // If data wasn't restored during login, try again
            restoreUserData(user.id, true).then((restored) => {
              setDataRestored(restored);
              console.log("User data restored after sync:", restored);
            });
          }
        });
        
        // Set up more frequent automatic syncs (every 20 seconds)
        const syncIntervalId = setInterval(() => {
          syncWorker.forceSyncNow().then(() => {
            console.log("Periodic sync completed for user:", user.id);
          });
        }, 20000); // 20 seconds
        
        return () => {
          clearInterval(syncIntervalId);
        };
      }).catch(err => {
        console.error("Error starting data sync worker:", err);
      });
      
      // Setup realtime subscriptions with Supabase
      const subscriptions = setupDataSyncSubscription(user.id);
      
      return () => {
        if (subscriptions) {
          subscriptions.forEach(channel => {
            if (channel && typeof channel.unsubscribe === 'function') {
              try {
                supabase.removeChannel(channel);
              } catch (e) {
                console.warn("Error removing channel:", e);
              }
            }
          });
        }
      };
    }
  }, [user, dataRestored]);

  // Check session validity more frequently and refresh data from Supabase
  useEffect(() => {
    if (!user) return;

    const checkSession = async () => {
      try {
        const valid = await refreshSession();
        if (!valid) {
          console.log('Session check failed, trying one last restoration attempt');
          const restoredUser = await restoreSession();
          if (!restoredUser && user) {
            console.log('Session is invalid after full check, logging out');
            toast.error("La tua sessione è scaduta. Effettua nuovamente il login.");
            setUser(null);
          }
        } else {
          if (user.id) {
            try {
              // Force data refresh from Supabase on every check to ensure latest data
              await restoreUserData(user.id, true);
              console.log("User data refreshed during session check from Supabase");
            } catch (dataError) {
              console.warn("Error refreshing user data during session check:", dataError);
            }
          }
        }
      } catch (error) {
        console.error('Error during session check:', error);
      }
    };

    // Check session and refresh data more frequently (every 2 minutes)
    const intervalId = setInterval(checkSession, 2 * 60 * 1000);
    
    // Run initial check
    checkSession();
    
    return () => clearInterval(intervalId);
  }, [user]);

  const { login, loginWithGoogle, register, logout } = useAuthMethods(user, setUser, setIsLoading);
  const { updateUser, isAdmin } = useUserProfile(user, setUser, setIsLoading);

  const value: UserContextType = {
    user,
    isLoading,
    sessionChecked,
    login,
    loginWithGoogle,
    register,
    logout,
    updateUser,
    isAdmin,
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

export const useUser = () => {
  const context = useContext(UserContext);
  
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  
  return context;
};
