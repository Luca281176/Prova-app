
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { toast } from 'sonner';
import { NavigateFunction } from 'react-router-dom';
import { FeatureAccessLevel, SubscriptionStatus } from '@/services/subscriptions/types';

export const handleAdminLogin = async (
  email: string,
  password: string,
  navigate: NavigateFunction
) => {
  console.log("Admin login process started");
  
  try {
    // Try real login first
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.log("Admin real login failed, creating mock admin session:", error.message);
      
      // If real login fails, create mock admin session with proper UUID format
      const mockTenantId = crypto.randomUUID(); // Using proper UUID format
      
      // Set admin mock tenant ID
      try {
        await tenantModule.setTenantId(mockTenantId);
      } catch (setTenantError) {
        console.warn("Failed to set tenant ID in JWT, but proceeding with admin login:", setTenantError);
      }
      
      const adminUser = {
        id: crypto.randomUUID(), // Using proper UUID format
        email: email,
        name: 'Admin User',
        restaurantName: 'Admin Restaurant',
        role: 'admin',
        createdAt: new Date().toISOString(),
        subscription: {
          id: `sub_${Date.now()}`,
          userId: crypto.randomUUID(),
          planId: FeatureAccessLevel.ULTIMATE,
          status: 'active' as SubscriptionStatus,
          currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          cancelAtPeriodEnd: false,
          paymentMethod: 'none'
        },
        tenant_id: mockTenantId
      };
      
      // Store admin session data for persistence
      localStorage.setItem('admin_session', JSON.stringify(adminUser));
      localStorage.setItem('current_tenant_id', mockTenantId);
      localStorage.setItem('had_active_session', 'true');
      
      // Save to user_data for compatibility
      localStorage.setItem('user_data', JSON.stringify(adminUser));
      
      console.log("✅ Admin user mock session created successfully");
      toast.success("Accesso amministratore effettuato con successo");
      
      navigate('/admin/dashboard');
      
      return adminUser;
    }
    
    if (!data.user) {
      throw new Error('Errore durante il login amministratore');
    }
    
    // Handle successful Supabase login for admin
    console.log("Admin authenticated via Supabase:", data.user.email);
    
    const adminTenantId = data.user.user_metadata?.tenant_id || crypto.randomUUID();
    
    // Set the tenant ID
    try {
      await tenantModule.setTenantId(adminTenantId);
    } catch (setTenantError) {
      console.warn("Failed to set tenant ID in JWT, but proceeding with admin login:", setTenantError);
    }
    
    // Store in localStorage for future reference
    localStorage.setItem('current_tenant_id', adminTenantId);
    localStorage.setItem('had_active_session', 'true');
    
    // Try to get user data from database
    const { data: fullUserData, error: fetchError } = await supabase
      .from('users')
      .select('*')
      .eq('id', data.user.id)
      .single();
      
    const adminUser = {
      id: data.user.id,
      email: data.user.email || email,
      name: fullUserData?.name || data.user.user_metadata?.name || 'Admin User',
      restaurantName: fullUserData?.restaurantName || data.user.user_metadata?.restaurantName || 'Admin Restaurant',
      role: 'admin',
      createdAt: fullUserData?.created_at || new Date().toISOString(),
      subscription: {
        id: `sub_${Date.now()}`,
        userId: data.user.id,
        planId: FeatureAccessLevel.ULTIMATE,
        status: 'active' as SubscriptionStatus,
        currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        cancelAtPeriodEnd: false,
        paymentMethod: 'none'
      },
      tenant_id: adminTenantId
    };
    
    // Store admin data in localStorage
    localStorage.setItem('user_data', JSON.stringify(adminUser));
    localStorage.setItem('admin_session', JSON.stringify(adminUser));
    
    console.log("✅ Admin user authenticated successfully");
    toast.success("Accesso amministratore effettuato con successo");
    
    navigate('/admin/dashboard');
    
    return adminUser;
  } catch (error) {
    console.error('Error during admin login:', error);
    toast.error('Errore durante il login amministratore');
    throw error;
  }
};
