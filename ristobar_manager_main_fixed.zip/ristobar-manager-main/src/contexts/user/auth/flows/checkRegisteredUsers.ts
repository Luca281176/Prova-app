
import { getRegisteredUsers } from '../../storageUtils';

export const findRegisteredUser = async (email: string, password: string): Promise<any | null> => {
  try {
    const registeredUsers = await getRegisteredUsers();
    
    if (!Array.isArray(registeredUsers)) {
      console.warn("getRegisteredUsers did not return an array:", registeredUsers);
      return null;
    }
    
    const matchedUser = registeredUsers.find((u: any) => 
      u.email === email && u.password === password
    );
    
    return matchedUser || null;
  } catch (error) {
    console.error("Error checking registered users:", error);
    return null;
  }
};
