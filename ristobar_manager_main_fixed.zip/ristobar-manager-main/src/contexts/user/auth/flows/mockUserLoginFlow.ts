
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { toast } from 'sonner';
import { NavigateFunction } from 'react-router-dom';
import { FeatureAccessLevel, SubscriptionStatus } from '@/services/subscriptions/types';

export const handleMockUserLogin = async (
  mockUser: any,
  navigate: NavigateFunction
) => {
  console.log("Mock user login process started:", mockUser.email);
  
  try {
    // Set mock tenant ID (generate if not already present)
    const mockTenantId = mockUser.tenant_id || crypto.randomUUID();
    
    // Set the tenant ID in the JWT
    try {
      await tenantModule.setTenantId(mockTenantId);
      localStorage.setItem('current_tenant_id', mockTenantId);
    } catch (error) {
      console.warn("Failed to set tenant ID in JWT, but proceeding with mock login:", error);
      // Continue with login process even if tenant ID setting fails
    }
    
    const subscriptionId = mockUser.subscription?.id || `sub_${Date.now()}`;
    const userId = mockUser.id || crypto.randomUUID();
    
    const authenticatedUser = {
      id: userId,
      email: mockUser.email,
      name: mockUser.name || 'Mock User',
      restaurantName: mockUser.restaurantName || 'Mock Restaurant',
      role: mockUser.role || 'owner',
      subscription: mockUser.subscription || {
        id: subscriptionId,
        userId: userId,
        planId: FeatureAccessLevel.PRO, // Sempre piano PRO per utenti di prova
        status: 'trialing' as SubscriptionStatus,
        currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        cancelAtPeriodEnd: false,
        paymentMethod: 'none',
      },
      tenant_id: mockTenantId,
      createdAt: mockUser.createdAt || new Date().toISOString(),
    };
    
    // Store mock session data for persistence
    localStorage.setItem('mock_user_session', JSON.stringify(authenticatedUser));
    localStorage.setItem('current_tenant_id', mockTenantId);
    
    // Save to user_data for compatibility
    localStorage.setItem('user_data', JSON.stringify(authenticatedUser));
    localStorage.setItem('had_active_session', 'true');
    
    console.log("✅ Mock user logged in successfully");
    toast.success("Accesso effettuato con successo");
    
    // Try to create user in database for cross-references
    try {
      const { error } = await supabase
        .from('users')
        .upsert({
          id: authenticatedUser.id,
          email: authenticatedUser.email,
          name: authenticatedUser.name,
          restaurantName: authenticatedUser.restaurantName,
          role: authenticatedUser.role,
          tenant_id: mockTenantId,
          created_at: authenticatedUser.createdAt
        });
        
      if (error) {
        console.warn("Failed to register mock user in database:", error.message);
      }
    } catch (dbError) {
      console.warn("Error syncing mock user to database:", dbError);
    }
    
    navigate('/dashboard');
    
    return authenticatedUser;
  } catch (error) {
    console.error('Error during mock user login:', error);
    toast.error('Errore durante il login dell\'utente di prova');
    throw error;
  }
};
