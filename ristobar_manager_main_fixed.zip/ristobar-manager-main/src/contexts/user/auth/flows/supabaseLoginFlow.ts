
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { toast } from 'sonner';
import { NavigateFunction } from 'react-router-dom';
import { getUserSubscription } from '@/services/subscriptions';
import { FeatureAccessLevel, SubscriptionStatus } from '@/services/subscriptions/types';

export const handleSupabaseLogin = async (
  email: string,
  password: string,
  navigate: NavigateFunction
) => {
  console.log("Real user login process started:", email);
  
  try {
    // Attempt to sign in with Supabase Auth
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.error("Login error:", error.message);
      throw new Error('Credenziali non valide. Riprova.');
    }
    
    if (!data.user) {
      throw new Error('Errore nel recupero dell\'utente.');
    }
    
    console.log("User authenticated via Supabase:", data.user.email);
    
    // Get tenant ID from user metadata
    const tenantId = data.user.user_metadata?.tenant_id || data.user.app_metadata?.tenant_id;
    
    // If no tenant ID found in metadata, try to get it from the database
    if (!tenantId) {
      console.warn("No tenant_id found in user metadata, checking database...");
      
      const { data: userData, error: dbError } = await supabase
        .from('users')
        .select('*')
        .eq('id', data.user.id)
        .single();
        
      if (dbError || !userData || !userData.tenant_id) {
        console.error("Error retrieving user data from database:", dbError?.message);
        throw new Error('Tenant ID non trovato. Accesso negato.');
      }
      
      // Set tenant ID in session
      try {
        await tenantModule.setTenantId(userData.tenant_id);
        localStorage.setItem('current_tenant_id', userData.tenant_id);
        console.log("Tenant ID set from database:", userData.tenant_id);
      } catch (setTenantError) {
        console.error("Failed to set tenant ID:", setTenantError);
        throw new Error('Impossibile impostare l\'ID del tenant. Accesso negato.');
      }
      
      // Try to get or create subscription
      let subscription = null;
      try {
        subscription = await getUserSubscription(data.user.id);
        console.log("Subscription retrieved:", subscription);
      } catch (subscriptionError) {
        console.warn("Error retrieving subscription:", subscriptionError);
      }
      
      // If no subscription found, create a default one
      if (!subscription) {
        console.log("No subscription found, creating default trial subscription");
        subscription = {
          id: `sub_${Date.now()}`,
          userId: data.user.id,
          planId: FeatureAccessLevel.PRO, // Cambiato da STARTER a PRO
          status: 'trialing' as SubscriptionStatus,
          currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          cancelAtPeriodEnd: false,
          paymentMethod: 'none'
        };
      }
      
      // Create authenticated user object
      const authenticatedUser = {
        id: data.user.id,
        email: data.user.email || email,
        name: userData.name || data.user.user_metadata?.name || 'User',
        restaurantName: userData.restaurantName || data.user.user_metadata?.restaurantName || 'Restaurant',
        role: userData.role || 'owner',
        createdAt: userData.created_at || new Date().toISOString(),
        subscription: subscription,
        tenant_id: userData.tenant_id
      };
      
      // Store user data in localStorage for future use
      localStorage.setItem('user_data', JSON.stringify(authenticatedUser));
      localStorage.setItem('had_active_session', 'true');
      
      console.log("✅ User logged in successfully with tenant ID from database");
      toast.success("Accesso effettuato con successo");
      
      navigate('/dashboard');
      
      return authenticatedUser;
    } else {
      // Tenant ID found in metadata, proceed with normal flow
      console.log("Found tenant_id in user metadata:", tenantId);
      
      // Set tenant ID in session
      try {
        await tenantModule.setTenantId(tenantId);
        localStorage.setItem('current_tenant_id', tenantId);
      } catch (setTenantError) {
        console.error("Failed to set tenant ID:", setTenantError);
        throw new Error('Impossibile impostare l\'ID del tenant. Accesso negato.');
      }
      
      // Get user data from database
      const { data: userData, error: dbError } = await supabase
        .from('users')
        .select('*')
        .eq('id', data.user.id)
        .single();
        
      if (dbError) {
        console.warn("Error retrieving user data from database:", dbError.message);
      }
      
      // Try to get or create subscription
      let subscription = null;
      try {
        subscription = await getUserSubscription(data.user.id);
        console.log("Subscription retrieved:", subscription);
      } catch (subscriptionError) {
        console.warn("Error retrieving subscription:", subscriptionError);
      }
      
      // If no subscription found, create a default one
      if (!subscription) {
        console.log("No subscription found, creating default trial subscription");
        subscription = {
          id: `sub_${Date.now()}`,
          userId: data.user.id,
          planId: FeatureAccessLevel.PRO, // Cambiato da STARTER a PRO
          status: 'trialing' as SubscriptionStatus,
          currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          cancelAtPeriodEnd: false,
          paymentMethod: 'none'
        };
      }
      
      // Create authenticated user object
      const authenticatedUser = {
        id: data.user.id,
        email: data.user.email || email,
        name: userData?.name || data.user.user_metadata?.name || 'User',
        restaurantName: userData?.restaurantName || data.user.user_metadata?.restaurantName || 'Restaurant',
        role: userData?.role || 'owner',
        createdAt: userData?.created_at || new Date().toISOString(),
        subscription: subscription,
        tenant_id: tenantId
      };
      
      // Store user data in localStorage for future use
      localStorage.setItem('user_data', JSON.stringify(authenticatedUser));
      localStorage.setItem('had_active_session', 'true');
      
      console.log("✅ User logged in successfully with tenant ID from metadata");
      toast.success("Accesso effettuato con successo");
      
      navigate('/dashboard');
      
      return authenticatedUser;
    }
  } catch (error) {
    console.error("Error during Supabase login:", error);
    throw error;
  }
};
