
import { supabase } from '@/integrations/supabase/client';

// Helper function to sync user data to Supabase restaurant_settings
export const syncUserDataToSupabase = async (userId: string, userData: any): Promise<boolean> => {
  try {
    // Get user preferences from localStorage or other sources
    const userPrefs = localStorage.getItem(`${userId}_userPreferences`);
    
    if (userPrefs) {
      await supabase
        .from('restaurant_settings')
        .upsert({
          tenant_id: userData.tenant_id,
          restaurant_name: userData.restaurantName || userData.name || '',
          general_settings: userPrefs,
          updated_at: new Date().toISOString()
        })
        .eq('tenant_id', userData.tenant_id);
      
      console.log("User preferences synced to Supabase for cross-browser access");
    }
    
    return true;
  } catch (error) {
    console.error("Error syncing user data to Supabase:", error);
    return false;
  }
};
