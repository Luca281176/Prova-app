
import { User } from '../types';
import { useLogin } from './useLogin';
import { useGoogleAuth } from './useGoogleAuth';
import { useRegister } from './useRegister';
import { useLogout } from './useLogout';

export const useAuthMethods = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const { logout, internalLogout } = useLogout(user, setUser, setIsLoading);
  const { login } = useLogin(user, setUser, setIsLoading, internalLogout);
  const { loginWithGoogle } = useGoogleAuth(user, setUser, setIsLoading, internalLogout);
  const { register } = useRegister(user, setUser, setIsLoading, internalLogout);

  return {
    login,
    loginWithGoogle,
    register,
    logout
  };
};

export default useAuthMethods;
