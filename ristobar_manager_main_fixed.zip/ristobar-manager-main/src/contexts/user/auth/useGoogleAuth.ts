
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { User } from '../types';
import { supabase } from '@/integrations/supabase/client';

export const useGoogleAuth = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  internalLogout: (withRedirect?: boolean) => Promise<void>
) => {
  const navigate = useNavigate();

  const loginWithGoogle = async () => {
    setIsLoading(true);
    
    try {
      console.log('Attempting login with Google');
      
      if (user) {
        await internalLogout(false);
      }
      
      try {
        // Dynamically determine callback URL based on where the app is running
        const redirectUrl = `${window.location.origin}/auth/callback`;
        console.log('Using redirect URL:', redirectUrl);
        
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: redirectUrl,
            // Ensure session persistence with additional options
            queryParams: {
              access_type: 'offline',
              prompt: 'consent',
            }
          },
        });
        
        if (error) {
          throw error;
        }
        
        // For Google login, we just need to return null as the auth flow will continue in the callback
        console.log("Google OAuth redirect in progress, waiting for callback");
        return null;
      } catch (error) {
        console.error('Error in Google authentication flow:', error);
        throw error;
      }
    } catch (error) {
      console.error('Google login error:', error);
      toast.error("Google authentication failed. Please try again or use email and password.");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return { loginWithGoogle };
};
