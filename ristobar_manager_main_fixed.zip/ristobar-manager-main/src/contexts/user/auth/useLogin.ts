
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { User } from '../types';
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { findRegisteredUser } from './flows/checkRegisteredUsers';
import { handleAdminLogin } from './flows/adminLoginFlow';
import { handleMockUserLogin } from './flows/mockUserLoginFlow';
import { handleSupabaseLogin } from './flows/supabaseLoginFlow';
import { syncUserDataToSupabase } from './helpers/syncUserData';
import { SubscriptionStatus } from '@/services/subscriptions/types';

export const useLogin = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  internalLogout: (withRedirect?: boolean) => Promise<void>
) => {
  const navigate = useNavigate();

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    try {
      console.log(`Attempting login for: ${email}`);
      
      // Logout if already logged in
      if (user) {
        await internalLogout(false);
      }
      
      // Handle admin login case
      if (email.toLowerCase() === 'luca.costanzo@ristobarmanager.it' && password === 'admin123') {
        console.log("Handling admin login flow");
        const adminUser = await handleAdminLogin(email, password, navigate);
        setUser(adminUser);
        return adminUser;
      } else {
        // Check if it's a mock user
        const matchedUser = await findRegisteredUser(email, password);
        
        if (matchedUser) {
          console.log("Found registered mock user, handling mock login flow");
          // Handle mock user login
          const authenticatedUser = await handleMockUserLogin(matchedUser, navigate);
          setUser(authenticatedUser);
          return authenticatedUser;
        } else {
          console.log("Not a mock user, handling real user login through Supabase");
          // Handle real user login through Supabase
          const authenticatedUser = await handleSupabaseLogin(email, password, navigate);
          setUser(authenticatedUser);
          return authenticatedUser;
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error(error instanceof Error ? error.message : "Credenziali non valide. Riprova.");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return { login };
};

// Direct login function (not using the hook)
export const loginUser = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    throw new Error(error.message);
  }

  if (!data.user) {
    throw new Error("Errore nel recupero dell'utente.");
  }

  // Recupera il tenant_id dai metadati dell'utente
  const tenantId = data.user.user_metadata?.tenant_id || data.user.app_metadata?.tenant_id;

  if (!tenantId) {
    console.error("❌ ERRORE: tenant_id non trovato nei metadati dell'utente!");
    
    // Try to get tenant_id from database as fallback
    try {
      const { data: userData, error: dbError } = await supabase
        .from('users')
        .select('*')  // Changed from just tenant_id to get all user data
        .eq('id', data.user.id)
        .single();
        
      if (dbError || !userData?.tenant_id) {
        throw new Error("Tenant ID non trovato nei metadati dell'utente. Accesso negato.");
      }
      
      // Set the tenant ID in the session
      console.log(`Tenant ID recuperato dal database: ${userData.tenant_id}`);
      await tenantModule.setTenantId(userData.tenant_id);
      
      // Salva nel localStorage per accessi successivi
      localStorage.setItem("user_data", JSON.stringify(userData));
      
      // Save to restaurant_settings if needed
      await syncUserDataToSupabase(data.user.id, userData);
      
      return {
        ...data.user,
        ...userData  // Include all user data from database
      };
    } catch (dbError) {
      throw new Error("Tenant ID non trovato nei metadati dell'utente. Accesso negato.");
    }
  } else {
    console.log("✅ tenant_id trovato nei metadati dell'utente:", tenantId);
    
    // Get complete user data from Supabase
    const { data: userData, error: dbError } = await supabase
      .from("users")
      .select("*")
      .eq("id", data.user.id)
      .single();
      
    if (dbError) {
      console.error("Errore nel recupero dati utente completi:", dbError.message);
    } else if (userData) {
      // Save to localStorage for future access
      localStorage.setItem("user_data", JSON.stringify(userData));
      
      // Save to restaurant_settings if needed
      await syncUserDataToSupabase(data.user.id, userData);
    }
    
    // Set the tenant ID in the session
    const success = await tenantModule.setTenantId(tenantId);
    
    if (!success) {
      throw new Error("Impossibile impostare il Tenant ID. Accesso negato.");
    }
  }

  // Always try to get the full user record
  const { data: fullUserData, error: fetchError } = await supabase
    .from("users")
    .select("*")
    .eq("id", data.user.id)
    .single();
    
  if (!fetchError && fullUserData) {
    return {
      ...data.user,
      ...fullUserData,
      tenant_id: tenantId || fullUserData.tenant_id
    };
  }

  return {
    ...data.user,
    tenant_id: tenantId
  };
};
