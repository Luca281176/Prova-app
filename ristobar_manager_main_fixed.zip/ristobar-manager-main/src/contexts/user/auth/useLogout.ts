
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { User } from '../types';
import { clearAllUserData, syncMemoryToStorage } from '../storageUtils';
import AuthService from '@/services/authService';
import { getToken } from '@/services/auth/tokenService';
import { supabase } from '@/integrations/supabase/client';

export const useLogout = (
  user: User | null,
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const navigate = useNavigate();

  const internalLogout = async (withRedirect = true): Promise<void> => {
    if (!user) return;
    
    setIsLoading(true);
    
    try {
      console.log('Logging out user...');
      
      // Prima di disconnettersi, sincronizziamo i dati in memoria con il browser e Supabase
      try {
        console.log('Syncing data to storage before logout...');
        
        // Forza una sincronizzazione di tutti i dati in memoria verso localStorage
        await syncMemoryToStorage();
        
        // Forza una sincronizzazione finale delle operazioni pendenti
        const { DataSyncWorker } = await import('../storage/DataSyncWorker');
        const syncWorker = DataSyncWorker.getInstance();
        await syncWorker.forceSyncNow();
        
        // Ensure all critical data is synced to Supabase
        if (user.id) {
          // Loop through all localStorage keys for this user and sync to Supabase
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(`${user.id}_`)) {
              const dataType = key.replace(`${user.id}_`, '');
              const data = localStorage.getItem(key);
              
              if (data) {
                try {
                  if (dataType === 'userPreferences' || dataType === 'generalSettings') {
                    // Store in restaurant_settings
                    await supabase
                      .from('restaurant_settings')
                      .upsert({
                        tenant_id: user.id,
                        restaurant_name: user.restaurantName || 'Restaurant',
                        general_settings: data,
                        updated_at: new Date().toISOString()
                      }, { onConflict: 'tenant_id' });
                  } else {
                    // Store in restaurant_data
                    await supabase
                      .from('restaurant_data')
                      .upsert({
                        tenant_id: user.id,
                        data_type: dataType,
                        data: JSON.parse(data),
                        updated_at: new Date().toISOString()
                      }, { onConflict: 'tenant_id, data_type' });
                  }
                } catch (syncError) {
                  console.warn(`Error syncing ${dataType} to Supabase:`, syncError);
                }
              }
            }
          }
        }
        
        // Attendiamo un po' per garantire che la sincronizzazione abbia il tempo di completarsi
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        console.log('Data sync completed before logout');
      } catch (syncError) {
        console.error('Error syncing data before logout:', syncError);
      }
      
      // Get the current auth token if it exists
      const token = getToken();
      
      // Revoke the token if it exists
      if (token) {
        try {
          await AuthService.revokeToken(token, user.id);
          console.log('Token successfully revoked');
        } catch (error) {
          console.warn('Error revoking token during logout:', error);
        }
      }
      
      // Sign out from Supabase
      try {
        console.log('Signing out from Supabase...');
        await supabase.auth.signOut({ scope: 'global' }); // Use global scope to invalidate all sessions
      } catch (error) {
        console.error('Error signing out from Supabase:', error);
      }
      
      // Clear critical authentication data
      console.log('Clearing auth data');
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      localStorage.removeItem('supabase.auth.token');
      sessionStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('supabase-session');
      sessionStorage.removeItem('supabase-session');
      localStorage.removeItem('had_active_session');
      
      // Remove Supabase cookies
      document.cookie = "sb-access-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
      document.cookie = "sb-refresh-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
      
      // Update state
      setUser(null);
      
      // Show success message
      toast.success('Logout effettuato con successo.');
      
      // Redirect to login page if requested
      if (withRedirect) {
        navigate('/login');
      }
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Errore durante il logout. Riprova.');
      
      // Force logout anyway as a last resort
      setUser(null);
      if (withRedirect) {
        navigate('/login');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return { 
    logout: internalLogout,
    internalLogout 
  };
};

export default useLogout;
