
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { User } from '../types';
import { 
  getRegisteredUsers,
  saveRegisteredUsers,
  restoreUserData
} from '../storageUtils';
import { getUserSubscription } from '@/services/subscriptions';
import AuthService from '@/services/authService';
import { supabase } from '@/integrations/supabase/client';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';
import { FeatureAccessLevel, SubscriptionStatus } from '@/services/subscriptions/types';

export const useRegister = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>,
  internalLogout: (withRedirect?: boolean) => Promise<void>
) => {
  const navigate = useNavigate();

  const register = async (name: string, email: string, password: string, restaurantName: string): Promise<User | null> => {
    setIsLoading(true);
    
    try {
      if (user) {
        await internalLogout(false);
      }
      
      console.log(`Registering new user: ${email}`);
      
      // Generate a unique tenant ID
      const tenantId = crypto.randomUUID();
      const tenantName = restaurantName || 'My Restaurant';
      const tenantSlug = email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '-');
      
      // Include tenant_id in user metadata when registering
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { 
            tenant_id: tenantId,
            tenant_name: tenantName,
            tenant_slug: tenantSlug,
            name: name,
            restaurantName: restaurantName,
            role: "owner"
          }
        }
      });
      
      if (error) throw error;
      
      if (!data || !data.user) {
        throw new Error('Registration failed: No user data returned');
      }
      
      // Double-check that tenant_id was saved in user metadata
      if (!data.user.user_metadata?.tenant_id) {
        console.error("Tenant ID not found in user metadata after registration");
        // Make a separate request to ensure tenant_id is saved
        await supabase.auth.updateUser({
          data: { 
            tenant_id: tenantId,
            tenant_name: tenantName,
            tenant_slug: tenantSlug,
            role: "owner"
          }
        });
        console.log("Tenant ID updated separately after registration");
      } else {
        console.log("✅ tenant_id saved in user metadata:", data.user.user_metadata.tenant_id);
      }
      
      // Create tenant record
      await supabase.from('tenants').insert({
        id: tenantId,
        name: tenantName,
        owner: data.user.id
      });
      
      // Link user to tenant
      await supabase.from('users').insert({
        id: data.user.id,
        email: email,
        name: name,
        tenant_id: tenantId
      });
      
      // Set tenant_id in session using tenantModule
      // Fixed: Don't evaluate void expression for truthiness, just run the function
      await tenantModule.setTenantId(tenantId, tenantName, tenantSlug);
      
      console.log("Registration successful, response:", data);
      console.log("✅ tenant_id saved in JWT metadata:", tenantId);
      
      const newUser = {
        ...data.user,
        password,
        tenant_id: tenantId // Explicitly add tenant_id to the user object
      };
      
      // Get registered users - this is now an async function
      const registeredUsers = await getRegisteredUsers();
      const success = await saveRegisteredUsers([...registeredUsers, newUser]);
      
      if (!success) {
        console.log("Failed to save to localStorage due to quota - continuing with in-memory user");
      }
      
      // Get subscription with proper type
      let subscription = await getUserSubscription(newUser.id);
      // If no subscription returned, create a default one
      if (!subscription) {
        subscription = {
          id: `sub_${Date.now()}`,
          userId: newUser.id,
          planId: FeatureAccessLevel.PRO, // Sempre Piano PRO per nuovi utenti
          status: 'trialing' as SubscriptionStatus,
          currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          cancelAtPeriodEnd: false,
          paymentMethod: 'none'
        };
      }
      
      // Create a properly formatted User object that matches our User type
      const authenticatedUser: User = {
        id: newUser.id,
        email: newUser.email || email,
        name: name,
        restaurantName: restaurantName,
        role: 'owner' as const,
        createdAt: new Date().toISOString(),
        subscription: subscription,
        tenant_id: tenantId,
        image: data.user.user_metadata?.avatar_url || undefined
      };
      
      try {
        localStorage.setItem('user', JSON.stringify(authenticatedUser));
        localStorage.setItem('userData', JSON.stringify(authenticatedUser));
        console.log("New user data saved to localStorage");
      } catch (storageError) {
        console.warn("LocalStorage quota exceeded, continuing without persistent storage", storageError);
        try {
          sessionStorage.setItem('userDataBackup', JSON.stringify(authenticatedUser));
          console.log("New user data saved to sessionStorage as backup");
        } catch (sessionError) {
          console.warn("SessionStorage also failed:", sessionError);
        }
      }
      
      setUser(authenticatedUser);
      console.log("New user registered and authenticated successfully with tenant_id:", tenantId);
      
      toast.success("Account creato con successo. Benvenuto in RistoBar!");
      
      return authenticatedUser; // Return the user object to satisfy the Promise<User | null> return type
    } catch (error) {
      console.error('Registration error:', error);
      toast.error("Non è stato possibile completare la registrazione.");
      return null; // Return null if registration fails
    } finally {
      setIsLoading(false);
    }
  };

  return { register };
};

export const registerUser = async (email: string, password: string, tenantName: string) => {
  // Generate a unique tenant ID
  const tenantId = crypto.randomUUID();
  
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { 
        tenant_id: tenantId,
        tenant_name: tenantName,
        role: "owner"
      }
    }
  });

  if (error) {
    throw new Error(error.message);
  }

  // Double-check tenant_id is in user metadata
  if (!data.user?.user_metadata?.tenant_id) {
    console.warn("tenant_id not found in user metadata after registerUser, updating...");
    await supabase.auth.updateUser({
      data: { 
        tenant_id: tenantId,
        tenant_name: tenantName,
        role: "owner"
      }
    });
  }
  
  // Create tenant record
  try {
    await supabase.from('tenants').insert({
      id: tenantId,
      name: tenantName,
      owner: data.user.id
    });
    
    // Link user to tenant
    await supabase.from('users').insert({
      id: data.user.id,
      email: email,
      name: data.user.user_metadata?.name || email.split('@')[0],
      tenant_id: tenantId
    });
    
    console.log("✅ Created tenant and linked user to it:", tenantId);
  } catch (dbError) {
    console.error("Failed to create tenant or link user:", dbError);
  }

  return {
    ...data.user,
    tenant_id: tenantId
  };
};
