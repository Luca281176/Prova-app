
// Solo l'utente amministratore per la gestione del sistema
export const MOCK_USERS = [
  {
    id: 'user_789012',
    email: 'luca.costanzo@ristobarmanager.it',
    name: 'Luca Costanzo',
    restaurantName: 'RistoBar Manager',
    role: 'admin' as const,
    createdAt: new Date().toISOString(),
    image: null,
    password: 'admin123', // Credenziali amministratore
  }
];
