
import { supabase } from '@/integrations/supabase/client';
import { User } from '../types';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

/**
 * Restores user session from Supabase or localStorage
 * @returns Promise<User | null> User object if session is restored, null otherwise
 */
export async function restoreSession(): Promise<User | null> {
  try {
    console.log('Attempting to restore session from Supabase');
    
    // First, try to get the session from Supabase
    const { data: sessionData, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Error getting Supabase session:', error);
    } else if (sessionData.session) {
      console.log('Found valid Supabase session');
      
      // Get the user from the session
      const { data: userData } = await supabase.auth.getUser();
      
      if (userData.user) {
        // Try to get additional user data from database
        try {
          const { data: dbUser, error: dbError } = await supabase
            .from('users')
            .select('*')
            .eq('id', userData.user.id)
            .maybeSingle();
            
          if (dbError) {
            console.warn('Error getting user data from database:', dbError);
          }
          
          // Create user object
          const user: User = {
            id: userData.user.id,
            email: userData.user.email || '',
            name: dbUser?.name || userData.user.user_metadata?.name || 'User',
            restaurantName: dbUser?.restaurantName || userData.user.user_metadata?.restaurantName || 'Restaurant',
            role: dbUser?.role || userData.user.user_metadata?.role || 'owner',
            createdAt: dbUser?.created_at || new Date().toISOString(),
            subscription: null,
            tenant_id: dbUser?.tenant_id || userData.user.user_metadata?.tenant_id
          };
          
          // Set the tenant ID in JWT for API calls
          if (user.tenant_id) {
            try {
              await tenantModule.setTenantId(user.tenant_id);
              localStorage.setItem('current_tenant_id', user.tenant_id);
            } catch (e) {
              console.warn('Failed to set tenant ID in JWT, but proceeding with session restoration:', e);
            }
          }
          
          console.log('Session restored for user:', user.email);
          localStorage.setItem('had_active_session', 'true');
          return user;
        } catch (dbError) {
          console.error('Error getting user data from database:', dbError);
        }
      }
    }
    
    // If we're here, check for mock/admin sessions
    return restoreFromLocalStorage();
  } catch (error) {
    console.error('Error restoring session:', error);
    return restoreFromLocalStorage();
  }
}

/**
 * Helper function to restore session from localStorage
 */
function restoreFromLocalStorage(): User | null {
  try {
    console.log('Checking for mock/admin sessions');
    const mockSessionStr = localStorage.getItem('mock_user_session');
    const adminSessionStr = localStorage.getItem('admin_session');
    
    if (adminSessionStr) {
      try {
        const adminUser = JSON.parse(adminSessionStr);
        console.log('Restored admin session for:', adminUser.email);
        
        // Ensure admin role is set
        adminUser.role = 'admin';
        
        // Make sure subscription is set for admin
        if (!adminUser.subscription) {
          adminUser.subscription = {
            planId: 'ultimate',
            status: 'active',
            currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
            cancelAtPeriodEnd: false,
            paymentMethod: 'none',
          };
        }
        
        // Set the tenant ID in JWT for API calls
        if (adminUser.tenant_id) {
          try {
            tenantModule.setTenantId(adminUser.tenant_id);
            localStorage.setItem('current_tenant_id', adminUser.tenant_id);
          } catch (e) {
            console.warn('Failed to set tenant ID in JWT, but proceeding with admin session:', e);
          }
        }
        
        // Update localStorage with the corrected data
        localStorage.setItem('admin_session', JSON.stringify(adminUser));
        localStorage.setItem('user_data', JSON.stringify(adminUser));
        localStorage.setItem('had_active_session', 'true');
        
        return adminUser;
      } catch (e) {
        console.error('Error parsing admin session:', e);
      }
    }
    
    if (mockSessionStr) {
      try {
        const mockUser = JSON.parse(mockSessionStr);
        console.log('Restored mock user session for:', mockUser.email);
        
        // Set the tenant ID in JWT for API calls
        if (mockUser.tenant_id) {
          try {
            tenantModule.setTenantId(mockUser.tenant_id);
            localStorage.setItem('current_tenant_id', mockUser.tenant_id);
          } catch (e) {
            console.warn('Failed to set tenant ID in JWT, but proceeding with mock session:', e);
          }
        }
        
        localStorage.setItem('had_active_session', 'true');
        return mockUser;
      } catch (e) {
        console.error('Error parsing mock user session:', e);
      }
    }
    
    // As a last resort, check for user_data
    const userDataStr = localStorage.getItem('user_data');
    if (userDataStr) {
      try {
        const userData = JSON.parse(userDataStr);
        console.log('Restored user data from local storage for:', userData.email);
        
        // Set the tenant ID in JWT for API calls
        if (userData.tenant_id) {
          try {
            tenantModule.setTenantId(userData.tenant_id);
            localStorage.setItem('current_tenant_id', userData.tenant_id);
          } catch (e) {
            console.warn('Failed to set tenant ID in JWT, but proceeding with user data:', e);
          }
        }
        
        localStorage.setItem('had_active_session', 'true');
        return userData;
      } catch (e) {
        console.error('Error parsing user data:', e);
      }
    }
    
    console.log('No active session found during restoration');
    return null;
  } catch (e) {
    console.error('Error in restoreFromLocalStorage:', e);
    return null;
  }
}
