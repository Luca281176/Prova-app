
import { supabase } from '@/integrations/supabase/client';

/**
 * Checks if the current session is valid
 * @returns Promise<boolean> True if the session is valid
 */
export async function hasValidSession(): Promise<boolean> {
  try {
    console.log('Checking if session is valid...');
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Error checking session validity:', error);
      return checkForMockOrAdminSessions();
    }
    
    // If there's a valid Supabase session, return true
    if (data.session) {
      console.log('Found valid Supabase session');
      
      // Check if session is about to expire
      const expiresAt = data.session.expires_at ? data.session.expires_at * 1000 : 0;
      const now = Date.now();
      const fiveMinutes = 5 * 60 * 1000;
      
      if (expiresAt - now < fiveMinutes) {
        console.log('Session expires soon, refreshing...');
        const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
        return !refreshError && !!refreshData.session;
      }
      
      return true;
    }
    
    // If no Supabase session, check for mock/admin sessions
    return checkForMockOrAdminSessions();
  } catch (error) {
    console.error('Exception during session validity check:', error);
    return checkForMockOrAdminSessions();
  }
}

/**
 * Helper function to check for mock or admin sessions
 */
function checkForMockOrAdminSessions(): boolean {
  try {
    console.log('No Supabase session found, checking for mock/admin sessions');
    const mockSessionStr = localStorage.getItem('mock_user_session');
    const adminSessionStr = localStorage.getItem('admin_session');
    
    if (adminSessionStr) {
      try {
        const adminUser = JSON.parse(adminSessionStr);
        if (adminUser && adminUser.role === 'admin') {
          console.log('Confirmed admin session validity');
          
          // Make sure admin subscription is set properly
          if (!adminUser.subscription) {
            adminUser.subscription = {
              planId: 'ultimate',
              status: 'active',
              currentPeriodEnd: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
              cancelAtPeriodEnd: false,
              paymentMethod: 'none',
            };
            localStorage.setItem('admin_session', JSON.stringify(adminUser));
            localStorage.setItem('user_data', JSON.stringify(adminUser));
          }
          
          return true;
        }
      } catch (e) {
        console.error('Error parsing admin session:', e);
      }
    }
    
    if (mockSessionStr) {
      try {
        const mockUser = JSON.parse(mockSessionStr);
        if (mockUser) {
          console.log('Confirmed mock user session validity');
          return true;
        }
      } catch (e) {
        console.error('Error parsing mock session:', e);
      }
    }
    
    console.log('No valid session found');
    return false;
  } catch (e) {
    console.error('Error checking mock/admin sessions:', e);
    return false;
  }
}
