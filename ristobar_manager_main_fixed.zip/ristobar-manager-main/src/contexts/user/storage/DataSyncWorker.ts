
import { supabase } from '@/integrations/supabase/client';
import { SyncProcessor } from './syncWorker/SyncProcessor';
import { NetworkMonitor } from './syncWorker/NetworkMonitor';
import { DataSyncConfig, DEFAULT_SYNC_CONFIG } from './syncWorker/DataSyncConfig';
import { toast } from 'sonner';

/**
 * Worker responsabile della sincronizzazione dei dati con il server.
 * Implementa il pattern Singleton per garantire una sola istanza.
 */
export class DataSyncWorker {
  private static instance: DataSyncWorker;
  private isRunning: boolean = false;
  private intervalId?: number;
  private processor: SyncProcessor;
  private networkMonitor: NetworkMonitor;
  private config: DataSyncConfig;
  private lastStatusNotification: number = 0;
  private isInitialized: boolean = false;

  /**
   * Inizializza il DataSyncWorker
   */
  private constructor(config: Partial<DataSyncConfig> = {}) {
    this.config = { ...DEFAULT_SYNC_CONFIG, ...config };
    this.processor = new SyncProcessor();
    this.networkMonitor = new NetworkMonitor(this.onNetworkChange.bind(this));
    this.startSync();
    this.isInitialized = true;
    console.log('🔄 DataSyncWorker initialized');
  }

  /**
   * Ottiene l'istanza del DataSyncWorker (Singleton pattern)
   */
  static getInstance(config?: Partial<DataSyncConfig>): DataSyncWorker {
    if (!DataSyncWorker.instance) {
      DataSyncWorker.instance = new DataSyncWorker(config);
    }
    return DataSyncWorker.instance;
  }

  /**
   * Reagisce ai cambiamenti nello stato della rete
   */
  private async onNetworkChange(isOnline: boolean) {
    if (isOnline) {
      console.log('🌐 Connessione ripristinata, avvio sincronizzazione...');
      this.syncPendingOperations();
      
      // Notifica l'utente solo se è passato abbastanza tempo dall'ultima notifica
      const now = Date.now();
      if (now - this.lastStatusNotification > this.config.statusNotificationInterval) {
        toast.success('Connessione ripristinata, sincronizzazione dati in corso');
        this.lastStatusNotification = now;
      }
    } else {
      console.log('📴 Connessione persa, sincronizzazione in pausa');
      
      const now = Date.now();
      if (now - this.lastStatusNotification > this.config.statusNotificationInterval) {
        toast.warning('Connessione persa, i dati verranno sincronizzati quando sarai di nuovo online');
        this.lastStatusNotification = now;
      }
    }
  }

  /**
   * Sincronizza le operazioni in sospeso con il backend
   */
  private async syncPendingOperations() {
    if (this.isRunning || !this.networkMonitor.isOnline()) return;

    this.isRunning = true;
    console.log('🔄 Inizio sincronizzazione operazioni in sospeso...');

    try {
      const { data: operations, error } = await supabase
        .from('pending_operations')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: true })
        .limit(this.config.batchSize);

      if (error) throw error;

      if (operations && operations.length > 0) {
        console.log(`🔄 Trovate ${operations.length} operazioni da sincronizzare`);
        
        let successCount = 0;
        for (const op of operations) {
          const success = await this.processor.processSyncOperation(op);
          if (success) successCount++;
        }
        
        // Notifica solo se ci sono state operazioni completate con successo
        if (successCount > 0) {
          const now = Date.now();
          if (now - this.lastStatusNotification > this.config.statusNotificationInterval) {
            toast.success(`Sincronizzate ${successCount} operazioni con successo`);
            this.lastStatusNotification = now;
          }
        }
      }
    } catch (error) {
      console.error('❌ Errore durante la sincronizzazione:', error);
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Avvia il processo di sincronizzazione periodica
   */
  private startSync() {
    if (this.intervalId) return;

    this.intervalId = window.setInterval(() => {
      if (this.isInitialized) {
        this.syncPendingOperations();
      }
    }, this.config.syncInterval);

    // Prima sincronizzazione immediata
    setTimeout(() => {
      if (this.isInitialized) {
        this.syncPendingOperations();
      }
    }, 1000);
    
    console.log('🔄 Sincronizzazione periodica avviata con intervallo di', 
      Math.round(this.config.syncInterval / 1000), 'secondi');
  }

  /**
   * Forza una sincronizzazione immediata e attende il completamento
   */
  public async forceSyncNow(): Promise<boolean> {
    console.log('🔄 Sincronizzazione forzata avviata');
    
    if (!this.networkMonitor.isOnline()) {
      console.log('📴 Impossibile sincronizzare: dispositivo offline');
      toast.warning('Impossibile sincronizzare: dispositivo offline');
      return false;
    }
    
    // Se è già in esecuzione una sincronizzazione, attendi che termini
    if (this.isRunning) {
      console.log('⏳ Sincronizzazione già in corso, attendi...');
      // Attendi fino a 5 secondi per il completamento della sincronizzazione corrente
      for (let i = 0; i < 10; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        if (!this.isRunning) break;
      }
      
      // Se è ancora in esecuzione dopo l'attesa, interrompi
      if (this.isRunning) {
        console.log('⏳ Timeout attesa sincronizzazione in corso');
        return false;
      }
    }
    
    // Esegui la sincronizzazione
    this.isRunning = true;
    try {
      const { data: operations, error } = await supabase
        .from('pending_operations')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: true });

      if (error) throw error;

      if (operations && operations.length > 0) {
        console.log(`🔄 Trovate ${operations.length} operazioni da sincronizzare`);
        
        let successCount = 0;
        for (const op of operations) {
          const success = await this.processor.processSyncOperation(op);
          if (success) successCount++;
        }
        
        if (successCount > 0) {
          toast.success(`Sincronizzate ${successCount} operazioni con successo`);
        }
        
        return successCount > 0;
      } else {
        console.log('✅ Nessuna operazione in sospeso da sincronizzare');
        return true;
      }
    } catch (error) {
      console.error('❌ Errore durante la sincronizzazione forzata:', error);
      toast.error('Errore durante la sincronizzazione');
      return false;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Arresta il processo di sincronizzazione
   */
  public stopSync() {
    if (this.intervalId) {
      window.clearInterval(this.intervalId);
      this.intervalId = undefined;
    }
    
    this.networkMonitor.destroy();
  }
  
  /**
   * Configurazione del worker
   */
  public updateConfig(config: Partial<DataSyncConfig>): void {
    this.config = { ...this.config, ...config };
    
    // Riavvia il sync con la nuova configurazione
    this.stopSync();
    this.startSync();
    
    console.log('🔄 Configurazione aggiornata:', this.config);
  }
  
  /**
   * Verifica lo stato di inizializzazione
   */
  public isReady(): boolean {
    return this.isInitialized;
  }
}
