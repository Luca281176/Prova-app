
import { supabase } from '@/integrations/supabase/client';
import { memoryStorage } from './memoryStorage';
import { safeStorage } from './safeStorage';
import { getUserStorageKey } from './storageUtils';

// Sync all memory data to localStorage and Supabase
export const syncMemoryToStorage = async (): Promise<boolean> => {
  try {
    console.log(`Syncing all memory data to storage`);
    
    // Get all user IDs in memory storage
    const userIds = Object.keys(memoryStorage);
    if (userIds.length === 0) {
      console.log(`No memory data to sync`);
      return true;
    }
    
    for (const userId of userIds) {
      if (!memoryStorage[userId]) {
        console.log(`No memory data to sync for user ${userId}`);
        continue;
      }
      
      const keys = Object.keys(memoryStorage[userId]);
      
      for (const key of keys) {
        const data = memoryStorage[userId][key];
        if (data) {
          try {
            // Extract the actual key part (removing userId prefix if it exists)
            const actualKey = key.startsWith(`${userId}_`) ? key : `${userId}_${key}`;
            const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
            
            // Save to localStorage first for immediate access
            localStorage.setItem(actualKey, jsonData);
            
            // Always save to Supabase (force sync)
            try {
              await safeStorage.setItem(actualKey, jsonData);
            } catch (supabaseError) {
              console.warn(`Error syncing ${key} to Supabase:`, supabaseError);
            }
          } catch (keyError) {
            console.warn(`Error syncing key ${key}:`, keyError);
          }
        }
      }
      
      console.log(`Memory data sync completed for user ${userId}`);
    }
    
    return true;
  } catch (error) {
    console.error(`Error syncing memory data:`, error);
    return false;
  }
};

// Function to specifically sync data to Supabase
export const syncSpecificDataToSupabase = async (userId: string, key: string, data: any): Promise<boolean> => {
  try {
    if (!userId || !key) {
      console.warn('Invalid userId or key for syncSpecificDataToSupabase');
      return false;
    }
    
    console.log(`Syncing ${key} data to Supabase for user ${userId}`);
    
    try {
      // Always sync to Supabase regardless of local state
      const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
      
      // Determine how to store the data based on key type
      if (key === 'userPreferences' || key === 'generalSettings') {
        // Store in restaurant_settings
        const { error } = await supabase
          .from('restaurant_settings')
          .upsert({
            tenant_id: userId,
            general_settings: jsonData,
            updated_at: new Date().toISOString()
          }, { onConflict: 'tenant_id' });
          
        if (error) {
          console.error(`Error syncing ${key} to restaurant_settings:`, error);
          return false;
        }
        
        console.log(`Successfully synced ${key} to restaurant_settings`);
      } else {
        // Store in restaurant_data
        const { error } = await supabase
          .from('restaurant_data')
          .upsert({
            tenant_id: userId,
            data_type: key,
            data: typeof data === 'object' ? data : JSON.parse(jsonData),
            updated_at: new Date().toISOString()
          }, { onConflict: 'tenant_id, data_type' });
          
        if (error) {
          console.error(`Error syncing ${key} to restaurant_data:`, error);
          return false;
        }
        
        console.log(`Successfully synced ${key} to restaurant_data`);
      }
      
      // Update local storage AFTER successful Supabase sync
      const storageKey = `${userId}_${key}`;
      localStorage.setItem(storageKey, jsonData);
      
      return true;
    } catch (error) {
      console.error(`Error in syncSpecificDataToSupabase:`, error);
      return false;
    }
  } catch (error) {
    console.error(`Error in syncSpecificDataToSupabase:`, error);
    return false;
  }
};

// Function to restore user data from Supabase
export const restoreUserData = async (userId: string, userData?: any): Promise<boolean> => {
  try {
    console.log(`Restoring user data for ${userId} from Supabase`, userData ? 'with user data' : 'without user data');
    
    // Query restaurant_settings first
    const { data: settingsData, error: settingsError } = await supabase
      .from('restaurant_settings')
      .select('*')
      .eq('tenant_id', userId)
      .single();
    
    let restoredAny = false;
    
    if (settingsError) {
      console.warn(`Error retrieving restaurant settings for ${userId}:`, settingsError);
    } else if (settingsData) {
      console.log(`Found restaurant settings for ${userId}`);
      
      // Store restaurant settings in multiple storage locations
      try {
        // Store the complete settings object
        localStorage.setItem(`${userId}_restaurantInfo`, JSON.stringify(settingsData));
        
        // Also store each element separately for backward compatibility
        if (settingsData.general_settings) {
          let generalSettings;
          
          // Try to parse if it's a string
          try {
            generalSettings = typeof settingsData.general_settings === 'string' 
              ? JSON.parse(settingsData.general_settings) 
              : settingsData.general_settings;
              
            localStorage.setItem(`${userId}_generalSettings`, JSON.stringify(generalSettings));
            localStorage.setItem(`${userId}_userPreferences`, JSON.stringify(generalSettings));
            
            // Update memory storage
            if (!memoryStorage[userId]) {
              memoryStorage[userId] = {};
            }
            memoryStorage[userId]['generalSettings'] = generalSettings;
            memoryStorage[userId]['userPreferences'] = generalSettings;
            
            restoredAny = true;
          } catch (parseError) {
            console.warn(`Error parsing general_settings:`, parseError);
          }
        }
        
        if (settingsData.restaurant_name) {
          localStorage.setItem(`${userId}_restaurantName`, settingsData.restaurant_name);
        }
        
        if (settingsData.restaurant_logo) {
          localStorage.setItem(`${userId}_restaurantLogo`, settingsData.restaurant_logo);
        }
      } catch (storageError) {
        console.warn(`Error storing restaurant settings:`, storageError);
      }
    }
    
    // Now query for restaurant_data to get all specific data types
    // Always force retrieval of all data from Supabase
    console.log(`Forcing restoration of all data types from restaurant_data`);
    
    try {
      const { data: restaurantData, error: restaurantError } = await supabase
        .from('restaurant_data')
        .select('data_type, data, version')
        .eq('tenant_id', userId)
        .eq('is_deleted', false);
        
      if (restaurantError) {
        console.warn(`Error retrieving restaurant data:`, restaurantError);
      } else if (restaurantData && restaurantData.length > 0) {
        console.log(`Found ${restaurantData.length} data items in restaurant_data`);
        
        // Process each data item
        for (const item of restaurantData) {
          try {
            if (!item) continue;
            const { data_type, data, version } = item as { data_type: string, data: any, version: number };
            
            if (data_type && data) {
              // Store with user-specific key
              const storageKey = `${userId}_${data_type}`;
              const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
              
              console.log(`Restoring data for ${data_type} (version: ${version})`);
              
              // Save to all storage mechanisms
              localStorage.setItem(storageKey, jsonData);
              
              try {
                sessionStorage.setItem(storageKey, jsonData);
              } catch (sessionError) {
                // Ignore session storage errors
              }
              
              // Update memory storage
              if (!memoryStorage[userId]) {
                memoryStorage[userId] = {};
              }
              memoryStorage[userId][data_type] = typeof data === 'string' ? JSON.parse(data) : data;
              
              restoredAny = true;
            }
          } catch (itemError) {
            console.warn(`Error processing data item:`, itemError);
          }
        }
        
        if (restoredAny) {
          console.log(`Successfully restored user data from restaurant_data table`);
        }
      } else {
        console.log(`No data found in restaurant_data for user ${userId}`);
      }
    } catch (dataError) {
      console.warn(`Error retrieving restaurant_data:`, dataError);
    }
    
    return restoredAny;
  } catch (error) {
    console.error(`Error in restoreUserData:`, error);
    return false;
  }
};
