
// Re-export all storage functionality from our modules
// Be specific about what we export from each file to avoid conflicts
import { 
  getUserStorageKey,
  getUserData,
  getUserDataSync,
  clearAllUserData
} from './storageUtils';

import {
  syncMemoryToStorage,
  syncSpecificDataToSupabase,
  restoreUserData
} from './dataSync';

import {
  setupDataSyncSubscription,
  subscribeToChanges
} from './subscriptions';

import { memoryStorage } from './memoryStorage';
import { safeStorage } from './safeStorage';

// Export specific functions to avoid conflicts
export {
  // From storageUtils
  getUserStorageKey,
  getUserData,
  getUserDataSync,
  clearAllUserData,
  
  // From dataSync
  syncMemoryToStorage,
  syncSpecificDataToSupabase,
  restoreUserData,
  
  // From subscriptions
  setupDataSyncSubscription,
  subscribeToChanges,
  
  // From other modules
  memoryStorage,
  safeStorage
};

// Export other utilities as needed
export * from './syncWorker/DataSyncConfig';
export * from './syncWorker/NetworkMonitor';
export * from './syncWorker/SyncProcessor';
