
// In-memory fallback storage with tenant isolation
const memoryStorage: Record<string, Record<string, any>> = {};

export { memoryStorage };
