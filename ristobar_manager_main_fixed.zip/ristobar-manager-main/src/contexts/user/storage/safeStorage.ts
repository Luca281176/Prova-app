
import { supabase } from '@/integrations/supabase/client';
import { memoryStorage } from './memoryStorage';
import { DataSyncWorker } from './DataSyncWorker';
import { syncOperations } from './sync';
import { toast } from 'sonner';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

// Inizializza il worker di sincronizzazione
const syncWorker = DataSyncWorker.getInstance();

/**
 * Verifica e corregge il tenant_id se necessario
 * @param tenantId Il tenant_id da verificare
 * @returns Promise<string> Il tenant_id corretto
 */
const ensureValidTenantId = async (tenantId: string): Promise<string> => {
  // Se il tenant_id è "default" o vuoto, prova a recuperare quello corretto
  if (!tenantId || tenantId === 'default') {
    console.warn("⚠️ Rilevato tenant_id non valido:", tenantId);
    
    // Tenta di recuperare il tenant_id corretto dall'auth o da localStorage
    const correctId = await tenantModule.getCurrentTenantId();
    
    if (correctId) {
      console.log("✅ Tenant_id corretto recuperato:", correctId);
      return correctId;
    } else {
      console.error("❌ Impossibile recuperare un tenant_id valido");
      throw new Error("Tenant ID non valido e impossibile recuperarne uno corretto");
    }
  }
  
  return tenantId;
};

// Helper to safely use localStorage with memory fallback and Supabase sync
export const safeStorage = {
  getItem: async (key: string): Promise<string | null> => {
    try {
      // Check if this is a user-specific key
      const keyParts = key.split('_');
      if (keyParts.length >= 2) {
        let userId = keyParts[0];  // Il primo componente è l'ID dell'utente/tenant
        
        // Verifica che il tenant_id sia valido
        try {
          userId = await ensureValidTenantId(userId);
          
          // Se il tenant_id è cambiato, aggiorna la chiave
          if (userId !== keyParts[0]) {
            const newKey = `${userId}_${keyParts.slice(1).join('_')}`;
            console.log(`🔄 Aggiornata chiave di storage da ${key} a ${newKey}`);
            key = newKey;
          }
        } catch (error) {
          console.error("Errore durante la verifica del tenant_id:", error);
          // Continua con il valore originale come fallback
        }
        
        const dataType = keyParts.slice(1).join('_'); // Il resto è il tipo di dati
        
        console.log(`Attempting to retrieve data from Supabase for tenant: ${userId}, type: ${dataType}`);
        
        // ALWAYS try to get the freshest data from Supabase first
        try {
          const { data, error } = await supabase
            .from('restaurant_data')
            .select('data')
            .eq('tenant_id', userId)
            .eq('data_type', dataType)
            .maybeSingle();

          if (error) {
            console.warn('Error retrieving data from Supabase:', error.message);
          } else if (data?.data) {
            console.log(`Data retrieved from Supabase for ${dataType}`);
            // Save to localStorage for faster access next time
            const jsonData = JSON.stringify(data.data);
            localStorage.setItem(key, jsonData);
            
            // Also save to memory
            if (!memoryStorage[userId]) {
              memoryStorage[userId] = {};
            }
            memoryStorage[userId][dataType] = data.data;
            
            return jsonData;
          } else {
            console.log(`No data found in Supabase for ${dataType}`);
          }
        } catch (supabaseError) {
          console.warn('Error querying Supabase:', supabaseError);
        }
      }
      
      // If not found in Supabase, check localStorage as fallback
      const item = localStorage.getItem(key);
      if (item !== null) {
        return item;
      }
      
      // Finally try memory storage as last resort
      const tenantId = key.split('_')[0];
      return memoryStorage[tenantId]?.[key] || null;
    } catch (error) {
      console.warn(`Error accessing storage for ${key}, using memory fallback`);
      const tenantId = key.split('_')[0];
      return memoryStorage[tenantId]?.[key] || null;
    }
  },
  
  setItem: async (key: string, value: string): Promise<boolean> => {
    try {
      // Save to localStorage for immediate local access
      localStorage.setItem(key, value);
      
      // Always save data to Supabase 
      const keyParts = key.split('_');
      if (keyParts.length >= 2) {
        let tenantId = keyParts[0];
        
        // Verifica che il tenant_id sia valido
        try {
          tenantId = await ensureValidTenantId(tenantId);
          
          // Se il tenant_id è cambiato, aggiorna la chiave e risalva in localStorage
          if (tenantId !== keyParts[0]) {
            const newKey = `${tenantId}_${keyParts.slice(1).join('_')}`;
            console.log(`🔄 Aggiornata chiave di storage da ${key} a ${newKey}`);
            localStorage.setItem(newKey, value);
            key = newKey;
          }
        } catch (error) {
          console.error("Errore durante la verifica del tenant_id:", error);
          // Continua con il valore originale come fallback
        }
        
        const dataType = keyParts.slice(1).join('_');
        
        console.log(`Saving data to Supabase for tenant: ${tenantId}, type: ${dataType}`);
        
        let jsonData;
        try {
          jsonData = JSON.parse(value);
        } catch (e) {
          jsonData = value; // Use as-is if not valid JSON
        }
        
        try {
          // First try direct save
          const { error } = await supabase.rpc('sync_restaurant_data', {
            p_tenant_id: tenantId,
            p_data_type: dataType,
            p_data: jsonData,
            p_client_version: 1
          });

          if (error) {
            console.warn('Error in direct sync with Supabase:', error.message);
            throw error;
          } else {
            console.log(`Data successfully saved to Supabase for ${dataType}`);
          }
        } catch (directSyncError) {
          // If direct save fails, create a pending operation
          console.log('Creating pending operation for future sync');
          
          await syncOperations.createPendingOperation(
            tenantId,
            'save',
            {
              data_type: dataType,
              data: jsonData,
              version: 1
            }
          );
          
          // Immediately try to sync
          syncWorker.forceSyncNow();
        }
      }
      
      // Save to memory as fallback
      const tenantId = key.split('_')[0];
      if (!memoryStorage[tenantId]) {
        memoryStorage[tenantId] = {};
      }
      
      try {
        memoryStorage[tenantId][key] = JSON.parse(value);
      } catch (e) {
        memoryStorage[tenantId][key] = value;
      }

      // Trigger a custom event for real-time updates across tabs
      window.dispatchEvent(new CustomEvent('storage-updated', { 
        detail: { key, value } 
      }));
      
      return true;
    } catch (error) {
      console.warn(`Error setting storage for ${key}, using memory fallback only`);
      const tenantId = key.split('_')[0];
      if (!memoryStorage[tenantId]) {
        memoryStorage[tenantId] = {};
      }
      
      try {
        memoryStorage[tenantId][key] = JSON.parse(value);
      } catch (e) {
        memoryStorage[tenantId][key] = value;
      }
      
      return false;
    }
  },
  
  removeItem: async (key: string): Promise<void> => {
    try {
      localStorage.removeItem(key);
      
      // Also remove from Supabase
      const keyParts = key.split('_');
      if (keyParts.length >= 2) {
        let tenantId = keyParts[0];
        
        // Verifica che il tenant_id sia valido
        try {
          tenantId = await ensureValidTenantId(tenantId);
        } catch (error) {
          console.error("Errore durante la verifica del tenant_id:", error);
          // Continua con il valore originale come fallback
        }
        
        const dataType = keyParts.slice(1).join('_');
        
        try {
          await supabase
            .from('restaurant_data')
            .update({ is_deleted: true })
            .eq('tenant_id', tenantId)
            .eq('data_type', dataType);
            
          console.log(`Data marked as deleted on Supabase for ${dataType}`);
        } catch (supabaseError) {
          console.warn('Error marking data as deleted:', supabaseError);
        }
      }
    } catch (error) {
      console.warn(`Error removing from storage for ${key}`);
    }
    
    // Clean memory storage
    const tenantId = key.split('_')[0];
    if (memoryStorage[tenantId]) {
      delete memoryStorage[tenantId][key];
    }
  },
  
  // Clear all data for a specific tenant
  clearTenantData: async (tenantId: string): Promise<void> => {
    // Verifica che il tenant_id sia valido
    try {
      tenantId = await ensureValidTenantId(tenantId);
    } catch (error) {
      console.error("Errore durante la verifica del tenant_id:", error);
      // Continua con il valore originale come fallback
    }
    
    console.log(`Clearing all data for tenant: ${tenantId}`);
    
    try {
      // Clean localStorage
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(`${tenantId}_`)) {
          keysToRemove.push(key);
        }
      }
      
      keysToRemove.forEach(key => {
        console.log(`Clearing localStorage key: ${key}`);
        try {
          localStorage.removeItem(key);
        } catch (error) {
          console.warn("Error clearing localStorage:", error);
        }
      });
      
      // Mark as deleted all data in Supabase
      try {
        await supabase
          .from('restaurant_data')
          .update({ is_deleted: true })
          .eq('tenant_id', tenantId);
          
        console.log('All tenant data marked as deleted in Supabase');
      } catch (supabaseError) {
        console.warn('Error marking data as deleted:', supabaseError);
      }
    } catch (error) {
      console.warn("Error clearing storage:", error);
    }
    
    // Clear memory
    if (memoryStorage[tenantId]) {
      console.log(`Clearing memory storage for tenant: ${tenantId}`);
      delete memoryStorage[tenantId];
    }
  },
  
  // Force immediate synchronization
  forceSyncNow: async (): Promise<boolean> => {
    try {
      const result = await syncWorker.forceSyncNow();
      if (result) {
        toast.success('Sincronizzazione dati completata');
      }
      return result;
    } catch (error) {
      console.error("Error during force sync:", error);
      return false;
    }
  },
  
  // Get correct tenant ID
  getTenantId: async (): Promise<string | null> => {
    try {
      const tenantId = await tenantModule.getCurrentTenantId();
      return tenantId;
    } catch (error) {
      console.error("Error retrieving tenant ID:", error);
      return null;
    }
  }
};
