
import { memoryStorage } from './memoryStorage';

// Helper function to get user-specific storage key
export const getUserStorageKey = (userId: string, key: string) => {
  return `${userId}_${key}`;
};

// Get user data from storage with user-specific key - sync version
export const getUserDataSync = <T>(userId: string, key: string, defaultValue: T = null as unknown as T): T => {
  if (!userId || typeof userId !== 'string') {
    console.warn(`Invalid userId: ${userId} for key: ${key}`);
    return defaultValue;
  }

  const storageKey = `${userId}_${key}`;
  
  try {
    const data = localStorage.getItem(storageKey);
    if (data === null) {
      // If not in localStorage, check memory storage
      if (memoryStorage[userId] && memoryStorage[userId][key] !== undefined) {
        return memoryStorage[userId][key] as T;
      }
      return defaultValue;
    }
    
    return JSON.parse(data) as T;
  } catch (error) {
    console.error(`Error getting user data for key ${key}:`, error);
    return defaultValue;
  }
};

// Get user data from storage with user-specific key - async version
export const getUserData = async (userId: string, key: string, defaultValue: any = null, forceSupabase = false) => {
  if (!userId) {
    console.warn(`Attempted to get user data with key ${key} but userId is empty`);
    return defaultValue;
  }

  try {
    const storageKey = getUserStorageKey(userId, key);
    console.log(`Getting user data for ${userId} with key ${key}, forceSupabase: ${forceSupabase}`);
    
    // First try localStorage (most reliable)
    const localData = localStorage.getItem(storageKey);
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (parseError) {
        console.warn(`Error parsing localStorage data for ${key}:`, parseError);
      }
    }
    
    // Then try sessionStorage
    try {
      const sessionData = sessionStorage.getItem(storageKey);
      if (sessionData) {
        return JSON.parse(sessionData);
      }
    } catch (sessionError) {
      console.warn(`Error getting ${key} from sessionStorage:`, sessionError);
    }
    
    // Try memory storage
    if (memoryStorage[userId] && memoryStorage[userId][key] !== undefined) {
      return memoryStorage[userId][key];
    }
    
    return defaultValue;
  } catch (error) {
    console.error(`Error retrieving ${key} for user ${userId}:`, error);
    return defaultValue;
  }
};

// Save user data to storage with user-specific key
export const saveUserDataToStorage = async (userId: string, key: string, data: any): Promise<boolean> => {
  try {
    if (!userId) {
      console.warn(`Cannot save data with key ${key}: userId is empty`);
      return false;
    }
    
    const storageKey = getUserStorageKey(userId, key);
    const jsonData = JSON.stringify(data);
    console.log(`Saving user data for ${userId} with key ${key}`);
    
    // Save to local storage first
    localStorage.setItem(storageKey, jsonData);
    
    // Also save to sessionStorage as backup
    try {
      sessionStorage.setItem(storageKey, jsonData);
    } catch (sessionError) {
      console.warn(`Error saving ${key} to sessionStorage:`, sessionError);
    }
    
    // Also store in memory as an additional fallback
    if (!memoryStorage[userId]) {
      memoryStorage[userId] = {};
    }
    memoryStorage[userId][key] = data;
    
    return true;
  } catch (error) {
    console.error(`Error saving ${key} for user ${userId}:`, error);
    
    // Last resort fallback: try to save to memory only
    try {
      if (!memoryStorage[userId]) {
        memoryStorage[userId] = {};
      }
      memoryStorage[userId][key] = data;
      console.warn(`Saved ${key} to memory storage only as fallback`);
    } catch (memoryError) {
      console.error(`Complete failure saving ${key} for user ${userId}:`, memoryError);
      return false;
    }
    
    return false;
  }
};

// Clear all auth related data but preserve user data
export const clearAllUserData = () => {
  console.log("Clearing authentication tokens and session data");
  
  try {
    // Remove auth tokens from localStorage and sessionStorage
    const authKeys = [
      'auth_token',
      'supabase.auth.token', 
      'supabase-session', 
      'had_active_session',
      'sb-access-token',
      'sb-refresh-token'
    ];
    
    // Clear authentication data
    authKeys.forEach(key => {
      console.log(`Clearing auth key: ${key}`);
      localStorage.removeItem(key);
      try {
        sessionStorage.removeItem(key);
      } catch (e) {
        // Ignore errors on sessionStorage
      }
    });
    
    // Clear Supabase cookies
    document.cookie = "sb-access-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
    document.cookie = "sb-refresh-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
    
    console.log("Auth data cleared, user data preserved");
  } catch (error) {
    console.warn("Error during selective auth data clearing:", error);
  }
};

// Sync memory data to localStorage and sessionStorage
export const syncMemoryToStorage = async () => {
  console.log("Syncing memory data to persistent storage...");
  
  try {
    // For each user in memory storage
    for (const userId in memoryStorage) {
      const userData = memoryStorage[userId];
      
      // For each data key for this user
      for (const key in userData) {
        const data = userData[key];
        if (data !== undefined) {
          // Save to localStorage
          try {
            const storageKey = getUserStorageKey(userId, key);
            const jsonData = JSON.stringify(data);
            localStorage.setItem(storageKey, jsonData);
            
            // Also try sessionStorage
            try {
              sessionStorage.setItem(storageKey, jsonData);
            } catch (e) {
              // Ignore sessionStorage errors
            }
          } catch (e) {
            console.warn(`Error syncing ${key} from memory to storage:`, e);
          }
        }
      }
    }
    
    console.log("Memory data successfully synced to storage");
    return true;
  } catch (error) {
    console.error("Error syncing memory data to storage:", error);
    return false;
  }
};

// Sync specific data to Supabase
export const syncSpecificDataToSupabase = async (userId: string, dataType: string, data: any) => {
  if (!userId || !dataType) return false;
  
  try {
    console.log(`Syncing data type ${dataType} to Supabase for user ${userId}`);
    
    const { supabase } = await import('@/integrations/supabase/client');
    
    if (dataType === 'userPreferences' || dataType === 'generalSettings') {
      // Get restaurant name if available
      let restaurantName = 'Restaurant';
      try {
        const nameData = localStorage.getItem(`${userId}_restaurantName`);
        if (nameData) {
          restaurantName = nameData;
        }
      } catch (e) {
        // Ignore error
      }
      
      // Save to restaurant_settings
      await supabase
        .from('restaurant_settings')
        .upsert({
          tenant_id: userId,
          restaurant_name: restaurantName,
          general_settings: typeof data === 'string' ? data : JSON.stringify(data),
          updated_at: new Date().toISOString()
        }, { onConflict: 'tenant_id' });
    } else {
      // Save to restaurant_data
      await supabase
        .from('restaurant_data')
        .upsert({
          tenant_id: userId,
          data_type: dataType,
          data: data,
          updated_at: new Date().toISOString(),
          version: 1 // Default version for new records
        }, { onConflict: 'tenant_id, data_type' });
    }
    
    console.log(`Successfully synced ${dataType} to Supabase`);
    return true;
  } catch (error) {
    console.error(`Error syncing ${dataType} to Supabase:`, error);
    return false;
  }
};
