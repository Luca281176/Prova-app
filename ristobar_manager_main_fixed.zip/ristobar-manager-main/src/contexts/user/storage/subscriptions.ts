
import { supabase } from '@/integrations/supabase/client';
import { memoryStorage } from './memoryStorage';
import { getUserStorageKey } from './storageUtils';

// Function to set up a subscription for changes to user data in Supabase
export const setupDataSyncSubscription = (userId: string) => {
  if (!userId) return null;
  
  try {
    console.log(`Setting up data sync subscription for user ${userId}`);
    
    // Subscribe to changes in restaurant_data for this tenant
    const channel = supabase
      .channel(`tenant_${userId}_changes`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'restaurant_data',
        filter: `tenant_id=eq.${userId}`
      }, (payload) => {
        try {
          console.log(`Received change for restaurant_data:`, payload);
          
          if (payload.new) {
            const newData = payload.new as any;
            if (newData.data_type && newData.data) {
              const { data_type, data, version } = newData;
              
              // Check if we have a newer version locally
              const localData = localStorage.getItem(`${userId}_${data_type}`);
              if (localData) {
                try {
                  const localObj = JSON.parse(localData);
                  if (localObj && localObj.version && localObj.version > version) {
                    console.log(`Local version (${localObj.version}) is newer than server version (${version}), not updating`);
                    return;
                  }
                } catch (e) {
                  // Continue with update if we can't parse local version
                }
              }
              
              // Update local storage with the new data
              const storageKey = `${userId}_${data_type}`;
              const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
              
              localStorage.setItem(storageKey, jsonData);
              
              // Update memory storage
              if (!memoryStorage[userId]) {
                memoryStorage[userId] = {};
              }
              memoryStorage[userId][data_type] = typeof data === 'string' ? JSON.parse(data) : data;
              
              console.log(`Updated local data for ${data_type} from Supabase realtime`);
            }
          }
        } catch (error) {
          console.error(`Error processing realtime update:`, error);
        }
      })
      .subscribe();
      
    // Also subscribe to restaurant_settings changes
    const settingsChannel = supabase
      .channel(`tenant_${userId}_settings_changes`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'restaurant_settings',
        filter: `tenant_id=eq.${userId}`
      }, (payload) => {
        try {
          console.log(`Received change for restaurant_settings:`, payload);
          
          if (payload.new) {
            const newData = payload.new as any;
            const { general_settings, restaurant_name, restaurant_logo } = newData;
            
            // Update general settings if available
            if (general_settings) {
              try {
                const parsedSettings = typeof general_settings === 'string' 
                  ? JSON.parse(general_settings) 
                  : general_settings;
                
                localStorage.setItem(`${userId}_generalSettings`, JSON.stringify(parsedSettings));
                localStorage.setItem(`${userId}_userPreferences`, JSON.stringify(parsedSettings));
                
                // Update memory storage
                if (!memoryStorage[userId]) {
                  memoryStorage[userId] = {};
                }
                memoryStorage[userId]['generalSettings'] = parsedSettings;
                memoryStorage[userId]['userPreferences'] = parsedSettings;
              } catch (e) {
                console.warn(`Error parsing general_settings from realtime update:`, e);
              }
            }
            
            // Update restaurant name if available
            if (restaurant_name) {
              localStorage.setItem(`${userId}_restaurantName`, restaurant_name);
            }
            
            // Update restaurant logo if available
            if (restaurant_logo) {
              localStorage.setItem(`${userId}_restaurantLogo`, restaurant_logo);
            }
            
            console.log(`Updated restaurant settings from Supabase realtime`);
          }
        } catch (error) {
          console.error(`Error processing settings realtime update:`, error);
        }
      })
      .subscribe();
    
    return [channel, settingsChannel];
  } catch (error) {
    console.error(`Error setting up data sync subscription:`, error);
    return null;
  }
};

// Subscribe to changes for a specific key
export const subscribeToChanges = (userId: string, key: string, callback: (data: any) => void) => {
  if (!userId || !key || !callback) return () => {};
  
  try {
    console.log(`Setting up subscription for ${key} changes`);
    
    // Set up local storage event listener
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === `${userId}_${key}` && event.newValue) {
        try {
          const newData = JSON.parse(event.newValue);
          callback(newData);
        } catch (e) {
          console.warn(`Error parsing storage event data:`, e);
        }
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Return cleanup function
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  } catch (error) {
    console.error(`Error setting up change subscription:`, error);
    return () => {};
  }
};
