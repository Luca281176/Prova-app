
import { toast } from 'sonner';

/**
 * Interfaccia per i dati necessari alla gestione dei conflitti
 */
export interface ConflictResolutionData {
  localVersion: number;
  serverVersion: number;
  localData: any;
  serverData: any;
  dataType: string;
}

/**
 * Strategia di risoluzione dei conflitti
 */
export enum ConflictResolutionStrategy {
  KEEP_LOCAL = 'keep_local',
  KEEP_SERVER = 'keep_server',
  MERGE = 'merge',
  MANUAL = 'manual'
}

/**
 * Gestione dei conflitti di sincronizzazione
 */
export const conflictManager = {
  /**
   * Determina la strategia di risoluzione ottimale in base al tipo di dati
   */
  determineStrategy(dataType: string): ConflictResolutionStrategy {
    switch (dataType) {
      case 'menuData':
      case 'userPreferences':
        // Per dati complessi, l'utente potrebbe voler decidere
        return ConflictResolutionStrategy.MANUAL;
      case 'restaurantName':
        // Per dati semplici, scegliamo automaticamente la versione più recente
        return ConflictResolutionStrategy.KEEP_SERVER;
      default:
        // Per sicurezza, chiediamo all'utente
        return ConflictResolutionStrategy.MANUAL;
    }
  },
  
  /**
   * Risolve un conflitto secondo la strategia specificata
   */
  resolveConflict(
    data: ConflictResolutionData, 
    strategy: ConflictResolutionStrategy
  ): any {
    switch (strategy) {
      case ConflictResolutionStrategy.KEEP_LOCAL:
        return data.localData;
      case ConflictResolutionStrategy.KEEP_SERVER:
        toast.info(`Dati aggiornati da un altro dispositivo per: ${data.dataType}`);
        return data.serverData;
      case ConflictResolutionStrategy.MERGE:
        // Implementazione di una semplice strategia di unione
        return this.mergeData(data.localData, data.serverData, data.dataType);
      case ConflictResolutionStrategy.MANUAL:
        // Per ora usiamo sempre i dati del server per semplicità
        toast.info(`Rilevato conflitto di dati per: ${data.dataType}. Utilizzata versione dal server.`);
        return data.serverData;
      default:
        return data.serverData;
    }
  },
  
  /**
   * Unisce i dati locali e remoti in base al tipo
   */
  mergeData(localData: any, serverData: any, dataType: string): any {
    // Implementazione specifica per ogni tipo di dati
    if (dataType === 'menuData' && Array.isArray(localData) && Array.isArray(serverData)) {
      // Unione basata su ID per gli array
      const mergedItems = [...serverData];
      const serverIds = new Set(serverData.map(item => item.id));
      
      localData.forEach(localItem => {
        if (!serverIds.has(localItem.id)) {
          mergedItems.push(localItem);
        }
      });
      
      return mergedItems;
    }
    
    // Default: per oggetti, unione semplice
    if (typeof localData === 'object' && !Array.isArray(localData) &&
        typeof serverData === 'object' && !Array.isArray(serverData)) {
      return { ...serverData, ...localData };
    }
    
    // In caso di dubbio, usa i dati del server
    return serverData;
  }
};
