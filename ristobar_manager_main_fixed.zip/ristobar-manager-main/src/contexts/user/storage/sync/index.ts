
// Esporta tutte le funzionalità di sincronizzazione
import { conflictManager, ConflictResolutionStrategy } from './conflictManager';
import { syncOperations } from './syncOperations';
import { realtimeSync } from './realtimeSync';

export {
  conflictManager,
  ConflictResolutionStrategy,
  syncOperations,
  realtimeSync
};

// Riesporta i tipi dalla sincronizzazione
export type { ConflictResolutionData } from './conflictManager';
