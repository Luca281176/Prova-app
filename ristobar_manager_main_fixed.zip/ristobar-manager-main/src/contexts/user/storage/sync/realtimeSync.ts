
import { supabase } from '@/integrations/supabase/client';

/**
 * Funzioni per la gestione della sincronizzazione in tempo reale
 */
export const realtimeSync = {
  /**
   * Configura un canale di ascolto per i cambiamenti ai dati del ristorante
   */
  subscribeToRestaurantData(
    tenantId: string, 
    onDataChange: (dataType: string, newData: any) => void
  ): any {
    if (!tenantId) {
      console.warn('Tentativo di sottoscrizione senza tenant_id');
      return null;
    }
    
    console.log(`Setting up real-time data sync for tenant: ${tenantId}`);
    
    const channel = supabase
      .channel(`tenant-${tenantId}`)
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'restaurant_data',
        filter: `tenant_id=eq.${tenantId}`
      }, (payload) => {
        console.log("Restaurant data changed:", payload);
        
        if (payload.new && payload.new.data_type) {
          onDataChange(payload.new.data_type, payload.new.data);
        }
      })
      .subscribe();
      
    return channel;
  },
  
  /**
   * Configura un canale di ascolto per cambiamenti alle operazioni in sospeso
   */
  subscribeToPendingOperations(
    tenantId: string,
    onOperationChange: (operation: any) => void
  ): any {
    if (!tenantId) {
      console.warn('Tentativo di sottoscrizione senza tenant_id');
      return null;
    }
    
    const channel = supabase
      .channel(`pending-ops-${tenantId}`)
      .on('postgres_changes', {
        event: '*', 
        schema: 'public',
        table: 'pending_operations',
        filter: `tenant_id=eq.${tenantId}`
      }, (payload) => {
        console.log("Pending operation changed:", payload);
        onOperationChange(payload.new);
      })
      .subscribe();
      
    return channel;
  },
  
  /**
   * Rimuove un canale di ascolto
   */
  unsubscribeChannel(channel: any): void {
    if (channel) {
      supabase.removeChannel(channel);
    }
  }
};
