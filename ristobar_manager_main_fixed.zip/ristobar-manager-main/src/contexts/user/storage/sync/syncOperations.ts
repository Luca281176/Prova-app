
import { supabase } from '@/integrations/supabase/client';
import { v4 as uuidv4 } from 'uuid';

/**
 * Funzioni per gestire la sincronizzazione dei dati
 */
export const syncOperations = {
  /**
   * Crea una nuova operazione in sospeso
   * @param tenantId ID del tenant
   * @param operationType Tipo di operazione (save, delete, ecc.)
   * @param data Dati da sincronizzare
   * @returns Promise<string|null> ID dell'operazione creata o null in caso di errore
   */
  createPendingOperation: async (
    tenantId: string, 
    operationType: string, 
    data: any
  ): Promise<string | null> => {
    if (!tenantId) {
      console.error('Errore: tenantId è obbligatorio per creare un\'operazione in sospeso');
      return null;
    }
    
    try {
      // Genera un ID client per l'operazione
      const clientGeneratedId = uuidv4();
      
      console.log(`Creazione operazione in sospeso: ${operationType} per tenant ${tenantId}`, data);
      
      const { data: operation, error } = await supabase
        .from('pending_operations')
        .insert({
          tenant_id: tenantId,
          operation_type: operationType,
          data,
          client_generated_id: clientGeneratedId,
          status: 'pending',
          retry_count: 0
        })
        .select('id')
        .single();
      
      if (error) {
        console.error('Errore nella creazione dell\'operazione in sospeso:', error);
        
        // In caso di errore con Supabase, mantieni l'operazione in memoria
        // per tentare nuovamente in seguito
        try {
          const pendingOpsStr = localStorage.getItem(`${tenantId}_pending_ops`) || '[]';
          const pendingOps = JSON.parse(pendingOpsStr);
          
          pendingOps.push({
            id: clientGeneratedId,
            tenant_id: tenantId,
            operation_type: operationType,
            data,
            created_at: new Date().toISOString(),
            status: 'pending',
            retry_count: 0,
            client_generated: true
          });
          
          localStorage.setItem(`${tenantId}_pending_ops`, JSON.stringify(pendingOps));
          console.log('Operazione salvata localmente per sincronizzazione futura');
          return clientGeneratedId;
        } catch (localError) {
          console.error('Errore nel salvataggio locale dell\'operazione:', localError);
          return null;
        }
      }
      
      return operation?.id || null;
    } catch (error) {
      console.error('Errore durante la creazione dell\'operazione in sospeso:', error);
      return null;
    }
  },
  
  /**
   * Recupera le operazioni in sospeso per un tenant
   * @param tenantId ID del tenant
   * @returns Promise<any[]> Lista delle operazioni in sospeso
   */
  getPendingOperations: async (tenantId: string): Promise<any[]> => {
    if (!tenantId) return [];
    
    try {
      // Prima recupera le operazioni dal server
      const { data: operations, error } = await supabase
        .from('pending_operations')
        .select('*')
        .eq('tenant_id', tenantId)
        .eq('status', 'pending')
        .order('created_at', { ascending: true });
      
      if (error) {
        console.warn('Errore nel recupero delle operazioni in sospeso da Supabase:', error);
      }
      
      // Poi recupera eventuali operazioni salvate localmente
      try {
        const pendingOpsStr = localStorage.getItem(`${tenantId}_pending_ops`);
        if (pendingOpsStr) {
          const localOps = JSON.parse(pendingOpsStr);
          
          // Unisci le operazioni locali con quelle del server
          const allOperations = [...(operations || [])];
          
          // Aggiungi solo le operazioni locali che non sono già presenti nel server
          for (const localOp of localOps) {
            if (!allOperations.some(op => op.client_generated_id === localOp.id)) {
              allOperations.push(localOp);
            }
          }
          
          return allOperations;
        }
      } catch (localError) {
        console.warn('Errore nel recupero delle operazioni locali:', localError);
      }
      
      return operations || [];
    } catch (error) {
      console.error('Errore durante il recupero delle operazioni in sospeso:', error);
      return [];
    }
  },
  
  /**
   * Marca un'operazione come completata
   * @param operationId ID dell'operazione
   * @returns Promise<boolean> Success/failure
   */
  markOperationCompleted: async (operationId: string, tenantId?: string): Promise<boolean> => {
    try {
      // Se l'operazione ha un ID completo, aggiorna nel database
      if (operationId.length > 30) {
        const { error } = await supabase
          .from('pending_operations')
          .update({ 
            status: 'completed',
            error_message: null 
          })
          .eq('id', operationId);
        
        if (error) {
          console.warn('Errore nell\'aggiornamento dello stato dell\'operazione:', error);
          return false;
        }
      } 
      // Altrimenti, potrebbe essere un'operazione locale
      else if (tenantId) {
        try {
          const pendingOpsStr = localStorage.getItem(`${tenantId}_pending_ops`);
          if (pendingOpsStr) {
            const pendingOps = JSON.parse(pendingOpsStr);
            const updatedOps = pendingOps.filter(op => op.id !== operationId);
            localStorage.setItem(`${tenantId}_pending_ops`, JSON.stringify(updatedOps));
          }
        } catch (localError) {
          console.warn('Errore nell\'aggiornamento delle operazioni locali:', localError);
          return false;
        }
      }
      
      return true;
    } catch (error) {
      console.error('Errore durante l\'aggiornamento dell\'operazione:', error);
      return false;
    }
  }
};
