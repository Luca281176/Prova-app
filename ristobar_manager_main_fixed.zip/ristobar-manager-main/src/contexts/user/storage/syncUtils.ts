
// File di utilità per la sincronizzazione dei dati, semplificato dopo il refactoring

import { memoryStorage } from './memoryStorage';
import { safeStorage } from './safeStorage';
import { supabase } from '@/integrations/supabase/client';
import { getUserStorageKey } from './userDataStorage';
import { realtimeSync } from './sync';
import { syncOperations } from './sync';
import { DataSyncWorker } from './DataSyncWorker';

// Sync all memory storage to persistent storage on unload or at intervals
export const syncMemoryToStorage = async (): Promise<boolean> => {
  console.log("Syncing memory storage to persistent storage");
  
  try {
    let success = true;
    
    // For each tenant in memory storage
    for (const tenant in memoryStorage) {
      const tenantData = memoryStorage[tenant];
      
      // Skip empty tenant data
      if (!tenantData || Object.keys(tenantData).length === 0) {
        continue;
      }
      
      // For each item in tenant data
      for (const key in tenantData) {
        try {
          // Create a tenant-specific key for storage
          const storageKey = tenant === 'global' ? key : getUserStorageKey(tenant, key);
          
          // Stringify data
          const jsonData = JSON.stringify(tenantData[key]);
          
          // Save to persistent storage
          const itemSuccess = await safeStorage.setItem(storageKey, jsonData);
          
          // If any item fails, mark overall sync as failed
          if (!itemSuccess) {
            success = false;
          }
        } catch (itemError) {
          console.error(`Error syncing item ${key} for tenant ${tenant}:`, itemError);
          success = false;
        }
      }
    }
    
    return success;
  } catch (error) {
    console.error("Error during memory to storage sync:", error);
    return false;
  }
};

// Restore user data from Supabase and local storage
export const restoreUserData = async (userId: string): Promise<boolean> => {
  console.log(`Restoring user data for: ${userId}`);
  
  try {
    if (!userId) {
      console.warn("Cannot restore data: userId is empty");
      return false;
    }
    
    // Try to get data from Supabase for cross-browser sync
    try {
      const { data: settings, error } = await supabase
        .from('restaurant_settings')
        .select('*')
        .eq('tenant_id', userId)
        .maybeSingle();
      
      if (settings && !error) {
        console.log("Found user settings in Supabase");
        
        try {
          // Restore restaurant name if available
          if (settings.restaurant_name) {
            const storageKey = getUserStorageKey(userId, 'restaurantName');
            await safeStorage.setItem(storageKey, JSON.stringify(settings.restaurant_name));
            console.log("Restored restaurant name from Supabase");
          }
          
          // Restore general settings if available
          if (settings.general_settings) {
            try {
              const generalSettings = typeof settings.general_settings === 'string' 
                ? JSON.parse(settings.general_settings) 
                : settings.general_settings;
                
              const storageKey = getUserStorageKey(userId, 'userPreferences');
              await safeStorage.setItem(storageKey, JSON.stringify(generalSettings));
              console.log("Restored general settings from Supabase");
              
              // Also restore in memory
              if (!memoryStorage[userId]) {
                memoryStorage[userId] = {};
              }
              memoryStorage[userId]['userPreferences'] = generalSettings;
            } catch (parseError) {
              console.error("Error parsing general settings:", parseError);
            }
          }
          
          // Try to get menu data if available
          if (settings.menu_data) {
            try {
              const menuData = typeof settings.menu_data === 'string'
                ? JSON.parse(settings.menu_data)
                : settings.menu_data;
                
              const storageKey = getUserStorageKey(userId, 'menuData');
              await safeStorage.setItem(storageKey, JSON.stringify(menuData));
              console.log("Restored menu data from Supabase");
              
              // Also restore in memory
              if (!memoryStorage[userId]) {
                memoryStorage[userId] = {};
              }
              memoryStorage[userId]['menuData'] = menuData;
            } catch (parseError) {
              console.error("Error parsing menu data:", parseError);
            }
          }
          
          return true;
        } catch (settingsError) {
          console.error("Error restoring settings from Supabase:", settingsError);
        }
      }
    } catch (supabaseError) {
      console.error("Error fetching settings from Supabase:", supabaseError);
    }
    
    // Funzionalità di ripristino cache locale mantenuta
    try {
      const keysToRestore = [];
      
      // Find persistent copies
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(`persistent_${userId}_`)) {
          keysToRestore.push(key);
        }
      }
      
      if (keysToRestore.length > 0) {
        console.log(`Found ${keysToRestore.length} persistent data items to restore`);
        
        for (const persistentKey of keysToRestore) {
          try {
            // Get the value from the persistent copy
            const value = localStorage.getItem(persistentKey);
            
            // Calculate the original key (remove "persistent_" prefix)
            const originalKey = persistentKey.replace('persistent_', '');
            
            if (value) {
              // Restore to regular storage
              localStorage.setItem(originalKey, value);
              console.log(`Restored ${originalKey} from persistent copy`);
              
              // Also restore to memory
              const keyParts = originalKey.split('_');
              if (keyParts.length > 1) {
                const dataKey = keyParts.slice(1).join('_');
                
                if (!memoryStorage[userId]) {
                  memoryStorage[userId] = {};
                }
                
                try {
                  memoryStorage[userId][dataKey] = JSON.parse(value);
                } catch (parseError) {
                  console.warn(`Error parsing value for ${dataKey}:`, parseError);
                  memoryStorage[userId][dataKey] = value;
                }
              }
            }
          } catch (keyError) {
            console.error(`Error restoring ${persistentKey}:`, keyError);
          }
        }
        
        return true;
      }
    } catch (error) {
      console.error("Error restoring from localStorage:", error);
    }
    
    return false;
  } catch (error) {
    console.error("Error in restoreUserData:", error);
    return false;
  }
};

// Sync specific data to Supabase for cross-browser access
export const syncSpecificDataToSupabase = async (userId: string, key: string, data: any): Promise<boolean> => {
  console.log(`Syncing ${key} data to Supabase for user ${userId}`);
  
  try {
    if (!userId) {
      console.warn("Cannot sync data: userId is empty");
      return false;
    }
    
    let columnToUpdate = '';
    let dataToSync = data;
    
    // Map local storage key to Supabase column
    switch (key) {
      case 'restaurantName':
        columnToUpdate = 'restaurant_name';
        break;
      case 'userPreferences':
        columnToUpdate = 'general_settings';
        dataToSync = JSON.stringify(data);
        break;
      case 'menuData':
        columnToUpdate = 'menu_data';
        dataToSync = JSON.stringify(data);
        break;
      default:
        // For keys we don't explicitly handle
        console.log(`No specific Supabase column for ${key}, storing as JSON`);
        columnToUpdate = 'other_settings';
        const otherSettings = { [key]: data };
        dataToSync = JSON.stringify(otherSettings);
    }
    
    // Prepare the update object
    const updateData = {
      tenant_id: userId,
      [columnToUpdate]: dataToSync,
      last_updated: new Date().toISOString()
    };
    
    // Upsert to the restaurant_settings table
    const { error } = await supabase
      .from('restaurant_settings')
      .upsert(updateData)
      .eq('tenant_id', userId);
    
    if (error) {
      console.error("Error syncing data to Supabase:", error);
      return false;
    }
    
    console.log(`Successfully synced ${key} to Supabase`);
    return true;
  } catch (error) {
    console.error(`Error syncing ${key} to Supabase:`, error);
    return false;
  }
};

// Set up real-time subscription for data sync between devices
export const setupDataSyncSubscription = (userId: string, onDataChange: (table: string, newData: any) => void) => {
  if (!userId) {
    console.warn("Cannot setup sync: userId is empty");
    return null;
  }
  
  return realtimeSync.subscribeToRestaurantData(userId, onDataChange);
};

// Subscribe to changes in user data from other devices (ristrutturato per usare il modulo realtimeSync)
export const subscribeToChanges = (userId: string, callback: (newData: any) => void) => {
  return realtimeSync.subscribeToRestaurantData(userId, (dataType, newData) => {
    callback(newData);
  });
};

// Metodo per avviare manualmente il worker di sincronizzazione
export const startSyncWorker = (config?: any) => {
  return DataSyncWorker.getInstance(config);
};
