
/**
 * Configurazioni per il DataSyncWorker
 */
export interface DataSyncConfig {
  /** Intervallo in ms tra sincronizzazioni */
  syncInterval: number;
  /** Numero massimo di operazioni da processare per batch */
  batchSize: number;
  /** Tempo minimo tra notifiche di stato (ms) */
  statusNotificationInterval: number;
}

/**
 * Configurazione predefinita per il DataSyncWorker
 */
export const DEFAULT_SYNC_CONFIG: DataSyncConfig = {
  syncInterval: 5 * 60 * 1000, // 5 minuti
  batchSize: 10,
  statusNotificationInterval: 30 * 1000 // 30 secondi
};
