
/**
 * Classe responsabile per il monitoraggio dello stato della rete
 */
export class NetworkMonitor {
  private onlineCallback: (isOnline: boolean) => void;
  
  /**
   * Crea un nuovo monitor di rete
   * @param callback Funzione da chiamare quando lo stato della rete cambia
   */
  constructor(callback: (isOnline: boolean) => void) {
    this.onlineCallback = callback;
    this.initialize();
  }
  
  /**
   * Inizializza gli event listener per il monitoraggio della rete
   */
  private initialize(): void {
    window.addEventListener('online', () => this.onNetworkChange(true));
    window.addEventListener('offline', () => this.onNetworkChange(false));
  }
  
  /**
   * Risponde ai cambiamenti dello stato della rete
   * @param isOnline Se la connessione è online
   */
  private onNetworkChange(isOnline: boolean): void {
    this.onlineCallback(isOnline);
  }
  
  /**
   * Rimuove gli event listener
   */
  public destroy(): void {
    window.removeEventListener('online', () => this.onNetworkChange(true));
    window.removeEventListener('offline', () => this.onNetworkChange(false));
  }
  
  /**
   * Verifica se la connessione è attualmente online
   * @returns boolean
   */
  public isOnline(): boolean {
    return navigator.onLine;
  }
}
