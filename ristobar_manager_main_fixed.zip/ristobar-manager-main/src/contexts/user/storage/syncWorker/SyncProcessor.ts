
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

/**
 * Classe responsabile per l'elaborazione effettiva delle operazioni di sincronizzazione
 */
export class SyncProcessor {
  
  /**
   * Elabora un'operazione di sincronizzazione verso Supabase
   * @param op Operazione da sincronizzare
   * @returns Promise<boolean> Success/failure
   */
  public async processSyncOperation(op: any): Promise<boolean> {
    try {
      if (op.operation_type === 'save') {
        console.log(`Sincronizzazione operazione ${op.id} di tipo ${op.operation_type} per tenant ${op.tenant_id}`);
        console.log(`Dati da sincronizzare:`, op.data);
        
        // Prima salva i dati localmente per garantire la persistenza
        try {
          if (op.data && op.data.data_type && op.data.data) {
            const storageKey = `${op.tenant_id}_${op.data.data_type}`;
            localStorage.setItem(storageKey, JSON.stringify(op.data.data));
            console.log(`Dati salvati in localStorage con chiave ${storageKey}`);
          }
        } catch (localError) {
          console.warn('Errore nel salvataggio locale:', localError);
        }
        
        // Poi sincronizza con Supabase
        const { data: result, error: syncError } = await supabase
          .rpc('sync_restaurant_data', {
            p_tenant_id: op.tenant_id,
            p_data_type: op.data.data_type,
            p_data: op.data.data,
            p_client_version: op.data.version || 1
          });

        if (syncError) {
          console.error(`Errore nella sincronizzazione:`, syncError);
          throw syncError;
        }

        console.log(`Risultato sincronizzazione:`, result);

        // Aggiorna lo stato dell'operazione
        await this.markOperationCompleted(op.id);

        console.log(`✅ Operazione ${op.id} completata con successo`);
        return true;
      } else {
        console.warn(`Tipo di operazione non supportato: ${op.operation_type}`);
      }
      
      return false;
    } catch (opError) {
      console.error(`❌ Errore sincronizzazione operazione ${op.id}:`, opError);
      
      // Aggiorna lo stato dell'operazione con l'errore
      await this.markOperationError(op.id, opError.message, op.retry_count || 0);
      
      return false;
    }
  }

  /**
   * Marca un'operazione come completata
   * @param operationId ID dell'operazione
   */
  private async markOperationCompleted(operationId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('pending_operations')
        .update({ 
          status: 'completed',
          error_message: null 
        })
        .eq('id', operationId);
        
      if (error) {
        console.warn(`Errore nell'aggiornamento dello stato dell'operazione ${operationId}:`, error);
      }
    } catch (error) {
      console.error(`Errore durante il completamento dell'operazione ${operationId}:`, error);
    }
  }

  /**
   * Marca un'operazione come fallita
   * @param operationId ID dell'operazione
   * @param errorMessage Messaggio di errore
   * @param currentRetryCount Conteggio attuale dei tentativi
   */
  private async markOperationError(
    operationId: string, 
    errorMessage: string, 
    currentRetryCount: number
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('pending_operations')
        .update({
          status: 'error',
          retry_count: currentRetryCount + 1,
          error_message: errorMessage
        })
        .eq('id', operationId);
        
      if (error) {
        console.warn(`Errore nell'aggiornamento dello stato di errore dell'operazione ${operationId}:`, error);
      }
    } catch (error) {
      console.error(`Errore durante la marcatura dell'errore dell'operazione ${operationId}:`, error);
    }
  }
  
  /**
   * Conta le operazioni in sospeso per un tenant
   * @param tenantId ID del tenant
   * @returns Promise<number> Numero di operazioni in sospeso
   */
  public async countPendingOperations(tenantId: string): Promise<number> {
    try {
      const { count, error } = await supabase
        .from('pending_operations')
        .select('*', { count: 'exact', head: true })
        .eq('tenant_id', tenantId)
        .eq('status', 'pending');
        
      if (error) {
        console.warn(`Errore nel conteggio delle operazioni in sospeso:`, error);
        return 0;
      }
      
      return count || 0;
    } catch (error) {
      console.error(`Errore durante il conteggio delle operazioni in sospeso:`, error);
      return 0;
    }
  }
}
