
import { safeStorage } from './safeStorage';
import { memoryStorage } from './memoryStorage';
import { supabase } from '@/integrations/supabase/client';

// Helper function to get user-specific storage key
export const getUserStorageKey = (userId: string, key: string) => {
  return `${userId}_${key}`;
};

// Sync all memory data to localStorage and Supabase
export const syncMemoryToStorage = async (): Promise<boolean> => {
  try {
    console.log(`Syncing all memory data to storage`);
    
    // Get all user IDs in memory storage
    const userIds = Object.keys(memoryStorage);
    if (userIds.length === 0) {
      console.log(`No memory data to sync`);
      return true;
    }
    
    for (const userId of userIds) {
      if (!memoryStorage[userId]) {
        console.log(`No memory data to sync for user ${userId}`);
        continue;
      }
      
      const keys = Object.keys(memoryStorage[userId]);
      
      for (const key of keys) {
        const data = memoryStorage[userId][key];
        if (data) {
          try {
            // Extract the actual key part (removing userId prefix if it exists)
            const actualKey = key.startsWith(`${userId}_`) ? key : `${userId}_${key}`;
            const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
            
            // Save to localStorage first for immediate access
            localStorage.setItem(actualKey, jsonData);
            
            // Also try to save to Supabase (async)
            try {
              await safeStorage.setItem(actualKey, jsonData);
            } catch (supabaseError) {
              console.warn(`Error syncing ${key} to Supabase:`, supabaseError);
            }
          } catch (keyError) {
            console.warn(`Error syncing key ${key}:`, keyError);
          }
        }
      }
      
      console.log(`Memory data sync completed for user ${userId}`);
    }
    
    return true;
  } catch (error) {
    console.error(`Error syncing memory data:`, error);
    return false;
  }
};

// Save user data to storage with user-specific key with fallback mechanisms
export const saveUserDataToStorage = async (userId: string, key: string, data: any): Promise<boolean> => {
  try {
    if (!userId) {
      console.warn(`Cannot save data with key ${key}: userId is empty`);
      return false;
    }
    
    const storageKey = getUserStorageKey(userId, key);
    const jsonData = JSON.stringify(data);
    console.log(`Saving user data for ${userId} with key ${key}`);
    
    // Save to local storage first
    localStorage.setItem(storageKey, jsonData);
    
    // Also save to sessionStorage as backup
    try {
      sessionStorage.setItem(storageKey, jsonData);
    } catch (sessionError) {
      console.warn(`Error saving ${key} to sessionStorage:`, sessionError);
    }
    
    // Also store in memory as an additional fallback
    if (!memoryStorage[userId]) {
      memoryStorage[userId] = {};
    }
    memoryStorage[userId][key] = data;
    
    // Try to save using safeStorage (which attempts Supabase save)
    try {
      await safeStorage.setItem(storageKey, jsonData);
    } catch (safeStorageError) {
      console.warn(`Error using safeStorage for ${key}:`, safeStorageError);
      // Already saved to localStorage and memory, so still consider this a partial success
    }
    
    return true;
  } catch (error) {
    console.error(`Error saving ${key} for user ${userId}:`, error);
    
    // Last resort fallback: try to save to memory only
    try {
      if (!memoryStorage[userId]) {
        memoryStorage[userId] = {};
      }
      memoryStorage[userId][key] = data;
      console.warn(`Saved ${key} to memory storage only as fallback`);
    } catch (memoryError) {
      console.error(`Complete failure saving ${key} for user ${userId}:`, memoryError);
      return false;
    }
    
    return false;
  }
};

// Get user data from storage with user-specific key
export const getUserData = async (userId: string, key: string, defaultValue: any = null, forceSupabase = false) => {
  if (!userId) {
    console.warn(`Attempted to get user data with key ${key} but userId is empty`);
    return defaultValue;
  }

  try {
    const storageKey = getUserStorageKey(userId, key);
    console.log(`Getting user data for ${userId} with key ${key}, forceSupabase: ${forceSupabase}`);
    
    // If forceSupabase is true, try Supabase first
    if (forceSupabase) {
      try {
        console.log(`Forcing data retrieval from Supabase for ${key}`);
        const supabaseData = await safeStorage.getItem(storageKey);
        if (supabaseData) {
          try {
            const parsedData = JSON.parse(supabaseData);
            
            // Update localStorage with the latest data from Supabase
            localStorage.setItem(storageKey, supabaseData);
            
            // Update memory storage
            if (!memoryStorage[userId]) {
              memoryStorage[userId] = {};
            }
            memoryStorage[userId][key] = parsedData;
            
            console.log(`Successfully retrieved ${key} from Supabase`);
            return parsedData;
          } catch (parseError) {
            console.warn(`Error parsing Supabase data for ${key}:`, parseError);
          }
        }
      } catch (supabaseError) {
        console.warn(`Error getting ${key} from Supabase:`, supabaseError);
      }
    }
    
    // First try localStorage (most reliable)
    const localData = localStorage.getItem(storageKey);
    if (localData) {
      try {
        return JSON.parse(localData);
      } catch (parseError) {
        console.warn(`Error parsing localStorage data for ${key}:`, parseError);
      }
    }
    
    // Then try sessionStorage
    try {
      const sessionData = sessionStorage.getItem(storageKey);
      if (sessionData) {
        return JSON.parse(sessionData);
      }
    } catch (sessionError) {
      console.warn(`Error getting ${key} from sessionStorage:`, sessionError);
    }
    
    // Try memory storage
    if (memoryStorage[userId] && memoryStorage[userId][key] !== undefined) {
      return memoryStorage[userId][key];
    }
    
    // Last attempt with safeStorage which tries Supabase
    try {
      const safeData = await safeStorage.getItem(storageKey);
      if (safeData) {
        try {
          const parsedData = JSON.parse(safeData);
          
          // Update localStorage with the data from Supabase
          localStorage.setItem(storageKey, safeData);
          
          return parsedData;
        } catch (parseError) {
          console.warn(`Error parsing Supabase data for ${key}:`, parseError);
        }
      }
    } catch (safeError) {
      console.warn(`Error getting ${key} from safeStorage:`, safeError);
    }
    
    return defaultValue;
  } catch (error) {
    console.error(`Error retrieving ${key} for user ${userId}:`, error);
    return defaultValue;
  }
};

// Modified version: only clears authentication data, not user data
export const clearAllUserData = () => {
  console.log("Clearing session data but preserving user data");
  
  try {
    // Only remove authentication keys
    const authKeys = [
      'auth_token',
      'supabase.auth.token', 
      'supabase-session', 
      'had_active_session'
    ];
    
    // Remove only the specified authentication keys
    authKeys.forEach(key => {
      console.log(`Clearing auth key: ${key}`);
      localStorage.removeItem(key);
      try {
        sessionStorage.removeItem(key);
      } catch (e) {
        // Ignore errors on sessionStorage
      }
    });
    
    console.log("Auth data cleared, user data preserved");
  } catch (error) {
    console.warn("Error during selective auth data clearing:", error);
  }
};

// Export a sync function that doesn't return a promise
export const getUserDataSync = <T>(userId: string, key: string, defaultValue: T = null as unknown as T): T => {
  if (!userId || typeof userId !== 'string') {
    console.warn(`Invalid userId: ${userId} for key: ${key}`);
    return defaultValue;
  }

  const storageKey = `${userId}_${key}`;
  
  try {
    const data = localStorage.getItem(storageKey);
    if (data === null) {
      // If not in localStorage, check memory storage
      if (memoryStorage[userId] && memoryStorage[userId][key] !== undefined) {
        return memoryStorage[userId][key] as T;
      }
      return defaultValue;
    }
    
    return JSON.parse(data) as T;
  } catch (error) {
    console.error(`Error getting user data for key ${key}:`, error);
    return defaultValue;
  }
};

// Function to restore user data from Supabase (with force option)
export const restoreUserData = async (userId: string, forceRestore = false): Promise<boolean> => {
  try {
    console.log(`Restoring user data for ${userId} from Supabase (force: ${forceRestore})`);
    
    // Query restaurant_settings first
    const { data: settingsData, error: settingsError } = await supabase
      .from('restaurant_settings')
      .select('*')
      .eq('tenant_id', userId)
      .single();
    
    let restoredAny = false;
    
    if (settingsError) {
      console.warn(`Error retrieving restaurant settings for ${userId}:`, settingsError);
    } else if (settingsData) {
      console.log(`Found restaurant settings for ${userId}`);
      
      // Store restaurant settings in multiple storage locations
      try {
        // Store the complete settings object
        localStorage.setItem(`${userId}_restaurantInfo`, JSON.stringify(settingsData));
        
        // Also store each element separately for backward compatibility
        if (settingsData.general_settings) {
          let generalSettings;
          
          // Try to parse if it's a string
          try {
            generalSettings = typeof settingsData.general_settings === 'string' 
              ? JSON.parse(settingsData.general_settings) 
              : settingsData.general_settings;
              
            localStorage.setItem(`${userId}_generalSettings`, JSON.stringify(generalSettings));
            localStorage.setItem(`${userId}_userPreferences`, JSON.stringify(generalSettings));
            
            // Update memory storage
            if (!memoryStorage[userId]) {
              memoryStorage[userId] = {};
            }
            memoryStorage[userId]['generalSettings'] = generalSettings;
            memoryStorage[userId]['userPreferences'] = generalSettings;
            
            restoredAny = true;
          } catch (parseError) {
            console.warn(`Error parsing general_settings:`, parseError);
          }
        }
        
        if (settingsData.restaurant_name) {
          localStorage.setItem(`${userId}_restaurantName`, settingsData.restaurant_name);
        }
        
        if (settingsData.restaurant_logo) {
          localStorage.setItem(`${userId}_restaurantLogo`, settingsData.restaurant_logo);
        }
      } catch (storageError) {
        console.warn(`Error storing restaurant settings:`, storageError);
      }
    }
    
    // Now query for restaurant_data to get more specific data types
    if (forceRestore) {
      console.log(`Forcing restoration of all data types from restaurant_data`);
      
      try {
        const { data: restaurantData, error: restaurantError } = await supabase
          .from('restaurant_data')
          .select('data_type, data, version')
          .eq('tenant_id', userId)
          .eq('is_deleted', false);
          
        if (restaurantError) {
          console.warn(`Error retrieving restaurant data:`, restaurantError);
        } else if (restaurantData && restaurantData.length > 0) {
          console.log(`Found ${restaurantData.length} data items in restaurant_data`);
          
          // Process each data item
          for (const item of restaurantData) {
            try {
              if (!item) continue;
              const { data_type, data, version } = item as { data_type: string, data: any, version: number };
              
              if (data_type && data) {
                // Store with user-specific key
                const storageKey = `${userId}_${data_type}`;
                const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
                
                console.log(`Restoring data for ${data_type} (version: ${version})`);
                
                // Save to all storage mechanisms
                localStorage.setItem(storageKey, jsonData);
                
                try {
                  sessionStorage.setItem(storageKey, jsonData);
                } catch (sessionError) {
                  // Ignore session storage errors
                }
                
                // Update memory storage
                if (!memoryStorage[userId]) {
                  memoryStorage[userId] = {};
                }
                memoryStorage[userId][data_type] = typeof data === 'string' ? JSON.parse(data) : data;
                
                restoredAny = true;
              }
            } catch (itemError) {
              console.warn(`Error processing data item:`, itemError);
            }
          }
          
          if (restoredAny) {
            console.log(`Successfully restored user data from restaurant_data table`);
          }
        } else {
          console.log(`No data found in restaurant_data for user ${userId}`);
        }
      } catch (dataError) {
        console.warn(`Error retrieving restaurant_data:`, dataError);
      }
    }
    
    return restoredAny;
  } catch (error) {
    console.error(`Error in restoreUserData:`, error);
    return false;
  }
};

// Function to specifically sync data to Supabase
export const syncSpecificDataToSupabase = async (userId: string, key: string): Promise<boolean> => {
  try {
    if (!userId || !key) {
      console.warn('Invalid userId or key for syncSpecificDataToSupabase');
      return false;
    }
    
    const storageKey = `${userId}_${key}`;
    const localData = localStorage.getItem(storageKey);
    
    if (!localData) {
      console.log(`No local data found for ${key} to sync to Supabase`);
      return false;
    }
    
    console.log(`Syncing ${key} data to Supabase for user ${userId}`);
    
    try {
      // Try to parse the data (ensure it's valid JSON)
      const parsedData = JSON.parse(localData);
      
      // Determine how to store the data based on key type
      if (key === 'userPreferences' || key === 'generalSettings') {
        // Store in restaurant_settings
        const { data, error } = await supabase
          .from('restaurant_settings')
          .upsert({
            tenant_id: userId,
            general_settings: localData,
            updated_at: new Date().toISOString()
          }, { onConflict: 'tenant_id' });
          
        if (error) {
          console.error(`Error syncing ${key} to restaurant_settings:`, error);
          return false;
        }
        
        console.log(`Successfully synced ${key} to restaurant_settings`);
      } else {
        // Store in restaurant_data
        const { data, error } = await supabase
          .from('restaurant_data')
          .upsert({
            tenant_id: userId,
            data_type: key,
            data: parsedData,
            updated_at: new Date().toISOString()
          }, { onConflict: 'tenant_id, data_type' });
          
        if (error) {
          console.error(`Error syncing ${key} to restaurant_data:`, error);
          return false;
        }
        
        console.log(`Successfully synced ${key} to restaurant_data`);
      }
      
      return true;
    } catch (parseError) {
      console.error(`Error parsing data for ${key}:`, parseError);
      return false;
    }
  } catch (error) {
    console.error(`Error in syncSpecificDataToSupabase:`, error);
    return false;
  }
};

// Function to set up a subscription for changes to user data in Supabase
export const setupDataSyncSubscription = (userId: string) => {
  if (!userId) return null;
  
  try {
    console.log(`Setting up data sync subscription for user ${userId}`);
    
    // Subscribe to changes in restaurant_data for this tenant
    const channel = supabase
      .channel(`tenant_${userId}_changes`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'restaurant_data',
        filter: `tenant_id=eq.${userId}`
      }, (payload) => {
        try {
          console.log(`Received change for restaurant_data:`, payload);
          
          if (payload.new) {
            const newData = payload.new as any;
            if (newData.data_type && newData.data) {
              const { data_type, data, version } = newData;
              
              // Check if we have a newer version locally
              const localData = localStorage.getItem(`${userId}_${data_type}`);
              if (localData) {
                try {
                  const localObj = JSON.parse(localData);
                  if (localObj && localObj.version && localObj.version > version) {
                    console.log(`Local version (${localObj.version}) is newer than server version (${version}), not updating`);
                    return;
                  }
                } catch (e) {
                  // Continue with update if we can't parse local version
                }
              }
              
              // Update local storage with the new data
              const storageKey = `${userId}_${data_type}`;
              const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
              
              localStorage.setItem(storageKey, jsonData);
              
              // Update memory storage
              if (!memoryStorage[userId]) {
                memoryStorage[userId] = {};
              }
              memoryStorage[userId][data_type] = typeof data === 'string' ? JSON.parse(data) : data;
              
              console.log(`Updated local data for ${data_type} from Supabase realtime`);
            }
          }
        } catch (error) {
          console.error(`Error processing realtime update:`, error);
        }
      })
      .subscribe();
      
    // Also subscribe to restaurant_settings changes
    const settingsChannel = supabase
      .channel(`tenant_${userId}_settings_changes`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'restaurant_settings',
        filter: `tenant_id=eq.${userId}`
      }, (payload) => {
        try {
          console.log(`Received change for restaurant_settings:`, payload);
          
          if (payload.new) {
            const newData = payload.new as any;
            const { general_settings, restaurant_name, restaurant_logo } = newData;
            
            // Update general settings if available
            if (general_settings) {
              try {
                const parsedSettings = typeof general_settings === 'string' 
                  ? JSON.parse(general_settings) 
                  : general_settings;
                
                localStorage.setItem(`${userId}_generalSettings`, JSON.stringify(parsedSettings));
                localStorage.setItem(`${userId}_userPreferences`, JSON.stringify(parsedSettings));
                
                // Update memory storage
                if (!memoryStorage[userId]) {
                  memoryStorage[userId] = {};
                }
                memoryStorage[userId]['generalSettings'] = parsedSettings;
                memoryStorage[userId]['userPreferences'] = parsedSettings;
              } catch (e) {
                console.warn(`Error parsing general_settings from realtime update:`, e);
              }
            }
            
            // Update restaurant name if available
            if (restaurant_name) {
              localStorage.setItem(`${userId}_restaurantName`, restaurant_name);
            }
            
            // Update restaurant logo if available
            if (restaurant_logo) {
              localStorage.setItem(`${userId}_restaurantLogo`, restaurant_logo);
            }
            
            console.log(`Updated restaurant settings from Supabase realtime`);
          }
        } catch (error) {
          console.error(`Error processing settings realtime update:`, error);
        }
      })
      .subscribe();
    
    return [channel, settingsChannel];
  } catch (error) {
    console.error(`Error setting up data sync subscription:`, error);
    return null;
  }
};

export const subscribeToChanges = (userId: string, key: string, callback: (data: any) => void) => {
  if (!userId || !key || !callback) return () => {};
  
  try {
    console.log(`Setting up subscription for ${key} changes`);
    
    // Set up local storage event listener
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === `${userId}_${key}` && event.newValue) {
        try {
          const newData = JSON.parse(event.newValue);
          callback(newData);
        } catch (e) {
          console.warn(`Error parsing storage event data:`, e);
        }
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Return cleanup function
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  } catch (error) {
    console.error(`Error setting up change subscription:`, error);
    return () => {};
  }
};
