
// This file is maintained for backwards compatibility and re-exports 
// the functionality from the refactored storage modules
import { 
  getUserStorageKey,
  getUserData,
  getUserDataSync,
  clearAllUserData
} from './storage/storageUtils';

import {
  restoreUserData,
  syncSpecificDataToSupabase,
  syncMemoryToStorage
} from './storage/dataSync';

import {
  setupDataSyncSubscription,
  subscribeToChanges
} from './storage/subscriptions';

// Re-export everything explicitly to avoid conflicts
export {
  getUserStorageKey,
  getUserData,
  getUserDataSync,
  clearAllUserData,
  restoreUserData,
  syncSpecificDataToSupabase,
  syncMemoryToStorage,
  setupDataSyncSubscription,
  subscribeToChanges
};

// Add these functions or modify the existing ones to ensure a consistent API
export const getRegisteredUsers = async () => {
  // Implementation for getting registered users
  return [];
};

export const saveRegisteredUsers = async (users: any[]) => {
  // Implementation for saving registered users
  console.log('Saving registered users:', users.length);
  return true; // Return a boolean indicating success
};

export const clearUserSpecificData = async (userId: string) => {
  // Implementation for clearing user data
  console.log('Clearing data for user:', userId);
};

export const initializeRegisteredUsers = async () => {
  // Implementation for initializing registered users
  console.log('Initializing registered users');
};

export const migrateLocalStorageData = async (userId?: string) => {
  // Implementation for migrating local storage data
  console.log('Migrating local storage data', userId ? `for user: ${userId}` : '');
};

// Define the saveUserDataToStorage function (only once)
export const saveUserDataToStorage = async (userId: string, key: string, data: any): Promise<boolean> => {
  try {
    if (!userId) {
      console.warn(`Cannot save data with key ${key}: userId is empty`);
      return false;
    }
    
    const storageKey = getUserStorageKey(userId, key);
    const jsonData = JSON.stringify(data);
    console.log(`Saving user data for ${userId} with key ${key}`);
    
    // Save to local storage first
    localStorage.setItem(storageKey, jsonData);
    
    // Also save to memory as an additional fallback
    const { memoryStorage } = await import('./storage/memoryStorage');
    if (!memoryStorage[userId]) {
      memoryStorage[userId] = {};
    }
    memoryStorage[userId][key] = data;
    
    return true;
  } catch (error) {
    console.error(`Error saving ${key} for user ${userId}:`, error);
    return false;
  }
};
