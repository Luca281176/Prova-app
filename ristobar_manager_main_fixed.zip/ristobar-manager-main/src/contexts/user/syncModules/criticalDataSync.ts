
import { syncSpecificDataToSupabase } from '../storageUtils';
import { toast } from 'sonner';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

/**
 * Verifica se il tenant_id è valido (non è "default" o vuoto)
 * @param userId ID del tenant da verificare
 * @returns Promise<string> Il tenant_id corretto
 */
const ensureValidTenantId = async (userId: string): Promise<string> => {
  if (!userId || userId === "default") {
    console.warn("⚠️ Rilevato tenant_id non valido:", userId);
    
    // Tenta di recuperare il tenant_id corretto dall'auth o da localStorage
    const correctId = await tenantModule.getCurrentTenantId();
    
    if (correctId) {
      console.log("✅ Tenant_id corretto recuperato:", correctId);
      return correctId;
    } else {
      console.error("❌ Impossibile recuperare un tenant_id valido");
      throw new Error("Tenant ID non valido e impossibile recuperarne uno corretto");
    }
  }
  
  return userId;
};

/**
 * Setup listener for critical data changes that need synchronization
 * @param userId User ID for data synchronization
 * @returns Cleanup function
 */
export const setupCriticalDataSync = (userId: string): (() => void) => {
  try {
    // Verifica iniziale del tenant_id
    ensureValidTenantId(userId).then(validId => {
      if (validId !== userId) {
        console.log(`⚠️ tenant_id corretto (${validId}) è diverso da quello fornito (${userId})`);
        userId = validId;
      }
    }).catch(err => {
      console.error("Errore nella verifica del tenant_id:", err);
      return () => {};
    });
    
    if (!userId) return () => {};
    
    // Sync interval for automatic periodic sync of critical data
    const syncIntervalId = setInterval(() => {
      // Verifica il tenant_id prima di sincronizzare
      ensureValidTenantId(userId).then(validId => {
        synchronizeCriticalData(validId);
      }).catch(err => {
        console.error("Errore nella sincronizzazione periodica:", err);
      });
    }, 60000); // Every minute
    
    // Create a function to listen for critical data changes and trigger sync
    const handleStorageChange = async (event: StorageEvent) => {
      if (!event.key) return;
      
      // Verifica il tenant_id prima di procedere
      let validTenantId: string;
      try {
        validTenantId = await ensureValidTenantId(userId);
      } catch (error) {
        console.error("Errore nel recupero del tenant_id valido:", error);
        return;
      }
      
      // Only sync user-specific data
      if (!event.key.startsWith(`${validTenantId}_`)) return;
      
      // Only sync critical data types
      const isCriticalData = 
        event.key.includes('userPreferences') || 
        event.key.includes('restaurantInfo') || 
        event.key.includes('generalSettings') || 
        event.key.includes('menuData') || 
        event.key.includes('tableLayout') || 
        event.key.includes('roomLayout') ||
        event.key.includes('cashierSettings');
        
      if (isCriticalData && event.newValue) {
        // Extract the key without user ID prefix
        const dataKey = event.key.replace(`${validTenantId}_`, '');
        
        // Sync to Supabase with a small delay to batch changes
        let data;
        try {
          data = JSON.parse(event.newValue);
        } catch (e) {
          data = event.newValue; // Use as string if not JSON
        }
        
        // Aggiungi un indicatore di sincronizzazione visual
        toast.loading("Sincronizzazione in corso...", {
          duration: 2000,
          id: "sync-in-progress"
        });
        
        // Use setTimeout to debounce multiple rapid changes
        setTimeout(() => {
          syncSpecificDataToSupabase(validTenantId, dataKey, data)
            .then(success => {
              if (success) {
                // Update sync timestamp
                localStorage.setItem(`${validTenantId}_last_settings_sync`, new Date().toISOString());
                toast.success("Dati sincronizzati con successo", {
                  duration: 2000,
                  id: "sync-success"
                });
              } else {
                toast.error("Errore durante la sincronizzazione", {
                  duration: 3000,
                  id: "sync-error"
                });
                
                // Retry sync after failure
                setTimeout(() => {
                  syncSpecificDataToSupabase(validTenantId, dataKey, data);
                }, 5000);
              }
            });
        }, 1000);
      }
    };

    // Function to sync critical data without an event trigger
    const synchronizeCriticalData = (validTenantId: string) => {
      const criticalKeys = [
        'userPreferences',
        'restaurantInfo',
        'generalSettings',
        'menuData',
        'tableLayout',
        'roomLayout',
        'cashierSettings'
      ];

      console.log(`🔄 Sincronizzazione automatica dati critici per tenant: ${validTenantId}`);

      // Loop through critical keys and sync their data
      criticalKeys.forEach(key => {
        const storageKey = `${validTenantId}_${key}`;
        const dataStr = localStorage.getItem(storageKey);
        
        if (dataStr) {
          try {
            const data = JSON.parse(dataStr);
            syncSpecificDataToSupabase(validTenantId, key, data)
              .then(success => {
                if (success) {
                  console.log(`✅ Auto-synced ${key} successfully`);
                } else {
                  console.warn(`❌ Failed to auto-sync ${key}`);
                }
              });
          } catch (e) {
            // For non-JSON data
            syncSpecificDataToSupabase(validTenantId, key, dataStr);
          }
        }
      });
    };
    
    // Add storage listener
    window.addEventListener('storage', handleStorageChange);
    
    // Initial sync of critical data
    ensureValidTenantId(userId).then(validId => {
      synchronizeCriticalData(validId);
    }).catch(err => {
      console.error("Errore nella sincronizzazione iniziale:", err);
    });
    
    // Return cleanup function
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(syncIntervalId);
    };
  } catch (error) {
    console.error("Errore nell'inizializzazione del sync dei dati critici:", error);
    return () => {};
  }
};
