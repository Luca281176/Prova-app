
import { supabase } from '@/integrations/supabase/client';
import { syncMemoryToStorage } from '../storageUtils';
import { toast } from 'sonner';
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

/**
 * Force an immediate refresh of data from Supabase
 * @param userId The user's ID
 * @returns Promise<void>
 */
export const forceRefreshFromSupabase = async (userId: string): Promise<void> => {
  try {
    // If userId is "default", try to get the correct tenant_id
    if (userId === "default" || !userId) {
      console.error("Invalid tenant_id detected: ", userId);
      const correctTenantId = await tenantModule.getCurrentTenantId();
      
      if (correctTenantId) {
        console.log("🔄 Corretto tenant_id da 'default' a:", correctTenantId);
        userId = correctTenantId;
      } else {
        throw new Error("Impossibile determinare il tenant_id corretto");
      }
    }
    
    console.log("🔄 Forza aggiornamento dati da Supabase per tenant:", userId);
    
    // Mostra un toast di aggiornamento in corso
    toast.loading("Sincronizzazione in corso...", {
      id: "force-sync-progress",
      duration: 5000
    });
    
    // Prima, aggiorna tutti i dati su Supabase
    await syncMemoryToStorage();
    
    // Poi, invia un segnale per aggiornare la versione dei dati
    const { error } = await supabase
      .from('sync_signals')
      .upsert({
        tenant_id: userId,
        last_update: new Date().toISOString(),
        version: Math.floor(Date.now() / 1000) // Usa timestamp unix come versione
      }, { onConflict: 'tenant_id' });
      
    if (error) {
      console.error("Errore nell'invio del segnale di sync:", error);
      toast.error("Errore durante la sincronizzazione", {
        id: "force-sync-error"
      });
    } else {
      console.log("✅ Segnale di aggiornamento inviato con successo per tenant:", userId);
      toast.success("Sincronizzazione completata con successo", {
        id: "force-sync-success"
      });
    }
    
    // Forzare un aggiornamento completo dei dati
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (!userError && userData) {
      // Salva nel localStorage
      localStorage.setItem('user', JSON.stringify(userData));
    }
    
    // Recupera tutti i dati del ristorante
    const { data: restaurantData, error: dataError } = await supabase
      .from('restaurant_data')
      .select('*')
      .eq('tenant_id', userId)
      .eq('is_deleted', false);
      
    if (!dataError && restaurantData && restaurantData.length > 0) {
      for (const item of restaurantData) {
        if (item.data_type && item.data) {
          const storageKey = `${userId}_${item.data_type}`;
          const jsonData = typeof item.data === 'string' ? item.data : JSON.stringify(item.data);
          localStorage.setItem(storageKey, jsonData);
        }
      }
    }
    
    // Aggiorna il timestamp dell'ultimo sync globale
    localStorage.setItem(`${userId}_last_global_sync`, Date.now().toString());
    
  } catch (e) {
    console.error("Errore durante il refresh forzato:", e);
    toast.error("Errore durante la sincronizzazione", {
      id: "force-sync-error"
    });
  }
};

/**
 * Display a toast notification and trigger forced refresh
 * @param userId The user's ID
 */
export const handleForceSyncEvent = (userId: string) => {
  // Verifica se il tenant_id è valido
  if (!userId || userId === "default") {
    console.warn("⚠️ handleForceSyncEvent ricevuto tenant_id non valido:", userId);
    
    // Prova a recuperare il tenant_id corretto
    tenantModule.getCurrentTenantId().then(correctId => {
      if (correctId) {
        console.log("✅ Recuperato tenant_id corretto:", correctId);
        forceRefreshFromSupabase(correctId);
        toast.info("Sincronizzazione forzata in corso...", {
          duration: 2000,
          id: "force-sync"
        });
      } else {
        toast.error("Impossibile determinare il tenant ID", {
          duration: 3000
        });
      }
    });
    return;
  }
  
  forceRefreshFromSupabase(userId);
  toast.info("Sincronizzazione forzata in corso...", {
    duration: 2000,
    id: "force-sync"
  });
};
