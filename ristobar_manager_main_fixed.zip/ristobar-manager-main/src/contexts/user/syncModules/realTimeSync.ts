
import { supabase } from '@/integrations/supabase/client';
import { User } from '../types';
import { toast } from 'sonner';
import { restoreUserData } from '../storageUtils';

type SetUserFunction = React.Dispatch<React.SetStateAction<User | null>>;

/**
 * Set up real-time listeners for user data updates
 * @param user The current user
 * @param setUser Function to update user state
 * @returns Cleanup function for all channels
 */
export const setupRealTimeSync = (
  user: User | null, 
  setUser: SetUserFunction
): (() => void) => {
  if (!user) return () => {};
  
  // Set up real-time listener for user updates
  const userChannel = supabase
    .channel('public:users')
    .on('postgres_changes', { 
      event: 'UPDATE', 
      schema: 'public', 
      table: 'users',
      filter: `id=eq.${user.id}`
    }, (payload) => {
      console.log('Real-time user data update received:', payload);
      if (payload.new && user) {
        const updatedUser = {
          ...user,
          ...payload.new,
          subscription: user.subscription
        };
        
        setUser(updatedUser);
        
        // Save to localStorage
        try {
          localStorage.setItem('user', JSON.stringify(updatedUser));
        } catch (storageError) {
          console.warn("LocalStorage quota exceeded when saving real-time user update", storageError);
        }
      }
    })
    .subscribe((status) => {
      console.log(`User data channel status: ${status}`);
      if (status === 'SUBSCRIBED') {
        console.log('Successfully subscribed to real-time user updates');
      } else if (status === 'CHANNEL_ERROR') {
        console.error('Error subscribing to user updates channel');
        setTimeout(() => {
          // Retry subscription after error
          userChannel.subscribe();
        }, 5000);
      }
    });
    
  // Also listen for restaurant settings changes for cross-browser sync
  const settingsChannel = supabase
    .channel('public:restaurant_settings')
    .on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'restaurant_settings',
      filter: `tenant_id=eq.${user.id}`
    }, async (payload) => {
      console.log('Real-time settings update received:', payload);
      
      if (payload.new && typeof payload.new === 'object' && 'general_settings' in payload.new) {
        // Get current timestamp for comparison
        const localTimestamp = localStorage.getItem(`${user.id}_last_settings_sync`);
        const remoteTimestamp = payload.new.updated_at;
        
        // Skip if the update was triggered by this browser (within last 5 seconds)
        if (localTimestamp && 
            new Date(remoteTimestamp as string).getTime() - new Date(localTimestamp).getTime() < 5000) {
          console.log('Ignoring settings update as it was likely triggered by this browser');
          return;
        }
        
        console.log('Applying settings from another browser/device');
        
        // Apply all settings from payload to localStorage
        let syncedCount = 0;
        const generalSettings = payload.new.general_settings;
        
        if (generalSettings && typeof generalSettings === 'object') {
          for (const [key, value] of Object.entries(generalSettings)) {
            if (value) {
              const storageKey = `${user.id}_${key}`;
              localStorage.setItem(storageKey, value as string);
              syncedCount++;
            }
          }
        }
        
        if (syncedCount > 0) {
          // Show toast notification
          toast.success("Sincronizzati i dati da altri dispositivi", {
            duration: 3000,
            id: "cross-device-sync" // Use ID to prevent duplicate toasts
          });
          
          // Update sync timestamp
          localStorage.setItem(`${user.id}_last_settings_sync`, new Date().toISOString());
          
          // Se ci sono molti dati sincronizzati, forza un reload della pagina
          if (syncedCount > 5) {
            toast.info("Aggiornamento consistente rilevato, ricaricamento pagina...", {
              duration: 2000,
              onAutoClose: () => {
                window.location.reload();
              }
            });
          }
        }
      }
    })
    .subscribe((status) => {
      console.log(`Settings channel status: ${status}`);
      if (status === 'SUBSCRIBED') {
        console.log('Successfully subscribed to settings updates');
      } else if (status === 'CHANNEL_ERROR') {
        console.error('Error subscribing to settings channel');
        setTimeout(() => {
          // Retry subscription after error
          settingsChannel.subscribe();
        }, 5000);
      }
    });
  
  // Anche ascolta per i segnali di sincronizzazione
  const syncSignalChannel = supabase
    .channel('public:sync_signals')
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'sync_signals',
      filter: `tenant_id=eq.${user.id}`
    }, (payload) => {
      console.log('Ricevuto segnale di sincronizzazione:', payload);
      
      if (payload.new && typeof payload.new === 'object') {
        // Use safe type checking
        const newPayload = payload.new as Record<string, any>;
        const lastUpdate = newPayload.last_update;
                         
        if (lastUpdate) {
          const signalTimestamp = new Date(lastUpdate as string).getTime();
          const lastLocalSync = localStorage.getItem(`${user.id}_last_global_sync`);
          
          // Se non c'è timestamp locale o il segnale è più recente
          if (!lastLocalSync || signalTimestamp > parseInt(lastLocalSync)) {
            toast.info("Rilevate modifiche da altri dispositivi, aggiornamento in corso...", {
              duration: 3000,
              id: "sync-signal-update"
            });
            
            // Aggiorna il timestamp dell'ultimo sync
            localStorage.setItem(`${user.id}_last_global_sync`, signalTimestamp.toString());
            
            // Ricarica la pagina dopo un breve delay
            setTimeout(() => {
              window.location.reload();
            }, 1500);
          }
        }
      }
    })
    .subscribe((status) => {
      console.log(`Sync signals channel status: ${status}`);
      if (status === 'SUBSCRIBED') {
        console.log('Successfully subscribed to sync signals');
      } else if (status === 'CHANNEL_ERROR') {
        console.error('Error subscribing to sync signals channel');
        setTimeout(() => {
          // Retry subscription after error
          syncSignalChannel.subscribe();
        }, 5000);
      }
    });
    
  // Return a cleanup function to remove all channels
  return () => {
    supabase.removeChannel(userChannel);
    supabase.removeChannel(settingsChannel);
    supabase.removeChannel(syncSignalChannel);
  };
};

/**
 * Periodically fetch latest data from Supabase
 * @param user Current user
 * @param setUser Function to update user state
 * @returns Cleanup function
 */
export const setupPeriodicSync = (
  user: User | null,
  setUser: SetUserFunction
): (() => void) => {
  if (!user) return () => {};
  
  const fetchLatestUserData = async () => {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("id", user.id)
        .single();

      if (error) {
        console.error("❌ Errore nel recupero dati utente da Supabase:", error);
      } else if (data) {
        console.log("✅ Dati utente aggiornati da Supabase", data);
        
        // Preserve subscription from current user state
        const updatedUser = {
          ...user,
          ...data,
          subscription: user.subscription
        };
        
        // Update local state
        setUser(updatedUser);
        
        // Save to localStorage
        try {
          localStorage.setItem('user', JSON.stringify(updatedUser));
        } catch (storageError) {
          console.warn("LocalStorage quota exceeded when saving updated user", storageError);
        }
      }
      
      // Also fetch restaurant settings for cross-browser sync
      const { data: settingsData, error: settingsError } = await supabase
        .from('restaurant_settings')
        .select('general_settings, updated_at')
        .eq('tenant_id', user.id)
        .single();
      
      if (!settingsError && settingsData && settingsData.general_settings) {
        console.log("Found settings in Supabase, checking for updates");
        
        // Get local timestamp to compare
        const localTimestamp = localStorage.getItem(`${user.id}_last_settings_sync`);
        
        // If Supabase data is newer or no local timestamp exists
        if (!localTimestamp || new Date(settingsData.updated_at) > new Date(localTimestamp)) {
          console.log("Settings in Supabase are newer, syncing to localStorage");
          
          // Restore all settings from Supabase to localStorage
          let restoredCount = 0;
          for (const [key, value] of Object.entries(settingsData.general_settings)) {
            if (value) {
              const storageKey = `${user.id}_${key}`;
              localStorage.setItem(storageKey, value as string);
              restoredCount++;
            }
          }
          
          if (restoredCount > 0) {
            console.log(`Synchronized ${restoredCount} settings from Supabase`);
            toast.success("Sincronizzati i dati da altri dispositivi", {
              duration: 3000,
              id: "cross-device-sync" // Use ID to prevent duplicate toasts
            });
            
            // Update sync timestamp
            localStorage.setItem(`${user.id}_last_settings_sync`, new Date().toISOString());
          }
        }
      }
      
      // Controlla anche i segnali di sincronizzazione
      const { data: syncSignal, error: syncError } = await supabase
        .from('sync_signals')
        .select('*')
        .eq('tenant_id', user.id)
        .single();
        
      if (!syncError && syncSignal) {
        console.log("Trovato segnale di sincronizzazione:", syncSignal);
        
        // Verifica se il segnale è più recente dell'ultimo aggiornamento locale
        const lastLocalSync = localStorage.getItem(`${user.id}_last_global_sync`);
        
        // Safe access to last_update with type checking
        const lastUpdate = syncSignal && typeof syncSignal === 'object' && 'last_update' in syncSignal
          ? syncSignal.last_update
          : null;
          
        if (lastUpdate) {
          const signalTimestamp = new Date(lastUpdate as string).getTime();
          
          if (!lastLocalSync || signalTimestamp > parseInt(lastLocalSync)) {
            console.log("Segnale di sincronizzazione più recente, forzo aggiornamento da Supabase");
            
            // Forza il recupero di tutti i dati da Supabase
            const { data: allData, error: dataError } = await supabase
              .from('restaurant_data')
              .select('*')
              .eq('tenant_id', user.id)
              .eq('is_deleted', false);
              
            if (!dataError && allData && allData.length > 0) {
              console.log(`Trovati ${allData.length} dati da sincronizzare`);
              
              // Applica tutti i dati al localStorage
              let syncedCount = 0;
              for (const item of allData) {
                if (item.data_type && item.data) {
                  const storageKey = `${user.id}_${item.data_type}`;
                  const jsonData = typeof item.data === 'string' ? item.data : JSON.stringify(item.data);
                  
                  localStorage.setItem(storageKey, jsonData);
                  syncedCount++;
                }
              }
              
              if (syncedCount > 0) {
                toast.success(`Sincronizzati ${syncedCount} elementi da altri dispositivi`, {
                  duration: 4000,
                  id: "cross-device-sync-all"
                });
                
                // Forza un reload della pagina per applicare i cambiamenti
                if (syncedCount > 3) {
                  toast.info("Ricaricamento pagina in corso per applicare i cambiamenti...", {
                    duration: 2000,
                    onAutoClose: () => {
                      window.location.reload();
                    }
                  });
                }
              }
              
              // Aggiorna il timestamp dell'ultimo sync globale
              localStorage.setItem(`${user.id}_last_global_sync`, signalTimestamp.toString());
            }
          }
        }
      }
    } catch (syncError) {
      console.error("Error syncing with Supabase:", syncError);
    }
  };

  // Run immediately and every 10 seconds (was 15 seconds before)
  fetchLatestUserData();
  const intervalId = setInterval(fetchLatestUserData, 10000);
  
  // Return cleanup function
  return () => {
    clearInterval(intervalId);
  };
};
