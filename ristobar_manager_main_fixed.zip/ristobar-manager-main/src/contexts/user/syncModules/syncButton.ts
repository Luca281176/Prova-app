
import { tenantModule } from '@/integrations/supabase/clientModules/tenant';

/**
 * Add a visible sync button to the UI
 * @returns HTMLElement|null The created button or null
 */
export const addSyncButton = (): HTMLElement | null => {
  let syncButton = document.getElementById('force-sync-button');
  
  if (!syncButton) {
    syncButton = document.createElement('button');
    syncButton.id = 'force-sync-button';
    syncButton.innerText = '🔄 Sincronizza';
    syncButton.style.position = 'fixed';
    syncButton.style.bottom = '20px';
    syncButton.style.right = '20px';
    syncButton.style.zIndex = '9999';
    syncButton.style.padding = '10px 15px';
    syncButton.style.borderRadius = '6px';
    syncButton.style.backgroundColor = '#4338ca'; // Indigo color
    syncButton.style.color = 'white';
    syncButton.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    syncButton.style.cursor = 'pointer';
    syncButton.style.border = 'none';
    syncButton.style.fontWeight = 'bold';
    syncButton.style.fontSize = '16px';
    
    // Add hover effect
    syncButton.addEventListener('mouseover', () => {
      syncButton.style.backgroundColor = '#3730a3';
      syncButton.style.transform = 'translateY(-2px)';
      syncButton.style.boxShadow = '0 6px 12px rgba(0,0,0,0.3)';
    });
    
    syncButton.addEventListener('mouseout', () => {
      syncButton.style.backgroundColor = '#4338ca';
      syncButton.style.transform = 'translateY(0)';
      syncButton.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    });
    
    // Add click visual feedback
    syncButton.addEventListener('mousedown', () => {
      syncButton.style.transform = 'translateY(1px)';
      syncButton.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
    });
    
    syncButton.addEventListener('mouseup', () => {
      syncButton.style.transform = 'translateY(-2px)';
      syncButton.style.boxShadow = '0 6px 12px rgba(0,0,0,0.3)';
    });
    
    // Add click event to force sync
    syncButton.addEventListener('click', async () => {
      // Verifica che il tenant_id sia corretto prima di forzare la sincronizzazione
      try {
        const tenantId = await tenantModule.getCurrentTenantId();
        
        if (!tenantId) {
          console.error("❌ Impossibile recuperare il tenant_id per la sincronizzazione");
          syncButton.innerText = '❌ Errore Tenant';
          
          setTimeout(() => {
            syncButton.innerText = '🔄 Sincronizza';
          }, 3000);
          
          return;
        }
        
        // Visualizza tenant_id per debug
        console.log(`🔄 Richiesta sincronizzazione per tenant: ${tenantId}`);
        
        // Dispatch event with correct tenant_id
        window.dispatchEvent(new CustomEvent('force-sync-data', {
          detail: { tenantId }
        }));
        
        // Visual feedback
        syncButton.classList.add('syncing');
        syncButton.innerText = '⟳ Sincronizzando...';
        
        setTimeout(() => {
          syncButton.innerText = '✓ Sincronizzato!';
          
          setTimeout(() => {
            syncButton.innerText = '🔄 Sincronizza';
            syncButton.classList.remove('syncing');
          }, 2000);
        }, 1000);
      } catch (error) {
        console.error("Errore durante la sincronizzazione:", error);
        syncButton.innerText = '❌ Errore';
        
        setTimeout(() => {
          syncButton.innerText = '🔄 Sincronizza';
        }, 3000);
      }
    });
    
    document.body.appendChild(syncButton);
    return syncButton;
  }
  
  return null;
};

/**
 * Remove the sync button from the UI
 */
export const removeSyncButton = (): void => {
  const syncButton = document.getElementById('force-sync-button');
  if (syncButton) {
    syncButton.remove();
  }
};
