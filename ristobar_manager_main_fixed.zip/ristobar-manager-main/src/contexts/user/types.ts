
import { UserSubscription } from '@/services/subscriptions/types';

export interface User {
  id: string;
  email: string;
  name: string;
  restaurantName?: string;
  role: string;
  createdAt: string;
  subscription: UserSubscription | null;
  tenant_id?: string;
  image?: string;
}

export interface UserContextType {
  user: User | null;
  isLoading: boolean;
  sessionChecked: boolean;
  login: (email: string, password: string) => Promise<User | null>;
  loginWithGoogle: () => Promise<void>;
  register: (email: string, password: string, name: string, restaurantName: string) => Promise<User | null>;
  logout: () => Promise<void>;
  updateUser: (user: Partial<User>) => Promise<User | null>;
  isAdmin: () => boolean;
}
