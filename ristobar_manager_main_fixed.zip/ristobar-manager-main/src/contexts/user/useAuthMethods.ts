
import { useAuthMethods as useRefactoredAuthMethods } from './auth/useAuthMethods';

// Re-export the useAuthMethods from the refactored version for backward compatibility
export const useAuthMethods = useRefactoredAuthMethods;

export default useAuthMethods;
