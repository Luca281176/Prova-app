
import { toast } from 'sonner';
import { User } from './types';
import { getRegisteredUsers, saveRegisteredUsers, saveUserDataToStorage } from './storageUtils';

export const useUserProfile = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>,
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>
) => {
  const updateUser = async (data: Partial<User>): Promise<User | null> => {
    if (!user) return null;
    
    setIsLoading(true);
    
    try {
      const updatedUser = {
        ...user,
        ...data,
      };
      
      try {
        localStorage.setItem('user', JSON.stringify(updatedUser));
      } catch (storageError) {
        console.warn("LocalStorage quota exceeded, continuing without persistent storage", storageError);
      }
      
      const registeredUsers = await getRegisteredUsers();
      const updatedUsers = registeredUsers.map((u: any) => 
        u.id === user.id ? { ...u, ...data } : u
      );
      await saveRegisteredUsers(updatedUsers);
      
      if (data.name || data.email || data.restaurantName || data.image) {
        const userPreferences = {
          name: updatedUser.name,
          email: updatedUser.email,
          restaurantName: updatedUser.restaurantName,
          image: updatedUser.image
        };
        
        try {
          await saveUserDataToStorage(user.id, 'userPreferences', userPreferences);
        } catch (storageError) {
          console.warn("LocalStorage quota exceeded when saving preferences", storageError);
        }
      }
      
      setUser(updatedUser);
      toast.success("Le modifiche al tuo profilo sono state salvate.");
      return updatedUser;
    } catch (error) {
      console.error('Update error:', error);
      toast.error("Non è stato possibile aggiornare il profilo.");
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const isAdmin = () => {
    return user?.email === 'luca.costanzo@ristobarmanager.it';
  };

  return {
    updateUser,
    isAdmin
  };
};
