
import { useEffect } from 'react';
import { User } from './types';
import { handleForceSyncEvent } from './syncModules/forceRefresh';
import { setupRealTimeSync, setupPeriodicSync } from './syncModules/realTimeSync';
import { addSyncButton, removeSyncButton } from './syncModules/syncButton';
import { setupCriticalDataSync } from './syncModules/criticalDataSync';

/**
 * Hook for managing user data synchronization across devices
 * @param user The current user object
 * @param setUser Function to update the user state
 */
export const useUserSync = (
  user: User | null, 
  setUser: React.Dispatch<React.SetStateAction<User | null>>
) => {
  // Setup real-time sync with Supabase for user data and settings
  useEffect(() => {
    if (!user) return;

    // Set up real-time sync channels
    const cleanupRealtimeSync = setupRealTimeSync(user, setUser);
    
    // Set up periodic data fetching
    const cleanupPeriodicSync = setupPeriodicSync(user, setUser);

    // Add event listener for force sync
    const handleForceSyncEventWrapper = () => {
      if (user && user.id) {
        handleForceSyncEvent(user.id);
      }
    };
    
    // Add listener for custom force sync event
    window.addEventListener('force-sync-data', handleForceSyncEventWrapper);

    // Add sync button after a short delay
    setTimeout(() => addSyncButton(), 1000);

    // Cleanup function
    return () => {
      cleanupRealtimeSync();
      cleanupPeriodicSync();
      window.removeEventListener('force-sync-data', handleForceSyncEventWrapper);
      removeSyncButton();
    };
  }, [user?.id, setUser]);

  // Add explicit sync trigger for important data changes
  useEffect(() => {
    if (!user) return;
    
    // Setup critical data sync mechanism
    const cleanupCriticalDataSync = setupCriticalDataSync(user.id);
    
    // Add sync button
    setTimeout(addSyncButton, 1000);
    
    return () => {
      cleanupCriticalDataSync();
      removeSyncButton();
    };
  }, [user]);
};
