
import { useUser } from './UserProvider';
import { getUserData, saveUserDataToStorage, clearAllUserData } from './storageUtils';

// Helper function to load user-specific data
export const loadUserData = (key: string, defaultValue: any = null) => {
  const { user } = useUser();
  if (!user) return defaultValue;
  
  // Use the user's ID as part of the storage key to ensure data isolation
  return getUserData(user.id, key, defaultValue);
};

// Helper function to save user-specific data
export const saveUserData = (key: string, data: any) => {
  const { user } = useUser();
  if (!user) return false;
  
  // Use the user's ID as part of the storage key to ensure data isolation
  return saveUserDataToStorage(user.id, key, data);
};

// Clear all user data (useful for logout or switching users)
export const clearUserData = () => {
  clearAllUserData();
};
