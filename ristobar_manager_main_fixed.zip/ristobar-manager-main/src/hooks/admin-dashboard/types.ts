
import { RealtimeChannel } from '@supabase/supabase-js';

export interface DashboardStats {
  totalUsers: number;
  totalRevenue: number;
  activeSubscriptions: number;
  userGrowth: number;
  activePlans: { starter: number; pro: number; ultimate: number };
  recentSignups: {
    id: string;
    name: string;
    email: string;
    date: string;
    plan: string;
  }[];
}

export interface UseAdminDashboardResult {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  stats: DashboardStats | null;
  isLoading: boolean;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  statusFilter: string;
  setStatusFilter: (status: string) => void;
  planFilter: string;
  setPlanFilter: (plan: string) => void;
  currentPage: number;
  totalItems: number;
  subscriptions: any[];
  itemsPerPage: number;
  handleActivateSubscription: (subscription: any) => Promise<void>;
  handleSuspendSubscription: (subscription: any) => Promise<void>;
  handleCancelSubscription: (subscription: any) => Promise<void>;
  handleUpgradeSubscription: (subscription: any) => Promise<void>;
  handleDowngradeSubscription: (subscription: any) => Promise<void>;
  handleNextPage: () => void;
  handlePrevPage: () => void;
}
