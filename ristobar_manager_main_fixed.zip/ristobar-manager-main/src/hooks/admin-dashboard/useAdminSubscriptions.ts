
import { useState, useEffect, useCallback } from 'react';
import { 
  getSubscriptions, 
  updateSubscription, 
  cancelSubscription, 
  UserSubscription,
  subscriptionPlans
} from '@/services/subscriptions';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

export const useAdminSubscriptions = () => {
  const [subscriptions, setSubscriptions] = useState<UserSubscription[]>([]);
  const [filteredSubscriptions, setFilteredSubscriptions] = useState<UserSubscription[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [planFilter, setPlanFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const itemsPerPage = 10;

  // Load subscriptions with useCallback to prevent unnecessary re-renders
  const loadSubscriptions = useCallback(async () => {
    try {
      setIsLoading(true);
      console.log('Loading subscriptions...');
      const result = await getSubscriptions(currentPage, itemsPerPage);
      setSubscriptions(result.subscriptions);
      setFilteredSubscriptions(result.subscriptions);
      setTotalItems(result.total);
    } catch (error) {
      console.error('Error loading subscriptions:', error);
      toast.error('Si è verificato un errore nel caricamento degli abbonamenti');
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, itemsPerPage]);

  // Load subscriptions when page changes
  useEffect(() => {
    loadSubscriptions();
  }, [loadSubscriptions]);

  // Filter subscriptions
  useEffect(() => {
    let filtered = [...subscriptions];
    
    // Filter by search
    if (searchTerm) {
      filtered = filtered.filter(sub => 
        sub.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (sub.id && sub.id.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(sub => sub.status === statusFilter);
    }
    
    // Filter by plan
    if (planFilter !== 'all') {
      filtered = filtered.filter(sub => sub.planId === planFilter);
    }
    
    setFilteredSubscriptions(filtered);
  }, [searchTerm, statusFilter, planFilter, subscriptions]);

  // Update subscription via Stripe
  const updateStripeSubscription = async (subscriptionId: string, data: any) => {
    try {
      const { data: result, error } = await supabase.functions.invoke('update-stripe-subscription', {
        body: { 
          subscriptionId,
          ...data
        }
      });
      
      if (error) throw error;
      return result;
    } catch (error) {
      console.error('Error updating Stripe subscription:', error);
      throw error;
    }
  };

  // Suspend subscription handler
  const handleSuspendSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      
      // Update subscription in Stripe (this will reflect in our webhook)
      await updateStripeSubscription(subscription.id, { 
        status: 'past_due' 
      });
      
      // Update our local database directly for immediate UI feedback
      await updateSubscription(subscription.id, { 
        status: 'past_due' as UserSubscription['status']
      });
      
      await loadSubscriptions();
      return true;
    } catch (error) {
      console.error('Error suspending subscription:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Activate subscription handler
  const handleActivateSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      
      // Update subscription in Stripe
      await updateStripeSubscription(subscription.id, { 
        status: 'active' 
      });
      
      // Update our local database directly for immediate UI feedback
      await updateSubscription(subscription.id, { 
        status: 'active' as UserSubscription['status']
      });
      
      await loadSubscriptions();
      return true;
    } catch (error) {
      console.error('Error activating subscription:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Cancel subscription handler
  const handleCancelSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      
      // Cancel subscription in Stripe
      const { data: result, error } = await supabase.functions.invoke('cancel-stripe-subscription', {
        body: { 
          subscriptionId: subscription.id
        }
      });
      
      if (error) throw error;
      
      // Update our local database directly for immediate UI feedback
      await cancelSubscription(subscription.id);
      
      await loadSubscriptions();
      return true;
    } catch (error) {
      console.error('Error cancelling subscription:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Upgrade subscription handler
  const handleUpgradeSubscription = async (subscription: UserSubscription) => {
    const currentPlanIndex = subscriptionPlans.findIndex(plan => plan.id === subscription.planId);
    if (currentPlanIndex < subscriptionPlans.length - 1) {
      const newPlanId = subscriptionPlans[currentPlanIndex + 1].id;
      try {
        setIsLoading(true);
        
        // Update subscription in Stripe
        const newStripePriceId = getStripePriceId(newPlanId);
        await updateStripeSubscription(subscription.id, { 
          priceId: newStripePriceId 
        });
        
        // Update our local database
        await updateSubscription(subscription.id, { 
          planId: newPlanId 
        });
        
        await loadSubscriptions();
        return true;
      } catch (error) {
        console.error('Error upgrading subscription:', error);
        throw error;
      } finally {
        setIsLoading(false);
      }
    }
    return false;
  };

  // Downgrade subscription handler
  const handleDowngradeSubscription = async (subscription: UserSubscription) => {
    const currentPlanIndex = subscriptionPlans.findIndex(plan => plan.id === subscription.planId);
    if (currentPlanIndex > 0) {
      const newPlanId = subscriptionPlans[currentPlanIndex - 1].id;
      try {
        setIsLoading(true);
        
        // Update subscription in Stripe
        const newStripePriceId = getStripePriceId(newPlanId);
        await updateStripeSubscription(subscription.id, { 
          priceId: newStripePriceId 
        });
        
        // Update our local database
        await updateSubscription(subscription.id, { 
          planId: newPlanId 
        });
        
        await loadSubscriptions();
        return true;
      } catch (error) {
        console.error('Error downgrading subscription:', error);
        throw error;
      } finally {
        setIsLoading(false);
      }
    }
    return false;
  };
  
  // Helper to get Stripe price ID from our plan ID
  const getStripePriceId = (planId: string): string => {
    // This mapping should match what's in the backend
    switch (planId) {
      case 'starter':
        return 'price_starter';
      case 'pro':
        return 'price_pro';
      case 'ultimate':
        return 'price_ultimate';
      default:
        return '';
    }
  };

  // Pagination handlers
  const handleNextPage = () => {
    const maxPage = Math.ceil(totalItems / itemsPerPage);
    if (currentPage < maxPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // Manual refresh function
  const refreshSubscriptions = useCallback(() => {
    loadSubscriptions();
  }, [loadSubscriptions]);

  return {
    subscriptions: filteredSubscriptions,
    isLoading,
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    planFilter,
    setPlanFilter,
    currentPage,
    totalItems,
    itemsPerPage,
    handleActivateSubscription,
    handleSuspendSubscription,
    handleCancelSubscription,
    handleUpgradeSubscription,
    handleDowngradeSubscription,
    handleNextPage,
    handlePrevPage,
    refreshSubscriptions
  };
};
