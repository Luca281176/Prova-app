
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { DashboardStats } from './types';
import { RealtimeChannel } from '@supabase/supabase-js';

export const useDataLoader = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [totalItems, setTotalItems] = useState(0);
  const [realTimeChannels, setRealTimeChannels] = useState<RealtimeChannel[]>([]);
  const { toast } = useToast();

  // Pulizia dei canali realtime quando il componente si smonta
  useEffect(() => {
    return () => {
      console.log('Pulizia dei canali realtime...');
      realTimeChannels.forEach(channel => {
        supabase.removeChannel(channel);
      });
    };
  }, [realTimeChannels]);

  const loadData = async () => {
    try {
      setIsLoading(true);
      console.log("Caricamento dati della dashboard in corso...");
      
      // Carica tutti gli abbonamenti, inclusi quelli in trial
      const { data: subscriptionsData, error: subscriptionsError } = await supabase
        .from('user_subscriptions')
        .select('*');
      
      if (subscriptionsError) {
        console.error("Errore nel caricamento degli abbonamenti:", subscriptionsError);
        toast({
          title: "Errore di caricamento",
          description: "Impossibile caricare i dati degli abbonamenti.",
          variant: "destructive"
        });
      }

      console.log("Dati abbonamenti caricati:", subscriptionsData);
      
      // Carica tutti gli utenti dalla tabella users, inclusi quelli senza abbonamento
      const { data: allUsers, error: usersError } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (usersError) {
        console.error("Errore nel caricamento degli utenti:", usersError);
        toast({
          title: "Errore di caricamento",
          description: "Impossibile caricare i dati degli utenti.",
          variant: "destructive"
        });
      }

      console.log("Utenti caricati:", allUsers);
      
      // Calcola statistiche abbonamenti, includendo gli utenti in trial
      const totalUsers = allUsers?.length || 0;
      const activeSubscriptions = subscriptionsData?.filter(sub => 
        sub.status === 'active' || sub.status === 'trialing'
      ).length || 0;
      
      const activePlans = {
        starter: subscriptionsData?.filter(sub => 
          (sub.status === 'active' || sub.status === 'trialing') && 
          sub.plan_id === 'starter'
        ).length || 0,
        pro: subscriptionsData?.filter(sub => 
          (sub.status === 'active' || sub.status === 'trialing') && 
          sub.plan_id === 'pro'
        ).length || 0,
        ultimate: subscriptionsData?.filter(sub => 
          (sub.status === 'active' || sub.status === 'trialing') && 
          sub.plan_id === 'ultimate'
        ).length || 0,
      };

      console.log("Piani attivi calcolati:", activePlans);
      
      // Prendi i primi 4 utenti per mostrare iscrizioni recenti
      const recentUsers = allUsers ? allUsers.slice(0, 4) : [];
      
      console.log("Utenti recenti selezionati:", recentUsers);
      
      // Formatta gli utenti recenti includendo anche quelli in trial
      const recentSignups = recentUsers.map(user => {
        const userSubscription = subscriptionsData?.find(sub => sub.user_id === user.id);
        
        return {
          id: user.id,
          name: user.name || 'Utente senza nome',
          email: user.email || 'Email non disponibile',
          date: user.created_at || new Date().toISOString(),
          plan: userSubscription?.plan_id || 'Trial'
        };
      });

      console.log("Utenti formattati per il display:", recentSignups);
      
      // Calcola ricavi totali basati sugli abbonamenti attivi paganti (escludendo trial)
      const totalRevenue = (
        (activePlans.pro * 49) + 
        (activePlans.ultimate * 99)
      );
      
      // Crescita utenti arbitraria per demo
      const userGrowth = 15;
      
      // Aggiorna lo stato con tutte le statistiche
      setStats({
        totalUsers,
        totalRevenue,
        activeSubscriptions,
        userGrowth,
        activePlans,
        recentSignups
      });
      
      // Carica anche i dati della scheda abbonamenti
      setSubscriptions(subscriptionsData || []);
      setTotalItems(subscriptionsData?.length || 0);
      
      setIsLoading(false);
    } catch (error) {
      console.error("Errore nel caricamento dei dati della dashboard:", error);
      setIsLoading(false);
      
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante il caricamento dei dati.",
        variant: "destructive"
      });
    }
  };

  const setupRealtimeSubscriptions = () => {
    // Rimuovi qualsiasi canale esistente prima di crearne di nuovi
    realTimeChannels.forEach(channel => {
      supabase.removeChannel(channel);
    });

    const newChannels: RealtimeChannel[] = [];
    
    console.log('Configurazione dei canali realtime...');
    
    try {
      const usersChannel = supabase
        .channel('admin-dashboard-users')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'users' },
          (payload) => {
            console.log('Rilevata modifica alla tabella users:', payload);
            loadData();
          }
        )
        .subscribe((status) => {
          console.log(`Canale users stato: ${status}`);
          if (status === 'SUBSCRIBED') {
            console.log('Sottoscrizione a users avvenuta con successo');
          } else if (status === 'CHANNEL_ERROR') {
            console.error('Errore nella sottoscrizione al canale users');
          }
        });
      
      const subscriptionsChannel = supabase
        .channel('admin-dashboard-subscriptions')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'user_subscriptions' },
          (payload) => {
            console.log('Rilevata modifica alla tabella subscriptions:', payload);
            loadData();
          }
        )
        .subscribe((status) => {
          console.log(`Canale subscriptions stato: ${status}`);
          if (status === 'SUBSCRIBED') {
            console.log('Sottoscrizione a subscriptions avvenuta con successo');
          } else if (status === 'CHANNEL_ERROR') {
            console.error('Errore nella sottoscrizione al canale subscriptions');
          }
        });

      newChannels.push(usersChannel, subscriptionsChannel);
      setRealTimeChannels(newChannels);
    } catch (error) {
      console.error('Errore nella configurazione dei canali realtime:', error);
    }
    
    return newChannels;
  };

  return {
    stats,
    isLoading,
    subscriptions,
    totalItems,
    loadData,
    setupRealtimeSubscriptions
  };
};
