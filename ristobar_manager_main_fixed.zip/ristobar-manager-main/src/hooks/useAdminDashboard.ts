import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/contexts/user';
import { useDataLoader } from './admin-dashboard/useDataLoader';
import { supabase } from '@/integrations/supabase/client';

export const useAdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [users, setUsers] = useState([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(true);
  const navigate = useNavigate();
  const { user, isAdmin } = useUser();
  const { toast } = useToast();
  
  const {
    stats,
    isLoading,
    setupRealtimeSubscriptions
  } = useDataLoader();

  async function fetchUsers() {
    setIsLoadingUsers(true);
    console.log("🔄 Recupero utenti da Supabase...");
    
    try {
      const { data, error } = await supabase
        .from("users")
        .select("id, email, name, created_at, tenant_id")
        .order('created_at', { ascending: false });

      if (error) {
        console.error("❌ Errore nel recupero utenti:", error.message);
        toast({
          title: "Errore",
          description: "Impossibile recuperare l'elenco degli utenti",
          variant: "destructive"
        });
      } else {
        console.log("✅ Utenti recuperati con successo:", data);
        setUsers(data || []);
      }
    } catch (err) {
      console.error("❌ Errore durante la richiesta a Supabase:", err);
    } finally {
      setIsLoadingUsers(false);
    }
  }

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!isAdmin) {
      navigate('/dashboard');
      toast({
        title: "Accesso negato",
        description: "Non hai i permessi per accedere a questa pagina.",
        variant: "destructive"
      });
      return;
    }

    fetchUsers();

    const channels = setupRealtimeSubscriptions();

    const usersChannel = supabase
      .channel("users_changes")
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'users' 
      }, (payload) => {
        console.log("🔄 Nuovo utente aggiunto:", payload.new);
        setUsers(prevUsers => [payload.new, ...prevUsers]);
        toast({
          title: "Nuovo utente registrato",
          description: `${payload.new.email || 'Utente'} si è appena registrato`,
        });
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'users'
      }, (payload) => {
        console.log("🔄 Utente aggiornato:", payload.new);
        setUsers(prevUsers => 
          prevUsers.map(user => user.id === payload.new.id ? payload.new : user)
        );
      })
      .on('postgres_changes', {
        event: 'DELETE',
        schema: 'public',
        table: 'users'
      }, (payload) => {
        console.log("🔄 Utente rimosso:", payload.old);
        setUsers(prevUsers => 
          prevUsers.filter(user => user.id !== payload.old.id)
        );
      })
      .subscribe();

    return () => {
      console.log('Cleaning up realtime subscriptions...');
      channels.forEach(channel => {
        supabase.removeChannel(channel);
      });
      supabase.removeChannel(usersChannel);
    };
  }, [user, isAdmin, navigate, toast]);

  return {
    activeTab,
    setActiveTab,
    stats,
    isLoading,
    users,
    isLoadingUsers,
    refreshUsers: fetchUsers
  };
};
