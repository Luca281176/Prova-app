
import { useUser } from '@/contexts/user';
import { hasAccess, hasSubscriptionLevel } from '@/services/subscriptions/featureAccess';
import { FeatureAccessLevel } from '@/services/subscriptions/types';

/**
 * Hook personalizzato per verificare l'accesso alle funzionalità basato sull'abbonamento
 */
function useFeatureAccess() {
  const { user } = useUser();
  
  return {
    /**
     * Controlla se l'utente ha accesso a una specifica funzionalità
     * @param featureName Nome della funzionalità
     * @returns true se l'utente ha accesso, altrimenti false
     */
    canAccess: (featureName: string) => {
      const result = hasAccess(user?.subscription, featureName);
      console.log(`useFeatureAccess.canAccess("${featureName}") = ${result}`, user?.subscription);
      return result;
    },
    
    /**
     * Controlla se l'utente ha un livello di abbonamento specifico o superiore
     * @param level Livello di abbonamento richiesto
     * @returns true se l'utente ha il livello richiesto, altrimenti false
     */
    hasLevel: (level: FeatureAccessLevel | string) => {
      const result = hasSubscriptionLevel(user?.subscription, level);
      console.log(`useFeatureAccess.hasLevel(${level}) = ${result}`, user?.subscription);
      return result;
    },
    
    /**
     * Ritorna il livello di accesso dell'utente
     * @returns Livello di accesso dell'utente corrente
     */
    userLevel: () => {
      if (!user?.subscription) return null;
      return user.subscription.planId;
    }
  };
}

export default useFeatureAccess;
