
import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { useUser } from '@/contexts/user/UserProvider';

interface StorageState {
  version: number;
  data: any;
  isSyncing: boolean;
  lastSyncedAt: Date | null;
}

export const usePersistentStorage = (dataType: string, initialData: any = null) => {
  const { currentTenant } = useTenant();
  const { user } = useUser();
  const [state, setState] = useState<StorageState>({
    version: 1,
    data: initialData,
    isSyncing: false,
    lastSyncedAt: null
  });

  // Carica i dati iniziali da Supabase
  useEffect(() => {
    if (!currentTenant?.id || !user) return;

    const loadData = async () => {
      try {
        const { data, error } = await supabase
          .from('restaurant_data')
          .select('data, version')
          .eq('tenant_id', currentTenant.id)
          .eq('data_type', dataType)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          setState(prev => ({
            ...prev,
            version: data.version,
            data: data.data,
            lastSyncedAt: new Date()
          }));

          // Salva in localStorage come fallback
          localStorage.setItem(
            `${currentTenant.id}_${dataType}`,
            JSON.stringify({
              version: data.version,
              data: data.data,
              timestamp: new Date().toISOString()
            })
          );
        }
      } catch (error) {
        console.error('Errore caricamento dati:', error);
        // Prova a recuperare dal localStorage
        const cached = localStorage.getItem(`${currentTenant.id}_${dataType}`);
        if (cached) {
          try {
            const parsedCache = JSON.parse(cached);
            setState(prev => ({
              ...prev,
              version: parsedCache.version,
              data: parsedCache.data,
              lastSyncedAt: new Date(parsedCache.timestamp)
            }));
          } catch (e) {
            console.error('Errore parsing cache:', e);
          }
        }
      }
    };

    loadData();
  }, [currentTenant?.id, user, dataType]);

  // Imposta la sincronizzazione real-time
  useEffect(() => {
    if (!currentTenant?.id || !user) return;

    const channel = supabase
      .channel('restaurant_data_changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'restaurant_data',
          filter: `tenant_id=eq.${currentTenant.id}`,
        },
        (payload) => {
          if (payload.new && payload.new.data_type === dataType) {
            const newData = payload.new;
            if (newData.version > state.version) {
              setState(prev => ({
                ...prev,
                version: newData.version,
                data: newData.data,
                lastSyncedAt: new Date()
              }));

              localStorage.setItem(
                `${currentTenant.id}_${dataType}`,
                JSON.stringify({
                  version: newData.version,
                  data: newData.data,
                  timestamp: new Date().toISOString()
                })
              );

              toast.info('Dati aggiornati da un altro dispositivo');
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentTenant?.id, user, dataType, state.version]);

  const saveData = async (newData: any) => {
    if (!currentTenant?.id || !user) {
      console.error('Nessun tenant o utente attivo');
      return false;
    }

    setState(prev => ({ ...prev, isSyncing: true }));

    try {
      // Salva immediatamente in localStorage come fallback
      localStorage.setItem(
        `${currentTenant.id}_${dataType}`,
        JSON.stringify({
          version: state.version,
          data: newData,
          timestamp: new Date().toISOString()
        })
      );

      // Sincronizza con Supabase
      const { data: result, error } = await supabase
        .rpc('sync_restaurant_data', {
          p_tenant_id: currentTenant.id,
          p_data_type: dataType,
          p_data: newData,
          p_client_version: state.version
        });

      if (error) throw error;

      if (result.status === 'conflict') {
        // Gestione conflitti
        setState(prev => ({
          ...prev,
          version: result.version,
          data: result.current_data,
          lastSyncedAt: new Date()
        }));
        toast.warning('Conflitto rilevato, dati aggiornati alla versione più recente');
      } else {
        // Aggiornamento riuscito
        setState(prev => ({
          ...prev,
          version: result.version,
          data: result.data,
          lastSyncedAt: new Date()
        }));
        toast.success('Dati salvati correttamente');
      }

      return true;
    } catch (error) {
      console.error('Errore salvataggio dati:', error);
      toast.error('Errore durante il salvataggio dei dati');

      // Salva l'operazione in sospeso per riprovarla più tardi
      try {
        await supabase
          .from('pending_operations')
          .insert({
            tenant_id: currentTenant.id,
            operation_type: 'save',
            data: {
              data_type: dataType,
              data: newData,
              version: state.version
            }
          });
      } catch (e) {
        console.error('Errore salvataggio operazione in sospeso:', e);
      }

      return false;
    } finally {
      setState(prev => ({ ...prev, isSyncing: false }));
    }
  };

  return {
    data: state.data,
    version: state.version,
    isSyncing: state.isSyncing,
    lastSyncedAt: state.lastSyncedAt,
    saveData
  };
};
