
import { createClient } from '@supabase/supabase-js';
import { toast } from 'sonner';
import { schedulerModule } from './clientModules/scheduler';
import { tokenModule } from './clientModules/token';
import { tenantModule } from './clientModules/tenant';
import { loggingModule } from './clientModules/logging';
import { backupModule } from './clientModules/backup';

// Supabase configuration
const supabaseUrl = 'https://dsylhitlicqytqcucfxt.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRzeWxoaXRsaWNxeXRxY3VjZnh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDEzNTg4MjYsImV4cCI6MjA1NjkzNDgyNn0.xAPV36JL5gupfn4UcOcyyNPqrzQmsnIm2CqBVUZsKbc';

// Create Supabase client with enhanced persistence configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storageKey: 'supabase.auth.token'
  }
});

// Handle auth state changes with improved error handling
supabase.auth.onAuthStateChange((event, session) => {
  console.log('Auth state changed:', event, session ? 'Session exists' : 'No session');
  
  if (event === 'SIGNED_IN' && session) {
    console.log('User signed in successfully');
    localStorage.setItem('supabase.auth.token', JSON.stringify(session));
    localStorage.setItem('supabase-session', JSON.stringify(session));
  }
  else if (event === 'SIGNED_OUT') {
    console.log('User signed out, clearing storage');
    localStorage.removeItem('supabase.auth.token');
    localStorage.removeItem('supabase-session');
  }
  else if (event === 'TOKEN_REFRESHED' && session) {
    console.log('Token refreshed successfully');
    localStorage.setItem('supabase.auth.token', JSON.stringify(session));
    localStorage.setItem('supabase-session', JSON.stringify(session));
  }
});

// Export other modules
export const {
  isTokenRevoked,
  revokeToken,
  revokeAllUserTokens
} = tokenModule;

export const {
  setTenantId,
  getCurrentTenantId,
  getCurrentTenantInfo
} = tenantModule;

export const {
  recordFailedRequest
} = loggingModule;

export const {
  performBackup
} = backupModule;
