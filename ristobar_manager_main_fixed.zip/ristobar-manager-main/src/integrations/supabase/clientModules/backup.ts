
import { supabase } from '../client';

/**
 * Performs automatic data backup
 * This function should be called periodically (e.g. daily)
 */
const performBackup = async (): Promise<boolean> => {
  try {
    // Call an Edge Function that performs the database backup
    console.log('Starting automatic data backup...');
    
    const { data, error } = await supabase.functions.invoke('backup-database', {
      body: { timestamp: new Date().toISOString() }
    });
    
    if (error) {
      console.error('Error executing backup:', error);
      
      // Log the failed backup attempt
      const insertResult = await supabase.from('backups').insert({
        status: 'failed',
        error_message: error.message || 'Unknown error during backup'
      });
      
      if (insertResult.error) {
        console.error('Failed to log backup error:', insertResult.error);
      }
      
      return false;
    }
    
    console.log('Backup completed successfully:', data);
    
    // Track the successful backup
    if (data && typeof data === 'object') {
      const insertResult = await supabase.from('backups').insert({
        status: 'completed',
        backup_location: data.details?.location || null,
        backup_size: data.details?.size || null
      });
      
      if (insertResult.error) {
        console.error('Failed to log successful backup:', insertResult.error);
      }
    }
    
    return true;
  } catch (err) {
    console.error('Error executing backup:', err);
    
    // Log the failed backup with exception
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    const insertResult = await supabase.from('backups').insert({
      status: 'failed',
      error_message: errorMessage
    });
    
    if (insertResult.error) {
      console.error('Failed to log backup error:', insertResult.error);
    }
    
    return false;
  }
};

/**
 * Schedules a daily backup
 */
const scheduleDailyBackup = (): void => {
  // Schedule a backup every 24 hours
  setInterval(async () => {
    console.log('Running scheduled daily backup...');
    await performBackup();
  }, 24 * 60 * 60 * 1000); // 24 hours
};

/**
 * Gets the latest backup record
 */
const getLatestBackup = async (): Promise<any> => {
  try {
    const { data, error } = await supabase
      .from('backups')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1);
      
    if (error) {
      console.error('Error retrieving latest backup:', error);
      return null;
    }
    
    return data?.[0] || null;
  } catch (err) {
    console.error('Error retrieving latest backup:', err);
    return null;
  }
};

export const backupModule = {
  performBackup,
  scheduleDailyBackup,
  getLatestBackup
};
