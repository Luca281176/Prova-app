
import { supabase } from '../client';

/**
 * Records a failed request for rate limiting
 * @param ip IP address or identifier
 * @param action Action type (login, register, etc.)
 */
const recordFailedRequest = async (ip: string, action: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('access_logs')
      .insert({
        ip: ip,
        action: action,
        status: 'failed',
        timestamp: new Date().toISOString()
      });
      
    if (error) {
      console.error('Error recording failed request:', error);
    }
  } catch (err) {
    console.warn('Error logging failed request:', err);
  }
};

export const loggingModule = {
  recordFailedRequest
};
