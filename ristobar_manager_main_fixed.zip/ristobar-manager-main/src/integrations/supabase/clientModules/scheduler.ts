import { supabase } from '../client';

// Token refresh interval in milliseconds (15 minutes)
const TOKEN_REFRESH_INTERVAL = 15 * 60 * 1000;

// Time before token expiration to start refresh (5 minutes)
const REFRESH_THRESHOLD = 5 * 60 * 1000;

/**
 * Function to schedule token refresh
 * @param session Current user session
 */
const scheduleTokenRefresh = (session: any) => {
  if (!session || !session.expires_at) return;
  
  // Calculate when the token will expire in milliseconds
  const expiresAt = session.expires_at * 1000; // Convert from seconds to milliseconds
  const now = Date.now();
  
  // Time remaining before expiration
  const timeRemaining = expiresAt - now;
  
  // If the token is already expired or about to expire, refresh immediately
  if (timeRemaining <= REFRESH_THRESHOLD) {
    refreshToken();
    return;
  }
  
  // Otherwise schedule refresh for 5 minutes before expiration
  const refreshTime = timeRemaining - REFRESH_THRESHOLD;
  console.log(`Token refresh scheduled in ${Math.floor(refreshTime / 60000)} minutes`);
  
  setTimeout(() => {
    refreshToken();
  }, refreshTime);
};

/**
 * Function to refresh the user's token
 */
const refreshToken = async () => {
  try {
    console.log('Executing token refresh');
    const { data, error } = await supabase.auth.refreshSession();
    
    if (error) {
      console.error('Error refreshing token:', error);
      return;
    }
    
    if (data.session) {
      console.log('Token successfully renewed');
      // Schedule next refresh
      scheduleTokenRefresh(data.session);
    }
  } catch (err) {
    console.error('Unexpected error during token refresh:', err);
  }
};

export const schedulerModule = {
  scheduleTokenRefresh,
  refreshToken
};
