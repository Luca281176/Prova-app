import { supabase } from '../client';
import { toast } from 'sonner';

/**
 * Configures the Supabase client with a tenant ID for data isolation
 * This function sets the tenant ID in the JWT metadata for RLS
 */
const setTenantId = async (tenantId: string, tenantName?: string, tenantSlug?: string) => {
  try {
    if (!tenantId) {
      console.error('Error: invalid tenant ID');
      return false;
    }

    console.log(`Setting tenant ID: ${tenantId}, Name: ${tenantName}, Slug: ${tenantSlug}`);
    
    // First, save to localStorage as early fallback
    try {
      localStorage.setItem('current_tenant_id', tenantId);
      if (tenantName) localStorage.setItem('current_tenant_name', tenantName);
      if (tenantSlug) localStorage.setItem('current_tenant_slug', tenantSlug);
    } catch (storageError) {
      console.warn('Could not save tenant info to localStorage:', storageError);
    }
    
    // Check if we have a valid session
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      console.error('Error: Session check failed', sessionError.message);
      
      // Try to refresh the session before failing
      const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
      
      if (refreshError || !refreshData.session) {
        console.error('Error: Failed to refresh session', refreshError?.message);
        
        // Last resort: try to login with stored credentials if available
        const storedEmail = localStorage.getItem('last_login_email');
        const storedPassword = sessionStorage.getItem('temp_auth_password');
        
        if (storedEmail && storedPassword) {
          console.log('Attempting to recover session with stored credentials');
          try {
            const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
              email: storedEmail,
              password: storedPassword
            });
            
            if (loginError || !loginData.session) {
              console.error('Failed to recover session:', loginError?.message);
              sessionStorage.removeItem('temp_auth_password'); // Clear for security
              toast.error('Impossibile recuperare la sessione, effettua il login manualmente');
              return false;
            }
            
            console.log('Session recovered successfully');
          } catch (loginAttemptError) {
            console.error('Error during login recovery attempt:', loginAttemptError);
            sessionStorage.removeItem('temp_auth_password'); // Clear for security
            return false;
          }
        } else {
          toast.error('Sessione scaduta, effettua nuovamente il login');
          return false;
        }
      } else {
        console.log('Session refreshed successfully, proceeding with tenant update');
      }
    } else if (!sessionData.session) {
      console.error('Error: No active session found');
      
      // See if we can restore session from localStorage
      const storedTenantId = localStorage.getItem('current_tenant_id');
      if (storedTenantId && storedTenantId === tenantId) {
        console.log('Using stored tenant ID as fallback since no active session');
        return true; // Return true since we're using localStorage fallback
      }
      
      toast.error('Impossibile aggiornare il tenant: nessuna sessione attiva');
      return false;
    }
    
    // Add a small delay before updating user to ensure session is fully established
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Update user metadata with tenant information, with retry logic
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const { error } = await supabase.auth.updateUser({
          data: { 
            tenant_id: tenantId,
            tenant_name: tenantName || undefined,
            tenant_slug: tenantSlug || undefined
          }
        });

        if (error) {
          console.error(`Error updating tenant ID (attempt ${attempt}):`, error.message);
          
          if (attempt < 3) {
            // Exponential backoff: 200ms, 400ms, 800ms
            const backoff = Math.pow(2, attempt - 1) * 200;
            console.log(`Retrying in ${backoff}ms...`);
            await new Promise(resolve => setTimeout(resolve, backoff));
            continue;
          }
          
          // Final attempt failed, check if it's a session issue
          if (error.message.includes('session') || error.message.includes('JWT')) {
            console.log('Session appears to be invalid, trying to refresh...');
            
            const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
            
            if (refreshError || !refreshData.session) {
              console.error('Failed to refresh session:', refreshError?.message);
              
              // Try database fallback
              try {
                const { data: userData } = await supabase.auth.getUser();
                if (userData?.user?.id) {
                  await supabase
                    .from('users')
                    .update({ tenant_id: tenantId })
                    .eq('id', userData.user.id);
                  
                  console.log('Tenant ID saved to database as fallback');
                  return true;
                }
              } catch (dbError) {
                console.error('Error saving tenant ID to database:', dbError);
              }
              
              toast.error(`Impossibile aggiornare la sessione: ${refreshError?.message || 'errore sconosciuto'}`);
              return false;
            }
            
            // Try once more after successful refresh
            console.log('Session refreshed, retrying tenant update...');
            const { error: retryError } = await supabase.auth.updateUser({
              data: { 
                tenant_id: tenantId,
                tenant_name: tenantName || undefined,
                tenant_slug: tenantSlug || undefined
              }
            });
            
            if (retryError) {
              console.error('Error updating tenant ID after session refresh:', retryError.message);
              
              // Try database fallback
              try {
                const { data: userData } = await supabase.auth.getUser();
                if (userData?.user?.id) {
                  await supabase
                    .from('users')
                    .update({ tenant_id: tenantId })
                    .eq('id', userData.user.id);
                  
                  console.log('Tenant ID saved to database as fallback after refresh failure');
                  return true;
                }
              } catch (dbError) {
                console.error('Error saving tenant ID to database:', dbError);
              }
              
              toast.error(`Tenant update error: ${retryError.message}`);
              return false;
            }
          } else {
            // Try database fallback on non-session errors
            try {
              const { data: userData } = await supabase.auth.getUser();
              if (userData?.user?.id) {
                await supabase
                  .from('users')
                  .update({ tenant_id: tenantId })
                  .eq('id', userData.user.id);
                
                console.log('Tenant ID saved to database as fallback on general error');
                return true;
              }
            } catch (dbError) {
              console.error('Error saving tenant ID to database:', dbError);
            }
            
            toast.error(`Tenant update error: ${error.message}`);
            return false;
          }
        }
        
        // If we reached here without continuing the retry loop, it means success
        break;
      } catch (err) {
        console.error(`Unexpected error in setTenantId (attempt ${attempt}):`, err);
        
        if (attempt < 3) {
          // Exponential backoff before retry
          const backoff = Math.pow(2, attempt - 1) * 200;
          await new Promise(resolve => setTimeout(resolve, backoff));
        } else {
          // Try database fallback as last resort
          try {
            const { data: userData } = await supabase.auth.getUser();
            if (userData?.user?.id) {
              await supabase
                .from('users')
                .update({ tenant_id: tenantId })
                .eq('id', userData.user.id);
              
              console.log('Tenant ID saved to database as fallback after unexpected error');
              return true;
            }
          } catch (dbError) {
            console.error('Error saving tenant ID to database:', dbError);
          }
          
          toast.error(`Errore imprevisto durante l'aggiornamento del tenant`);
          return false;
        }
      }
    }
    
    // Verify metadata to confirm it was updated
    const { data: verifyData, error: verifyError } = await supabase.auth.getUser();
    
    if (verifyError) {
      console.error('Error verifying user:', verifyError.message);
      return localStorage.getItem('current_tenant_id') === tenantId; // Fall back to localStorage check
    }
    
    // Check both user_metadata and app_metadata
    const userMetadata = verifyData.user?.user_metadata || {};
    const appMetadata = verifyData.user?.app_metadata || {};
    
    if (userMetadata.tenant_id === tenantId || appMetadata.tenant_id === tenantId) {
      console.log('✅ Tenant ID correttamente salvato nei metadati JWT:', tenantId);
      return true;
    } else {
      console.warn('❌ Tenant ID non salvato correttamente nei metadati JWT', { userMetadata, appMetadata });
      
      // Save tenant information to the database as a fallback
      try {
        const { data: userData } = await supabase.auth.getUser();
        if (userData?.user?.id) {
          await supabase
            .from('users')
            .update({ tenant_id: tenantId })
            .eq('id', userData.user.id);
          
          console.log('Tenant ID saved to database as fallback');
          return true;
        }
      } catch (dbError) {
        console.error('Error saving tenant ID to database:', dbError);
      }
      
      return localStorage.getItem('current_tenant_id') === tenantId; // Fall back to localStorage check
    }
  } catch (err) {
    console.error('Error setting tenant ID:', err);
    toast.error(`Tenant configuration error: ${err instanceof Error ? err.message : String(err)}`);
    
    // Return true if we've at least saved to localStorage as a fallback
    return localStorage.getItem('current_tenant_id') === tenantId;
  }
};

/**
 * Gets the current tenant ID from user metadata in Supabase Auth
 * @returns The current tenant ID or null if not available
 */
const getCurrentTenantId = async (): Promise<string | null> => {
  try {
    // First check localStorage for cached value
    const cachedTenantId = localStorage.getItem('current_tenant_id');
    
    // Try to get from Supabase Auth
    const { data, error } = await supabase.auth.getUser();
    
    if (error || !data.user) {
      console.error('Error getting user:', error?.message);
      return cachedTenantId; // Return cached value as fallback
    }
    
    // Check in both user_metadata and app_metadata
    const userMetadata = data.user.user_metadata || {};
    const appMetadata = data.user.app_metadata || {};
    
    // Return tenant_id from either metadata source
    const metadataTenantId = userMetadata.tenant_id || appMetadata.tenant_id;
    
    if (metadataTenantId) {
      // Update cache if we got a value from metadata
      localStorage.setItem('current_tenant_id', metadataTenantId);
      return metadataTenantId;
    }
    
    if (!metadataTenantId && cachedTenantId) {
      // If we have a cached value but no metadata value, try to update metadata
      try {
        await supabase.auth.updateUser({
          data: { tenant_id: cachedTenantId }
        });
        console.log('Updated user metadata with cached tenant ID');
      } catch (updateError) {
        console.error('Failed to update metadata with cached tenant ID:', updateError);
      }
      
      return cachedTenantId;
    }
    
    // As a last resort, try to get from database
    try {
      const { data: userData, error: dbError } = await supabase
        .from('users')
        .select('tenant_id')
        .eq('id', data.user.id)
        .single();
        
      if (!dbError && userData?.tenant_id) {
        // Update cache and metadata
        localStorage.setItem('current_tenant_id', userData.tenant_id);
        
        try {
          await supabase.auth.updateUser({
            data: { tenant_id: userData.tenant_id }
          });
          console.log('Updated user metadata with database tenant ID');
        } catch (updateError) {
          console.error('Failed to update metadata with database tenant ID:', updateError);
        }
        
        return userData.tenant_id;
      }
    } catch (dbError) {
      console.error('Error retrieving tenant ID from database:', dbError);
    }
    
    return null;
  } catch (err) {
    console.error('Error retrieving tenant ID:', err);
    return localStorage.getItem('current_tenant_id'); // Return cached value as fallback
  }
};

/**
 * Gets all information about the current tenant from user metadata
 * @returns An object with tenant information or null
 */
const getCurrentTenantInfo = async () => {
  try {
    // Check cache first
    const cachedTenantId = localStorage.getItem('current_tenant_id');
    const cachedTenantName = localStorage.getItem('current_tenant_name');
    const cachedTenantSlug = localStorage.getItem('current_tenant_slug');
    
    // Try to get from Supabase Auth
    const { data, error } = await supabase.auth.getUser();
    
    if (error || !data.user) {
      console.error('Error getting user:', error?.message);
      
      // Return cached values as fallback if available
      if (cachedTenantId) {
        return {
          id: cachedTenantId,
          name: cachedTenantName || 'Tenant',
          slug: cachedTenantSlug || cachedTenantId
        };
      }
      
      return null;
    }
    
    // Check in both user_metadata and app_metadata
    const userMetadata = data.user.user_metadata || {};
    const appMetadata = data.user.app_metadata || {};
    
    // Look for tenant_id in both places
    const tenantId = userMetadata.tenant_id || appMetadata.tenant_id || cachedTenantId;
    
    if (!tenantId) {
      // As a last resort, try to get from database
      try {
        const { data: userData, error: dbError } = await supabase
          .from('users')
          .select('tenant_id')
          .eq('id', data.user.id)
          .single();
          
        if (!dbError && userData?.tenant_id) {
          // Update cache and metadata
          localStorage.setItem('current_tenant_id', userData.tenant_id);
          
          try {
            await supabase.auth.updateUser({
              data: { tenant_id: userData.tenant_id }
            });
            console.log('Updated user metadata with database tenant ID');
          } catch (updateError) {
            console.error('Failed to update metadata with database tenant ID:', updateError);
          }
          
          return {
            id: userData.tenant_id,
            name: userMetadata.tenant_name || appMetadata.tenant_name || 'Tenant',
            slug: userMetadata.tenant_slug || appMetadata.tenant_slug || userData.tenant_id
          };
        }
      } catch (dbError) {
        console.error('Error retrieving tenant ID from database:', dbError);
      }
      
      return null;
    }
    
    // Update cache if needed
    if (tenantId !== cachedTenantId) {
      localStorage.setItem('current_tenant_id', tenantId);
    }
    
    const tenantName = userMetadata.tenant_name || appMetadata.tenant_name || cachedTenantName || 'Tenant';
    const tenantSlug = userMetadata.tenant_slug || appMetadata.tenant_slug || cachedTenantSlug || tenantId;
    
    // Update cache if needed
    if (tenantName !== cachedTenantName) {
      localStorage.setItem('current_tenant_name', tenantName);
    }
    if (tenantSlug !== cachedTenantSlug) {
      localStorage.setItem('current_tenant_slug', tenantSlug);
    }
    
    return {
      id: tenantId,
      name: tenantName,
      slug: tenantSlug
    };
  } catch (err) {
    console.error('Error retrieving tenant information:', err);
    
    // Return cached values as fallback if available
    const cachedTenantId = localStorage.getItem('current_tenant_id');
    if (cachedTenantId) {
      return {
        id: cachedTenantId,
        name: localStorage.getItem('current_tenant_name') || 'Tenant',
        slug: localStorage.getItem('current_tenant_slug') || cachedTenantId
      };
    }
    
    return null;
  }
};

export const tenantModule = {
  setTenantId,
  getCurrentTenantId,
  getCurrentTenantInfo
};
