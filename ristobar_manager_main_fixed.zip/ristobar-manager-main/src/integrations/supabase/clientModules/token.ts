
import { supabase } from '../client';

// Revoked tokens list (in memory - now synchronized with the database)
const revokedTokens = new Set<string>();

/**
 * Checks if a token has been revoked
 * @param token Token to check
 * @returns true if the token has been revoked, false otherwise
 */
const isTokenRevoked = (token: string): boolean => {
  return revokedTokens.has(token);
};

/**
 * Revokes a JWT token
 * @param token Token to revoke
 */
const revokeToken = (token: string): void => {
  if (token) {
    console.log('Revoking token');
    revokedTokens.add(token);
    
    // Store revoked token in localStorage for persistence across sessions
    try {
      const storedTokens = localStorage.getItem('revoked_tokens');
      const tokens = storedTokens ? JSON.parse(storedTokens) : [];
      if (!tokens.includes(token)) {
        tokens.push(token);
        localStorage.setItem('revoked_tokens', JSON.stringify(tokens));
      }
    } catch (error) {
      console.warn('Error storing revoked token in localStorage:', error);
    }
    
    // Synchronize with the database
    try {
      import('../tokenSync').then(module => {
        module.syncRevokedToken(token);
      }).catch(error => {
        console.warn('Error importing tokenSync module:', error);
      });
    } catch (error) {
      console.warn('Error synchronizing revoked token:', error);
    }
  }
};

/**
 * Revokes all tokens for the current user
 */
const revokeAllUserTokens = async (): Promise<void> => {
  try {
    // In Supabase, this is equivalent to a session reset
    const { error } = await supabase.auth.refreshSession();
    
    if (error) {
      console.error('Error revoking all tokens:', error);
      return;
    }
    
    console.log('All user tokens successfully revoked');
  } catch (err) {
    console.error('Error revoking all tokens:', err);
  }
};

/**
 * Initialize revoked tokens from localStorage
 */
const initRevokedTokens = () => {
  try {
    const storedTokens = localStorage.getItem('revoked_tokens');
    if (storedTokens) {
      const tokens = JSON.parse(storedTokens);
      tokens.forEach((token: string) => {
        revokedTokens.add(token);
      });
      console.log(`Loaded ${tokens.length} revoked tokens from localStorage`);
    }
  } catch (error) {
    console.warn('Error loading revoked tokens from localStorage:', error);
  }
};

// Initialize revoked tokens when this module is imported
initRevokedTokens();

export const tokenModule = {
  isTokenRevoked,
  revokeToken,
  revokeAllUserTokens
};
