
import { supabase } from './client';

/**
 * Sincronizza un token revocato con il database Supabase
 * @param token Token da sincronizzare come revocato
 * @param userId ID dell'utente associato al token (opzionale)
 */
export async function syncRevokedToken(token: string, userId?: string): Promise<boolean> {
  try {
    if (!token) {
      console.warn('Tentativo di sincronizzare un token vuoto');
      return false;
    }
    
    // Crea un hash del token per non salvare il token completo nel DB
    const tokenHash = await createTokenHash(token);
    
    const expiresAt = new Date();
    // I token scadono dopo 30 giorni (periodo più lungo possibile per un token JWT)
    expiresAt.setDate(expiresAt.getDate() + 30);
    
    const { error } = await supabase
      .from('revoked_tokens')
      .insert({
        token_hash: tokenHash,
        user_id: userId || null,
        revoked_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString()
      });
      
    if (error) {
      // Se l'errore è dovuto a un vincolo unique, significa che il token è già revocato
      if (error.code === '23505') {
        return true;
      }
      
      console.error('Errore durante la sincronizzazione del token revocato:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Errore imprevisto durante la sincronizzazione del token:', error);
    return false;
  }
}

/**
 * Crea un hash del token per non salvare il token completo nel database
 * @param token Token da hashare
 * @returns Promise<string> Hash del token
 */
async function createTokenHash(token: string): Promise<string> {
  // Utilizziamo un algoritmo di hashing per non salvare il token in chiaro
  const encoder = new TextEncoder();
  const data = encoder.encode(token);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}
