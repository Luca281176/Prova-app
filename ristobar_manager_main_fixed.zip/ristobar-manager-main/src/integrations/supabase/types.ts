export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_notifications: {
        Row: {
          created_at: string | null
          date: string | null
          id: string
          message: string
          read: boolean | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string | null
          date?: string | null
          id?: string
          message: string
          read?: boolean | null
          title: string
          type: string
        }
        Update: {
          created_at?: string | null
          date?: string | null
          id?: string
          message?: string
          read?: boolean | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      backups: {
        Row: {
          backup_location: string | null
          backup_size: number | null
          created_at: string
          error_message: string | null
          id: string
          status: string
        }
        Insert: {
          backup_location?: string | null
          backup_size?: number | null
          created_at?: string
          error_message?: string | null
          id?: string
          status?: string
        }
        Update: {
          backup_location?: string | null
          backup_size?: number | null
          created_at?: string
          error_message?: string | null
          id?: string
          status?: string
        }
        Relationships: []
      }
      employee_roles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          permissions: Json
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          permissions?: Json
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          permissions?: Json
        }
        Relationships: []
      }
      error_logs: {
        Row: {
          error_details: string | null
          error_message: string
          id: string
          service: string
          timestamp: string
        }
        Insert: {
          error_details?: string | null
          error_message: string
          id?: string
          service: string
          timestamp?: string
        }
        Update: {
          error_details?: string | null
          error_message?: string
          id?: string
          service?: string
          timestamp?: string
        }
        Relationships: []
      }
      failed_transactions: {
        Row: {
          error_message: string
          id: string
          tenant_id: string | null
          timestamp: string
          transaction_data: Json
          transaction_id: string
        }
        Insert: {
          error_message: string
          id: string
          tenant_id?: string | null
          timestamp?: string
          transaction_data: Json
          transaction_id: string
        }
        Update: {
          error_message?: string
          id?: string
          tenant_id?: string | null
          timestamp?: string
          transaction_data?: Json
          transaction_id?: string
        }
        Relationships: []
      }
      isolation_tests: {
        Row: {
          created_at: string
          id: string
          tenant_id: string
          test_data: string | null
          test_name: string
        }
        Insert: {
          created_at?: string
          id: string
          tenant_id: string
          test_data?: string | null
          test_name: string
        }
        Update: {
          created_at?: string
          id?: string
          tenant_id?: string
          test_data?: string | null
          test_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "isolation_tests_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          customer_email: string | null
          customer_name: string
          customer_phone: string | null
          customer_table: string | null
          id: string
          items: Json
          status: string
          tenant_id: string | null
          total_amount: number
        }
        Insert: {
          created_at?: string
          customer_email?: string | null
          customer_name: string
          customer_phone?: string | null
          customer_table?: string | null
          id?: string
          items: Json
          status: string
          tenant_id?: string | null
          total_amount: number
        }
        Update: {
          created_at?: string
          customer_email?: string | null
          customer_name?: string
          customer_phone?: string | null
          customer_table?: string | null
          id?: string
          items?: Json
          status?: string
          tenant_id?: string | null
          total_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "orders_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      pending_operations: {
        Row: {
          client_generated_id: string | null
          created_at: string | null
          data: Json
          error_message: string | null
          id: string
          operation_type: string
          retry_count: number | null
          status: string | null
          tenant_id: string
        }
        Insert: {
          client_generated_id?: string | null
          created_at?: string | null
          data: Json
          error_message?: string | null
          id?: string
          operation_type: string
          retry_count?: number | null
          status?: string | null
          tenant_id: string
        }
        Update: {
          client_generated_id?: string | null
          created_at?: string | null
          data?: Json
          error_message?: string | null
          id?: string
          operation_type?: string
          retry_count?: number | null
          status?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pending_operations_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      reservations: {
        Row: {
          created_at: string
          customer_name: string
          date: string
          email: string | null
          id: string
          notes: string | null
          party_size: number
          phone: string
          special_requests: string[] | null
          status: string
          table_id: string | null
          time: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_name: string
          date: string
          email?: string | null
          id?: string
          notes?: string | null
          party_size: number
          phone: string
          special_requests?: string[] | null
          status?: string
          table_id?: string | null
          time: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_name?: string
          date?: string
          email?: string | null
          id?: string
          notes?: string | null
          party_size?: number
          phone?: string
          special_requests?: string[] | null
          status?: string
          table_id?: string | null
          time?: string
          updated_at?: string
        }
        Relationships: []
      }
      restaurant_data: {
        Row: {
          created_at: string | null
          data: Json
          data_type: string
          id: string
          is_deleted: boolean | null
          tenant_id: string
          updated_at: string | null
          version: number | null
        }
        Insert: {
          created_at?: string | null
          data?: Json
          data_type: string
          id?: string
          is_deleted?: boolean | null
          tenant_id: string
          updated_at?: string | null
          version?: number | null
        }
        Update: {
          created_at?: string | null
          data?: Json
          data_type?: string
          id?: string
          is_deleted?: boolean | null
          tenant_id?: string
          updated_at?: string | null
          version?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "restaurant_data_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      restaurant_settings: {
        Row: {
          created_at: string
          general_settings: Json
          id: string
          restaurant_logo: string | null
          restaurant_name: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          general_settings?: Json
          id?: string
          restaurant_logo?: string | null
          restaurant_name: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          general_settings?: Json
          id?: string
          restaurant_logo?: string | null
          restaurant_name?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "restaurant_settings_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      revoked_tokens: {
        Row: {
          id: string
          revoked_at: string
          token: string
          user_id: string | null
        }
        Insert: {
          id?: string
          revoked_at?: string
          token: string
          user_id?: string | null
        }
        Update: {
          id?: string
          revoked_at?: string
          token?: string
          user_id?: string | null
        }
        Relationships: []
      }
      rooms: {
        Row: {
          capacity: number
          created_at: string
          id: string
          name: string
          position: number | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          capacity?: number
          created_at?: string
          id?: string
          name: string
          position?: number | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          capacity?: number
          created_at?: string
          id?: string
          name?: string
          position?: number | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      staff: {
        Row: {
          contracttype: string | null
          created_at: string
          custompermissions: Json | null
          date_of_birth: string | null
          email: string | null
          firstname: string
          hiredate: string | null
          id: string
          lastname: string
          permissionlevel: string | null
          phone: string | null
          role: string
          salary: number | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          contracttype?: string | null
          created_at?: string
          custompermissions?: Json | null
          date_of_birth?: string | null
          email?: string | null
          firstname: string
          hiredate?: string | null
          id?: string
          lastname: string
          permissionlevel?: string | null
          phone?: string | null
          role: string
          salary?: number | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          contracttype?: string | null
          created_at?: string
          custompermissions?: Json | null
          date_of_birth?: string | null
          email?: string | null
          firstname?: string
          hiredate?: string | null
          id?: string
          lastname?: string
          permissionlevel?: string | null
          phone?: string | null
          role?: string
          salary?: number | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      staff_credentials: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          password_changed: boolean | null
          temporary_password: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          password_changed?: boolean | null
          temporary_password?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          password_changed?: boolean | null
          temporary_password?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      staff_performance: {
        Row: {
          averageordertime: number | null
          created_at: string
          date: string
          id: string
          notes: string | null
          ordersprocessed: number | null
          rating: number
          sales: number | null
          staffid: string
          tablesserved: number | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          averageordertime?: number | null
          created_at?: string
          date: string
          id?: string
          notes?: string | null
          ordersprocessed?: number | null
          rating: number
          sales?: number | null
          staffid: string
          tablesserved?: number | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          averageordertime?: number | null
          created_at?: string
          date?: string
          id?: string
          notes?: string | null
          ordersprocessed?: number | null
          rating?: number
          sales?: number | null
          staffid?: string
          tablesserved?: number | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_performance_staffid_fkey"
            columns: ["staffid"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_shifts: {
        Row: {
          confirmed: boolean | null
          created_at: string
          date: string
          endtime: string
          id: string
          notes: string | null
          staffid: string
          starttime: string
          status: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          confirmed?: boolean | null
          created_at?: string
          date: string
          endtime: string
          id?: string
          notes?: string | null
          staffid: string
          starttime: string
          status?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          confirmed?: boolean | null
          created_at?: string
          date?: string
          endtime?: string
          id?: string
          notes?: string | null
          staffid?: string
          starttime?: string
          status?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_shifts_staffid_fkey"
            columns: ["staffid"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          created_at: string | null
          expires_at: string | null
          id: string
          status: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          status?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      tables: {
        Row: {
          capacity: number
          created_at: string
          id: string
          name: string
          position: number | null
          room_id: string
          status: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          capacity?: number
          created_at?: string
          id?: string
          name: string
          position?: number | null
          room_id: string
          status?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          capacity?: number
          created_at?: string
          id?: string
          name?: string
          position?: number | null
          room_id?: string
          status?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tables_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          created_at: string | null
          id: string
          is_deleted: boolean | null
          name: string
          owner_email: string | null
          owner_id: string | null
          plan: string | null
          slug: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_deleted?: boolean | null
          name: string
          owner_email?: string | null
          owner_id?: string | null
          plan?: string | null
          slug?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          is_deleted?: boolean | null
          name?: string
          owner_email?: string | null
          owner_id?: string | null
          plan?: string | null
          slug?: string | null
        }
        Relationships: []
      }
      transactions: {
        Row: {
          customer_data: Json | null
          customer_name: string | null
          discount: number | null
          final_amount: number | null
          id: string
          notes: string | null
          operator_name: string | null
          order_id: string | null
          original_amount: number | null
          payment_method: string | null
          payment_reference: string | null
          status: string | null
          table_id: string | null
          table_name: string | null
          tenant_id: string | null
          timestamp: string | null
          tip: number | null
          user_id: string | null
        }
        Insert: {
          customer_data?: Json | null
          customer_name?: string | null
          discount?: number | null
          final_amount?: number | null
          id?: string
          notes?: string | null
          operator_name?: string | null
          order_id?: string | null
          original_amount?: number | null
          payment_method?: string | null
          payment_reference?: string | null
          status?: string | null
          table_id?: string | null
          table_name?: string | null
          tenant_id?: string | null
          timestamp?: string | null
          tip?: number | null
          user_id?: string | null
        }
        Update: {
          customer_data?: Json | null
          customer_name?: string | null
          discount?: number | null
          final_amount?: number | null
          id?: string
          notes?: string | null
          operator_name?: string | null
          order_id?: string | null
          original_amount?: number | null
          payment_method?: string | null
          payment_reference?: string | null
          status?: string | null
          table_id?: string | null
          table_name?: string | null
          tenant_id?: string | null
          timestamp?: string | null
          tip?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "transactions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_preferences: {
        Row: {
          created_at: string
          id: string
          preferences: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          preferences?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          preferences?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          cancel_at_period_end: boolean
          created_at: string
          current_period_end: string
          id: string
          payment_method: string | null
          plan_id: string
          restaurant_id: string | null
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end: string
          id?: string
          payment_method?: string | null
          plan_id: string
          restaurant_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string
          id?: string
          payment_method?: string | null
          plan_id?: string
          restaurant_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      users: {
        Row: {
          created_at: string | null
          email: string
          first_login: boolean | null
          id: string
          last_activity: string | null
          last_password_reset: string | null
          name: string
          password: string | null
          permissions: Json | null
          restaurantname: string | null
          role: string | null
          tenant_id: string
        }
        Insert: {
          created_at?: string | null
          email: string
          first_login?: boolean | null
          id?: string
          last_activity?: string | null
          last_password_reset?: string | null
          name: string
          password?: string | null
          permissions?: Json | null
          restaurantname?: string | null
          role?: string | null
          tenant_id: string
        }
        Update: {
          created_at?: string | null
          email?: string
          first_login?: boolean | null
          id?: string
          last_activity?: string | null
          last_password_reset?: string | null
          name?: string
          password?: string | null
          permissions?: Json | null
          restaurantname?: string | null
          role?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "users_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_columns_info: {
        Args: {
          table_name: string
        }
        Returns: {
          column_name: string
          data_type: string
          is_nullable: boolean
        }[]
      }
      get_tenant_id: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      jwt_with_tenant: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      set_user_tenant: {
        Args: {
          tenant_id: string
        }
        Returns: Json
      }
      sync_restaurant_data: {
        Args: {
          p_tenant_id: string
          p_data_type: string
          p_data: Json
          p_client_version: number
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
