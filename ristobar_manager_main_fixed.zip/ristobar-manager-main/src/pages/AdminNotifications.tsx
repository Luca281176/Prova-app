
import AuthLayout from '@/components/AuthLayout';
import { AdminNavbar } from '@/components/dashboard/AdminNavbar';
import { useUser } from '@/contexts/user';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BellIcon, CheckIcon, TrashIcon, SettingsIcon, UserIcon, CreditCardIcon, AlertTriangleIcon, Loader2 } from 'lucide-react';
import { useNotifications } from '@/contexts/notification/NotificationContext';
import { format, formatDistanceToNow } from 'date-fns';
import { it } from 'date-fns/locale';

const AdminNotifications = () => {
  const { user, isAdmin } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { 
    notifications, 
    unreadCount, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification,
    isLoading
  } = useNotifications();

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!isAdmin()) {
      navigate('/dashboard');
      toast({
        title: "Accesso negato",
        description: "Non hai i permessi per accedere a questa pagina.",
        variant: "destructive"
      });
      return;
    }
  }, [user, isAdmin, navigate, toast]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'user':
        return <UserIcon className="h-5 w-5 text-blue-500" />;
      case 'payment':
        return <CreditCardIcon className="h-5 w-5 text-green-500" />;
      case 'system':
        return <SettingsIcon className="h-5 w-5 text-purple-500" />;
      case 'alert':
        return <AlertTriangleIcon className="h-5 w-5 text-red-500" />;
      default:
        return <BellIcon className="h-5 w-5 text-gray-500" />;
    }
  };

  // Format date in relative format (e.g. "2 days ago")
  const formatRelativeDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true, locale: it });
    } catch (error) {
      console.error('Error formatting date:', error);
      return dateString;
    }
  };

  const renderNotificationsList = (notificationsList: any[]) => {
    if (isLoading) {
      return (
        <Card>
          <CardContent className="p-8 text-center">
            <Loader2 className="h-12 w-12 mx-auto text-muted-foreground/50 animate-spin" />
            <p className="mt-4 text-muted-foreground">Caricamento notifiche in corso...</p>
          </CardContent>
        </Card>
      );
    }

    if (notificationsList.length === 0) {
      return (
        <Card>
          <CardContent className="p-8 text-center">
            <BellIcon className="h-12 w-12 mx-auto text-muted-foreground/50" />
            <p className="mt-4 text-muted-foreground">Non ci sono notifiche da visualizzare.</p>
          </CardContent>
        </Card>
      );
    }

    return notificationsList.map(notification => (
      <Card key={notification.id} className={`${!notification.read ? 'bg-muted/40' : ''}`}>
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className="mt-1">
              {getIcon(notification.type)}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">{notification.title}</h3>
                  <p className="text-sm text-muted-foreground">{notification.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{formatRelativeDate(notification.date)}</p>
                </div>
                <div className="flex gap-2">
                  {!notification.read && (
                    <Button variant="ghost" size="icon" onClick={() => markAsRead(notification.id)}>
                      <CheckIcon className="h-4 w-4" />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => deleteNotification(notification.id)}>
                    <TrashIcon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    ));
  };

  return (
    <AuthLayout>
      <AdminNavbar />
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Notifiche</h1>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Badge variant="secondary" className="bg-primary text-primary-foreground">
                {unreadCount} nuove
              </Badge>
            )}
            <Button variant="outline" onClick={markAllAsRead}>
              Segna tutte come lette
            </Button>
          </div>
        </div>
        
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">Tutte</TabsTrigger>
            <TabsTrigger value="unread">Non lette {unreadCount > 0 && `(${unreadCount})`}</TabsTrigger>
            <TabsTrigger value="users">Utenti</TabsTrigger>
            <TabsTrigger value="payments">Pagamenti</TabsTrigger>
            <TabsTrigger value="system">Sistema</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-4">
            {renderNotificationsList(notifications)}
          </TabsContent>
          
          <TabsContent value="unread" className="space-y-4">
            {renderNotificationsList(notifications.filter(n => !n.read))}
          </TabsContent>
          
          <TabsContent value="users" className="space-y-4">
            {renderNotificationsList(notifications.filter(n => n.type === 'user'))}
          </TabsContent>
          
          <TabsContent value="payments" className="space-y-4">
            {renderNotificationsList(notifications.filter(n => n.type === 'payment'))}
          </TabsContent>
          
          <TabsContent value="system" className="space-y-4">
            {renderNotificationsList(notifications.filter(n => n.type === 'system' || n.type === 'alert'))}
          </TabsContent>
        </Tabs>
      </div>
    </AuthLayout>
  );
};

export default AdminNotifications;
