
import AuthLayout from '@/components/AuthLayout';
import { AdminNavbar } from '@/components/dashboard/AdminNavbar';
import { useUser } from '@/contexts/user';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import AddNotificationForm from '@/components/admin/AddNotificationForm';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription, FeatureAccessLevel } from '@/services/subscriptions/types';
import { hasSubscriptionLevel } from '@/services/subscriptions';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';

const AdminSettings = () => {
  const { user, isAdmin } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!isAdmin()) {
      navigate('/dashboard');
      toast({
        title: "Accesso negato",
        description: "Non hai i permessi per accedere a questa pagina.",
        variant: "destructive"
      });
      return;
    }
    
    // Fetch user subscription
    const fetchSubscription = async () => {
      if (user) {
        try {
          const subscription = await getUserSubscription(user.id);
          // Use type assertion to handle the compatibility issue
          setUserSubscription(subscription as unknown as UserSubscription);
        } catch (error) {
          console.error("Error fetching subscription:", error);
          setUserSubscription(null);
        }
      }
      setIsLoading(false);
    };
    
    fetchSubscription();
  }, [user, isAdmin, navigate, toast]);

  const handleSaveSettings = () => {
    toast({
      title: "Impostazioni salvate",
      description: "Le impostazioni sono state salvate con successo."
    });
  };
  
  // Check if user has access to advanced sections (Pro+ plan)
  const hasAdvancedAccess = userSubscription ? hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO) : false;

  if (isLoading) {
    return (
      <AuthLayout>
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <AdminNavbar />
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Impostazioni Amministratore</h1>
          {hasAdvancedAccess ? (
            <AddNotificationForm />
          ) : null}
        </div>
        
        <Tabs defaultValue="general" className="space-y-4">
          <TabsList>
            <TabsTrigger value="general">Generali</TabsTrigger>
            <TabsTrigger value="security">Sicurezza</TabsTrigger>
            <TabsTrigger value="emails">Email</TabsTrigger>
            <TabsTrigger value="backups">Backup</TabsTrigger>
            <TabsTrigger value="notifications">Notifiche</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Impostazioni Generali</CardTitle>
                <CardDescription>
                  Configura le impostazioni generali della piattaforma
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="site-name">Nome del Sito</Label>
                  <Input id="site-name" defaultValue="Gestionale Ristorante" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="admin-email">Email Amministratore</Label>
                  <Input id="admin-email" type="email" defaultValue="admin@example.com" />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch id="maintenance-mode" />
                  <Label htmlFor="maintenance-mode">Modalità Manutenzione</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch id="enable-registration" defaultChecked />
                  <Label htmlFor="enable-registration">Registrazione Utenti</Label>
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSettings}>Salva Impostazioni</Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Sicurezza</CardTitle>
                <CardDescription>
                  Gestisci le impostazioni di sicurezza
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password-policy">Policy Password</Label>
                  <select id="password-policy" className="w-full p-2 border rounded">
                    <option>Standard (minimo 8 caratteri)</option>
                    <option>Forte (min 10 caratteri, numeri, simboli)</option>
                    <option>Personalizzata</option>
                  </select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch id="two-factor" />
                  <Label htmlFor="two-factor">Richiedi Autenticazione a Due Fattori</Label>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Timeout Sessione (minuti)</Label>
                  <Input id="session-timeout" type="number" defaultValue="30" />
                </div>
              </CardContent>
              <CardFooter>
                <Button onClick={handleSaveSettings}>Salva Impostazioni</Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="emails" className="space-y-4">
            {hasAdvancedAccess ? (
              <Card>
                <CardHeader>
                  <CardTitle>Configurazione Email</CardTitle>
                  <CardDescription>
                    Configura il servizio di invio email
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="smtp-server">Server SMTP</Label>
                    <Input id="smtp-server" defaultValue="smtp.example.com" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="smtp-port">Porta SMTP</Label>
                    <Input id="smtp-port" type="number" defaultValue="587" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="smtp-user">Utente SMTP</Label>
                    <Input id="smtp-user" defaultValue="noreply@example.com" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="smtp-password">Password SMTP</Label>
                    <Input id="smtp-password" type="password" defaultValue="********" />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch id="email-encryption" defaultChecked />
                    <Label htmlFor="email-encryption">Usa Crittografia TLS</Label>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveSettings}>Salva Impostazioni</Button>
                </CardFooter>
              </Card>
            ) : (
              <PlanFeatureAlert
                title="Configurazione avanzata email non disponibile"
                description="La configurazione avanzata delle email è disponibile solo per gli abbonamenti Pro e Ultimate."
                availableInPlans={['Pro', 'Ultimate']}
                buttonText="Aggiorna il tuo piano"
                buttonLink="/subscriptions"
              />
            )}
          </TabsContent>
          
          <TabsContent value="backups" className="space-y-4">
            {hasAdvancedAccess ? (
              <Card>
                <CardHeader>
                  <CardTitle>Configurazione Backup</CardTitle>
                  <CardDescription>
                    Gestisci le impostazioni di backup automatico
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="auto-backup" defaultChecked />
                    <Label htmlFor="auto-backup">Backup Automatico</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="backup-frequency">Frequenza Backup</Label>
                    <select id="backup-frequency" className="w-full p-2 border rounded">
                      <option>Giornaliera</option>
                      <option>Settimanale</option>
                      <option>Mensile</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="backup-time">Ora Backup</Label>
                    <Input id="backup-time" type="time" defaultValue="03:00" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="backup-retention">Conservazione Backup (giorni)</Label>
                    <Input id="backup-retention" type="number" defaultValue="30" />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveSettings}>Salva Impostazioni</Button>
                </CardFooter>
              </Card>
            ) : (
              <PlanFeatureAlert
                title="Configurazione avanzata backup non disponibile"
                description="La configurazione avanzata dei backup è disponibile solo per gli abbonamenti Pro e Ultimate."
                availableInPlans={['Pro', 'Ultimate']}
                buttonText="Aggiorna il tuo piano"
                buttonLink="/subscriptions"
              />
            )}
          </TabsContent>
          
          <TabsContent value="notifications" className="space-y-4">
            {hasAdvancedAccess ? (
              <Card>
                <CardHeader>
                  <CardTitle>Impostazioni Notifiche</CardTitle>
                  <CardDescription>
                    Configura le preferenze per le notifiche di sistema
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="enable-email-notifications" defaultChecked />
                    <Label htmlFor="enable-email-notifications">Invia notifiche via email</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch id="enable-browser-notifications" defaultChecked />
                    <Label htmlFor="enable-browser-notifications">Abilita notifiche browser</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notifications-interval">Intervallo verifica (minuti)</Label>
                    <Input id="notifications-interval" type="number" defaultValue="5" min="1" max="60" />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Tipi di notifiche da mostrare</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center space-x-2">
                        <Switch id="show-user-notifications" defaultChecked />
                        <Label htmlFor="show-user-notifications">Utenti</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="show-payment-notifications" defaultChecked />
                        <Label htmlFor="show-payment-notifications">Pagamenti</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="show-system-notifications" defaultChecked />
                        <Label htmlFor="show-system-notifications">Sistema</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="show-alert-notifications" defaultChecked />
                        <Label htmlFor="show-alert-notifications">Avvisi</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col items-start gap-4 sm:flex-row sm:justify-between sm:items-center">
                  <Button onClick={handleSaveSettings}>Salva Impostazioni</Button>
                  <AddNotificationForm triggerButton={true} />
                </CardFooter>
              </Card>
            ) : (
              <PlanFeatureAlert
                title="Gestione notifiche non disponibile"
                description="La configurazione avanzata delle notifiche è disponibile solo per gli abbonamenti Pro e Ultimate."
                availableInPlans={['Pro', 'Ultimate']}
                buttonText="Aggiorna il tuo piano"
                buttonLink="/subscriptions"
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AuthLayout>
  );
};

export default AdminSettings;
