
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Settings2, PlusCircle, CalendarRange, LayoutGrid, Clock, Map } from 'lucide-react';
import AuthLayout from '@/components/AuthLayout';
import LocationSelector from '@/components/rooms/LocationSelector';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar"; // Changed from date-picker to calendar

const AdvancedReservations = () => {
  const [locations, setLocations] = useState<string[]>(['Sede A', 'Sede B', 'Sede C']);
  const [selectedLocation, setSelectedLocation] = useState<string>(locations[0]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [showSettingsDialog, setShowSettingsDialog] = useState<boolean>(false);
  const [showAddReservationDialog, setShowAddReservationDialog] = useState<boolean>(false);
  
  const handleLocationChange = (location: string) => {
    setSelectedLocation(location);
  };

  return (
    <AuthLayout>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-tight">Prenotazioni Avanzate</h1>
          
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSettingsDialog(true)}
            >
              <Settings2 className="h-4 w-4 mr-2" />
              Impostazioni
            </Button>
            
            <Button
              size="sm"
              onClick={() => setShowAddReservationDialog(true)}
            >
              <PlusCircle className="h-4 w-4 mr-2" />
              Nuova Prenotazione
            </Button>
          </div>
        </div>
        
        {/* Barra superiore con filtri e selettore della sede */}
        <div className="flex flex-col md:flex-row gap-4">
          <LocationSelector
            locations={locations}
            selectedLocation={selectedLocation}
            onLocationChange={handleLocationChange}
            className="md:w-2/3"
          />
          
          <Card className="p-4 md:w-1/3">
            <div className="flex items-center space-x-2">
              <CalendarRange className="h-5 w-5 text-primary" />
              <Calendar 
                mode="single"
                selected={selectedDate} 
                onSelect={(date) => date && setSelectedDate(date)}
              />
            </div>
          </Card>
        </div>
        
        {/* Tabs per passare tra le viste */}
        <Tabs defaultValue="grid" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="grid">
              <LayoutGrid className="h-4 w-4 mr-2" />
              Griglia
            </TabsTrigger>
            <TabsTrigger value="timeline">
              <Clock className="h-4 w-4 mr-2" />
              Timeline
            </TabsTrigger>
            <TabsTrigger value="map">
              <Map className="h-4 w-4 mr-2" />
              Mappa
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="grid">
            <p>Griglia</p>
          </TabsContent>
          <TabsContent value="timeline">
            <p>Timeline</p>
          </TabsContent>
          <TabsContent value="map">
            <p>Mappa</p>
          </TabsContent>
        </Tabs>
        
        {/* Modals */}
        {/* Add Reservation Dialog */}
        {/* Settings Dialog */}
      </div>
    </AuthLayout>
  );
};

export default AdvancedReservations;
