
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Spinner } from '@/components/ui/spinner';

const AuthCallback = () => {
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        console.log('Processing authentication callback...');
        
        // Get session after OAuth callback
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error retrieving session:', error);
          setError('Autenticazione fallita. Riprova.');
          setTimeout(() => navigate('/login'), 2000);
          return;
        }
        
        if (data.session) {
          console.log('Authentication successful!');
          localStorage.setItem('supabase-session', JSON.stringify(data.session));
          toast.success('Login effettuato con successo');
          navigate('/dashboard');
        } else {
          console.warn('No session found after authentication');
          setError('Autenticazione incompleta. Riprova.');
          setTimeout(() => navigate('/login'), 2000);
        }
      } catch (err) {
        console.error('Error during authentication callback:', err);
        setError('Si è verificato un errore durante l\'autenticazione.');
        setTimeout(() => navigate('/login'), 2000);
      }
    };

    handleAuthCallback();
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md p-8 space-y-8 bg-card rounded-lg shadow-lg">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Autenticazione in corso...</h2>
          {error ? (
            <div className="mt-4 text-destructive">{error}</div>
          ) : (
            <div className="flex flex-col items-center mt-6 space-y-4">
              <Spinner size="lg" />
              <p className="text-muted-foreground">
                Stiamo completando il processo di login...
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthCallback;
