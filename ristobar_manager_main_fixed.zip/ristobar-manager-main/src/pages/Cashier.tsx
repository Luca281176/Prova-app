
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CreditCard, ReceiptText, History, Settings, Printer } from 'lucide-react';
import CashierPaymentPanel from '@/components/cashier/CashierPaymentPanel';
import CashierTransactionHistory from '@/components/cashier/CashierTransactionHistory';
import CashierSettings from '@/components/cashier/CashierSettings';
import { Badge } from '@/components/ui/badge';
import { getCashierOrders } from '@/services/ordersService';
import { toast } from '@/hooks/use-toast';

const Cashier = () => {
  const [pendingOrdersCount, setPendingOrdersCount] = useState(0);
  const [activeTab, setActiveTab] = useState('payment');
  
  const loadPendingOrdersCount = async () => {
    try {
      const cashierOrders = await getCashierOrders();
      setPendingOrdersCount(cashierOrders.length);
    } catch (error) {
      console.error('Error loading cashier orders count:', error);
    }
  };
  
  useEffect(() => {
    loadPendingOrdersCount();
    
    const handleCashierQueueUpdated = () => {
      console.log('Cashier queue updated event received');
      loadPendingOrdersCount();
    };
    
    const handleOrdersUpdated = () => {
      console.log('Orders updated event received in Cashier');
      loadPendingOrdersCount();
    };
    
    const handleTransactionCreated = () => {
      console.log('Transaction created event received, switching to transactions tab');
      setActiveTab('transactions');
    };
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Shortcut: Alt+F for fiscal receipt
      if (e.altKey && e.key === 'f') {
        if (activeTab !== 'payment') {
          setActiveTab('payment');
          toast({
            title: "Ricevuta fiscale selezionata",
            description: "Modalità scontrino fiscale attivata",
          });
        }
      }
      
      // Shortcut: Alt+I for invoice
      if (e.altKey && e.key === 'i') {
        if (activeTab !== 'payment') {
          setActiveTab('payment');
        }
        toast({
          title: "Fattura selezionata",
          description: "Modalità fattura attivata",
        });
        
        // Dispatch a custom event to set receipt type to invoice
        window.dispatchEvent(new CustomEvent('set-receipt-invoice'));
      }
    };
    
    window.addEventListener('cashier-queue-updated', handleCashierQueueUpdated);
    window.addEventListener('order-completed', handleCashierQueueUpdated);
    window.addEventListener('orders-updated', handleOrdersUpdated);
    window.addEventListener('transaction-created', handleTransactionCreated);
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('cashier-queue-updated', handleCashierQueueUpdated);
      window.removeEventListener('order-completed', handleCashierQueueUpdated);
      window.removeEventListener('orders-updated', handleOrdersUpdated);
      window.removeEventListener('transaction-created', handleTransactionCreated);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [activeTab]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  return (
    <AuthLayout>
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Cassa</h1>
          <p className="text-muted-foreground">Gestisci i pagamenti del tuo ristorante</p>
        </div>
        {pendingOrdersCount > 0 && (
          <Badge className="bg-green-500 hover:bg-green-600">
            {pendingOrdersCount} {pendingOrdersCount === 1 ? 'ordine' : 'ordini'} da pagare
          </Badge>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="payment" className="relative">
            <CreditCard className="h-4 w-4 mr-2" />
            Pagamento
            {pendingOrdersCount > 0 && (
              <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center rounded-full">
                {pendingOrdersCount}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="transactions">
            <History className="h-4 w-4 mr-2" />
            Transazioni
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Impostazioni
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="payment" className="space-y-4">
          <CashierPaymentPanel />
        </TabsContent>
        
        <TabsContent value="transactions">
          <CashierTransactionHistory />
        </TabsContent>
        
        <TabsContent value="settings">
          <CashierSettings />
        </TabsContent>
      </Tabs>
    </AuthLayout>
  );
};

export default Cashier;
