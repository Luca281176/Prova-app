
import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/user';
import AuthLayout from '@/components/AuthLayout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, CreditCard, AlertCircle, Loader2 } from 'lucide-react';
import { createSubscription, subscriptionPlans } from '@/services/subscriptions';
import { createCheckoutSession, verifyPaymentSession } from '@/services/stripeCheckout';
import PaymentSummary from '@/components/checkout/PaymentSummary';
import { toast } from 'sonner';

const Checkout = () => {
  const { user, updateUser } = useUser();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [redirectAttempts, setRedirectAttempts] = useState<number>(0);
  const [initialLoad, setInitialLoad] = useState(true);
  
  const planId = searchParams.get('plan');
  const success = searchParams.get('success') === 'true';
  const sessionId = searchParams.get('session_id');
  
  // Log page load and query params for debugging
  useEffect(() => {
    console.log('Checkout page loaded with params:', {
      planId,
      success,
      sessionId,
      url: window.location.href,
      hasUserSubscription: user?.subscription ? true : false
    });
    
    // Set initialLoad to false after the first render
    if (initialLoad) {
      setInitialLoad(false);
    }
  }, [planId, success, sessionId, user, initialLoad]);
  
  const selectedPlan = subscriptionPlans.find(plan => plan.id === planId);
  
  // Handle successful checkout redirect from Stripe
  useEffect(() => {
    if (success && sessionId && planId && user) {
      const completeSubscription = async () => {
        try {
          setIsLoading(true);
          
          // Verify the payment session with our backend
          const result = await verifyPaymentSession(sessionId);
          
          if (result.success) {
            updateUser({
              ...user,
              subscription: result.subscription
            });
            
            setIsSuccess(true);
            toast.success("Abbonamento attivato con successo!");
          } else {
            setError('Si è verificato un errore nella verifica del pagamento. Riprova più tardi.');
            toast.error("Errore nella verifica del pagamento");
          }
        } catch (err) {
          console.error('Error completing subscription:', err);
          setError('Si è verificato un errore durante l\'elaborazione del pagamento. Riprova più tardi.');
          toast.error("Errore nell'attivazione dell'abbonamento");
        } finally {
          setIsLoading(false);
        }
      };
      
      completeSubscription();
    }
  }, [success, sessionId, planId, user, updateUser]);
  
  // Redirect to Stripe Checkout
  const handleCheckout = async () => {
    if (!user || !planId) return;
    
    try {
      setIsLoading(true);
      setIsRedirecting(true);
      setError(null);
      
      // Get Stripe price ID for the selected plan
      const stripePriceId = getStripePriceId(planId);
      
      if (!stripePriceId) {
        throw new Error('Piano non valido');
      }
      
      console.log('Redirecting to Stripe checkout with price ID:', stripePriceId);
      
      // Create checkout session and redirect to Stripe
      const checkoutData = await createCheckoutSession(stripePriceId, user.id);
      
      if (checkoutData && checkoutData.url) {
        // Redirect to Stripe Checkout
        window.location.href = checkoutData.url;
      } else {
        throw new Error('Impossibile creare la sessione di pagamento');
      }
    } catch (err) {
      console.error('Error processing payment:', err);
      setError('Si è verificato un errore durante l\'elaborazione del pagamento. Riprova più tardi.');
      setIsRedirecting(false);
      setIsLoading(false);
    }
  };
  
  // Helper to get Stripe price ID from our plan ID
  const getStripePriceId = (planId: string): string => {
    // Match the values expected by the backend in create-checkout-session/index.ts
    switch (planId) {
      case 'starter':
        return 'price_starter';
      case 'pro':
        return 'price_pro';
      case 'ultimate':
        return 'price_ultimate';
      default:
        return '';
    }
  };
  
  // Redirect if no plan selected unless coming from a successful checkout
  useEffect(() => {
    if (!planId && !success) {
      console.log('No plan ID found, redirecting to subscriptions page');
      navigate('/subscriptions');
    }
  }, [planId, navigate, success]);
  
  // ✅ CORREZIONE: Logica di reindirizzamento completamente rivista per evitare loop
  useEffect(() => {
    // Skip redirect on initial load to avoid flashes
    if (initialLoad) return;
    
    // Non reindirizzare in questi casi:
    // 1. Durante il caricamento
    // 2. Quando è in corso un flusso di successo
    // 3. Quando si sta tornando da Stripe (success=true)
    // 4. Quando abbiamo già tentato un reindirizzamento
    // 5. Quando l'utente sta cambiando piano (selezionando un piano diverso dal corrente)
    
    const hasAttemptedRedirect = redirectAttempts > 0;
    const isSuccessFlow = isSuccess || success;
    const hasSelectedPlan = !!planId;
    
    // L'utente ha già un abbonamento?
    const hasExistingSubscription = !!user?.subscription;
    
    // L'utente sta cambiando piano?
    const isChangingPlan = hasSelectedPlan && 
                          hasExistingSubscription && 
                          user.subscription?.planId !== planId;
    
    console.log('Checkout redirect check:', {
      hasExistingSubscription,
      isSuccessFlow,
      hasSelectedPlan,
      isChangingPlan,
      redirectAttempts,
      isLoading
    });
    
    // Reindirizza solo se:
    // - L'utente ha già un abbonamento
    // - Non è in un flusso di successo o cambio piano
    // - Non abbiamo già tentato un reindirizzamento
    // - Non siamo in fase di caricamento
    if (hasExistingSubscription && 
        !isSuccessFlow && 
        !isChangingPlan && 
        !hasAttemptedRedirect && 
        !isLoading) {
      
      console.log('User already has subscription and not changing plan, redirecting to subscriptions page');
      setRedirectAttempts(prev => prev + 1);
      navigate('/subscriptions');
    }
  }, [user, navigate, isSuccess, success, isLoading, planId, redirectAttempts, initialLoad]);
  
  if (!selectedPlan && !success) {
    console.log('No selected plan found, showing loading');
    return (
      <AuthLayout>
        <div className="max-w-3xl mx-auto py-8">
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2 text-lg">Caricamento...</p>
          </div>
        </div>
      </AuthLayout>
    );
  }
  
  return (
    <AuthLayout>
      <div className="max-w-3xl mx-auto py-8 animate-fade-up">
        <div className="mb-8">
          <h1 className="text-2xl font-bold tracking-tight">Checkout</h1>
          <p className="text-muted-foreground">Completa il tuo ordine per attivare l'abbonamento</p>
        </div>
        
        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2 text-lg">{isRedirecting ? 'Reindirizzamento al checkout...' : 'Elaborazione in corso...'}</p>
          </div>
        )}
        
        {isSuccess && !isLoading && (
          <Card className="border-green-200 bg-green-50 dark:bg-green-950/20">
            <CardHeader>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-6 w-6 text-green-600" />
                <CardTitle>Pagamento completato con successo!</CardTitle>
              </div>
              <CardDescription>
                Il tuo abbonamento è stato attivato correttamente.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium">Dettagli dell'abbonamento:</h3>
                  <p>Piano: <strong>{selectedPlan?.name || 'Piano sottoscritto'}</strong></p>
                  <p>Prezzo: <strong>€{selectedPlan?.price.toFixed(2) || '0.00'}/mese</strong></p>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Riceverai una email di conferma con i dettagli del tuo abbonamento.
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={() => navigate('/dashboard')}>
                Vai alla dashboard
              </Button>
            </CardFooter>
          </Card>
        )}
        
        {!isSuccess && !isLoading && selectedPlan && (
          <div className="grid md:grid-cols-5 gap-6">
            <div className="md:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>Informazioni di pagamento</CardTitle>
                  <CardDescription>
                    Completa il checkout per attivare il tuo abbonamento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border p-4 rounded-md bg-accent/10">
                      <h3 className="font-medium mb-2">Pagamento sicuro</h3>
                      <p className="text-sm text-muted-foreground">
                        Il tuo pagamento verrà elaborato in modo sicuro tramite Stripe, leader mondiale nei servizi di pagamento.
                      </p>
                    </div>
                    
                    <Button 
                      onClick={handleCheckout}
                      disabled={isLoading}
                      className="w-full"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Elaborazione...
                        </>
                      ) : (
                        <>
                          <CreditCard className="mr-2 h-4 w-4" />
                          Procedi al pagamento
                        </>
                      )}
                    </Button>
                    
                    {error && (
                      <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-start space-x-2 text-red-800 dark:bg-red-950/20 dark:border-red-900 dark:text-red-400">
                        <AlertCircle className="h-5 w-5 shrink-0" />
                        <p className="text-sm">{error}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:col-span-2">
              <PaymentSummary plan={selectedPlan} />
            </div>
          </div>
        )}
      </div>
    </AuthLayout>
  );
};

export default Checkout;
