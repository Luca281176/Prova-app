
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { RocketIcon, TimerIcon, GlobeIcon, CircuitBoardIcon, AtomIcon } from 'lucide-react';
import { motion } from 'framer-motion';

const ComingSoon = () => {
  const [email, setEmail] = useState('');
  const [countdownValues, setCountdownValues] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Calculate countdown to April 30, 2024
  useEffect(() => {
    const targetDate = new Date('2024-04-30T00:00:00');
    
    const updateCountdown = () => {
      const now = new Date();
      const difference = targetDate.getTime() - now.getTime();
      
      if (difference <= 0) {
        setCountdownValues({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0
        });
        return;
      }
      
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      
      setCountdownValues({ days, hours, minutes, seconds });
    };
    
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes('@')) {
      toast.error("Per favore, inserisci un indirizzo email valido");
      return;
    }
    
    // Here you would typically call an API to save the email
    console.log("Email subscription:", email);
    
    toast.success("Grazie per la tua iscrizione! Ti terremo aggiornato sul lancio.");
    setEmail('');
  };

  const CountdownItem = ({ value, label }: { value: number, label: string }) => (
    <motion.div 
      className="flex flex-col items-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-primary/10 backdrop-blur-sm rounded-lg w-16 h-16 sm:w-24 sm:h-24 flex items-center justify-center mb-2">
        <span className="text-2xl sm:text-4xl font-bold text-primary">{value}</span>
      </div>
      <span className="text-sm text-muted-foreground">{label}</span>
    </motion.div>
  );

  const Feature = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
    <motion.div 
      className="flex flex-col items-center text-center p-6 rounded-lg glass-panel"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-primary/10 p-3 rounded-full mb-4">
        <Icon className="h-8 w-8 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </motion.div>
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section with Countdown */}
      <div className="flex-1 relative overflow-hidden bg-gradient-to-b from-background to-accent/30">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-24">
          <motion.div 
            className="max-w-4xl mx-auto text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center justify-center px-4 py-2 rounded-full bg-primary/10 text-primary mb-6">
              <RocketIcon className="h-4 w-4 mr-2" />
              <span className="text-sm font-medium">Lancio Imminente</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
              La Rivoluzione nella Gestione 
              <span className="text-primary block mt-2">del Tuo Ristorante</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Stiamo per lanciare la piattaforma che cambierà per sempre il modo in cui gestisci il tuo ristorante. Preparati a semplificare ogni aspetto della tua attività.
            </p>
            
            {/* Countdown Timer */}
            <div className="mb-12">
              <h2 className="text-2xl font-semibold mb-6 flex items-center justify-center">
                <TimerIcon className="h-6 w-6 mr-2 text-primary" />
                <span>Manca poco al lancio</span>
              </h2>
              
              <div className="flex justify-center space-x-4 sm:space-x-8">
                <CountdownItem value={countdownValues.days} label="Giorni" />
                <CountdownItem value={countdownValues.hours} label="Ore" />
                <CountdownItem value={countdownValues.minutes} label="Minuti" />
                <CountdownItem value={countdownValues.seconds} label="Secondi" />
              </div>
            </div>
            
            {/* Subscribe Form */}
            <div className="glass-panel p-8 rounded-xl max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-4">Rimani aggiornato</h3>
              <p className="text-muted-foreground mb-6">
                Iscriviti per ricevere aggiornamenti sul lancio e ottenere accesso anticipato.
              </p>
              
              <form onSubmit={handleSubscribe} className="flex flex-col space-y-4">
                <Input
                  type="email" 
                  placeholder="La tua email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full"
                />
                <Button type="submit" className="w-full">
                  Iscriviti ora
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Features Preview */}
      <div className="bg-background py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <motion.h2 
              className="text-3xl font-bold mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Cosa aspettarsi
            </motion.h2>
            <motion.p 
              className="text-muted-foreground max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Scopri le funzionalità innovative che renderanno RistoBar Manager indispensabile per la tua attività.
            </motion.p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Feature 
              icon={GlobeIcon} 
              title="Gestione Completa" 
              description="Controlla ogni aspetto del tuo ristorante, dalle prenotazioni agli ordini, dalla gestione del personale all'inventario." 
            />
            <Feature 
              icon={CircuitBoardIcon} 
              title="Integrazione Avanzata" 
              description="Connetti facilmente tutte le tue operazioni in un unico sistema centralizzato e accessibile da qualsiasi dispositivo." 
            />
            <Feature 
              icon={AtomIcon} 
              title="Intelligenza Artificiale" 
              description="Analisi predittive e suggerimenti automatizzati per ottimizzare il tuo business e aumentare i profitti." 
            />
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="bg-accent/20 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            © {new Date().getFullYear()} RistoBar Manager. Tutti i diritti riservati.
          </p>
          <div className="flex justify-center space-x-4 mt-4">
            <Button variant="link" onClick={() => window.location.href = '/'}>
              Home
            </Button>
            <Button variant="link" onClick={() => window.location.href = '#'}>
              Contatti
            </Button>
            <Button variant="link" onClick={() => window.location.href = '#'}>
              Privacy
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ComingSoon;
