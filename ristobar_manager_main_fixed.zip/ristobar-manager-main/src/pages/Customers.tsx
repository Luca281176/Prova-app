
import { useState } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UsersIcon, PlusIcon, FilterIcon, SearchIcon, DownloadIcon, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useUser } from '@/contexts/UserContext';

const Customers = () => {
  const { user } = useUser();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const { toast } = useToast();
  
  // Empty array for real customer data
  const restaurantCustomers: any[] = [];
  const filteredCustomers: any[] = [];
    
  const handleExportCustomers = () => {
    if (restaurantCustomers.length === 0) {
      toast({
        title: "Nessun dato da esportare",
        description: "Non ci sono clienti da esportare al momento.",
      });
      return;
    }
    
    toast({
      title: "Export completato",
      description: "I dati dei clienti sono stati esportati con successo.",
    });
  };
  
  return (
    <AuthLayout>
      <div className="animate-fade-up">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Clienti</h1>
            <p className="text-muted-foreground">Gestisci e monitora i tuoi clienti e abbonati</p>
          </div>
          <div className="flex mt-4 sm:mt-0 space-x-2">
            <Button size="sm" variant="outline" onClick={handleExportCustomers} disabled={restaurantCustomers.length === 0}>
              <DownloadIcon className="h-4 w-4 mr-2" />
              Esporta
            </Button>
            <Button size="sm">
              <PlusIcon className="h-4 w-4 mr-2" />
              Nuovo Cliente
            </Button>
          </div>
        </div>
        
        <Card className="glass-panel mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <SearchIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Cerca clienti..."
                  className="pl-9 pr-4 py-2 w-full rounded-md border border-input bg-background"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="flex gap-2">
                <select
                  className="px-4 py-2 rounded-md border border-input bg-background"
                  value={selectedFilter}
                  onChange={(e) => setSelectedFilter(e.target.value)}
                >
                  <option value="all">Tutti gli stati</option>
                  <option value="active">Attivi</option>
                  <option value="inactive">Inattivi</option>
                  <option value="pending">In attesa</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid gap-6">
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <UsersIcon className="h-5 w-5 mr-2" />
                  Clienti e Abbonati
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="py-3 px-4 text-left font-medium">Nome</th>
                      <th className="py-3 px-4 text-left font-medium">Email</th>
                      <th className="py-3 px-4 text-left font-medium">Telefono</th>
                      <th className="py-3 px-4 text-left font-medium">Stato Abbonamento</th>
                      <th className="py-3 px-4 text-left font-medium">Piano</th>
                      <th className="py-3 px-4 text-left font-medium">Ultima Visita</th>
                      <th className="py-3 px-4 text-right font-medium">Totale Speso</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td colSpan={7} className="py-16 text-center">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <AlertCircle className="h-12 w-12 mb-3" />
                          <p className="text-lg font-medium mb-1">Nessun cliente registrato</p>
                          <p className="text-sm max-w-md mx-auto">
                            Aggiungi il tuo primo cliente cliccando sul pulsante "Nuovo Cliente" in alto.
                          </p>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <Card className="glass-panel">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Clienti Totali</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0</div>
                <p className="text-xs text-muted-foreground mt-2">Aggiungi nuovi clienti per visualizzare le statistiche</p>
              </CardContent>
            </Card>
            
            <Card className="glass-panel">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Abbonamenti Attivi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0</div>
                <p className="text-xs text-muted-foreground mt-2">
                  0% del totale
                </p>
              </CardContent>
            </Card>
            
            <Card className="glass-panel">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Fatturato Medio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">€0.00</div>
                <p className="text-xs text-muted-foreground mt-2">Per cliente</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
};

export default Customers;
