
import { useEffect, useState } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { useUser } from '@/contexts/user';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { DashboardSelector } from '@/components/dashboard/DashboardSelector';
import AdminDashboard from '@/components/dashboard/AdminDashboard';
import { isSubscriptionActive, getDaysRemaining } from '@/services/subscriptions';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { AdminNavbar } from '@/components/dashboard/AdminNavbar';
import { supabase } from '@/integrations/supabase/client';
import { Spinner } from '@/components/ui/spinner';
import { setupSubscriptionSync } from '@/services/stripeCheckout';
import { hasValidSession, refreshSession } from '@/contexts/user/session';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface DashboardProps {
  adminMode?: boolean;
}

const Dashboard = ({ adminMode = false }: DashboardProps) => {
  const { user, isLoading: isUserLoading, sessionChecked, logout } = useUser();
  const { currentTenant, isLoading: isTenantLoading, setCurrentTenant } = useTenant();
  const [isSyncing, setIsSyncing] = useState(false);
  const [sessionValid, setSessionValid] = useState(true);
  const [wasLoggedIn, setWasLoggedIn] = useState(false);
  const [isEmailConfirmed, setIsEmailConfirmed] = useState(true);
  const navigate = useNavigate();
  
  const isLoading = isUserLoading || isTenantLoading;

  useEffect(() => {
    if (user) {
      // Check if email is confirmed using Supabase
      const checkEmailConfirmation = async () => {
        try {
          const { data: userMetadata } = await supabase.auth.getUser();
          if (userMetadata && userMetadata.user) {
            // If email confirmed status is available in metadata
            const confirmed = userMetadata.user.email_confirmed_at !== null;
            setIsEmailConfirmed(confirmed);
            
            if (!confirmed) {
              console.log('User email not confirmed');
            }
          }
        } catch (error) {
          console.error('Error checking email confirmation:', error);
        }
      };
      
      checkEmailConfirmation();
    }
  }, [user]);

  useEffect(() => {
    const checkPreviousLogin = () => {
      try {
        const hadPreviousSession = localStorage.getItem('had_active_session') === 'true';
        setWasLoggedIn(hadPreviousSession);
        
        if (user) {
          localStorage.setItem('had_active_session', 'true');
        }
      } catch (error) {
        console.error('Error checking previous login state:', error);
      }
    };
    
    checkPreviousLogin();
  }, [user]);

  useEffect(() => {
    let isMounted = true;
    
    const checkSession = async () => {
      if (user) {
        if (isMounted) {
          setSessionValid(true);
        }
        return;
      }

      try {
        if (!user && sessionChecked) {
          const valid = await hasValidSession();
          console.log('Session validity check result:', valid);
          
          if (isMounted) {
            setSessionValid(valid);
          }
          
          if (!valid && !isUserLoading && wasLoggedIn) {
            console.log('No valid session detected, attempting refresh...');
            const refreshSuccessful = await refreshSession();
            
            if (refreshSuccessful && isMounted) {
              console.log('Session refresh successful');
              setSessionValid(true);
              
              setTimeout(() => {
                window.location.reload();
              }, 500);
            } else if (isMounted) {
              console.log('Session refresh failed');
            }
          }
        }
      } catch (error) {
        console.error('Error during session check:', error);
      }
    };
    
    checkSession();
    
    return () => {
      isMounted = false;
    };
  }, [user, isUserLoading, sessionChecked, wasLoggedIn]);

  useEffect(() => {
    console.log("Dashboard mounted, user:", user);
    console.log("Admin mode:", adminMode);
    
    if (user && user.subscription) {
      const active = isSubscriptionActive(user.subscription);
      const daysLeft = getDaysRemaining(user.subscription);
      
      console.log(`User has subscription plan: ${user.subscription.planId}`);
      console.log(`Subscription is ${active ? 'active' : 'inactive'}`);
      
      if (active) {
        console.log(`Days remaining: ${daysLeft}`);
      }
      
      if (user.subscription.cancelAtPeriodEnd) {
        console.log('Subscription will be canceled at the end of the period');
      }
    } else {
      console.log('User has no subscription or is in trial period');
    }
  }, [user, adminMode]);

  useEffect(() => {
    async function fetchTenant() {
      if (user && !currentTenant && !isTenantLoading) {
        setIsSyncing(true);
        console.log("🔄 Recupero dati tenant da Supabase...");
        
        try {
          const { data, error } = await supabase
            .from("tenants")
            .select("*")
            .eq("id", user.id)
            .maybeSingle();

          if (error) {
            console.error("❌ Errore nel recupero del tenant:", error.message);
            const slug = user.restaurantName
              ? user.restaurantName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
              : `tenant-${user.id}`;
              
            setCurrentTenant({
              id: user.id,
              name: user.restaurantName || 'Restaurant',
              slug: slug,
              schemaName: `tenant_${user.id}`,
              storagePath: `tenant_${user.id}`
            });
            
            console.log("Created fallback tenant from user data");
          } else if (data) {
            console.log("✅ Tenant recuperato con successo:", data);
            setCurrentTenant({
              id: data.id,
              name: data.name || user.restaurantName || 'Restaurant',
              slug: data.slug || `tenant-${user.id}`,
              schemaName: `tenant_${data.id}`,
              storagePath: `tenant_${data.id}`
            });
          } else {
            console.warn("⚠️ Nessun tenant trovato, ritento il recupero...");
            
            const retry = await supabase
              .from("tenants")
              .select("*")
              .eq("id", user.id)
              .single();

            if (retry.data) {
              console.log("✅ Tenant recuperato al secondo tentativo:", retry.data);
              setCurrentTenant({
                id: retry.data.id,
                name: retry.data.name || user.restaurantName || 'Restaurant',
                slug: retry.data.slug || `tenant-${user.id}`,
                schemaName: `tenant_${retry.data.id}`,
                storagePath: `tenant_${retry.data.id}`
              });
            } else {
              console.warn("⚠️ Tenant ancora non trovato, creando un tenant temporaneo...");
              const slug = user.restaurantName
                ? user.restaurantName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
                : `tenant-${user.id}`;
                
              setCurrentTenant({
                id: user.id,
                name: user.restaurantName || 'Restaurant',
                slug: slug,
                schemaName: `tenant_${user.id}`,
                storagePath: `tenant_${user.id}`
              });
            }
          }
        } catch (error) {
          console.error("❌ Errore di connessione a Supabase:", error);
          toast.error("Errore nell'inizializzazione del ristorante");
        } finally {
          setIsSyncing(false);
        }
      }
    }
    
    fetchTenant();
  }, [user, currentTenant, isTenantLoading, setCurrentTenant]);

  useEffect(() => {
    console.log("Setting up real-time tenant updates listener");
    
    const channel = supabase
      .channel("tenants_updates")
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'tenants',
        filter: `id=eq.${user.id}`
      }, (payload) => {
        console.log("Real-time tenant update received:", payload);
        if (payload.new && setCurrentTenant) {
          setCurrentTenant({
            id: payload.new.id,
            name: payload.new.name || 'Restaurant',
            slug: payload.new.slug || `tenant-${payload.new.id}`,
            schemaName: `tenant_${payload.new.id}`,
            storagePath: `tenant_${payload.new.id}`
          });
          toast.success("Restaurant data updated", {
            description: "Restaurant data has been synchronized"
          });
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, setCurrentTenant]);

  useEffect(() => {
    if (!user) return;
    
    const cleanupSync = setupSubscriptionSync(user.id, (subscription) => {
      if (user && subscription) {
        console.log("Subscription updated via real-time:", subscription);
      }
    });
    
    return () => {
      if (cleanupSync) cleanupSync();
    };
  }, [user]);

  if (isLoading || isSyncing) {
    return (
      <AuthLayout>
        <div className="flex flex-col w-full p-8 gap-4">
          {isSyncing ? (
            <div className="flex flex-col items-center justify-center p-8 space-y-4">
              <Spinner size="lg" />
              <p className="text-muted-foreground">Synchronizing data...</p>
            </div>
          ) : (
            <>
              <Skeleton className="h-10 w-[250px]" />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                <Skeleton className="h-40 w-full" />
                <Skeleton className="h-40 w-full" />
                <Skeleton className="h-40 w-full" />
              </div>
              <Skeleton className="h-80 w-full mt-6" />
            </>
          )}
        </div>
      </AuthLayout>
    );
  }

  if (!sessionChecked) {
    return (
      <AuthLayout>
        <div className="flex flex-col items-center justify-center p-8 space-y-4">
          <Spinner size="lg" />
          <p className="text-muted-foreground">Verifica sessione in corso...</p>
        </div>
      </AuthLayout>
    );
  }

  if (!user) {
    return (
      <AuthLayout>
        <div className="p-8 text-center">
          <h2 className="text-xl font-semibold mb-4">
            {!sessionValid && wasLoggedIn ? 'Sessione scaduta' : 'Login richiesto'}
          </h2>
          <p>
            {!sessionValid && wasLoggedIn 
              ? 'La tua sessione è scaduta. Per favore effettua nuovamente il login.'
              : 'Per favore effettua il login per accedere alla dashboard.'}
          </p>
          <Button 
            onClick={() => navigate('/login')} 
            className="mt-4"
          >
            Vai al login
          </Button>
        </div>
      </AuthLayout>
    );
  }

  // Check if email is confirmed
  if (!isEmailConfirmed) {
    return (
      <AuthLayout>
        <div className="p-8 max-w-3xl mx-auto">
          <Alert variant="warning" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Conferma la tua email</AlertTitle>
            <AlertDescription>
              Ti abbiamo inviato un'email di conferma all'indirizzo {user.email}. Per favore controlla la tua casella email e clicca sul link di conferma per attivare il tuo account.
            </AlertDescription>
          </Alert>
          
          <div className="bg-card p-6 rounded-lg shadow-sm border border-border space-y-6">
            <h2 className="text-xl font-semibold">Non hai ricevuto l'email di conferma?</h2>
            
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Se non hai ricevuto l'email di conferma, controlla la cartella dello spam o della posta indesiderata.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  onClick={async () => {
                    try {
                      await supabase.auth.resend({
                        type: 'signup',
                        email: user.email,
                      });
                      toast.success("Email di conferma inviata nuovamente");
                    } catch (error) {
                      console.error("Error resending confirmation email:", error);
                      toast.error("Errore nell'invio dell'email. Riprova più tardi.");
                    }
                  }}
                >
                  Invia di nuovo l'email
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={async () => {
                    await logout();
                    navigate('/login');
                  }}
                >
                  Torna al login
                </Button>
              </div>
            </div>
            
            <div className="pt-4 border-t border-border mt-6">
              <p className="text-sm text-muted-foreground">
                Per assistenza, contatta il nostro supporto clienti all'indirizzo support@ristobarmanager.it
              </p>
            </div>
          </div>
        </div>
      </AuthLayout>
    );
  }

  const isAppOwner = user.email === 'luca.costanzo@ristobarmanager.it';
  
  return (
    <AuthLayout>
      {adminMode && isAppOwner ? (
        <>
          <AdminNavbar />
          <AdminDashboard />
        </>
      ) : (
        <DashboardSelector adminMode={adminMode} />
      )}
    </AuthLayout>
  );
};

export default Dashboard;
