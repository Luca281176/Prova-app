
import AuthLayout from '@/components/AuthLayout';
import { AdminNavbar } from '@/components/dashboard/AdminNavbar';
import { useUser } from '@/contexts/user';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { DatabaseIcon, DownloadIcon, RefreshCwIcon } from 'lucide-react';

const DatabaseAdmin = () => {
  const { user, isAdmin } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!isAdmin) {
      navigate('/dashboard');
      toast({
        title: "Accesso negato",
        description: "Non hai i permessi per accedere a questa pagina.",
        variant: "destructive"
      });
      return;
    }
  }, [user, isAdmin, navigate, toast]);

  const handleBackupDatabase = () => {
    toast({
      title: "Backup avviato",
      description: "Il backup del database è stato avviato. Riceverai una notifica quando sarà completato.",
    });
  };

  const handleRestoreDatabase = () => {
    toast({
      title: "Funzionalità in arrivo",
      description: "La funzionalità di ripristino del database sarà disponibile a breve.",
    });
  };

  return (
    <AuthLayout>
      <AdminNavbar />
      <div className="container mx-auto py-6">
        <h1 className="text-2xl font-bold mb-6">Gestione Database</h1>
        
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Panoramica</TabsTrigger>
            <TabsTrigger value="backup">Backup</TabsTrigger>
            <TabsTrigger value="tables">Tabelle</TabsTrigger>
            <TabsTrigger value="queries">Query</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Statistiche Database</CardTitle>
                  <CardDescription>Panoramica delle dimensioni e prestazioni</CardDescription>
                </CardHeader>
                <CardContent>
                  <dl className="space-y-2">
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Dimensione Totale</dt>
                      <dd className="text-sm font-medium">256.4 MB</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Tabelle</dt>
                      <dd className="text-sm font-medium">24</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Indici</dt>
                      <dd className="text-sm font-medium">42</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Ultimo Backup</dt>
                      <dd className="text-sm font-medium">2 giorni fa</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Prestazioni</CardTitle>
                  <CardDescription>Statistiche di utilizzo e prestazioni</CardDescription>
                </CardHeader>
                <CardContent>
                  <dl className="space-y-2">
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Query al minuto</dt>
                      <dd className="text-sm font-medium">124</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Tempo medio di risposta</dt>
                      <dd className="text-sm font-medium">45ms</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Connessioni attive</dt>
                      <dd className="text-sm font-medium">12</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-muted-foreground">Utilizzo CPU</dt>
                      <dd className="text-sm font-medium">24%</dd>
                    </div>
                  </dl>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Azioni Rapide</CardTitle>
                  <CardDescription>Operazioni comuni sul database</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={handleBackupDatabase}
                  >
                    <DownloadIcon className="mr-2 h-4 w-4" />
                    Backup Database
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={handleRestoreDatabase}
                  >
                    <DatabaseIcon className="mr-2 h-4 w-4" />
                    Ripristina Database
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                  >
                    <RefreshCwIcon className="mr-2 h-4 w-4" />
                    Ottimizza Database
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="backup" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Gestione Backup</CardTitle>
                <CardDescription>
                  Configura e gestisci i backup del database
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Backup Manuali</h3>
                  <div className="flex space-x-2">
                    <Button onClick={handleBackupDatabase}>
                      <DownloadIcon className="mr-2 h-4 w-4" />
                      Esegui Backup Ora
                    </Button>
                    <Button variant="outline" onClick={handleRestoreDatabase}>
                      Ripristina da Backup
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Backup Automatici</h3>
                  <p className="text-sm text-muted-foreground">
                    I backup automatici sono configurati per eseguirsi ogni giorno alle 03:00.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Backup Recenti</h3>
                  <div className="border rounded-md">
                    <div className="flex items-center justify-between border-b p-3">
                      <span className="font-medium">backup_20250309_030012.sql</span>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Download</Button>
                        <Button variant="outline" size="sm">Ripristina</Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between border-b p-3">
                      <span className="font-medium">backup_20250308_030014.sql</span>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Download</Button>
                        <Button variant="outline" size="sm">Ripristina</Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-3">
                      <span className="font-medium">backup_20250307_030011.sql</span>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Download</Button>
                        <Button variant="outline" size="sm">Ripristina</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="tables" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Tabelle del Database</CardTitle>
                <CardDescription>
                  Visualizza e gestisci le tabelle del database
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-md">
                  <div className="flex items-center justify-between border-b p-3">
                    <span className="font-medium">users</span>
                    <div className="text-sm text-muted-foreground">32.4 MB - 8,546 righe</div>
                  </div>
                  <div className="flex items-center justify-between border-b p-3">
                    <span className="font-medium">user_subscriptions</span>
                    <div className="text-sm text-muted-foreground">5.7 MB - 1,245 righe</div>
                  </div>
                  <div className="flex items-center justify-between border-b p-3">
                    <span className="font-medium">menu_items</span>
                    <div className="text-sm text-muted-foreground">12.1 MB - 3,567 righe</div>
                  </div>
                  <div className="flex items-center justify-between border-b p-3">
                    <span className="font-medium">reservations</span>
                    <div className="text-sm text-muted-foreground">18.9 MB - 4,321 righe</div>
                  </div>
                  <div className="flex items-center justify-between border-b p-3">
                    <span className="font-medium">inventory_items</span>
                    <div className="text-sm text-muted-foreground">9.5 MB - 2,876 righe</div>
                  </div>
                  <div className="flex items-center justify-between p-3">
                    <span className="font-medium">transactions</span>
                    <div className="text-sm text-muted-foreground">24.8 MB - 6,543 righe</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="queries" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Query SQL</CardTitle>
                <CardDescription>
                  Esegui query SQL direttamente sul database
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="query" className="text-sm font-medium">Query SQL</label>
                  <textarea 
                    id="query" 
                    className="w-full h-32 p-2 border rounded-md"
                    placeholder="SELECT * FROM users LIMIT 10;"
                  />
                </div>
                <Button>Esegui Query</Button>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Risultati</h3>
                  <p className="text-sm text-muted-foreground">
                    Nessun risultato da visualizzare. Esegui una query per vedere i risultati.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AuthLayout>
  );
};

export default DatabaseAdmin;
