import React, { useState, useEffect } from 'react';
import { getRestaurantInfoSync } from '@/components/cashier/bill/RestaurantInfoProvider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { QrCode, Share2, Download, Smartphone } from 'lucide-react';
import QRCode from 'qrcode.react';
import { useUser } from '@/contexts/user/UserProvider';
import { useToast } from '@/hooks/use-toast';

const DigitalMenu = () => {
  // Change from async getRestaurantInfo to sync getRestaurantInfoSync
  const restaurantInfo = getRestaurantInfoSync();
  const { user } = useUser();
  const { toast } = useToast();
  const [menuUrl, setMenuUrl] = useState('');
  const [activeTab, setActiveTab] = useState('qrcode');
  
  useEffect(() => {
    // Generate a menu URL based on restaurant info
    if (user && user.id) {
      const baseUrl = window.location.origin;
      const slug = restaurantInfo.name
        .toLowerCase()
        .replace(/\s+/g, '-')
        .replace(/[^a-z0-9-]/g, '');
      
      setMenuUrl(`${baseUrl}/menu/${slug}?id=${user.id}`);
    }
  }, [user, restaurantInfo.name]);
  
  const handleDownloadQR = () => {
    const canvas = document.getElementById('menu-qrcode') as HTMLCanvasElement;
    if (!canvas) return;
    
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = `${restaurantInfo.name.replace(/\s+/g, '-')}-menu-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: 'QR Code scaricato',
      description: 'Il QR Code è stato scaricato con successo',
    });
  };
  
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Menu di ${restaurantInfo.name}`,
          text: 'Dai un\'occhiata al nostro menu digitale!',
          url: menuUrl,
        });
        
        toast({
          title: 'Menu condiviso',
          description: 'Il link al menu è stato condiviso con successo',
        });
      } catch (error) {
        console.error('Errore durante la condivisione:', error);
        toast({
          title: 'Errore',
          description: 'Non è stato possibile condividere il menu',
          variant: 'destructive',
        });
      }
    } else {
      // Fallback per browser che non supportano Web Share API
      navigator.clipboard.writeText(menuUrl);
      toast({
        title: 'Link copiato',
        description: 'Il link al menu è stato copiato negli appunti',
      });
    }
  };
  
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Menu Digitale</h1>
          <p className="text-muted-foreground">
            Crea e gestisci il tuo menu digitale accessibile tramite QR Code
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleShare}>
            <Share2 className="mr-2 h-4 w-4" />
            Condividi
          </Button>
          <Button onClick={handleDownloadQR}>
            <Download className="mr-2 h-4 w-4" />
            Scarica QR
          </Button>
        </div>
      </div>
      
      <Separator />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Anteprima Menu Digitale</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center p-6 border rounded-lg bg-muted">
              <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-4 bg-primary text-primary-foreground">
                  <div className="flex items-center justify-between">
                    {restaurantInfo.logo && (
                      <img 
                        src={restaurantInfo.logo} 
                        alt={restaurantInfo.name} 
                        className="h-12 w-auto object-contain"
                      />
                    )}
                    <h2 className="text-xl font-bold">{restaurantInfo.name}</h2>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-2">Menu del Giorno</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Antipasto Misto</span>
                      <span>€8.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Pasta al Pomodoro</span>
                      <span>€10.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tiramisù</span>
                      <span>€5.00</span>
                    </div>
                  </div>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground text-center">
                Questa è un'anteprima semplificata. Il menu reale includerà tutte le categorie e i prodotti configurati.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Condivisione</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="qrcode">
                  <QrCode className="h-4 w-4 mr-2" />
                  QR Code
                </TabsTrigger>
                <TabsTrigger value="link">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Link
                </TabsTrigger>
              </TabsList>
              <TabsContent value="qrcode" className="pt-4">
                <div className="flex flex-col items-center justify-center">
                  <QRCode
                    id="menu-qrcode"
                    value={menuUrl}
                    size={200}
                    level="H"
                    includeMargin={true}
                    renderAs="canvas"
                  />
                  <p className="mt-4 text-sm text-center text-muted-foreground">
                    Stampa questo QR Code e posizionalo sui tavoli per permettere ai clienti di visualizzare il menu.
                  </p>
                </div>
              </TabsContent>
              <TabsContent value="link" className="pt-4">
                <div className="space-y-4">
                  <div className="p-2 bg-muted rounded-md overflow-x-auto">
                    <code className="text-sm break-all">{menuUrl}</code>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => {
                      navigator.clipboard.writeText(menuUrl);
                      toast({
                        title: 'Link copiato',
                        description: 'Il link al menu è stato copiato negli appunti',
                      });
                    }}
                  >
                    Copia link
                  </Button>
                  <p className="text-sm text-muted-foreground">
                    Condividi questo link sui social media o via email per permettere ai clienti di visualizzare il menu.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Impostazioni Menu Digitale</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Il menu digitale mostra automaticamente tutti i prodotti attivi nel tuo menu. 
            Puoi personalizzare l'aspetto e le informazioni mostrate.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="outline" className="justify-start">
              <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
              Personalizza aspetto
            </Button>
            <Button variant="outline" className="justify-start">
              <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 20h9"></path>
                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
              </svg>
              Modifica informazioni
            </Button>
            <Button variant="outline" className="justify-start">
              <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="9" y1="3" x2="9" y2="21"></line>
              </svg>
              Gestisci categorie
            </Button>
            <Button variant="outline" className="justify-start">
              <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="16"></line>
                <line x1="8" y1="12" x2="16" y2="12"></line>
              </svg>
              Aggiungi prodotti
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DigitalMenu;
