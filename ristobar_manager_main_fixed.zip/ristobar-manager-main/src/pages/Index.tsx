
import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import LandingHeader from '@/components/LandingHeader';
import LandingFeatures from '@/components/LandingFeatures';
import LandingTestimonials from '@/components/LandingTestimonials';
import LandingSupport from '@/components/LandingSupport';
import LandingFooter from '@/components/LandingFooter';
import LandingPricing from '@/components/LandingPricing';
import LandingContact from '@/components/LandingContact';
import { Toaster } from 'sonner';

const Index = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Add smooth scrolling for anchor links
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      if (anchor && anchor.hash && anchor.hash.startsWith('#')) {
        e.preventDefault();
        const targetElement = document.querySelector(anchor.hash);
        
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth' });
          
          // Update URL without page reload
          window.history.pushState(null, '', anchor.hash);
        }
      }
    };
    
    document.addEventListener('click', handleAnchorClick);
    
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1">
        <LandingHeader />
        <LandingFeatures />
        <LandingTestimonials />
        <LandingPricing />
        <LandingContact />
        <LandingSupport />
      </main>
      <LandingFooter />
      <Toaster position="bottom-right" />
    </div>
  );
};

export default Index;
