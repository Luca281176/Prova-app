
import { useState } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { InventoryProvider } from '@/contexts/InventoryContext';
import { InventoryDashboard } from '@/components/inventory/InventoryDashboard';
import { InventoryList } from '@/components/inventory/InventoryList';
import { SuppliersList } from '@/components/inventory/SuppliersList';
import { OrdersManagement } from '@/components/inventory/OrdersManagement';
import { InventorySettings } from '@/components/inventory/InventorySettings';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';
import { useUser } from '@/contexts/user';
import { getUserSubscription } from '@/services/subscriptions';
import { hasSubscriptionLevel } from '@/services/subscriptions/featureAccess';
import { FeatureAccessLevel } from '@/services/subscriptions/types';
import { useEffect, useState as useReactState } from 'react';

export default function Inventory() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const { user } = useUser();
  const [hasAccess, setHasAccess] = useReactState(false);
  const [isLoading, setIsLoading] = useReactState(true);

  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setHasAccess(false);
        setIsLoading(false);
        return;
      }
      
      try {
        const subscription = await getUserSubscription(user.id);
        console.log("Inventory access check - User subscription:", subscription);
        
        // User with Pro or Ultimate plan can access inventory
        const canAccessInventory = hasSubscriptionLevel(subscription, FeatureAccessLevel.PRO);
        console.log("Can access inventory:", canAccessInventory, "Subscription plan:", subscription?.planId);
        
        setHasAccess(canAccessInventory);
      } catch (error) {
        console.error("Error checking inventory access:", error);
        setHasAccess(false);
      }
      setIsLoading(false);
    };
    
    checkAccess();
  }, [user]);

  if (isLoading) {
    return (
      <AuthLayout>
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AuthLayout>
    );
  }

  if (!hasAccess) {
    return (
      <AuthLayout>
        <div className="space-y-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Magazzino</h1>
            <p className="text-muted-foreground">
              Gestisci il tuo inventario, monitora scorte e ordini, e ricevi notifiche sulle giacenze
            </p>
          </div>
          
          <div className="my-12">
            <PlanFeatureAlert
              title="Accesso non disponibile per il piano Starter"
              description="La gestione del magazzino è una funzionalità avanzata disponibile solo per gli abbonamenti Pro e Ultimate."
              availableInPlans={['Pro', 'Ultimate']}
              buttonText="Aggiorna il tuo piano"
              buttonLink="/subscriptions"
            />
          </div>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <InventoryProvider>
        <div className="space-y-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Magazzino</h1>
            <p className="text-muted-foreground">
              Gestisci il tuo inventario, monitora scorte e ordini, e ricevi notifiche sulle giacenze
            </p>
          </div>
          
          <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-5 mb-8">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="inventory">Inventario</TabsTrigger>
              <TabsTrigger value="suppliers">Fornitori</TabsTrigger>
              <TabsTrigger value="orders">Ordini</TabsTrigger>
              <TabsTrigger value="settings">Impostazioni</TabsTrigger>
            </TabsList>
            
            <TabsContent value="dashboard" className="space-y-6">
              <InventoryDashboard />
            </TabsContent>
            
            <TabsContent value="inventory" className="space-y-6">
              <InventoryList />
            </TabsContent>
            
            <TabsContent value="suppliers" className="space-y-6">
              <SuppliersList />
            </TabsContent>
            
            <TabsContent value="orders" className="space-y-6">
              <OrdersManagement />
            </TabsContent>
            
            <TabsContent value="settings" className="space-y-6">
              <InventorySettings />
            </TabsContent>
          </Tabs>
        </div>
      </InventoryProvider>
    </AuthLayout>
  );
}
