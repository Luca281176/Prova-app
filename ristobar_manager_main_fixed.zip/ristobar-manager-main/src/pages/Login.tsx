
import { useState } from 'react';
import { supabase } from '@/config/supabase';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async () => {
        const { user, session, error } = await supabase.auth.signInWithPassword({ email, password });

        if (error) {
            console.error("❌ Errore durante il login:", error);
            setError(error.message);
            return;
        }

        if (session) {
            console.log("✅ Login riuscito:", user);
            navigate('/dashboard'); // Reindirizza alla dashboard
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            {error && <p className="error">{error}</p>}
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
            <button onClick={handleLogin}>Accedi</button>
        </div>
    );
};

export default Login;
