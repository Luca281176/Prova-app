
import { Layout } from "@/components/ui/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import EmailTemplate from "@/components/marketing/EmailTemplate";
import SocialMediaPosts from "@/components/marketing/SocialMediaPosts";
import QuickGuide from "@/components/marketing/QuickGuide";
import CustomerSupport from "@/components/marketing/CustomerSupport";
import { 
  RocketIcon, 
  MailIcon, 
  Share2Icon, 
  BookOpenIcon, 
  HelpCircleIcon 
} from "lucide-react";

const Marketing = () => {
  return (
    <Layout>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <RocketIcon className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Strategia di Lancio</h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-8">
          <div className="col-span-1 md:col-span-2 space-y-4">
            <h2 className="text-xl font-semibold">RistoBar Manager 4.0</h2>
            <p className="text-muted-foreground">
              La strategia di lancio per RistoBar Manager 4.0 include una pagina "Coming Soon", 
              una campagna email marketing, post sui social media, una guida rapida per i ristoratori 
              e un sistema di supporto clienti completo.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm">
                  ✓
                </div>
                <span>Pagina Coming Soon con timer</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm">
                  ✓
                </div>
                <span>Campagna email marketing</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm">
                  ✓
                </div>
                <span>Post sui social media</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm">
                  ✓
                </div>
                <span>Guida rapida per ristoratori</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm">
                  ✓
                </div>
                <span>Sistema di supporto clienti</span>
              </div>
            </div>
            <div className="pt-4">
              <Button asChild className="w-full">
                <a href="/coming-soon">
                  Visualizza Pagina Coming Soon
                </a>
              </Button>
            </div>
          </div>
          
          <div className="col-span-1 md:col-span-3">
            <div className="rounded-lg overflow-hidden border">
              <img 
                src="https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?auto=format&fit=crop&q=80&w=800&ixlib=rb-4.0.3" 
                alt="RistoBar Manager" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">
                  Lancio Previsto: 30 Aprile 2024
                </h3>
                <p className="text-muted-foreground mb-4">
                  Tutti i materiali di marketing sono pronti per il lancio. La campagna inizierà con la pubblicazione
                  della pagina "Coming Soon" e proseguirà con email marketing, post sui social media e attivazione
                  del supporto clienti.
                </p>
                <div className="flex flex-wrap gap-3">
                  <Button variant="outline" className="gap-2">
                    <Share2Icon className="h-4 w-4" />
                    Condividi
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <MailIcon className="h-4 w-4" />
                    Invia Email
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <Tabs defaultValue="email" className="mt-12">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="email" className="flex items-center gap-2">
              <MailIcon className="h-4 w-4" /> Email Marketing
            </TabsTrigger>
            <TabsTrigger value="social" className="flex items-center gap-2">
              <Share2Icon className="h-4 w-4" /> Social Media
            </TabsTrigger>
            <TabsTrigger value="guide" className="flex items-center gap-2">
              <BookOpenIcon className="h-4 w-4" /> Guida Rapida
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center gap-2">
              <HelpCircleIcon className="h-4 w-4" /> Supporto Clienti
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="email">
            <EmailTemplate />
          </TabsContent>
          
          <TabsContent value="social">
            <SocialMediaPosts />
          </TabsContent>
          
          <TabsContent value="guide">
            <QuickGuide />
          </TabsContent>
          
          <TabsContent value="support">
            <CustomerSupport />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Marketing;
