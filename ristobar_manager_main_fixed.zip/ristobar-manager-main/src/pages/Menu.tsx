
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PlusIcon } from 'lucide-react';
import MenuCategoriesList from '@/components/menu/MenuCategoriesList';
import MenuSettings from '@/components/menu/MenuSettings';
import AddCategoryDialog from '@/components/menu/AddCategoryDialog';
import { loadMenuData } from '@/services/menuService';
import { useUser } from '@/contexts/user';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription } from '@/services/subscriptions/types';
import DigitalMenuManager from '@/components/menu/DigitalMenuManager';

const Menu = () => {
  const [showAddCategoryDialog, setShowAddCategoryDialog] = useState(false);
  const { user } = useUser();
  const [isLoading, setIsLoading] = useState(true);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [activeTab, setActiveTab] = useState("categories");

  // Precaricamento dei dati
  useEffect(() => {
    const loadData = async () => {
      // Carica i dati del menu
      loadMenuData();
      
      // Carica i dati dell'abbonamento se l'utente è autenticato
      if (user?.id) {
        try {
          const subscription = await getUserSubscription(user.id);
          setUserSubscription(subscription);
        } catch (error) {
          console.error("Error fetching subscription:", error);
        }
      }
      
      setIsLoading(false);
    };
    
    loadData();
    
    // Attiva l'ascolto per sincronizzazioni tra tabs
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'risto_menu_data') {
        // Forza l'aggiornamento dei componenti figli
        window.dispatchEvent(new CustomEvent('menu-data-updated'));
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [user?.id]);

  if (isLoading) {
    return (
      <AuthLayout>
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AuthLayout>
    );
  }

  // Assicura che il digital menu sia sempre renderizzato, anche se l'utente non ha un abbonamento
  const handleTabClick = (value: string) => {
    setActiveTab(value);
    console.log("Tab changed to:", value);
  };

  return (
    <AuthLayout>
      <div className="mt-6 mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Menu</h1>
          <p className="text-muted-foreground">Gestisci il menu del tuo ristorante</p>
        </div>
        <Button onClick={() => setShowAddCategoryDialog(true)} className="w-full md:w-auto">
          <PlusIcon className="h-4 w-4 mr-2" />
          Aggiungi Categoria
        </Button>
      </div>

      <Tabs defaultValue="categories" value={activeTab} onValueChange={handleTabClick} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="categories">Categorie e Piatti</TabsTrigger>
          <TabsTrigger value="digital">Menu Digitale</TabsTrigger>
          <TabsTrigger value="settings">Impostazioni</TabsTrigger>
        </TabsList>
        
        <TabsContent value="categories" className="space-y-4">
          <MenuCategoriesList />
        </TabsContent>
        
        <TabsContent value="digital">
          <DigitalMenuManager userSubscription={userSubscription} />
        </TabsContent>
        
        <TabsContent value="settings">
          <MenuSettings userSubscription={userSubscription} />
        </TabsContent>
      </Tabs>

      {showAddCategoryDialog && (
        <AddCategoryDialog 
          open={showAddCategoryDialog} 
          onOpenChange={setShowAddCategoryDialog} 
        />
      )}
    </AuthLayout>
  );
};

export default Menu;
