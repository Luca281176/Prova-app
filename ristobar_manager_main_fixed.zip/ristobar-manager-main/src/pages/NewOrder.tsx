
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import AuthLayout from '@/components/AuthLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, PrinterIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { addOrder, Order } from '@/services/ordersService';
import { loadMenuData, Category, Dish } from '@/services/menuService';
import { useStaff } from '@/contexts/StaffContext';
import { updateTableStatus } from '@/services/roomsService';
import { StaffProvider } from '@/contexts/StaffContext';

const PRIORITIES = [
  { value: '1', label: '1° uscita' },
  { value: '2', label: '2° uscita' },
  { value: '3', label: '3° uscita' },
  { value: '4', label: '4° uscita' },
  { value: '5', label: '5° uscita' },
];

interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  notes: string;
  priority?: string;
}

const NewOrderContent = () => {
  const [searchParams] = useSearchParams();
  const tableId = searchParams.get('tableId');
  const tableName = searchParams.get('tableName');
  const navigate = useNavigate();
  const { toast } = useToast();
  const { staff, loading: staffLoading } = useStaff();

  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<string>('');
  const [itemNotes, setItemNotes] = useState<string>('');
  const [itemPriority, setItemPriority] = useState<string>('');
  const [operatorId, setOperatorId] = useState<string>('');
  const [operatorName, setOperatorName] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [menuLoading, setMenuLoading] = useState<boolean>(true);

  const operators = staff.map(member => ({
    id: member.id,
    name: `${member.firstName} ${member.lastName}`,
    role: member.role
  }));

  useEffect(() => {
    const loadMenu = () => {
      try {
        const menuData = loadMenuData();
        setCategories(menuData);
        
        if (menuData.length > 0) {
          setSelectedCategory(menuData[0].id);
          setDishes(menuData[0].dishes);
        }
      } catch (error) {
        console.error('Errore nel caricamento del menu:', error);
        toast({
          title: "Errore",
          description: "Impossibile caricare il menu",
          variant: "destructive"
        });
      } finally {
        setMenuLoading(false);
      }
    };
    
    loadMenu();
    
    const handleMenuDataUpdated = () => loadMenu();
    window.addEventListener('menu-data-updated', handleMenuDataUpdated);
    
    return () => {
      window.removeEventListener('menu-data-updated', handleMenuDataUpdated);
    };
  }, [toast]);

  useEffect(() => {
    if (selectedCategory) {
      const category = categories.find(c => c.id === selectedCategory);
      if (category) {
        setDishes(category.dishes);
        setSelectedItemId('');
      }
    }
  }, [selectedCategory, categories]);

  const goBack = () => {
    navigate(`/orders?tableId=${tableId}&tableName=${tableName}`);
  };

  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const handleAddItem = () => {
    if (!selectedItemId) return;
    
    const dish = dishes.find(item => item.id === selectedItemId);
    if (!dish || !dish.available) return;
    
    const existingItemIndex = orderItems.findIndex(item => 
      item.menuItemId === selectedItemId && item.priority === itemPriority
    );
    
    if (existingItemIndex >= 0) {
      const updatedItems = [...orderItems];
      updatedItems[existingItemIndex].quantity += 1;
      
      if (itemNotes) {
        updatedItems[existingItemIndex].notes = itemNotes;
      }
      
      setOrderItems(updatedItems);
    } else {
      setOrderItems([
        ...orderItems,
        {
          menuItemId: dish.id,
          name: dish.name,
          price: dish.price,
          quantity: 1,
          notes: itemNotes,
          priority: itemPriority
        }
      ]);
    }
    
    setItemNotes('');
  };

  const handleChangeQuantity = (index: number, change: number) => {
    const updatedItems = [...orderItems];
    const newQuantity = updatedItems[index].quantity + change;
    
    if (newQuantity <= 0) {
      updatedItems.splice(index, 1);
    } else {
      updatedItems[index].quantity = newQuantity;
    }
    
    setOrderItems(updatedItems);
  };

  const handleRemoveItem = (index: number) => {
    const updatedItems = [...orderItems];
    updatedItems.splice(index, 1);
    setOrderItems(updatedItems);
  };

  const handlePrintReceipt = (orderId: string, items: OrderItem[], tableName: string, operatorName: string) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Errore di stampa",
        description: "Non è stato possibile aprire la finestra di stampa. Controllare le impostazioni del browser.",
        variant: "destructive",
      });
      return;
    }
    
    const now = new Date();
    const dateFormatted = now.toLocaleDateString('it-IT');
    const timeFormatted = now.toLocaleTimeString('it-IT');
    
    const groupedItems = items.reduce((acc, item) => {
      const priority = item.priority || 'non-specificato';
      if (!acc[priority]) {
        acc[priority] = [];
      }
      acc[priority].push(item);
      return acc;
    }, {} as Record<string, OrderItem[]>);
    
    const sortedPriorities = Object.keys(groupedItems).sort((a, b) => {
      if (a === 'non-specificato') return 1;
      if (b === 'non-specificato') return -1;
      return parseInt(a) - parseInt(b);
    });
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Comanda #${orderId.substring(0, 6)}</title>
        <style>
          body {
            font-family: 'Courier New', monospace;
            width: 300px;
            margin: 0 auto;
            padding: 10px;
          }
          .header, .footer {
            text-align: center;
            margin-bottom: 10px;
          }
          .divider {
            border-top: 1px dashed #000;
            margin: 10px 0;
          }
          .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
          }
          .notes {
            font-style: italic;
            font-size: 0.9em;
            margin-left: 10px;
          }
          .priority-header {
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 5px;
            text-decoration: underline;
          }
          .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
          }
          @media print {
            body {
              width: 100%;
              max-width: 300px;
            }
            button {
              display: none;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h2>RISTORANTE</h2>
          <h3>COMANDA</h3>
        </div>
        
        <div class="info-row">
          <span>Data:</span>
          <span>${dateFormatted}</span>
        </div>
        <div class="info-row">
          <span>Ora:</span>
          <span>${timeFormatted}</span>
        </div>
        <div class="info-row">
          <span>Tavolo:</span>
          <span>${tableName}</span>
        </div>
        <div class="info-row">
          <span>Operatore:</span>
          <span>${operatorName}</span>
        </div>
        <div class="info-row">
          <span>Comanda:</span>
          <span>#${orderId.substring(0, 6)}</span>
        </div>
        
        <div class="divider"></div>
    `);
    
    sortedPriorities.forEach(priority => {
      const priorityLabel = priority === 'non-specificato' 
        ? 'NON SPECIFICATO' 
        : `${PRIORITIES.find(p => p.value === priority)?.label}`;
      
      printWindow.document.write(`
        <div class="priority-header">${priorityLabel}</div>
      `);
      
      groupedItems[priority].forEach(item => {
        printWindow.document.write(`
          <div class="item">
            <span>${item.quantity}x ${item.name}</span>
          </div>
        `);
        
        if (item.notes) {
          printWindow.document.write(`
            <div class="notes">→ ${item.notes}</div>
          `);
        }
      });
    });
    
    printWindow.document.write(`
        <div class="divider"></div>
        <div class="footer">
          <p>Comanda per cucina</p>
        </div>
        
        <div style="text-align: center; margin-top: 20px;">
          <button onclick="window.print();return false;">Stampa</button>
          <button onclick="window.close();return false;">Chiudi</button>
        </div>
      </body>
      </html>
    `);
    
    printWindow.document.close();
    
    printWindow.onload = function() {
      printWindow.focus();
      printWindow.print();
    };
  };

  const handleSubmitOrder = async () => {
    if (orderItems.length === 0) {
      toast({
        title: "Errore",
        description: "Aggiungi almeno un articolo all'ordine.",
        variant: "destructive",
      });
      return;
    }

    if (!operatorId) {
      toast({
        title: "Errore",
        description: "Seleziona un operatore per l'ordine.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      const operator = operators.find(op => op.id === operatorId);
      
      const orderData = {
        tableId: tableId || '',
        tableName: tableName || 'Tavolo sconosciuto',
        items: orderItems,
        total: calculateTotal(),
        timestamp: new Date().toISOString(),
        status: 'pending' as const,
        operatorName: operator?.name || 'Sconosciuto'
      };

      const savedOrder = await addOrder(orderData);
      
      console.log('Ordine salvato:', savedOrder);

      // Tentiamo di aggiornare lo stato del tavolo, ma non blocchiamo il processo se fallisce
      if (tableId) {
        try {
          await updateTableStatus(tableId, 'occupied');
        } catch (error) {
          console.log('Impossibile aggiornare lo stato del tavolo, ma l\'ordine è stato salvato:', error);
          // Non blocchiamo il flusso se l'aggiornamento del tavolo fallisce
        }
      }

      toast({
        title: "Ordine inviato",
        description: `Ordine #${savedOrder.id.substring(0, 6)} per il tavolo ${tableName} salvato con successo!`,
      });

      handlePrintReceipt(savedOrder.id, orderItems, tableName || 'Tavolo sconosciuto', operator?.name || 'Sconosciuto');

      navigate(`/orders?tableId=${tableId}&tableName=${tableName}`);
    } catch (error) {
      console.error('Errore durante il salvataggio dell\'ordine:', error);
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante il salvataggio dell'ordine. Riprova.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const groupedOrderItems = orderItems.reduce((acc, item) => {
    const priority = item.priority || 'non-specificato';
    if (!acc[priority]) {
      acc[priority] = [];
    }
    acc[priority].push(item);
    return acc;
  }, {} as Record<string, OrderItem[]>);

  const sortedPriorities = Object.keys(groupedOrderItems).sort((a, b) => {
    if (a === 'non-specificato') return 1;
    if (b === 'non-specificato') return -1;
    return parseInt(a) - parseInt(b);
  });

  return (
    <AuthLayout>
      <div className="space-y-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="space-y-1">
              <CardTitle className="text-2xl font-bold tracking-tight">
                {tableId && tableName 
                  ? `Nuovo ordine per il tavolo ${tableName}`
                  : 'Nuovo ordine'}
              </CardTitle>
              {tableId && (
                <div className="text-sm text-muted-foreground">
                  ID Tavolo: {tableId}
                </div>
              )}
            </div>
            <Button variant="outline" size="sm" onClick={goBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Torna agli ordini
            </Button>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="operator">Operatore</Label>
              
              {operators.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nessun operatore disponibile</p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {operators.map(op => (
                    <Button
                      key={op.id}
                      type="button"
                      onClick={() => {
                        setOperatorId(op.id);
                        setOperatorName(op.name);
                      }}
                      variant={operatorId === op.id ? "default" : "outline"}
                      className={`flex items-center justify-start gap-2 h-auto py-2 px-3 ${
                        operatorId === op.id ? "bg-primary text-primary-foreground" : ""
                      }`}
                    >
                      <div className="flex flex-col items-start text-left">
                        <span className="text-xs font-medium">{op.name}</span>
                        <span className="text-[10px] opacity-70">{op.role}</span>
                      </div>
                    </Button>
                  ))}
                </div>
              )}
            </div>

            <Tabs defaultValue="food" className="w-full">
              <TabsList>
                {categories.map(category => (
                  <TabsTrigger key={category.id} value={category.id} onClick={() => setSelectedCategory(category.id)}>
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {categories.map(category => (
                <TabsContent key={category.id} value={category.id} className="mt-4">
                  {category.dishes.length === 0 ? (
                    <div className="text-center py-8 border border-dashed rounded-lg">
                      <p className="text-muted-foreground mb-2">
                        Nessun elemento in questa categoria
                      </p>
                      <Button 
                        onClick={() => navigate('/menu')}
                        variant="outline"
                      >
                        Configura il menu
                      </Button>
                    </div>
                  ) : (
                    <div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {category.dishes.map(dish => (
                          <Button
                            key={dish.id}
                            variant="outline"
                            className={`h-auto py-2 px-3 justify-start ${!dish.available ? 'opacity-50' : ''}`}
                            disabled={!dish.available}
                            onClick={() => {
                              setSelectedItemId(dish.id);
                              const existingItem = orderItems.find(item => item.menuItemId === dish.id);
                              if (existingItem) {
                                const updatedItems = orderItems.map(item => 
                                  item.menuItemId === dish.id 
                                    ? { ...item, quantity: item.quantity + 1 } 
                                    : item
                                );
                                setOrderItems(updatedItems);
                              } else {
                                setOrderItems([
                                  ...orderItems,
                                  {
                                    menuItemId: dish.id,
                                    name: dish.name,
                                    price: dish.price,
                                    quantity: 1,
                                    notes: '',
                                  }
                                ]);
                              }
                            }}
                          >
                            <div className="flex flex-col items-start">
                              <span className="font-medium">{dish.name}</span>
                              <span className="text-xs text-muted-foreground">€{dish.price.toFixed(2)}</span>
                            </div>
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>

            {orderItems.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div>
                  <Label htmlFor="notes">Note</Label>
                  <Textarea
                    id="notes"
                    placeholder="Es. senza cipolla, ben cotto, ecc."
                    value={itemNotes}
                    onChange={(e) => setItemNotes(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="priority">Priorità di uscita</Label>
                  <Select value={itemPriority} onValueChange={setItemPriority}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleziona priorità" />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIORITIES.map(priority => (
                        <SelectItem key={priority.value} value={priority.value}>
                          {priority.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="border rounded-md p-4">
              <h3 className="font-medium mb-4">Riepilogo Ordine</h3>
              
              {orderItems.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  Nessun articolo aggiunto all'ordine
                </div>
              ) : (
                <ScrollArea className="h-[300px] pr-4">
                  {sortedPriorities.map(priority => (
                    <div key={priority} className="mb-4">
                      <div className="font-semibold text-sm text-muted-foreground mb-2">
                        {priority === 'non-specificato' ? 'Senza priorità' : `${PRIORITIES.find(p => p.value === priority)?.label}`}
                      </div>
                      
                      {groupedOrderItems[priority].map((item, indexInGroup) => {
                        const globalIndex = orderItems.findIndex(
                          oi => oi.menuItemId === item.menuItemId && 
                          oi.priority === item.priority && 
                          oi.notes === item.notes
                        );
                        
                        return (
                          <div key={`${item.menuItemId}-${indexInGroup}`} className="flex justify-between items-center mb-2 pb-2 border-b">
                            <div>
                              <div className="font-medium">{item.name}</div>
                              {item.notes && (
                                <div className="text-xs text-muted-foreground italic">
                                  Note: {item.notes}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Button 
                                variant="outline" 
                                size="icon" 
                                className="h-7 w-7"
                                onClick={() => handleChangeQuantity(globalIndex, -1)}
                              >
                                -
                              </Button>
                              <span className="w-6 text-center">{item.quantity}</span>
                              <Button 
                                variant="outline" 
                                size="icon" 
                                className="h-7 w-7"
                                onClick={() => handleChangeQuantity(globalIndex, 1)}
                              >
                                +
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 text-destructive"
                                onClick={() => handleRemoveItem(globalIndex)}
                              >
                                x
                              </Button>
                              <div className="ml-2 w-20 text-right">
                                €{(item.price * item.quantity).toFixed(2)}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ))}
                  
                  <div className="flex justify-between items-center font-medium pt-2 mt-2 border-t">
                    <span>Totale</span>
                    <span>€{calculateTotal().toFixed(2)}</span>
                  </div>
                </ScrollArea>
              )}
            </div>
          </CardContent>

          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={goBack}>Annulla</Button>
            <Button 
              onClick={handleSubmitOrder} 
              disabled={orderItems.length === 0 || !operatorId || isLoading}
            >
              <PrinterIcon className="mr-2 h-4 w-4" />
              {isLoading ? "Salvataggio..." : "Salva e Stampa"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </AuthLayout>
  );
};

const NewOrder = () => {
  return (
    <StaffProvider>
      <NewOrderContent />
    </StaffProvider>
  );
};

export default NewOrder;
