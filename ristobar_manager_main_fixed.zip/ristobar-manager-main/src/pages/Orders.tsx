
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AuthLayout from '@/components/AuthLayout';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ClipboardList } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { StaffProvider } from '@/contexts/StaffContext';
import { getOrdersForTable, getOrderById, Order } from '@/services/ordersService';
import TableOrderDialog from '@/components/tables/TableOrderDialog';
import { Table } from '@/components/RoomGrid';

const OrdersContent = () => {
  const [searchParams] = useSearchParams();
  const tableId = searchParams.get('tableId');
  const tableName = searchParams.get('tableName');
  const orderId = searchParams.get('orderId');
  const navigate = useNavigate();
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrders, setActiveOrders] = useState<Order[]>([]);
  const [completedOrders, setCompletedOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderDialog, setShowOrderDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Create a mock table object for the TableOrderDialog
  const mockTable: Table = tableId && tableName ? {
    id: tableId,
    name: tableName,
    seats: 4, // Default value since we don't have this info
    status: 'occupied',
    shape: 'square' // Default value since we don't have this info
  } : null;
  
  useEffect(() => {
    const loadOrders = async () => {
      setIsLoading(true);
      try {
        if (tableId) {
          const tableOrders = await getOrdersForTable(tableId);
          setOrders(tableOrders);
          setActiveOrders(tableOrders.filter(order => order.status === 'pending'));
          setCompletedOrders(tableOrders.filter(order => order.status !== 'pending'));
          
          // If orderId is specified, find and select that order
          if (orderId) {
            const order = await getOrderById(orderId);
            if (order) {
              setSelectedOrder(order);
              setShowOrderDialog(true);
            }
          }
        }
      } catch (error) {
        console.error("Error loading orders:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadOrders();
    
    // Listen for order updates
    const handleOrdersUpdated = () => {
      loadOrders();
    };
    
    window.addEventListener('orders-updated', handleOrdersUpdated);
    
    return () => {
      window.removeEventListener('orders-updated', handleOrdersUpdated);
    };
  }, [tableId, orderId]);
  
  const goBack = () => {
    navigate('/rooms');
  };

  const handleOrderClick = (order: Order) => {
    setSelectedOrder(order);
    setShowOrderDialog(true);
  };

  const handleOrderDialogClose = () => {
    setShowOrderDialog(false);
    setSelectedOrder(null);
    
    // Clear the orderId from URL when closing the dialog
    if (orderId) {
      navigate(`/orders?tableId=${tableId}&tableName=${tableName}`);
    }
  };

  const handleCreateNewOrder = () => {
    navigate(`/orders/new?tableId=${tableId}&tableName=${tableName}`);
  };

  const renderOrdersList = (ordersList: Order[]) => {
    if (ordersList.length === 0) {
      return (
        <div className="text-center py-8 border border-dashed rounded-lg">
          <p className="text-muted-foreground mb-2">
            Nessun ordine disponibile
          </p>
          {tableId && (
            <Button onClick={handleCreateNewOrder}>
              Crea nuovo ordine
            </Button>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {ordersList.map(order => (
          <div 
            key={order.id}
            className="p-4 border rounded-lg hover:bg-muted cursor-pointer transition-colors"
            onClick={() => handleOrderClick(order)}
          >
            <div className="flex justify-between items-center">
              <div>
                <div className="font-medium">Ordine #{order.id.substring(0, 8)}</div>
                <div className="text-sm text-muted-foreground">
                  {new Date(order.timestamp).toLocaleString()}
                </div>
                <div className="text-sm">
                  Operatore: {order.operatorName || 'Non specificato'}
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium">€{order.total.toFixed(2)}</div>
                <div className="text-sm">
                  {order.items.length} articoli
                </div>
                <div className={`text-xs py-1 px-2 rounded-full inline-block font-medium
                  ${order.status === 'pending' ? 'bg-blue-100 text-blue-800' : 
                    order.status === 'completed' ? 'bg-green-100 text-green-800' :
                      order.status === 'paid' ? 'bg-purple-100 text-purple-800' :
                        'bg-gray-100 text-gray-800'
                  }`}
                >
                  {order.status === 'pending' ? 'In corso' :
                    order.status === 'completed' ? 'Completato' :
                      order.status === 'paid' ? 'Pagato' : 'Annullato'}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <AuthLayout>
      <div className="space-y-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="space-y-1">
              <CardTitle className="text-2xl font-bold tracking-tight">
                {tableId && tableName 
                  ? `Ordini per il tavolo ${tableName}`
                  : 'Tutti gli ordini'}
              </CardTitle>
              {tableId && (
                <div className="text-sm text-muted-foreground">
                  ID Tavolo: {tableId}
                </div>
              )}
            </div>
            <Button variant="outline" size="sm" onClick={goBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Torna alle sale
            </Button>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active" className="w-full">
              <TabsList>
                <TabsTrigger value="active">Ordini attivi</TabsTrigger>
                <TabsTrigger value="completed">Ordini completati</TabsTrigger>
                <TabsTrigger value="all">Tutti gli ordini</TabsTrigger>
              </TabsList>
              <TabsContent value="active" className="mt-4">
                {isLoading ? (
                  <div className="text-center py-8">Caricamento...</div>
                ) : (
                  renderOrdersList(activeOrders)
                )}
              </TabsContent>
              <TabsContent value="completed" className="mt-4">
                {isLoading ? (
                  <div className="text-center py-8">Caricamento...</div>
                ) : (
                  renderOrdersList(completedOrders)
                )}
              </TabsContent>
              <TabsContent value="all" className="mt-4">
                {isLoading ? (
                  <div className="text-center py-8">Caricamento...</div>
                ) : (
                  renderOrdersList(orders)
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {selectedOrder && mockTable && (
        <TableOrderDialog
          table={mockTable}
          open={showOrderDialog}
          onOpenChange={handleOrderDialogClose}
          onSubmit={() => {}}
          existingOrder={selectedOrder}
        />
      )}
    </AuthLayout>
  );
};

const Orders = () => {
  return (
    <StaffProvider>
      <OrdersContent />
    </StaffProvider>
  );
};

export default Orders;
