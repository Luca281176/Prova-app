
import { useState } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { useUser } from '@/contexts/user';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { runStripePaymentSystemTests } from '@/utils/testPaymentSystem';
import { toast } from 'sonner';
import EmailTemplate from '@/components/marketing/EmailTemplate';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const PaymentSystemTest = () => {
  const { user } = useUser();
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testsCompleted, setTestsCompleted] = useState(false);
  
  const handleRunTests = async () => {
    if (!user || !user.id) {
      toast.error('Devi aver effettuato l\'accesso per eseguire i test');
      return;
    }
    
    setIsRunningTests(true);
    setTestsCompleted(false);
    
    try {
      await runStripePaymentSystemTests(user.id);
      setTestsCompleted(true);
    } catch (error) {
      console.error('Errore durante l\'esecuzione dei test:', error);
      toast.error('Si è verificato un errore durante l\'esecuzione dei test', {
        description: error.message
      });
    } finally {
      setIsRunningTests(false);
    }
  };
  
  return (
    <AuthLayout>
      <div className="max-w-4xl mx-auto py-8 animate-fade-up">
        <div className="mb-8">
          <h1 className="text-2xl font-bold tracking-tight">Test Sistema di Pagamenti</h1>
          <p className="text-muted-foreground">Verifica il corretto funzionamento del sistema di pagamenti Stripe</p>
        </div>
        
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Test Sistema Stripe</CardTitle>
              <CardDescription>
                Esegui una serie di test sul sistema di pagamenti per verificare che tutte le funzionalità siano correttamente configurate.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-accent/10 p-4 rounded-md">
                  <h3 className="font-medium mb-2">Test che verranno eseguiti:</h3>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Iscrizione a un piano di abbonamento (Starter, Pro, Ultimate)</li>
                    <li>Upgrade e downgrade tra i piani e verifica della gestione dei permessi</li>
                    <li>Simulazione di un pagamento fallito e verifica del blocco dell'accesso</li>
                    <li>Pagamento per un ordine e verifica dell'aggiornamento dello stato</li>
                    <li>Verifica che il webhook di Stripe aggiorni correttamente il database</li>
                    <li>Verifica che il cliente riceva un'email di conferma del pagamento</li>
                  </ul>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  <p><strong>Nota:</strong> Questi test eseguono delle simulazioni e non effettuano reali transazioni con Stripe.</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleRunTests} 
                disabled={isRunningTests}
                size="lg"
              >
                {isRunningTests ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Esecuzione test in corso...
                  </>
                ) : (
                  'Esegui Test'
                )}
              </Button>
            </CardFooter>
          </Card>
          
          {testsCompleted && (
            <Card className="border-green-200 bg-green-50 dark:bg-green-950/20">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <CardTitle>Test completati con successo!</CardTitle>
                </div>
                <CardDescription>
                  Tutti i test del sistema di pagamenti sono stati completati correttamente.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p>Il sistema di pagamenti Stripe è configurato correttamente e tutte le funzionalità sono operative:</p>
                  <ul className="space-y-1 list-disc list-inside text-green-700">
                    <li>Iscrizione a piani di abbonamento: ✅</li>
                    <li>Upgrade e downgrade tra piani: ✅</li>
                    <li>Gestione pagamenti falliti: ✅</li>
                    <li>Pagamenti per ordini: ✅</li>
                    <li>Webhook Stripe: ✅</li>
                    <li>Email di conferma: ✅</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}
          
          <div className="mt-8">
            <h2 className="text-xl font-semibold mb-4">Anteprima Email di Conferma</h2>
            <Tabs defaultValue="subscription-success">
              <TabsList className="mb-4">
                <TabsTrigger value="subscription-success">Abbonamento (Successo)</TabsTrigger>
                <TabsTrigger value="subscription-failed">Abbonamento (Fallito)</TabsTrigger>
                <TabsTrigger value="order">Conferma Ordine</TabsTrigger>
              </TabsList>
              
              <TabsContent value="subscription-success">
                <div className="border rounded-md p-4 bg-background">
                  <EmailTemplate 
                    recipientName="Mario Rossi"
                    planName="Pro"
                    planPrice="49.99"
                    paymentStatus="success"
                    isSubscriptionEmail={true}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="subscription-failed">
                <div className="border rounded-md p-4 bg-background">
                  <EmailTemplate 
                    recipientName="Mario Rossi"
                    planName="Pro"
                    planPrice="49.99"
                    paymentStatus="failed"
                    isSubscriptionEmail={true}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="order">
                <div className="border rounded-md p-4 bg-background">
                  <EmailTemplate 
                    recipientName="Mario Rossi"
                    orderNumber="1234"
                    planPrice="125.50"
                    isOrderConfirmation={true}
                  />
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AuthLayout>
  );
};

export default PaymentSystemTest;
