
import { useState, useEffect } from "react";
import AuthLayout from "@/components/AuthLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StaffList } from "@/components/staff/StaffList";
import { ShiftCalendar } from "@/components/staff/ShiftCalendar";
import { PerformanceStats } from "@/components/staff/PerformanceStats";
import { PermissionsManager } from "@/components/staff/PermissionsManager";
import { StaffProvider } from "@/contexts/StaffContext";
import { PlanFeatureAlert } from "@/components/dashboard/PlanFeatureAlert";
import { useUser } from "@/contexts/user";
import { getUserSubscription, hasSubscriptionLevel, FeatureAccessLevel } from "@/services/subscriptions";

export default function Personale() {
  const [activeTab, setActiveTab] = useState("staff");
  const { user } = useUser();
  const [accessLevels, setAccessLevels] = useState({
    shifts: false,
    performance: false
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setAccessLevels({ shifts: false, performance: false });
        setIsLoading(false);
        return;
      }
      
      const subscription = await getUserSubscription(user.id);
      const canAccessAdvancedFeatures = hasSubscriptionLevel(subscription, FeatureAccessLevel.PRO);
      
      setAccessLevels({
        shifts: canAccessAdvancedFeatures,
        performance: canAccessAdvancedFeatures
      });
      setIsLoading(false);
    };
    
    checkAccess();
  }, [user]);

  // Redirect to staff tab if user tries to access a restricted tab
  useEffect(() => {
    if (!isLoading) {
      if ((activeTab === "shifts" && !accessLevels.shifts) || 
          (activeTab === "performance" && !accessLevels.performance)) {
        setActiveTab("staff");
      }
    }
  }, [activeTab, accessLevels, isLoading]);

  const handleTabChange = (value) => {
    if ((value === "shifts" && !accessLevels.shifts) || 
        (value === "performance" && !accessLevels.performance)) {
      // Don't change tab if user doesn't have access
      return;
    }
    setActiveTab(value);
  };

  if (isLoading) {
    return (
      <AuthLayout>
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <StaffProvider>
        <div className="space-y-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Personale</h1>
            <p className="text-muted-foreground">
              Gestisci i tuoi dipendenti, assegna turni, configura permessi e monitora le performance
            </p>
          </div>
          
          <Tabs defaultValue="staff" value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid grid-cols-4 mb-8">
              <TabsTrigger value="staff">Dipendenti</TabsTrigger>
              <TabsTrigger value="permissions">Permessi</TabsTrigger>
              <TabsTrigger value="shifts" disabled={!accessLevels.shifts}>Turni</TabsTrigger>
              <TabsTrigger value="performance" disabled={!accessLevels.performance}>Performance</TabsTrigger>
            </TabsList>
            
            <TabsContent value="staff" className="space-y-6">
              <StaffList />
            </TabsContent>
            
            <TabsContent value="permissions" className="space-y-6">
              <PermissionsManager />
            </TabsContent>
            
            <TabsContent value="shifts" className="space-y-6">
              {accessLevels.shifts ? (
                <ShiftCalendar />
              ) : (
                <PlanFeatureAlert
                  title="Gestione turni non disponibile"
                  description="La gestione avanzata dei turni è una funzionalità disponibile solo per gli abbonamenti Pro e Ultimate."
                  availableInPlans={['Pro', 'Ultimate']}
                  buttonText="Aggiorna il tuo piano"
                  buttonLink="/subscriptions"
                />
              )}
            </TabsContent>
            
            <TabsContent value="performance" className="space-y-6">
              {accessLevels.performance ? (
                <PerformanceStats />
              ) : (
                <PlanFeatureAlert
                  title="Analisi performance non disponibile"
                  description="Le analisi avanzate delle performance del personale sono disponibili solo per gli abbonamenti Pro e Ultimate."
                  availableInPlans={['Pro', 'Ultimate']}
                  buttonText="Aggiorna il tuo piano"
                  buttonLink="/subscriptions"
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </StaffProvider>
    </AuthLayout>
  );
}
