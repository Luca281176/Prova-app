
import React, { useState, useEffect } from 'react';
import { useUser } from '@/contexts/user/UserProvider';
import { getUserData } from '@/contexts/user/storageUtils';

const Profile = () => {
  const { user } = useUser();
  const [restaurantInfo, setRestaurantInfo] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (user?.id) {
        try {
          const info = await getUserData(user.id, 'restaurantInfo', {});
          setRestaurantInfo(info);
        } catch (error) {
          console.error("Error loading restaurant info:", error);
        } finally {
          setIsLoading(false);
        }
      }
    };

    loadData();
  }, [user?.id]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      {/* Assuming the profile component displays restaurant info */}
      <h1>Profile</h1>
      {restaurantInfo && (
        <div>
          <p>Address: {restaurantInfo.address || 'Not set'}</p>
          <p>Phone: {restaurantInfo.phone || 'Not set'}</p>
          <p>VAT ID: {restaurantInfo.vat || 'Not set'}</p>
        </div>
      )}
    </div>
  );
};

export default Profile;
