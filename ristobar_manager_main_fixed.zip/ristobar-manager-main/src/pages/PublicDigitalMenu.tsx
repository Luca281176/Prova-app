
import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  loadDigitalMenuData, 
  getDigitalMenuRestaurantInfo, 
  setupMenuSettingsSync 
} from '@/services/digitalMenuService';
import { Category, Dish, loadMenuSettings } from '@/services/menuService';
import { AlertCircle, Phone, MapPin, Clock, Mail, Globe, CreditCard } from 'lucide-react';
import { DataSyncWorker } from '@/contexts/user/storage/DataSyncWorker';

const PublicDigitalMenu = () => {
  const { slug } = useParams<{ slug: string }>();
  const [searchParams] = useSearchParams();
  const userId = searchParams.get('id');
  
  const [menuData, setMenuData] = useState<Category[]>([]);
  const [restaurantInfo, setRestaurantInfo] = useState<any>({});
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [customSettings, setCustomSettings] = useState<any>({});

  useEffect(() => {
    const loadMenu = async () => {
      try {
        setIsLoading(true);
        
        // Load menu settings first to get customization settings
        const settings = loadMenuSettings();
        console.log("Loaded menu settings:", settings);
        
        if (settings.customization) {
          console.log("Loaded customization settings in public menu:", settings.customization);
          setCustomSettings(settings.customization);
        } else {
          console.log("No customization settings found in public menu");
        }
        
        // Then load menu data and restaurant info
        const menuData = loadDigitalMenuData();
        const restaurantInfo = getDigitalMenuRestaurantInfo();
        
        console.log("Loaded restaurant info:", restaurantInfo);
        
        setMenuData(menuData);
        setRestaurantInfo(restaurantInfo);
        
        if (menuData.length > 0) {
          setActiveCategory(menuData[0].id);
        }
      } catch (err) {
        console.error("Failed to load digital menu:", err);
        setError("Impossibile caricare il menu. Riprova più tardi.");
      } finally {
        setIsLoading(false);
      }
    };

    loadMenu();
    
    // Setup real-time sync for menu settings changes
    let cleanup: (() => void) | null = null;
    
    if (userId) {
      console.log("Setting up menu settings sync for user:", userId);
      
      cleanup = setupMenuSettingsSync(userId, (updatedSettings) => {
        console.log("Menu settings updated from sync:", updatedSettings);
        
        if (updatedSettings.customization) {
          setCustomSettings(updatedSettings.customization);
          
          // Reload menu data and restaurant info to apply new settings
          const menuData = loadDigitalMenuData();
          const restaurantInfo = getDigitalMenuRestaurantInfo();
          
          setMenuData(menuData);
          setRestaurantInfo(restaurantInfo);
          
          console.log("Reloaded menu data and restaurant info after settings update");
        }
      });
    }
    
    // Listen for storage changes to update menu data when settings change
    const handleStorageChange = () => {
      console.log("Storage change detected, reloading menu data");
      loadMenu();
    };
    
    window.addEventListener('menu-settings-updated', handleStorageChange);
    
    return () => {
      if (cleanup) cleanup();
      window.removeEventListener('menu-settings-updated', handleStorageChange);
    };
  }, [userId, slug]);

  // Force refresh when switching to this page
  useEffect(() => {
    // Attempt to sync with server if userId is available
    if (userId) {
      console.log("Attempting to sync menu data from server for user:", userId);
      
      // Force refresh from server if possible
      try {
        const syncWorker = DataSyncWorker.getInstance();
        syncWorker.forceSyncNow().then((success) => {
          if (success) {
            console.log("Successfully synced data from server");
          } else {
            console.log("Failed to sync data from server");
          }
        });
      } catch (error) {
        console.warn("Error syncing with server:", error);
      }
    }
  }, [userId]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
        <p className="text-muted-foreground">Caricamento menu in corso...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <AlertCircle className="h-12 w-12 text-destructive mb-4" />
        <h2 className="text-xl font-semibold mb-2">Menu non disponibile</h2>
        <p className="text-muted-foreground text-center">{error}</p>
      </div>
    );
  }

  // Custom styles from settings
  const customStyles = {
    '--primary-color': restaurantInfo.primaryColor || customSettings.primaryColor || '#6e59a5',
    '--accent-color': restaurantInfo.accentColor || customSettings.accentColor || '#d6bcfa'
  } as React.CSSProperties;
  
  // Use custom text or fallback to restaurant info
  const displayTitle = restaurantInfo.name || "Menu Digitale";
  const displayAddress = restaurantInfo.address || "";
  const displayPhone = restaurantInfo.phone || "";
  const displayEmail = restaurantInfo.email || "";
  const displayWebsite = restaurantInfo.website || "";
  const displayVat = restaurantInfo.vat || "";
  const displayDescription = restaurantInfo.description || "";
  const displayOpeningHours = restaurantInfo.openingHours || "";
  
  // Visibility settings
  const headerVisibility = restaurantInfo.headerVisibility || {};
  const visibility = restaurantInfo.visibility || {};
  
  const showLogo = restaurantInfo.showLogo !== false;
  
  const showAddress = headerVisibility.address !== false;
  const showPhone = headerVisibility.phone !== false;
  const showEmail = headerVisibility.email !== false;
  const showWebsite = headerVisibility.website !== false;
  const showVat = headerVisibility.vat !== false;
  const showDescription = headerVisibility.description !== false;
  const showOpeningHours = headerVisibility.openingHours !== false;
  
  const showPrices = visibility.prices !== false;
  const showDescriptions = visibility.descriptions !== false;
  const showAllergens = visibility.allergens !== false;
  
  // Check if a dish should be displayed based on availability settings
  const shouldShowDish = (dish: Dish) => {
    if (!dish.available && visibility.unavailable !== true) {
      return false;
    }
    return dish.visible !== false; // Only show dishes explicitly marked as visible
  };

  console.log("Rendering public menu with settings:", {
    customStyles,
    displayTitle,
    showPrices,
    showDescriptions,
    showAllergens,
    restaurantInfo
  });

  return (
    <div className="flex flex-col min-h-screen bg-muted/30" style={customStyles}>
      <header className="bg-primary text-primary-foreground py-4 px-4 md:px-6 shadow-md">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center">
              {showLogo && restaurantInfo.logo && (
                <img 
                  src={restaurantInfo.logo} 
                  alt={restaurantInfo.name} 
                  className="h-12 w-auto object-contain mr-3"
                />
              )}
              <div>
                <h1 className="text-xl font-bold">
                  {displayTitle}
                </h1>
                {showDescription && displayDescription && (
                  <p className="text-sm opacity-90 mt-1">{displayDescription}</p>
                )}
              </div>
            </div>
          </div>
          
          <div className="mt-2 pt-2 border-t border-primary-foreground/20">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm opacity-90">
              {showAddress && displayAddress && (
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{displayAddress}</span>
                </div>
              )}
              {showPhone && displayPhone && (
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-1" />
                  <span>{displayPhone}</span>
                </div>
              )}
              {showEmail && displayEmail && (
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-1" />
                  <span>{displayEmail}</span>
                </div>
              )}
              {showWebsite && displayWebsite && (
                <div className="flex items-center">
                  <Globe className="h-4 w-4 mr-1" />
                  <span>{displayWebsite}</span>
                </div>
              )}
              {showVat && displayVat && (
                <div className="flex items-center">
                  <CreditCard className="h-4 w-4 mr-1" />
                  <span>{displayVat}</span>
                </div>
              )}
              {showOpeningHours && displayOpeningHours && (
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{displayOpeningHours}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 flex-1">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Il Nostro Menu</h1>
          {showDescription && displayDescription && (
            <p className="text-muted-foreground">{displayDescription}</p>
          )}
        </div>

        {menuData.length === 0 ? (
          <Card className="text-center p-8">
            <CardContent>
              <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">Menu non disponibile</h2>
              <p className="text-muted-foreground">Il menu non è attualmente disponibile. Riprova più tardi.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-6">
            <div className="overflow-hidden">
              <div className="md:sticky md:top-6 p-4 bg-background shadow rounded-lg">
                <h2 className="font-medium mb-4">Categorie</h2>
                <nav className="space-y-1">
                  {menuData.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                        activeCategory === category.id
                          ? "bg-primary text-primary-foreground"
                          : "hover:bg-muted"
                      }`}
                    >
                      {category.name}
                      <span className="ml-2 text-xs font-medium rounded-full px-1.5 py-0.5 bg-muted-foreground/20">
                        {category.dishes.filter(shouldShowDish).length}
                      </span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            <div className="space-y-6">
              {menuData
                .filter((category) => category.id === activeCategory)
                .map((category) => {
                  const visibleDishes = category.dishes.filter(shouldShowDish);
                  return (
                    <div key={category.id}>
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-bold">{category.name}</h2>
                        <Badge variant="outline">{visibleDishes.length} piatti</Badge>
                      </div>

                      <div className="grid grid-cols-1 gap-4">
                        {visibleDishes.map((dish) => (
                          <Card key={dish.id} className="overflow-hidden">
                            <div className="flex flex-col md:flex-row">
                              {dish.image && (
                                <div className="w-full md:w-1/4">
                                  <img
                                    src={dish.image}
                                    alt={dish.name}
                                    className="h-48 md:h-full w-full object-cover"
                                  />
                                </div>
                              )}
                              <div className={`flex-1 p-4 ${dish.image ? '' : 'md:pl-4'}`}>
                                <div className="flex justify-between items-start mb-2">
                                  <h3 className="text-lg font-semibold">{dish.name}</h3>
                                  {showPrices && (
                                    <span className="font-bold">€{dish.price.toFixed(2)}</span>
                                  )}
                                </div>
                                {showDescriptions && dish.description && (
                                  <p className="text-muted-foreground mb-3">{dish.description}</p>
                                )}
                                {showAllergens && dish.allergies && dish.allergies.length > 0 && (
                                  <div className="w-full">
                                    <p className="text-xs text-muted-foreground mt-2">
                                      <span className="font-semibold">Allergeni:</span>{" "}
                                      {dish.allergies.join(", ")}
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}
      </main>

      <footer className="bg-muted py-6 px-4 mt-auto">
        <div className="container mx-auto">
          <Separator className="mb-6" />
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="font-semibold">{displayTitle}</h3>
              {showAddress && displayAddress && (
                <p className="text-sm text-muted-foreground">{displayAddress}</p>
              )}
              {showPhone && displayPhone && (
                <p className="text-sm text-muted-foreground">{displayPhone}</p>
              )}
              {showEmail && displayEmail && (
                <p className="text-sm text-muted-foreground">{displayEmail}</p>
              )}
              {showVat && displayVat && (
                <p className="text-sm text-muted-foreground">{displayVat}</p>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} {displayTitle} - Tutti i diritti riservati
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PublicDigitalMenu;
