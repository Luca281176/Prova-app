
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { UserIcon, MailIcon, LockIcon, EyeIcon, EyeOffIcon, BuildingIcon, AlertCircleIcon } from 'lucide-react';
import { useUser } from '@/contexts/user/UserProvider';
import { toast } from 'sonner';
import AuthService from '@/services/authService';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [restaurantName, setRestaurantName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [passwordFeedback, setPasswordFeedback] = useState('');
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const { register, isLoading, loginWithGoogle } = useUser();
  const navigate = useNavigate();

  useEffect(() => {
    AuthService.clearAllUserData();
  }, []);

  useEffect(() => {
    if (!password) {
      setPasswordStrength(0);
      setPasswordFeedback('');
      return;
    }

    let strength = 0;
    let feedback = '';

    if (password.length >= 8) {
      strength += 25;
    } else {
      feedback = 'La password deve contenere almeno 8 caratteri';
      setPasswordStrength(strength);
      setPasswordFeedback(feedback);
      return;
    }

    if (/[A-Z]/.test(password)) {
      strength += 25;
    } else {
      feedback = 'Aggiungi almeno una lettera maiuscola';
      setPasswordStrength(strength);
      setPasswordFeedback(feedback);
      return;
    }

    if (/[0-9]/.test(password)) {
      strength += 25;
    } else {
      feedback = 'Aggiungi almeno un numero';
      setPasswordStrength(strength);
      setPasswordFeedback(feedback);
      return;
    }

    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      strength += 25;
    } else {
      feedback = 'Aggiungi almeno un carattere speciale (!@#$%^&*.,?)';
      setPasswordStrength(strength);
      setPasswordFeedback(feedback);
      return;
    }

    const commonPasswords = ['password', 'password123', '123456', 'qwerty', 'admin', 'welcome'];
    if (commonPasswords.includes(password.toLowerCase())) {
      strength = 25;
      feedback = 'Password troppo comune, scegli una password più sicura';
    } else if (strength === 100) {
      feedback = 'Password molto sicura!';
    }

    setPasswordStrength(strength);
    setPasswordFeedback(feedback);
  }, [password]);

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 25) return 'bg-red-500';
    if (passwordStrength < 50) return 'bg-orange-500';
    if (passwordStrength < 75) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSubmitting) return;
    setIsSubmitting(true);
    setErrorMessage(null);
    
    if (password !== confirmPassword) {
      setErrorMessage("Le password non corrispondono");
      setIsSubmitting(false);
      return;
    }
    
    if (!acceptTerms) {
      setErrorMessage("Devi accettare i termini di servizio");
      setIsSubmitting(false);
      return;
    }

    if (passwordStrength < 100) {
      setErrorMessage(passwordFeedback || "La password non è abbastanza sicura");
      setIsSubmitting(false);
      return;
    }
    
    try {
      AuthService.clearAllUserData();
      
      console.log("Inizio registrazione con:", { name, email, restaurantName });
      
      const result = await register(name, email, password, restaurantName);
      if (result) {
        console.log("User registered:", result.name);
        console.log("Subscription plan:", result.subscription?.planId);
        console.log("Subscription type:", typeof result.subscription?.planId);
        console.log("Full subscription:", result.subscription);
        
        // Instead of redirecting, show the success message
        setRegistrationSuccess(true);
        setUserEmail(email);
        toast.success("Account creato con successo! Controlla la tua email per confermare la registrazione.");
      } else {
        setErrorMessage("Non è stato possibile completare la registrazione. Riprova più tardi.");
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error("Registration failed:", error);
      setErrorMessage(error instanceof Error ? error.message : "Non è stato possibile completare la registrazione. Riprova più tardi.");
      setIsSubmitting(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setErrorMessage(null);
    
    try {
      AuthService.clearAllUserData();
      
      console.log("Tentativo di login con Google");
      
      await loginWithGoogle();
      
      // Don't try to evaluate the result of loginWithGoogle as it returns void
      // Instead, rely on the navigation happening inside the loginWithGoogle function
      console.log("Login con Google completato");
      
      // No need to navigate here as it's handled in the loginWithGoogle function
    } catch (error) {
      console.error("Google login failed:", error);
      setErrorMessage(error instanceof Error ? error.message : "Non è stato possibile completare il login con Google. Riprova più tardi o usa email e password.");
      setIsSubmitting(false);
    }
  };

  // If registration is successful, show a confirmation page
  if (registrationSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background py-12 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 overflow-hidden">
          <div className="landing-gradient absolute -top-40 -right-40 w-[600px] h-[600px]"></div>
          <div className="landing-gradient absolute -bottom-40 -left-40 w-[600px] h-[600px]"></div>
        </div>
        
        <div className="max-w-md w-full space-y-8 glass-panel p-8 rounded-xl shadow-xl z-10 animate-scale-in">
          <div className="text-center">
            <Link to="/" className="inline-block">
              <span className="text-2xl font-semibold tracking-tight">
                Risto<span className="text-primary">Bar</span>
              </span>
            </Link>
            <h2 className="mt-6 text-2xl font-bold">Controlla la tua email</h2>
            <div className="mt-8 mb-8 p-4 bg-green-50 text-green-800 rounded-lg">
              <p className="text-lg font-medium">Ti abbiamo inviato un'email di conferma a:</p>
              <p className="text-lg font-bold mt-2">{userEmail}</p>
              <p className="mt-4">Per completare la registrazione e accedere alla tua prova gratuita, clicca sul link nell'email.</p>
            </div>
            
            <div className="mt-6">
              <p className="text-sm text-muted-foreground">Non hai ricevuto l'email? Controlla la cartella spam o</p>
              <Button 
                variant="outline" 
                className="mt-2" 
                onClick={() => {
                  // Add resend email logic here if needed
                  toast.success("Email di conferma inviata nuovamente");
                }}
              >
                Invia di nuovo
              </Button>
            </div>
            
            <div className="mt-8 pt-6 border-t border-border">
              <p className="text-sm text-muted-foreground">
                Hai già un account?{' '}
                <Link to="/login" className="text-primary hover:text-primary/80 hover:underline">
                  Accedi
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 overflow-hidden">
        <div className="landing-gradient absolute -top-40 -right-40 w-[600px] h-[600px]"></div>
        <div className="landing-gradient absolute -bottom-40 -left-40 w-[600px] h-[600px]"></div>
      </div>
      
      <div className="max-w-md w-full space-y-8 glass-panel p-8 rounded-xl shadow-xl z-10 animate-scale-in">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <span className="text-2xl font-semibold tracking-tight">
              Risto<span className="text-primary">Bar</span>
            </span>
          </Link>
          <h2 className="mt-6 text-2xl font-bold">Crea il tuo account</h2>
          <p className="mt-2 text-sm text-foreground/70">
            O{' '}
            <Link to="/login" className="text-primary hover:text-primary/80 hover:underline">
              accedi se hai già un account
            </Link>
          </p>
        </div>

        {errorMessage && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircleIcon className="h-4 w-4" />
            <AlertTitle>Errore</AlertTitle>
            <AlertDescription>{errorMessage}</AlertDescription>
          </Alert>
        )}
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="relative">
              <Label htmlFor="name" className="sr-only">
                Nome completo
              </Label>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <UserIcon className="h-5 w-5 text-foreground/40" />
              </div>
              <Input
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="block w-full pl-10 rounded-md"
                placeholder="Nome completo"
              />
            </div>
            
            <div className="relative">
              <Label htmlFor="email" className="sr-only">
                Email
              </Label>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MailIcon className="h-5 w-5 text-foreground/40" />
              </div>
              <Input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 rounded-md"
                placeholder="Email"
              />
            </div>
            
            <div className="relative">
              <Label htmlFor="restaurant" className="sr-only">
                Nome del ristorante
              </Label>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <BuildingIcon className="h-5 w-5 text-foreground/40" />
              </div>
              <Input
                id="restaurant"
                name="restaurant"
                type="text"
                required
                value={restaurantName}
                onChange={(e) => setRestaurantName(e.target.value)}
                className="block w-full pl-10 rounded-md"
                placeholder="Nome del ristorante"
              />
            </div>
            
            <div className="space-y-2">
              <div className="relative">
                <Label htmlFor="password" className="sr-only">
                  Password
                </Label>
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <LockIcon className="h-5 w-5 text-foreground/40" />
                </div>
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-10 rounded-md"
                  placeholder="Password"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-foreground/40 hover:text-foreground/70 focus:outline-none"
                  >
                    {showPassword ? (
                      <EyeOffIcon className="h-5 w-5" />
                    ) : (
                      <EyeIcon className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>

              {password && (
                <div className="space-y-1">
                  <Progress value={passwordStrength} className={getPasswordStrengthColor()} />
                  <p className="text-xs text-foreground/70">{passwordFeedback}</p>
                </div>
              )}
            </div>
            
            <div className="relative">
              <Label htmlFor="confirm-password" className="sr-only">
                Conferma Password
              </Label>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <LockIcon className="h-5 w-5 text-foreground/40" />
              </div>
              <Input
                id="confirm-password"
                name="confirm-password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="new-password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="block w-full pl-10 rounded-md"
                placeholder="Conferma Password"
              />
            </div>
          </div>

          <div className="flex items-start">
            <div className="flex items-center h-5">
              <Checkbox 
                id="terms" 
                checked={acceptTerms}
                onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                required
              />
            </div>
            <div className="ml-3 text-sm">
              <Label
                htmlFor="terms"
                className="text-foreground/80"
              >
                Accetto i{' '}
                <a
                  href="#"
                  className="text-primary hover:text-primary/80 hover:underline"
                >
                  Termini di Servizio
                </a>{' '}
                e la{' '}
                <a
                  href="#"
                  className="text-primary hover:text-primary/80 hover:underline"
                >
                  Privacy Policy
                </a>
              </Label>
            </div>
          </div>

          <div>
            <Button
              type="submit"
              className="w-full"
              disabled={
                isSubmitting || 
                !acceptTerms || 
                password !== confirmPassword || 
                passwordStrength < 100
              }
            >
              {isSubmitting ? 'Creazione in corso...' : 'Inizia la prova gratuita'}
            </Button>
            {password !== confirmPassword && password && confirmPassword && (
              <p className="text-destructive text-sm mt-2">Le password non corrispondono</p>
            )}
          </div>
        </form>
        
        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-background text-foreground/60">
                O continua con
              </span>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={handleGoogleLogin}
              disabled={isLoading || isSubmitting}
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Caricamento...
                </span>
              ) : (
                <>
                  <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12.545 10.239v3.818h5.556c-.23 1.438-1.67 4.22-5.556 4.22-3.346 0-6.078-2.753-6.078-6.15s2.732-6.15 6.078-6.15c1.903 0 3.177.81 3.908 1.51l2.662-2.545c-1.708-1.595-3.926-2.557-6.57-2.557-5.428 0-9.802 4.397-9.802 9.802s4.374 9.802 9.802 9.802c5.66 0 9.413-3.956 9.413-9.55 0-.642-.068-1.126-.153-1.621h-9.26z" />
                  </svg>
                  Google
                </>
              )}
            </Button>
            <Button 
              variant="outline" 
              className="w-full"
              disabled={true}
              title="Facebook login non è ancora disponibile"
            >
              <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.114c.73 0 1.323-.593 1.323-1.324v-21.35c0-.732-.593-1.325-1.325-1.325z" />
              </svg>
              Facebook
            </Button>
          </div>
          <p className="text-xs text-center mt-4 text-muted-foreground">
            Accedi facilmente con Google usando la tua configurazione Firebase esistente.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
