
import { useState, useCallback, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PlusIcon, CalendarIcon, ListIcon, BarChartIcon } from 'lucide-react';
import ReservationCalendar from '@/components/reservations/ReservationCalendar';
import ReservationsList from '@/components/reservations/ReservationsList';
import ReservationStats from '@/components/reservations/ReservationStats';
import AddReservationDialog from '@/components/reservations/AddReservationDialog';
import { toast } from '@/hooks/use-toast';
import { useUser } from '@/contexts/user';
import { getUserSubscription } from '@/services/subscriptions';
import { UserSubscription, FeatureAccessLevel } from '@/services/subscriptions/types';
import { hasSubscriptionLevel } from '@/services/subscriptions/featureAccess';
import { PlanFeatureAlert } from '@/components/dashboard/PlanFeatureAlert';

const Reservations = () => {
  const [showAddReservationDialog, setShowAddReservationDialog] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState("calendar");
  
  // Fetch user subscription
  useEffect(() => {
    const fetchSubscription = async () => {
      if (user) {
        try {
          const subscription = await getUserSubscription(user.id);
          setUserSubscription(subscription);
          console.log("Reservations - User subscription:", subscription);
          
          const hasStatsAccess = hasSubscriptionLevel(subscription, FeatureAccessLevel.PRO);
          console.log("Has access to reservation stats:", hasStatsAccess);
        } catch (error) {
          console.error("Error fetching subscription:", error);
          setUserSubscription(null);
        }
      }
      setIsLoading(false);
    };
    
    fetchSubscription();
  }, [user]);
  
  const handleAddReservation = () => {
    setShowAddReservationDialog(true);
  };

  const handleReservationSuccess = () => {
    // Increment trigger to force refresh of components
    setRefreshTrigger(prev => prev + 1);
    
    toast({
      title: "Prenotazione aggiunta",
      description: "La prenotazione è stata aggiunta con successo",
    });
  };

  const handleTabChange = (value: string) => {
    // Only change to stats tab if user has access
    if (value === "stats" && !hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO)) {
      return;
    }
    setActiveTab(value);
    
    // Force refresh when changing to stats tab
    if (value === "stats") {
      setRefreshTrigger(prev => prev + 1);
    }
  };

  if (isLoading) {
    return (
      <AuthLayout>
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </AuthLayout>
    );
  }

  const canAccessStats = hasSubscriptionLevel(userSubscription, FeatureAccessLevel.PRO);

  return (
    <AuthLayout>
      <div className="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Prenotazioni</h1>
          <p className="text-muted-foreground">Gestisci le prenotazioni del tuo ristorante</p>
        </div>
        <div className="flex flex-col md:flex-row gap-2">
          <Button onClick={handleAddReservation} className="w-full md:w-auto">
            <PlusIcon className="h-4 w-4 mr-2" />
            Nuova Prenotazione
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="calendar">
            <CalendarIcon className="h-4 w-4 mr-2" />
            Calendario
          </TabsTrigger>
          <TabsTrigger value="list">
            <ListIcon className="h-4 w-4 mr-2" />
            Lista Prenotazioni
          </TabsTrigger>
          <TabsTrigger value="stats" disabled={!canAccessStats}>
            <BarChartIcon className="h-4 w-4 mr-2" />
            Statistiche
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="calendar" className="space-y-4">
          <ReservationCalendar key={`calendar-${refreshTrigger}`} />
        </TabsContent>
        
        <TabsContent value="list">
          <ReservationsList key={`list-${refreshTrigger}`} refreshTrigger={refreshTrigger} />
        </TabsContent>
        
        <TabsContent value="stats">
          {canAccessStats ? (
            <ReservationStats 
              key={`stats-${refreshTrigger}`} 
              userSubscription={userSubscription} 
              refreshTrigger={refreshTrigger}
            />
          ) : (
            <PlanFeatureAlert
              title="Statistiche prenotazioni non disponibili"
              description="Le statistiche dettagliate sulle prenotazioni sono disponibili solo per gli abbonamenti Pro e Ultimate."
              availableInPlans={['Pro', 'Ultimate']}
              buttonText="Aggiorna il tuo piano"
              buttonLink="/subscriptions"
            />
          )}
        </TabsContent>
      </Tabs>

      {showAddReservationDialog && (
        <AddReservationDialog 
          open={showAddReservationDialog} 
          onOpenChange={setShowAddReservationDialog}
          onSuccess={handleReservationSuccess}
        />
      )}
    </AuthLayout>
  );
};

export default Reservations;
