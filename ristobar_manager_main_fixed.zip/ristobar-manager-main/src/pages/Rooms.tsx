
import { useState, useEffect } from 'react';
import AuthLayout from '@/components/AuthLayout';
import RoomGrid, { Room, Table } from '@/components/RoomGrid';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { Toaster } from '@/components/ui/toaster';
import ActiveOrders from '@/components/ActiveOrders';
import { StaffProvider } from '@/contexts/StaffContext';
import useRoomOperations from '@/components/rooms/RoomOperations';
import useTableOperations from '@/components/rooms/TableOperations';
import useRoomDialogs from '@/components/rooms/useRoomDialogs';
import RoomDialogs from '@/components/rooms/RoomDialogs';
import RoomsHeader from '@/components/rooms/RoomsHeader';
import { getReservations } from '@/services/reservationService';
import { Spinner } from '@/components/ui/spinner';
import useFeatureAccess from '@/hooks/useFeatureAccess';
import { FeatureAccessLevel } from '@/services/subscriptions/featureAccess';
import LocationSelector from '@/components/rooms/LocationSelector';
import { Dialog } from '@/components/ui/dialog';
import LocationsManager from '@/components/rooms/LocationsManager';
import { Badge } from '@/components/ui/badge';
import { getAllOrders } from '@/services/ordersService';
import ActiveOrdersNotification from '@/components/rooms/ActiveOrdersNotification';

const Rooms = () => {
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isLoadingReservations, setIsLoadingReservations] = useState(false);
  const { hasLevel } = useFeatureAccess();
  const isProOrHigher = hasLevel(FeatureAccessLevel.PRO);
  const isUltimate = hasLevel(FeatureAccessLevel.ULTIMATE);
  
  const [locations, setLocations] = useState<string[]>(['Sede Principale']);
  const [selectedLocation, setSelectedLocation] = useState<string>('Sede Principale');
  const [showLocationsManager, setShowLocationsManager] = useState(false);
  const [activeOrdersCount, setActiveOrdersCount] = useState(0);
  
  const dialogsManager = useRoomDialogs();
  const {
    selectedRoom,
    selectedTable,
    showNewRoomModal,
    setShowNewRoomModal,
    showEditRoomModal,
    setShowEditRoomModal,
    showNewTableModal,
    setShowNewTableModal,
    showEditTableModal,
    setShowEditTableModal,
    showDeleteRoomConfirm,
    setShowDeleteRoomConfirm,
    showDeleteTableConfirm,
    setShowDeleteTableConfirm,
    openEditRoomDialog,
    openDeleteRoomConfirm,
    openEditTableDialog,
    openDeleteTableConfirm,
    openNewTableDialog,
    setSelectedRoom
  } = dialogsManager;

  useEffect(() => {
    loadReservations();
    loadActiveOrdersCount();
    
    const savedLocations = localStorage.getItem('restaurant_locations');
    if (savedLocations) {
      try {
        const parsedLocations = JSON.parse(savedLocations);
        if (Array.isArray(parsedLocations) && parsedLocations.length > 0) {
          setLocations(parsedLocations);
          const savedSelectedLocation = localStorage.getItem('restaurant_selected_location');
          if (savedSelectedLocation && parsedLocations.includes(savedSelectedLocation)) {
            setSelectedLocation(savedSelectedLocation);
          } else {
            setSelectedLocation(parsedLocations[0]);
          }
        }
      } catch (error) {
        console.error('Error loading saved locations:', error);
      }
    }

    const handleOrdersUpdated = () => {
      console.log("Orders updated event received, refreshing active orders count");
      loadActiveOrdersCount();
    };
    
    window.addEventListener('orders-updated', handleOrdersUpdated);
    
    return () => {
      window.removeEventListener('orders-updated', handleOrdersUpdated);
    };
  }, []);

  const loadActiveOrdersCount = async () => {
    try {
      const allOrders = await getAllOrders();
      console.log(`Found ${allOrders.length} total orders`);
      const activeOrders = allOrders.filter(order => 
        (order.status === 'pending' || order.status === 'completed') &&
        (!isProOrHigher || !selectedLocation || order.locationId === selectedLocation)
      );
      console.log(`Filtered to ${activeOrders.length} active orders for location ${selectedLocation}`);
      setActiveOrdersCount(activeOrders.length);
    } catch (error) {
      console.error('Error loading active orders count:', error);
    }
  };

  const loadReservations = async () => {
    setIsLoadingReservations(true);
    try {
      const result = await getReservations();
      if (result.error) {
        console.error('Error loading reservations:', result.error);
        toast({
          title: "Errore",
          description: "Impossibile caricare le prenotazioni",
          variant: "destructive",
        });
      } else if (result.data) {
        console.log(`Loaded ${result.data.length} reservations`);
      }
    } catch (error) {
      console.error('Error loading reservations:', error);
      toast({
        title: "Errore",
        description: "Impossibile caricare le prenotazioni",
        variant: "destructive",
      });
    } finally {
      setIsLoadingReservations(false);
    }
  };

  const handleLocationChange = (location: string) => {
    setSelectedLocation(location);
    localStorage.setItem('restaurant_selected_location', location);
    setLastUpdate(new Date());
    loadActiveOrdersCount();
  };

  const handleAddLocation = (name: string) => {
    if (isProOrHigher && !isUltimate && locations.length >= 2) {
      toast({
        title: "Limite raggiunto",
        description: "Il piano Pro consente al massimo 2 sedi. Passa al piano Ultimate per sedi illimitate.",
        variant: "destructive",
      });
      return;
    }
    
    if (locations.includes(name)) {
      toast({
        title: "Errore",
        description: "Esiste già una sede con questo nome",
        variant: "destructive",
      });
      return;
    }
    
    const newLocations = [...locations, name];
    setLocations(newLocations);
    localStorage.setItem('restaurant_locations', JSON.stringify(newLocations));
    toast({
      title: "Sede aggiunta",
      description: `La sede "${name}" è stata aggiunta con successo`,
    });
  };

  const handleEditLocation = (oldName: string, newName: string) => {
    if (locations.includes(newName) && oldName !== newName) {
      toast({
        title: "Errore",
        description: "Esiste già una sede con questo nome",
        variant: "destructive",
      });
      return;
    }
    
    const newLocations = locations.map(loc => loc === oldName ? newName : loc);
    setLocations(newLocations);
    
    if (selectedLocation === oldName) {
      setSelectedLocation(newName);
      localStorage.setItem('restaurant_selected_location', newName);
    }
    
    localStorage.setItem('restaurant_locations', JSON.stringify(newLocations));
    toast({
      title: "Sede aggiornata",
      description: `La sede "${oldName}" è stata rinominata in "${newName}"`,
    });
  };

  const handleDeleteLocation = (name: string) => {
    if (locations.length <= 1) {
      toast({
        title: "Errore",
        description: "Deve esistere almeno una sede",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedLocation === name) {
      const anotherLocation = locations.find(loc => loc !== name) || 'Sede Principale';
      setSelectedLocation(anotherLocation);
      localStorage.setItem('restaurant_selected_location', anotherLocation);
    }
    
    const newLocations = locations.filter(loc => loc !== name);
    setLocations(newLocations);
    localStorage.setItem('restaurant_locations', JSON.stringify(newLocations));
    toast({
      title: "Sede eliminata",
      description: `La sede "${name}" è stata eliminata con successo`,
    });
  };

  const ProBadge = () => (
    <span className="ml-2 text-xs px-2 py-0.5 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-full font-medium">Piano Pro</span>
  );

  const roomOperations = useRoomOperations({
    onRoomUpdated: () => setLastUpdate(new Date()),
    locationId: isProOrHigher ? selectedLocation : undefined
  });
  
  const tableOperations = useTableOperations({
    onTableUpdated: () => setLastUpdate(new Date()),
    locationId: isProOrHigher ? selectedLocation : undefined
  });
  
  const { isProcessing: isRoomProcessing } = roomOperations;
  const { isProcessing: isTableProcessing } = tableOperations;
  const isProcessing = isRoomProcessing || isTableProcessing || isLoadingReservations;

  const handleAddRoomClick = () => {
    console.log("Opening new room dialog");
    setSelectedRoom(null);
    setShowNewRoomModal(true);
    setShowNewTableModal(false);
  };

  const handleAddTableClick = () => {
    if (!selectedRoom) {
      toast({
        title: "Attenzione",
        description: "Seleziona prima una sala per aggiungere un tavolo",
        variant: "destructive"
      });
      return;
    }
    console.log("Opening add table dialog for room:", selectedRoom);
    openNewTableDialog(selectedRoom);
  };

  const handleEditRoom = async (data: { name: string; capacity: number }) => {
    if (selectedRoom) {
      try {
        await roomOperations.handleEditRoom(selectedRoom, data);
        setShowEditRoomModal(false);
      } catch (error) {
        console.error("Error editing room:", error);
      }
    }
  };

  const handleDeleteRoom = async () => {
    if (selectedRoom) {
      try {
        await roomOperations.handleDeleteRoom(selectedRoom);
        setShowDeleteRoomConfirm(false);
      } catch (error) {
        console.error("Error deleting room:", error);
      }
    }
  };

  const handleAddTable = async (data: any) => {
    console.log("handleAddTable called with data:", data, "and selectedRoom:", selectedRoom);
    
    if (!selectedRoom) {
      toast({
        title: "Errore",
        description: "Nessuna sala selezionata per aggiungere il tavolo",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await tableOperations.handleAddTable(selectedRoom, data);
      setShowNewTableModal(false);
    } catch (error) {
      console.error("Error adding table:", error);
    }
  };

  const handleEditTable = async (data: any) => {
    if (selectedTable) {
      try {
        await tableOperations.handleEditTable(selectedTable, data);
        setShowEditTableModal(false);
      } catch (error) {
        console.error("Error editing table:", error);
      }
    }
  };

  const handleDeleteTable = async () => {
    if (selectedTable) {
      try {
        await tableOperations.handleDeleteTable(selectedTable);
        setShowDeleteTableConfirm(false);
      } catch (error) {
        console.error("Error deleting table:", error);
      }
    }
  };

  const handleSelectRoom = (room: Room | null) => {
    console.log("Room selected:", room);
    setSelectedRoom(room);
    
    if (room === null) {
      console.log("Opening new room dialog from handleSelectRoom");
      setShowNewRoomModal(true);
    }
  };

  const handleRefresh = () => {
    setLastUpdate(new Date());
    loadActiveOrdersCount();
    toast({
      title: "Aggiornato",
      description: "Le informazioni sulle sale sono state aggiornate",
    });
  };

  return (
    <AuthLayout>
      <StaffProvider>
        <div className="space-y-8">
          {isProOrHigher && (
            <div className="p-6 rounded-lg bg-card shadow-sm border">
              <div className="flex items-center mb-2">
                <h2 className="text-lg font-semibold">Selezione Sede</h2>
                {isProOrHigher && <ProBadge />}
              </div>
              <LocationSelector
                locations={locations}
                selectedLocation={selectedLocation}
                onLocationChange={handleLocationChange}
                onManageLocations={() => setShowLocationsManager(true)}
                canManageLocations={true}
              />
            </div>
          )}
          
          <Dialog open={showLocationsManager} onOpenChange={setShowLocationsManager}>
            <LocationsManager
              locations={locations}
              currentLocation={selectedLocation}
              onAddLocation={handleAddLocation}
              onEditLocation={handleEditLocation}
              onDeleteLocation={handleDeleteLocation}
            />
          </Dialog>
          
          <div className="p-6 rounded-lg bg-card shadow-sm border">
            <RoomsHeader 
              onAddRoomClick={handleAddRoomClick}
              isProcessing={isProcessing}
              locationName={selectedLocation}
              isPro={isProOrHigher}
              onRefreshClick={handleRefresh}
            />
            
            {/* Add the ActiveOrdersNotification component here */}
            <div className="mt-4">
              <ActiveOrdersNotification locationId={isProOrHigher ? selectedLocation : undefined} />
            </div>
          </div>
          
          <Tabs defaultValue="rooms" className="w-full">
            <TabsList className="mb-6 w-full justify-start border-b rounded-none p-0">
              <TabsTrigger 
                value="rooms" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none px-6 py-3"
              >
                Gestione Sale
              </TabsTrigger>
              <TabsTrigger 
                value="orders" 
                className="data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none rounded-none px-6 py-3 relative"
              >
                Ordini
                {activeOrdersCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px]"
                  >
                    {activeOrdersCount}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="rooms" className="space-y-6">
              {isLoadingReservations ? (
                <div className="flex items-center justify-center py-8 bg-card border rounded-lg">
                  <Spinner size="md" />
                  <span className="ml-2 text-muted-foreground">Caricamento prenotazioni...</span>
                </div>
              ) : (
                <div className="bg-background rounded-lg p-0">
                  <RoomGrid 
                    onEditRoom={openEditRoomDialog}
                    onDeleteRoom={openDeleteRoomConfirm}
                    onAddTable={handleAddTableClick}
                    onSelectRoom={handleSelectRoom}
                    selectedRoomId={selectedRoom?.id}
                    lastUpdate={lastUpdate}
                    onEditTable={openEditTableDialog}
                    onDeleteTable={openDeleteTableConfirm}
                    locationId={isProOrHigher ? selectedLocation : undefined}
                  />
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="orders" className="space-y-4">
              <div className="bg-card rounded-lg shadow-sm border p-6">
                <ActiveOrders />
              </div>
            </TabsContent>
          </Tabs>

          <RoomDialogs 
            {...dialogsManager}
            onAddRoom={roomOperations.handleAddRoom}
            onEditRoom={handleEditRoom}
            onDeleteRoom={handleDeleteRoom}
            onAddTable={handleAddTable}
            onEditTable={handleEditTable}
            onDeleteTable={handleDeleteTable}
            locationId={isProOrHigher ? selectedLocation : undefined}
          />
        </div>
      </StaffProvider>
      
      <Toaster />
    </AuthLayout>
  );
};

export default Rooms;
