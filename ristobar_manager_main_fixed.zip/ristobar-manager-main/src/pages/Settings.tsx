import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import CashierSettings from "@/components/cashier/CashierSettings";
import MenuSettings from "@/components/menu/MenuSettings";
import { InventorySettings } from "@/components/inventory/InventorySettings";
import { Layout } from "@/components/ui/layout";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/UserContext";
import { 
  Settings2Icon, 
  UserIcon, 
  BellIcon, 
  LockIcon, 
  PaletteIcon, 
  GlobeIcon,
  SaveIcon,
  RefreshCcwIcon,
  MailIcon,
  BuildingIcon,
  ClockIcon,
  CreditCardIcon,
  PrinterIcon,
  DatabaseIcon,
  ImageIcon,
  PhoneIcon,
  MapPinIcon,
  CalendarIcon,
  KeyIcon,
  UsersIcon,
  BanknoteIcon,
  ReceiptIcon,
  Upload,
  Trash2
} from "lucide-react";
import { deleteRestaurantLogo } from "@/components/cashier/bill/RestaurantInfoProvider";

export default function Settings() {
  const { toast } = useToast();
  const { user, updateUser } = useUser();
  
  // General settings
  const [darkMode, setDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [language, setLanguage] = useState("it");
  
  // Restaurant information
  const [restaurantName, setRestaurantName] = useState(user?.restaurantName || "");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState(user?.email || "");
  const [website, setWebsite] = useState("");
  const [description, setDescription] = useState("");
  
  // Logo and images
  const [restaurantLogo, setRestaurantLogo] = useState<string | null>(null);
  const [coverImage, setCoverImage] = useState<string | null>(null);
  
  // Opening hours
  const days = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"];
  const [openingHours, setOpeningHours] = useState(
    days.map(day => ({ 
      day, 
      isOpen: true, 
      openTime: "08:00", 
      closeTime: "22:00", 
      breakStart: "15:00", 
      breakEnd: "17:00",
      hasBreak: false
    }))
  );
  
  // Payment configurations
  const [acceptedPaymentMethods, setAcceptedPaymentMethods] = useState({
    cash: true,
    card: true,
    digital: false,
    invoice: false
  });
  
  // Receipt configurations
  const [receiptOptions, setReceiptOptions] = useState({
    automaticPrinting: true,
    showLogo: true,
    showTaxDetails: true,
    showContactInfo: true,
    footerText: "Grazie per la visita! Vi aspettiamo presto!"
  });
  
  // Backup
  const [autoBackup, setAutoBackup] = useState(true);
  const [backupFrequency, setBackupFrequency] = useState("daily");
  const [lastBackup, setLastBackup] = useState("Mai eseguito");

  // Personal info
  const [userName, setUserName] = useState(user?.name || "");
  const [userEmail, setUserEmail] = useState(user?.email || "");
  const [userPhone, setUserPhone] = useState("");
  
  // Security
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // Load any saved settings from localStorage on component mount
  useEffect(() => {
    // Load general settings
    const savedGeneralSettings = localStorage.getItem('generalSettings');
    if (savedGeneralSettings) {
      const settings = JSON.parse(savedGeneralSettings);
      setDarkMode(settings.darkMode);
      setLanguage(settings.language);
    }
    
    // Load restaurant info
    const savedRestaurantInfo = localStorage.getItem('restaurantInfo');
    if (savedRestaurantInfo) {
      const info = JSON.parse(savedRestaurantInfo);
      setAddress(info.address || "");
      setPhone(info.phone || "");
      setWebsite(info.website || "");
      setDescription(info.description || "");
    }
    
    // Load logo and images
    const savedLogo = localStorage.getItem('restaurantLogo');
    if (savedLogo) {
      setRestaurantLogo(savedLogo);
    }
    
    const savedCoverImage = localStorage.getItem('coverImage');
    if (savedCoverImage) {
      setCoverImage(savedCoverImage);
    }
    
    // Load opening hours
    const savedOpeningHours = localStorage.getItem('openingHours');
    if (savedOpeningHours) {
      setOpeningHours(JSON.parse(savedOpeningHours));
    }
    
    // Load notification settings
    const savedNotificationSettings = localStorage.getItem('notificationSettings');
    if (savedNotificationSettings) {
      const settings = JSON.parse(savedNotificationSettings);
      setEmailNotifications(settings.email);
      setPushNotifications(settings.push);
    }
    
    // Load payment methods
    const savedPaymentMethods = localStorage.getItem('paymentMethods');
    if (savedPaymentMethods) {
      setAcceptedPaymentMethods(JSON.parse(savedPaymentMethods));
    }
    
    // Load receipt options
    const savedReceiptOptions = localStorage.getItem('receiptOptions');
    if (savedReceiptOptions) {
      setReceiptOptions(JSON.parse(savedReceiptOptions));
    }
    
    // Load backup settings
    const savedBackupSettings = localStorage.getItem('backupSettings');
    if (savedBackupSettings) {
      const settings = JSON.parse(savedBackupSettings);
      setAutoBackup(settings.autoBackup);
      setBackupFrequency(settings.frequency);
      setLastBackup(settings.lastBackup);
    }
  }, []);

  const handleSaveGeneralSettings = () => {
    // Save to localStorage
    const generalSettings = {
      darkMode,
      language
    };
    
    localStorage.setItem('generalSettings', JSON.stringify(generalSettings));
    
    toast({
      title: "Impostazioni salvate",
      description: "Le tue impostazioni generali sono state aggiornate.",
    });
  };
  
  const handleSaveRestaurantInfo = () => {
    // Update the user object with new restaurant name
    if (user) {
      updateUser({ restaurantName });
    }
    
    // Save other restaurant information to localStorage
    const restaurantInfo = {
      address,
      phone,
      website,
      description
    };
    
    localStorage.setItem('restaurantInfo', JSON.stringify(restaurantInfo));
    
    // Save logo and cover image separately
    if (restaurantLogo) {
      localStorage.setItem('restaurantLogo', restaurantLogo);
    }
    
    if (coverImage) {
      localStorage.setItem('coverImage', coverImage);
    }
    
    // Save opening hours
    localStorage.setItem('openingHours', JSON.stringify(openingHours));
    
    toast({
      title: "Informazioni ristorante aggiornate",
      description: "Le informazioni del tuo ristorante sono state aggiornate con successo.",
    });
  };
  
  const handleSaveAccountInfo = () => {
    // Update the user object with new name and email
    if (user) {
      updateUser({ 
        name: userName,
        email: userEmail
      });
    }
    
    toast({
      title: "Profilo aggiornato",
      description: "Le tue informazioni personali sono state aggiornate con successo.",
    });
  };
  
  const handleUpdatePassword = () => {
    // Password validation
    if (newPassword !== confirmPassword) {
      toast({
        title: "Errore di aggiornamento",
        description: "Le password non coincidono. Riprova.",
        variant: "destructive"
      });
      return;
    }
    
    if (newPassword.length < 6) {
      toast({
        title: "Errore di aggiornamento",
        description: "La password deve essere di almeno 6 caratteri.",
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, you would update the password on the server
    // For this mock, we'll just show a success message
    
    toast({
      title: "Password aggiornata",
      description: "La tua password è stata aggiornata con successo.",
    });
    
    // Clear the password fields
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };
  
  const handleSaveNotificationSettings = () => {
    // Save notification settings to localStorage
    const notificationSettings = {
      email: emailNotifications,
      push: pushNotifications
    };
    
    localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
    
    toast({
      title: "Preferenze salvate",
      description: "Le tue preferenze di notifica sono state aggiornate.",
    });
  };
  
  const handleSavePaymentMethods = () => {
    // Save payment methods to localStorage
    localStorage.setItem('paymentMethods', JSON.stringify(acceptedPaymentMethods));
    
    toast({
      title: "Configurazione salvata",
      description: "I metodi di pagamento sono stati aggiornati con successo.",
    });
  };
  
  const handleSaveReceiptOptions = () => {
    // Save receipt options to localStorage
    localStorage.setItem('receiptOptions', JSON.stringify(receiptOptions));
    
    toast({
      title: "Configurazione salvata",
      description: "Le impostazioni degli scontrini sono state aggiornate con successo.",
    });
  };
  
  const handleManualBackup = () => {
    // Simulate a backup
    const now = new Date().toLocaleString('it-IT');
    setLastBackup(now);
    
    // Save backup settings
    const backupSettings = {
      autoBackup,
      frequency: backupFrequency,
      lastBackup: now
    };
    
    localStorage.setItem('backupSettings', JSON.stringify(backupSettings));
    
    toast({
      title: "Backup completato",
      description: "Il backup dei dati è stato eseguito con successo.",
    });
  };
  
  const handleSaveBackupSettings = () => {
    // Save backup settings
    const backupSettings = {
      autoBackup,
      frequency: backupFrequency,
      lastBackup
    };
    
    localStorage.setItem('backupSettings', JSON.stringify(backupSettings));
    
    toast({
      title: "Impostazioni salvate",
      description: "Le impostazioni di backup sono state aggiornate con successo.",
    });
  };

  // Logo upload handler
  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setRestaurantLogo(result);
        localStorage.setItem('restaurantLogo', result);
      };
      reader.readAsDataURL(file);
    }
  };

  // New handler for logo deletion
  const handleDeleteLogo = () => {
    if (user?.id) {
      // Delete the logo using the imported function
      const result = deleteRestaurantLogo(user.id);
      
      if (result) {
        // Clear the logo in the state
        setRestaurantLogo(null);
        
        toast({
          title: "Logo eliminato",
          description: "Il logo del ristorante è stato eliminato con successo.",
        });
      } else {
        toast({
          title: "Errore",
          description: "Si è verificato un errore durante l'eliminazione del logo.",
          variant: "destructive"
        });
      }
    } else {
      toast({
        title: "Errore",
        description: "Utente non trovato. Impossibile eliminare il logo.",
        variant: "destructive"
      });
    }
  };

  // Cover image upload handler
  const handleCoverImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setCoverImage(result);
        localStorage.setItem('coverImage', result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Layout>
      <Helmet>
        <title>Impostazioni | RistoBar</title>
      </Helmet>
      
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Impostazioni</h1>
          <p className="text-muted-foreground">
            Gestisci le tue preferenze e le configurazioni del sistema.
          </p>
        </div>
      </div>
      
      <Tabs defaultValue="generale" className="space-y-4">
        <TabsList className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 lg:grid-cols-7 mb-4">
          <TabsTrigger value="generale" className="flex items-center gap-2">
            <Settings2Icon className="h-4 w-4" />
            <span className="hidden sm:inline">Generale</span>
          </TabsTrigger>
          <TabsTrigger value="ristorante" className="flex items-center gap-2">
            <BuildingIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Ristorante</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center gap-2">
            <UserIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Account</span>
          </TabsTrigger>
          <TabsTrigger value="notifiche" className="flex items-center gap-2">
            <BellIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Notifiche</span>
          </TabsTrigger>
          <TabsTrigger value="pagamenti" className="flex items-center gap-2">
            <CreditCardIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Pagamenti</span>
          </TabsTrigger>
          <TabsTrigger value="scontrini" className="flex items-center gap-2">
            <ReceiptIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Scontrini</span>
          </TabsTrigger>
          <TabsTrigger value="sistema" className="flex items-center gap-2">
            <DatabaseIcon className="h-4 w-4" />
            <span className="hidden sm:inline">Sistema</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="generale" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Impostazioni Generali</CardTitle>
              <CardDescription>
                Gestisci le impostazioni generali del tuo account e dell'applicazione.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Aspetto</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="dark-mode">Modalità scura</Label>
                    <p className="text-sm text-muted-foreground">
                      Attiva la modalità scura per ridurre l'affaticamento degli occhi.
                    </p>
                  </div>
                  <Switch
                    id="dark-mode"
                    checked={darkMode}
                    onCheckedChange={setDarkMode}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Lingua e Regione</h3>
                <div className="grid gap-2">
                  <Label htmlFor="language">Lingua</Label>
                  <select
                    id="language"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                  >
                    <option value="it">Italiano</option>
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                  </select>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveGeneralSettings}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva modifiche
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="ristorante" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informazioni Ristorante</CardTitle>
              <CardDescription>
                Gestisci i dettagli e le informazioni del tuo ristorante.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="restaurant-name">Nome del ristorante</Label>
                  <Input 
                    id="restaurant-name" 
                    value={restaurantName} 
                    onChange={(e) => setRestaurantName(e.target.value)}
                    placeholder="Trattoria Bella Italia" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Indirizzo</Label>
                  <Input 
                    id="address" 
                    value={address} 
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Via Roma 123, Milano" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefono</Label>
                  <Input 
                    id="phone" 
                    value={phone} 
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+39 02 1234567" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="info@trattoriabellaitalia.it" 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="website">Sito web</Label>
                  <Input 
                    id="website" 
                    value={website} 
                    onChange={(e) => setWebsite(e.target.value)}
                    placeholder="www.trattoriabellaitalia.it" 
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="description">Descrizione</Label>
                  <Textarea 
                    id="description" 
                    value={description} 
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Descrizione del tuo ristorante..." 
                    rows={4} 
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Loghi e Immagini</h3>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="logo-upload">Logo del ristorante</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-20 w-20 rounded-md border border-dashed border-gray-300 flex items-center justify-center bg-gray-50 overflow-hidden">
                        {restaurantLogo ? (
                          <img 
                            src={restaurantLogo} 
                            alt="Logo ristorante" 
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <ImageIcon className="h-8 w-8 text-gray-400" />
                        )}
                      </div>
                      <div className="flex flex-col gap-2">
                        <Input
                          id="logo-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="hidden"
                        />
                        <Label 
                          htmlFor="logo-upload" 
                          className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2 cursor-pointer"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Carica logo
                        </Label>
                        
                        {restaurantLogo && (
                          <Button 
                            variant="destructive" 
                            size="sm" 
                            onClick={handleDeleteLogo}
                            className="flex items-center justify-center"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Elimina logo
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="banner-upload">Immagine copertina</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-20 w-36 rounded-md border border-dashed border-gray-300 flex items-center justify-center bg-gray-50 overflow-hidden">
                        {coverImage ? (
                          <img 
                            src={coverImage} 
                            alt="Immagine copertina" 
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <ImageIcon className="h-8 w-8 text-gray-400" />
                        )}
                      </div>
                      <div>
                        <Input
                          id="banner-upload"
                          type="file"
                          accept="image/*"
                          onChange={handleCoverImageUpload}
                          className="hidden"
                        />
                        <Label 
                          htmlFor="banner-upload" 
                          className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2 cursor-pointer"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Carica immagine
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Orari di Apertura</h3>
                <div className="space-y-4">
                  {openingHours.map((day, index) => (
                    <div key={day.day} className="grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-2 md:col-span-2">
                        <p className="text-sm font-medium">{day.day}</p>
                      </div>
                      <div className="col-span-2 md:col-span-1">
                        <div className="flex items-center h-full">
                          <Switch 
                            checked={day.isOpen} 
                            onCheckedChange={(checked) => {
                              const newHours = [...openingHours];
                              newHours[index].isOpen = checked;
                              setOpeningHours(newHours);
                            }} 
                          />
                        </div>
                      </div>
                      <div className="col-span-4 md:col-span-2">
                        <Input
                          type="time"
                          value={day.openTime}
                          onChange={(e) => {
                            const newHours = [...openingHours];
                            newHours[index].openTime = e.target.value;
                            setOpeningHours(newHours);
                          }}
                          disabled={!day.isOpen}
                        />
                      </div>
                      <div className="col-span-4 md:col-span-2">
                        <Input
                          type="time"
                          value={day.closeTime}
                          onChange={(e) => {
                            const newHours = [...openingHours];
                            newHours[index].closeTime = e.target.value;
                            setOpeningHours(newHours);
                          }}
                          disabled={!day.isOpen}
                        />
                      </div>
                      <div className="col-span-12 md:col-span-5 pl-0 md:pl-2 flex items-center gap-1">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id={`break-${index}`} 
                            checked={day.hasBreak && day.isOpen}
                            onCheckedChange={(checked) => {
                              const newHours = [...openingHours];
                              newHours[index].hasBreak = !!checked;
                              setOpeningHours(newHours);
                            }}
                            disabled={!day.isOpen}
                          />
                          <Label htmlFor={`break-${index}`} className="text-xs cursor-pointer">Pausa</Label>
                        </div>
                        {day.hasBreak && day.isOpen && (
                          <>
                            <Input
                              type="time"
                              value={day.breakStart}
                              onChange={(e) => {
                                const newHours = [...openingHours];
                                newHours[index].breakStart = e.target.value;
                                setOpeningHours(newHours);
                              }}
                              className="h-8 text-xs"
                              disabled={!day.isOpen}
                            />
                            <span>-</span>
                            <Input
                              type="time"
                              value={day.breakEnd}
                              onChange={(e) => {
                                const newHours = [...openingHours];
                                newHours[index].breakEnd = e.target.value;
                                setOpeningHours(newHours);
                              }}
                              className="h-8 text-xs"
                              disabled={!day.isOpen}
                            />
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button onClick={handleSaveRestaurantInfo}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva informazioni
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Informazioni Personali</CardTitle>
              <CardDescription>
                Aggiorna le tue informazioni personali e di contatto.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleSaveAccountInfo(); }}>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome completo</Label>
                    <Input 
                      id="name" 
                      value={userName} 
                      onChange={(e) => setUserName(e.target.value)}
                      placeholder="Mario Rossi" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={userEmail}
                      onChange={(e) => setUserEmail(e.target.value)}
                      placeholder="mario.rossi@example.com" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefono</Label>
                    <Input 
                      id="phone" 
                      value={userPhone}
                      onChange={(e) => setUserPhone(e.target.value)}
                      placeholder="+39 123 456 7890" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Ruolo</Label>
                    <Input id="role" placeholder="Proprietario" defaultValue={user?.role} disabled />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button type="submit">
                    <SaveIcon className="h-4 w-4 mr-2" />
                    Salva modifiche
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Sicurezza</CardTitle>
              <CardDescription>
                Gestisci la sicurezza del tuo account.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); handleUpdatePassword(); }}>
                <div className="space-y-2">
                  <Label htmlFor="current-password">Password attuale</Label>
                  <Input 
                    id="current-password" 
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password">Nuova password</Label>
                  <Input 
                    id="new-password" 
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Conferma password</Label>
                  <Input 
                    id="confirm-password" 
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                </div>
                <div className="flex justify-end">
                  <Button type="submit">Aggiorna password</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifiche" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Preferenze di Notifica</CardTitle>
              <CardDescription>
                Personalizza come e quando ricevere notifiche.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Notifiche Operazioni</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="reservations-notifications">Prenotazioni</Label>
                      <p className="text-sm text-muted-foreground">
                        Ricevi notifiche per nuove prenotazioni o modifiche
                      </p>
                    </div>
                    <Switch
                      id="reservations-notifications"
                      defaultChecked
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="orders-notifications">Ordini</Label>
                      <p className="text-sm text-muted-foreground">
                        Ricevi notifiche per nuovi ordini o modifiche
                      </p>
                    </div>
                    <Switch
                      id="orders-notifications"
                      defaultChecked
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="inventory-notifications">Inventario</Label>
                      <p className="text-sm text-muted-foreground">
                        Ricevi notifiche per scorte in esaurimento
                      </p>
                    </div>
                    <Switch
                      id="inventory-notifications"
                      defaultChecked
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Canali di Notifica</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Notifiche via email</Label>
                    <p className="text-sm text-muted-foreground">
                      Ricevi notifiche importanti via email.
                    </p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications">Notifiche push</Label>
                    <p className="text-sm text-muted-foreground">
                      Ricevi notifiche push nel browser.
                    </p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={pushNotifications}
                    onCheckedChange={setPushNotifications}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sms-notifications">Notifiche SMS</Label>
                    <p className="text-sm text-muted-foreground">
                      Ricevi notifiche urgenti via SMS.
                    </p>
                  </div>
                  <Switch
                    id="sms-notifications"
                    defaultChecked={false}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveNotificationSettings}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva preferenze
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="pagamenti" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurazione Pagamenti</CardTitle>
              <CardDescription>
                Gestisci i metodi di pagamento accettati dal tuo ristorante.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Metodi di Pagamento</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="cash-payment">Contanti</Label>
                      <p className="text-sm text-muted-foreground">
                        Accetta pagamenti in contanti.
                      </p>
                    </div>
                    <Switch
                      id="cash-payment"
                      checked={acceptedPaymentMethods.cash}
                      onCheckedChange={(checked) => setAcceptedPaymentMethods({...acceptedPaymentMethods, cash: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="card-payment">Carte di credito/debito</Label>
                      <p className="text-sm text-muted-foreground">
                        Accetta pagamenti con carte.
                      </p>
                    </div>
                    <Switch
                      id="card-payment"
                      checked={acceptedPaymentMethods.card}
                      onCheckedChange={(checked) => setAcceptedPaymentMethods({...acceptedPaymentMethods, card: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="digital-payment">Pagamenti digitali</Label>
                      <p className="text-sm text-muted-foreground">
                        Accetta pagamenti con app e wallet digitali.
                      </p>
                    </div>
                    <Switch
                      id="digital-payment"
                      checked={acceptedPaymentMethods.digital}
                      onCheckedChange={(checked) => setAcceptedPaymentMethods({...acceptedPaymentMethods, digital: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="invoice-payment">Fatturazione</Label>
                      <p className="text-sm text-muted-foreground">
                        Accetta pagamenti tramite fatturazione.
                      </p>
                    </div>
                    <Switch
                      id="invoice-payment"
                      checked={acceptedPaymentMethods.invoice}
                      onCheckedChange={(checked) => setAcceptedPaymentMethods({...acceptedPaymentMethods, invoice: checked})}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={handleSavePaymentMethods}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva configurazione
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="scontrini" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurazione Scontrini</CardTitle>
              <CardDescription>
                Personalizza il formato e le informazioni da includere negli scontrini.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Opzioni Scontrino</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="automatic-printing">Stampa automatica</Label>
                      <p className="text-sm text-muted-foreground">
                        Stampa automaticamente lo scontrino al completamento dell'ordine.
                      </p>
                    </div>
                    <Switch
                      id="automatic-printing"
                      checked={receiptOptions.automaticPrinting}
                      onCheckedChange={(checked) => setReceiptOptions({...receiptOptions, automaticPrinting: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="show-logo">Mostra logo</Label>
                      <p className="text-sm text-muted-foreground">
                        Includi il logo del ristorante nello scontrino.
                      </p>
                    </div>
                    <Switch
                      id="show-logo"
                      checked={receiptOptions.showLogo}
                      onCheckedChange={(checked) => setReceiptOptions({...receiptOptions, showLogo: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="show-tax">Dettagli IVA</Label>
                      <p className="text-sm text-muted-foreground">
                        Mostra i dettagli dell'IVA nello scontrino.
                      </p>
                    </div>
                    <Switch
                      id="show-tax"
                      checked={receiptOptions.showTaxDetails}
                      onCheckedChange={(checked) => setReceiptOptions({...receiptOptions, showTaxDetails: checked})}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="show-contact">Informazioni di contatto</Label>
                      <p className="text-sm text-muted-foreground">
                        Includi le informazioni di contatto nello scontrino.
                      </p>
                    </div>
                    <Switch
                      id="show-contact"
                      checked={receiptOptions.showContactInfo}
                      onCheckedChange={(checked) => setReceiptOptions({...receiptOptions, showContactInfo: checked})}
                    />
                  </div>
                </div>
                
                <div className="space-y-2 pt-2">
                  <Label htmlFor="footer-text">Testo a piè di pagina</Label>
                  <Textarea 
                    id="footer-text" 
                    value={receiptOptions.footerText} 
                    onChange={(e) => setReceiptOptions({...receiptOptions, footerText: e.target.value})}
                    placeholder="Grazie per la visita! Vi aspettiamo presto!" 
                    rows={2} 
                  />
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveReceiptOptions}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva configurazione
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="sistema" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Backup e Sistema</CardTitle>
              <CardDescription>
                Gestisci le impostazioni di backup e manutenzione del sistema.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Backup Automatico</h3>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="auto-backup">Backup automatico</Label>
                    <p className="text-sm text-muted-foreground">
                      Esegui backup automatici dei dati.
                    </p>
                  </div>
                  <Switch
                    id="auto-backup"
                    checked={autoBackup}
                    onCheckedChange={setAutoBackup}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backup-frequency">Frequenza backup</Label>
                  <select
                    id="backup-frequency"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={backupFrequency}
                    onChange={(e) => setBackupFrequency(e.target.value)}
                    disabled={!autoBackup}
                  >
                    <option value="daily">Giornaliera</option>
                    <option value="weekly">Settimanale</option>
                    <option value="monthly">Mensile</option>
                  </select>
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <div>
                    <p className="text-sm font-medium">Ultimo backup:</p>
                    <p className="text-sm text-muted-foreground">{lastBackup}</p>
                  </div>
                  <Button variant="outline" onClick={handleManualBackup}>
                    <RefreshCcwIcon className="h-4 w-4 mr-2" />
                    Backup manuale
                  </Button>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveBackupSettings}>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Salva impostazioni
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </Layout>
  );
}
