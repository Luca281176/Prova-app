
import { useUser } from '@/contexts/user';
import AuthLayout from '@/components/AuthLayout';
import { 
  subscriptionPlans, 
  isSubscriptionActive,
  getDaysRemaining
} from '@/services/subscriptions';
import NoSubscriptionView from '@/components/subscriptions/NoSubscriptionView';
import CurrentSubscriptionCard from '@/components/subscriptions/CurrentSubscriptionCard';
import SubscriptionPlansGrid from '@/components/subscriptions/SubscriptionPlansGrid';

const Subscriptions = () => {
  const { user } = useUser();
  
  if (!user || !user.subscription) {
    return (
      <AuthLayout>
        <NoSubscriptionView />
      </AuthLayout>
    );
  }
  
  const currentPlan = subscriptionPlans.find(plan => plan.id === user.subscription?.planId) || subscriptionPlans[0];
  const isActive = isSubscriptionActive(user.subscription);
  const daysRemaining = getDaysRemaining(user.subscription);
  
  return (
    <AuthLayout>
      <div className="animate-fade-up">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Gestione Abbonamento</h1>
            <p className="text-muted-foreground">Gestisci il tuo piano di abbonamento e visualizza i dettagli di fatturazione</p>
          </div>
        </div>
        
        <div className="grid gap-6">
          <CurrentSubscriptionCard 
            userSubscription={user.subscription}
            currentPlan={currentPlan}
            isActive={isActive}
          />
          
          <SubscriptionPlansGrid currentSubscription={user.subscription} />
        </div>
      </div>
    </AuthLayout>
  );
};

export default Subscriptions;
