
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '@/contexts/user'; // Updated import path
import AuthLayout from '@/components/AuthLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  getSubscriptions,
  updateSubscription,
  cancelSubscription,
  subscriptionPlans,
  type UserSubscription
} from '@/services/subscriptions';

// Import new components
import SubscriptionAdminHeader from '@/components/admin/SubscriptionAdminHeader';
import SubscriptionFilters from '@/components/admin/SubscriptionFilters';
import SubscriptionTable from '@/components/admin/SubscriptionTable';
import SubscriptionPagination from '@/components/admin/SubscriptionPagination';
import PaymentsTable from '@/components/admin/PaymentsTable';

const SubscriptionsAdmin = () => {
  const { user } = useUser();
  const navigate = useNavigate();
  const [subscriptions, setSubscriptions] = useState<UserSubscription[]>([]);
  const [filteredSubscriptions, setFilteredSubscriptions] = useState<UserSubscription[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [planFilter, setPlanFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const itemsPerPage = 10;

  // Ensure user is an admin
  useEffect(() => {
    if (user && user.role !== 'admin' && user.role !== 'owner') {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  // Load subscriptions
  useEffect(() => {
    const loadSubscriptions = async () => {
      try {
        setIsLoading(true);
        const result = await getSubscriptions(currentPage, itemsPerPage);
        setSubscriptions(result.subscriptions);
        setFilteredSubscriptions(result.subscriptions);
        setTotalItems(result.total);
      } catch (error) {
        console.error('Errore nel caricamento degli abbonamenti:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadSubscriptions();
  }, [currentPage]);

  // Filter subscriptions
  useEffect(() => {
    let filtered = [...subscriptions];
    
    // Filter by search
    if (searchTerm) {
      filtered = filtered.filter(sub => 
        sub.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(sub => sub.status === statusFilter);
    }
    
    // Filter by plan
    if (planFilter !== 'all') {
      filtered = filtered.filter(sub => sub.planId === planFilter);
    }
    
    setFilteredSubscriptions(filtered);
  }, [searchTerm, statusFilter, planFilter, subscriptions]);

  // Suspend subscription handler
  const handleSuspendSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      await updateSubscription(subscription.id, { 
        status: 'past_due' as UserSubscription['status']
      });
      
      // Update subscriptions list
      const result = await getSubscriptions(currentPage, itemsPerPage);
      setSubscriptions(result.subscriptions);
      setFilteredSubscriptions(result.subscriptions);
    } catch (error) {
      console.error('Errore nella sospensione dell\'abbonamento:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Activate subscription handler
  const handleActivateSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      await updateSubscription(subscription.id, { 
        status: 'active' as UserSubscription['status']
      });
      
      // Update subscriptions list
      const result = await getSubscriptions(currentPage, itemsPerPage);
      setSubscriptions(result.subscriptions);
      setFilteredSubscriptions(result.subscriptions);
    } catch (error) {
      console.error('Errore nell\'attivazione dell\'abbonamento:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Cancel subscription handler
  const handleCancelSubscription = async (subscription: UserSubscription) => {
    try {
      setIsLoading(true);
      await cancelSubscription(subscription.id);
      
      // Update subscriptions list
      const result = await getSubscriptions(currentPage, itemsPerPage);
      setSubscriptions(result.subscriptions);
      setFilteredSubscriptions(result.subscriptions);
    } catch (error) {
      console.error('Errore nella cancellazione dell\'abbonamento:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Upgrade subscription handler
  const handleUpgradeSubscription = async (subscription: UserSubscription) => {
    const currentPlanIndex = subscriptionPlans.findIndex(plan => plan.id === subscription.planId);
    if (currentPlanIndex < subscriptionPlans.length - 1) {
      const newPlanId = subscriptionPlans[currentPlanIndex + 1].id;
      try {
        setIsLoading(true);
        await updateSubscription(subscription.id, { 
          planId: newPlanId 
        });
        
        // Update subscriptions list
        const result = await getSubscriptions(currentPage, itemsPerPage);
        setSubscriptions(result.subscriptions);
        setFilteredSubscriptions(result.subscriptions);
      } catch (error) {
        console.error('Errore nell\'upgrade dell\'abbonamento:', error);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Downgrade subscription handler
  const handleDowngradeSubscription = async (subscription: UserSubscription) => {
    const currentPlanIndex = subscriptionPlans.findIndex(plan => plan.id === subscription.planId);
    if (currentPlanIndex > 0) {
      const newPlanId = subscriptionPlans[currentPlanIndex - 1].id;
      try {
        setIsLoading(true);
        await updateSubscription(subscription.id, { 
          planId: newPlanId 
        });
        
        // Update subscriptions list
        const result = await getSubscriptions(currentPage, itemsPerPage);
        setSubscriptions(result.subscriptions);
        setFilteredSubscriptions(result.subscriptions);
      } catch (error) {
        console.error('Errore nel downgrade dell\'abbonamento:', error);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Pagination handlers
  const handleNextPage = () => {
    const maxPage = Math.ceil(totalItems / itemsPerPage);
    if (currentPage < maxPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <AuthLayout>
      <div className="animate-fade-up">
        <SubscriptionAdminHeader />

        <Tabs defaultValue="subscriptions" className="space-y-4">
          <TabsList>
            <TabsTrigger value="subscriptions">Abbonamenti</TabsTrigger>
            <TabsTrigger value="payments">Pagamenti</TabsTrigger>
          </TabsList>
          
          <TabsContent value="subscriptions" className="space-y-4">
            <SubscriptionFilters 
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
              planFilter={planFilter}
              setPlanFilter={setPlanFilter}
            />

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Elenco Abbonamenti</CardTitle>
              </CardHeader>
              <CardContent>
                <SubscriptionTable 
                  subscriptions={filteredSubscriptions}
                  isLoading={isLoading}
                  onActivate={handleActivateSubscription}
                  onSuspend={handleSuspendSubscription}
                  onCancel={handleCancelSubscription}
                  onUpgrade={handleUpgradeSubscription}
                  onDowngrade={handleDowngradeSubscription}
                />
                
                <SubscriptionPagination 
                  currentPage={currentPage}
                  totalItems={totalItems}
                  itemsPerPage={itemsPerPage}
                  onNextPage={handleNextPage}
                  onPrevPage={handlePrevPage}
                />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="payments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Storico Pagamenti</CardTitle>
              </CardHeader>
              <CardContent>
                <PaymentsTable />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AuthLayout>
  );
};

export default SubscriptionsAdmin;
