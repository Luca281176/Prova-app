
import React from 'react';
import AuthLayout from '@/components/AuthLayout';
import { AdminNavbar } from '@/components/dashboard/AdminNavbar';
import { SystemStatus } from '@/components/admin/SystemStatus';
import { useUser } from '@/contexts/user';
import { Navigate } from 'react-router-dom';

const SystemStatusPage = () => {
  const { user } = useUser();
  
  // Check if user is app owner
  const isAppOwner = user?.email === 'luca.costanzo@ristobarmanager.it';
  
  if (!isAppOwner) {
    // Redirect to home page if user is not app owner
    return <Navigate to="/" />;
  }
  
  return (
    <AuthLayout>
      <AdminNavbar />
      <div className="container mx-auto py-6">
        <SystemStatus />
      </div>
    </AuthLayout>
  );
};

export default SystemStatusPage;
