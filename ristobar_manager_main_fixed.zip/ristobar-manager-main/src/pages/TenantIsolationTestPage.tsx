
import { TenantLayout } from '@/components/tenant/TenantLayout';
import { TenantIsolationTest } from '@/components/tenant/TenantIsolationTest';
import { Separator } from "@/components/ui/separator";
import { AlertTriangle } from 'lucide-react';

export function TenantIsolationTestPage() {
  return (
    <TenantLayout requiresAuth={false}>
      <div className="container mx-auto py-8">
        <h1 className="text-2xl font-bold mb-2">Test Isolamento Dati tra Tenant</h1>
        <p className="mb-6 text-gray-600">
          Questa pagina consente di testare l'isolamento dei dati tra tenant diversi.
          Il test verifica che i dati di un tenant non siano accessibili ad altri tenant.
        </p>
        
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-md mb-6">
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-amber-800">Informazioni Tecniche</h3>
              <p className="text-sm text-amber-700">
                Il test verifica l'isolamento sia a livello di frontend (localStorage) che a livello 
                di backend (schemi PostgreSQL separati). Ogni tenant deve avere accesso solo ai propri dati.
              </p>
            </div>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="my-8">
          <TenantIsolationTest />
        </div>
      </div>
    </TenantLayout>
  );
}

export default TenantIsolationTestPage;
