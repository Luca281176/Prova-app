
// Mock JWT service for multi-tenant authentication
// In a real app, this would use a proper JWT library

interface JwtPayload {
  sub: string;        // User ID
  tenantId: string;   // Tenant ID
  name: string;       // User name
  role: string;       // User role
  iat: number;        // Issued at timestamp
  exp: number;        // Expiration timestamp
}

// Mock function to create a JWT token
export const createToken = (userId: string, tenantId: string, name: string, role: string): string => {
  // In a real app, this would use a JWT library to sign the token
  const payload: JwtPayload = {
    sub: userId,
    tenantId,
    name,
    role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 3600 // Expires in 1 hour
  };
  
  // This is a mock token - in a real app, this would be properly signed
  return btoa(JSON.stringify(payload));
};

// Mock function to parse a JWT token
export const parseToken = (token: string): JwtPayload | null => {
  try {
    // In a real app, this would verify the signature
    return JSON.parse(atob(token));
  } catch (error) {
    console.error('Invalid token', error);
    return null;
  }
};

// Check if a token is valid (not expired)
export const isTokenValid = (token: string): boolean => {
  try {
    const payload = parseToken(token);
    if (!payload) return false;
    
    const now = Math.floor(Date.now() / 1000);
    return payload.exp > now;
  } catch (error) {
    return false;
  }
};

// Extract tenant ID from a token
export const getTenantIdFromToken = (token: string): string | null => {
  try {
    const payload = parseToken(token);
    return payload?.tenantId || null;
  } catch (error) {
    return null;
  }
};

// Store token in localStorage
export const storeToken = (token: string): void => {
  localStorage.setItem('auth_token', token);
};

// Get token from localStorage
export const getToken = (): string | null => {
  return localStorage.getItem('auth_token');
};

// Remove token from localStorage
export const removeToken = (): void => {
  localStorage.removeItem('auth_token');
};
