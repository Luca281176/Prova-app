
import axios, { AxiosRequestConfig, AxiosHeaders } from 'axios';
import AuthService from '../authService';
import { useTenant } from '@/contexts/tenant/TenantContext';

// Base URL for API
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Create an axios instance with base configuration
const tenantApi = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to add JWT token to every request
tenantApi.interceptors.request.use((config) => {
  const token = AuthService.getToken();
  
  if (token) {
    // Create proper headers using AxiosHeaders
    if (!config.headers) {
      config.headers = new AxiosHeaders();
    }
    config.headers.set('Authorization', `Bearer ${token}`);
  }
  
  return config;
});

/**
 * Hook to get an API instance with the correct tenant context
 */
export const useTenantApi = () => {
  const { currentTenant } = useTenant();
  
  // Helper to ensure X-Tenant-ID and X-Tenant-Schema headers are correctly set
  const addTenantHeaders = (config?: AxiosRequestConfig): AxiosRequestConfig => {
    const updatedConfig = { ...config };
    
    if (!updatedConfig.headers) {
      updatedConfig.headers = new AxiosHeaders();
    }
    
    if (currentTenant?.id) {
      // Set tenant headers using the proper method
      if (updatedConfig.headers instanceof AxiosHeaders) {
        updatedConfig.headers.set('X-Tenant-ID', currentTenant.id);
        
        // Also add the schema name if available
        if (currentTenant.schemaName) {
          updatedConfig.headers.set('X-Tenant-Schema', currentTenant.schemaName);
        }
      } else {
        // Fallback for older Axios versions or if headers is not an instance of AxiosHeaders
        const headers = updatedConfig.headers as Record<string, string>;
        headers['X-Tenant-ID'] = currentTenant.id;
        
        if (currentTenant.schemaName) {
          headers['X-Tenant-Schema'] = currentTenant.schemaName;
        }
      }
    }
    
    return updatedConfig;
  };
  
  const api = {
    get: async (url: string, config?: AxiosRequestConfig) => {
      const requestConfig = addTenantHeaders(config);
      return tenantApi.get(url, requestConfig);
    },
    
    post: async (url: string, data?: any, config?: AxiosRequestConfig) => {
      const requestConfig = addTenantHeaders(config);
      return tenantApi.post(url, data, requestConfig);
    },
    
    put: async (url: string, data?: any, config?: AxiosRequestConfig) => {
      const requestConfig = addTenantHeaders(config);
      return tenantApi.put(url, data, requestConfig);
    },
    
    delete: async (url: string, config?: AxiosRequestConfig) => {
      const requestConfig = addTenantHeaders(config);
      return tenantApi.delete(url, requestConfig);
    }
  };
  
  return api;
};

export default useTenantApi;
