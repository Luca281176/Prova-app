
import { useTenant } from '@/contexts/tenant/TenantContext';

/**
 * Hook per utilizzare il servizio di storage tenant-aware
 * @returns Funzioni per gestire i file del tenant
 */
export const useTenantStorage = () => {
  const { currentTenant } = useTenant();
  
  /**
   * Genera un percorso tenant-specific per un file
   * @param path Percorso del file all'interno della cartella del tenant
   * @returns Percorso completo
   */
  const getTenantFilePath = (path: string): string => {
    if (!currentTenant) {
      throw new Error('Tenant non disponibile');
    }
    
    // Assicura che il path non inizi con uno slash
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    
    // Usa il storagePath del tenant come base
    return `${currentTenant.storagePath}/${cleanPath}`;
  };
  
  /**
   * Carica un file nello storage del tenant
   * @param file File da caricare
   * @param path Percorso del file all'interno della cartella del tenant
   * @returns Promise con l'URL del file caricato
   */
  const uploadFile = async (file: File, path: string): Promise<string> => {
    if (!currentTenant) {
      throw new Error('Tenant non disponibile');
    }
    
    const tenantPath = getTenantFilePath(path);
    
    // In a real app, this would call Firebase Storage or another cloud storage service
    console.log(`Uploading file to ${tenantPath}`);
    
    // Per ora, simuliamo il caricamento
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Simuliamo un URL di storage
    return `https://storage.example.com/${tenantPath}/${file.name}`;
  };
  
  /**
   * Elimina un file dallo storage del tenant
   * @param filePath Percorso completo del file da eliminare
   * @returns Promise che si risolve quando il file è stato eliminato
   */
  const deleteFile = async (filePath: string): Promise<void> => {
    if (!currentTenant) {
      throw new Error('Tenant non disponibile');
    }
    
    // In a real app, this would call Firebase Storage or another cloud storage service
    console.log(`Deleting file ${filePath}`);
    
    // Per ora, simuliamo l'eliminazione
    await new Promise(resolve => setTimeout(resolve, 800));
  };
  
  /**
   * Ottiene l'URL di un file dallo storage del tenant
   * @param path Percorso del file all'interno della cartella del tenant
   * @returns Promise con l'URL del file
   */
  const getFileUrl = async (path: string): Promise<string> => {
    if (!currentTenant) {
      throw new Error('Tenant non disponibile');
    }
    
    const tenantPath = getTenantFilePath(path);
    
    // In a real app, this would call Firebase Storage or another cloud storage service
    console.log(`Getting URL for file ${tenantPath}`);
    
    // Per ora, simuliamo il recupero dell'URL
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Simuliamo un URL di storage
    return `https://storage.example.com/${tenantPath}`;
  };
  
  return {
    uploadFile,
    deleteFile,
    getFileUrl,
    getTenantFilePath
  };
};

export default useTenantStorage;
