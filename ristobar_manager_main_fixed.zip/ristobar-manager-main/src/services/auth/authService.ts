
import { supabase } from '@/integrations/supabase/client';
import { getToken, saveToken, revokeTokenLocal, isTokenRevoked } from './tokenService';
import { clearAllUserData } from '@/contexts/user/storageUtils';

// Constants
const SESSION_STORAGE_KEY = 'auth_token';
const LOCAL_STORAGE_KEY = 'auth_token';

class Auth {
  async login(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error('Login error:', error);
      throw error;
    }

    if (data.session) {
      saveToken(data.session.access_token);
    }

    return {
      user: data.user,
      token: data.session?.access_token,
    };
  }

  async loginWithGoogle() {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      if (error) {
        console.error('Google login error:', error);
        throw error;
      }

      return data;
    } catch (error) {
      console.error('Error during Google login:', error);
      throw error;
    }
  }

  async register(name: string, email: string, password: string, restaurantName: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          restaurantName,
        },
      },
    });

    if (error) {
      console.error('Registration error:', error);
      throw error;
    }

    return {
      user: data.user,
    };
  }

  async logout() {
    const { error } = await supabase.auth.signOut();

    if (error) {
      console.error('Logout error:', error);
      throw error;
    }

    clearAllUserData();
  }

  async getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  }

  async getSession() {
    return await supabase.auth.getSession();
  }

  saveToken(token: string): boolean {
    return saveToken(token);
  }

  getToken(): string | null {
    return getToken();
  }

  async revokeToken(token: string, userId?: string): Promise<void> {
    return revokeTokenLocal(token, userId);
  }

  isAuthenticated(): boolean {
    return !!getToken();
  }

  clearAllUserData() {
    clearAllUserData();
  }

  async restoreUserData(userId: string) {
    console.log(`Restoring user data for ${userId} from multiple sources`);
    
    try {
      // First try to get user data from Supabase for cross-browser sync
      const { data: userData, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) {
        console.warn("Could not fetch user data from Supabase:", error);
      } else if (userData) {
        console.log("Successfully retrieved user data from Supabase");
        
        // Save to local storage
        try {
          localStorage.setItem('userDataFromSupabase', JSON.stringify(userData));
        } catch (storageError) {
          console.warn("Error saving Supabase user data to localStorage:", storageError);
        }
      }
      
      // Try to get restaurant settings
      const { data: settingsData, error: settingsError } = await supabase
        .from('restaurant_settings')
        .select('*')
        .eq('tenant_id', userId)
        .single();
      
      if (!settingsError && settingsData) {
        console.log("Successfully retrieved restaurant settings from Supabase");
        
        // Save to local storage with user-specific key
        try {
          localStorage.setItem(`${userId}_restaurantInfo`, JSON.stringify(settingsData));
          localStorage.setItem(`${userId}_generalSettings`, settingsData.general_settings || '{}');
        } catch (storageError) {
          console.warn("Error saving restaurant settings to localStorage:", storageError);
        }
      }
      
      return true;
    } catch (error) {
      console.error("Error restoring user data:", error);
      return false;
    }
  }
  
  async logoutPreservingData() {
    try {
      const user = await this.getCurrentUser();
      
      if (user) {
        // First ensure data is synced to Supabase for cross-browser access
        try {
          // Save critical user preferences to Supabase
          const userPrefs = localStorage.getItem(`${user.id}_userPreferences`);
          const restaurantInfo = localStorage.getItem(`${user.id}_restaurantInfo`);
          const generalSettings = localStorage.getItem(`${user.id}_generalSettings`);
          
          if (userPrefs || restaurantInfo || generalSettings) {
            // Get the restaurant name from user metadata or use a default value
            const restaurantName = user.user_metadata?.restaurantName || '';
            
            await supabase
              .from('restaurant_settings')
              .upsert({
                tenant_id: user.id,
                restaurant_name: restaurantName,
                general_settings: generalSettings || '{}',
                updated_at: new Date().toISOString()
              })
              .eq('tenant_id', user.id);
              
            console.log("User settings successfully synced to Supabase for cross-browser access");
          }
          
          // Backup important localStorage items to sessionStorage
          const keysToBackup = [];
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith(`${user.id}_`)) {
              const value = localStorage.getItem(key);
              if (value) {
                sessionStorage.setItem(`backup_${key}`, value);
                keysToBackup.push(key);
              }
            }
          }
          
          if (keysToBackup.length > 0) {
            console.log(`Backed up ${keysToBackup.length} items to sessionStorage`);
          }
          
        } catch (syncError) {
          console.error("Error syncing data to Supabase before logout:", syncError);
        }
      }
      
      // Do a partial logout that preserves important data
      const token = getToken();
      if (token) {
        await revokeTokenLocal(token, user?.id);
      }
      
      // Only clear session data, not all user data
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      localStorage.removeItem('user');
      sessionStorage.removeItem('user');
      
      return true;
    } catch (error) {
      console.error("Error during preservation logout:", error);
      return false;
    }
  }

  clearAllUserDataService() {
    clearAllUserData();
  }
}

const AuthService = new Auth();
export default AuthService;
export { isTokenRevoked };
