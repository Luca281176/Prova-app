
// Questo file è mantenuto per compatibilità con il codice esistente
// ma ora utilizza solo Supabase per l'autenticazione

// Mock di Firebase Auth per mantenere la compatibilità con il codice esistente
export const auth = {
  currentUser: null,
  signOut: async () => Promise.resolve(),
  onAuthStateChange: () => {}
};

// Non serve più il provider Google di Firebase
export const googleProvider = {};
