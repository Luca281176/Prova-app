
import { supabase } from '@/integrations/supabase/client';
import { getToken, saveToken, revokeTokenLocal, isTokenRevoked } from './tokenService';
import { clearAllUserData } from '@/contexts/user/storageUtils';
import { restoreUserData, syncUserDataToSupabase } from './userDataService';

// Constants
const SESSION_STORAGE_KEY = 'auth_token';
const LOCAL_STORAGE_KEY = 'auth_token';

class Auth {
  async login(email: string, password: string) {
    // Clear any existing sessions before login
    try {
      await supabase.auth.signOut({ scope: 'global' });
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      localStorage.removeItem('supabase.auth.token');
      sessionStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('had_active_session');
    } catch (signOutError) {
      console.warn("Error clearing existing session before login:", signOutError);
    }
    
    // Slight delay to ensure session is cleared
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error('Login error:', error);
      throw error;
    }

    if (data.session) {
      saveToken(data.session.access_token);
    }

    return {
      user: data.user,
      token: data.session?.access_token,
    };
  }

  async loginWithGoogle() {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      if (error) {
        console.error('Google login error:', error);
        throw error;
      }

      return data;
    } catch (error) {
      console.error('Error during Google login:', error);
      throw error;
    }
  }

  async register(name: string, email: string, password: string, restaurantName: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          restaurantName,
        },
      },
    });

    if (error) {
      console.error('Registration error:', error);
      throw error;
    }

    return {
      user: data.user,
    };
  }

  async logout() {
    try {
      // Revoke the token if present
      const token = getToken();
      if (token) {
        await revokeTokenLocal(token);
      }
      
      // Sign out from Supabase with global scope to clear all sessions
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      
      if (error) {
        console.error('Supabase logout error:', error);
        throw error;
      }
      
      // Clear auth data
      clearAllUserData();
      
      // Remove additional session data
      localStorage.removeItem('supabase.auth.token');
      sessionStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('had_active_session');
      
      // Remove Supabase cookies
      document.cookie = "sb-access-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
      document.cookie = "sb-refresh-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
      
      return true;
    } catch (error) {
      console.error('Error during logout:', error);
      
      // Try a more aggressive cleanup if the normal logout fails
      try {
        localStorage.removeItem('auth_token');
        sessionStorage.removeItem('auth_token');
        localStorage.removeItem('supabase.auth.token');
        sessionStorage.removeItem('supabase.auth.token');
        localStorage.removeItem('had_active_session');
        
        // Remove Supabase cookies
        document.cookie = "sb-access-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
        document.cookie = "sb-refresh-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; secure; samesite=strict;";
      } catch (e) {
        console.error('Error during aggressive cleanup:', e);
      }
      
      throw error;
    }
  }

  async getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      // Get additional user information from Supabase
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', user.id)
          .single();
          
        if (!error && userData) {
          console.log("Enhanced user data retrieved from Supabase");
          // Save to localStorage for future access
          localStorage.setItem("user_data", JSON.stringify(userData));
          
          // Combine auth user with database user
          return {
            ...user,
            ...userData
          };
        }
      } catch (dbError) {
        console.warn("Error retrieving additional user data:", dbError);
      }
    }
    
    return user;
  }

  async getSession() {
    return await supabase.auth.getSession();
  }

  saveToken(token: string): boolean {
    return saveToken(token);
  }

  getToken(): string | null {
    return getToken();
  }

  async revokeToken(token: string, userId?: string): Promise<void> {
    return revokeTokenLocal(token, userId);
  }

  isAuthenticated(): boolean {
    // Check if there is a valid token
    const token = getToken();
    if (!token) return false;
    
    // Even if there's a token, check if we have an active Supabase session
    // This is async but we need a sync check, so we'll rely on the token check
    // and update the state asynchronously if needed
    this.validateSession();
    
    return true;
  }
  
  async validateSession(): Promise<boolean> {
    try {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        // If there's no session but we have a token, clear the token
        if (getToken()) {
          console.log('No active Supabase session, clearing token');
          localStorage.removeItem('auth_token');
          sessionStorage.removeItem('auth_token');
          return false;
        }
      }
      return !!data.session;
    } catch (e) {
      console.error('Error validating session:', e);
      return false;
    }
  }

  clearAllUserData() {
    clearAllUserData();
  }

  async restoreUserData(userId: string) {
    return await restoreUserData(userId);
  }
  
  async logoutPreservingData() {
    try {
      const user = await this.getCurrentUser();
      
      if (user) {
        // First ensure data is synced to Supabase for cross-browser access
        await syncUserDataToSupabase(user.id);
      }
      
      // Do a partial logout that preserves important data
      const token = getToken();
      if (token) {
        await revokeTokenLocal(token, user?.id);
      }
      
      // Only clear session data, not all user data
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      localStorage.removeItem('user');
      sessionStorage.removeItem('user');
      
      return true;
    } catch (error) {
      console.error("Error during preservation logout:", error);
      return false;
    }
  }

  clearAllUserDataService() {
    clearAllUserData();
  }
}

const AuthService = new Auth();
export default AuthService;
export { isTokenRevoked };
