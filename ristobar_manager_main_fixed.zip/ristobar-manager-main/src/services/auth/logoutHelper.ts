
import { supabase } from '@/integrations/supabase/client';

export async function logoutUser() {
  try {
    // Sign out from Supabase
    await supabase.auth.signOut();
    
    // Clear all session storage
    localStorage.removeItem('supabase-session');
    localStorage.removeItem('supabase.auth.token');
    sessionStorage.removeItem('supabase-session-backup');
    
    return true;
  } catch (error) {
    console.error('Error during logout:', error);
    
    // Even if there's an error, try to clear storage
    try {
      localStorage.removeItem('supabase-session');
      localStorage.removeItem('supabase.auth.token');
      sessionStorage.removeItem('supabase-session-backup');
    } catch (e) {
      console.error('Error clearing storage during logout:', e);
    }
    
    return false;
  }
}
