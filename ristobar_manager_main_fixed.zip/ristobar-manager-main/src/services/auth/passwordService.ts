
// Lista nera di password comuni
const COMMON_PASSWORDS = [
  'password', 'password123', '123456', 'qwerty', 'admin', 'welcome',
  'admin123', '12345678', 'football', 'iloveyou', 'baseball', 'abc123'
];

/**
 * Verifica la robustezza della password
 * @param password Password da verificare
 * @returns Oggetto con informazioni sulla validità della password
 */
export function passwordStrength(password: string): { isValid: boolean; message: string } {
  if (!password || password.length < 8) {
    return { isValid: false, message: 'La password deve contenere almeno 8 caratteri' };
  }
  
  if (COMMON_PASSWORDS.includes(password.toLowerCase())) {
    return { isValid: false, message: 'La password è troppo comune. Scegli una password più sicura' };
  }

  // Verifica requisiti di complessità
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumbers = /\d/.test(password);
  const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
  
  if (!(hasUpperCase && hasLowerCase && hasNumbers)) {
    return { 
      isValid: false, 
      message: 'La password deve contenere almeno una lettera maiuscola, una minuscola e un numero' 
    };
  }
  
  if (!hasSpecial) {
    return { 
      isValid: false, 
      message: 'La password deve contenere almeno un carattere speciale (!@#$%^&*.,?)' 
    };
  }
  
  return { isValid: true, message: 'Password valida' };
}
