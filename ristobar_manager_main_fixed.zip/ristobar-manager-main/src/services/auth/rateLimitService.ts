
// Rate limiting per protezione brute force
// In un'applicazione di produzione, questo dovrebbe essere implementato a livello server
// ma qui lo implementiamo lato client come dimostrazione
export type LoginAttempt = {
  count: number;
  lastAttempt: number;
  blocked: boolean;
  blockUntil: number;
};

// Costanti di configurazione
export const MAX_LOGIN_ATTEMPTS = 5;
export const BLOCK_TIME = 15 * 60 * 1000; // 15 minuti
export const ATTEMPT_WINDOW = 60 * 60 * 1000; // 1 ora

const loginAttempts: Record<string, LoginAttempt> = {};

/**
 * Hashing dell'email per l'utilizzo come chiave nelle rate limit
 * @param email Email da hashare
 * @returns Stringa hashata
 */
export function hashEmail(email: string): string {
  // Implementazione semplice per demo, in produzione usare un vero algoritmo di hashing
  let hash = 0;
  for (let i = 0; i < email.length; i++) {
    const char = email.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0; // Converte in intero a 32 bit
  }
  return hash.toString(16);
}

/**
 * Verifica se un utente è bloccato per troppi tentativi
 * @param email Email dell'utente
 * @returns Informazioni sul blocco
 */
export function checkRateLimit(email: string): { 
  blocked: boolean; 
  remainingTime: number; 
  attemptsLeft: number;
} {
  const now = Date.now();
  const emailHash = hashEmail(email);
  
  if (!loginAttempts[emailHash]) {
    loginAttempts[emailHash] = { count: 0, lastAttempt: now, blocked: false, blockUntil: 0 };
  }
  
  const attempt = loginAttempts[emailHash];
  
  // Verifica se l'account è bloccato
  if (attempt.blocked) {
    if (now < attempt.blockUntil) {
      return {
        blocked: true,
        remainingTime: attempt.blockUntil - now,
        attemptsLeft: 0
      };
    } else {
      // Sblocca l'account se il tempo di blocco è passato
      attempt.blocked = false;
      attempt.count = 0;
    }
  }
  
  // Resetta il conteggio dei tentativi se è passato il tempo di finestra
  if (now - attempt.lastAttempt > ATTEMPT_WINDOW) {
    attempt.count = 0;
  }
  
  // Aggiorna il timestamp dell'ultimo tentativo
  attempt.lastAttempt = now;
  
  return {
    blocked: false,
    remainingTime: 0,
    attemptsLeft: MAX_LOGIN_ATTEMPTS - attempt.count
  };
}

/**
 * Incrementa il contatore dei tentativi di login falliti
 * @param email Email dell'utente
 */
export function incrementLoginAttempts(email: string): void {
  const now = Date.now();
  const emailHash = hashEmail(email);
  
  if (!loginAttempts[emailHash]) {
    loginAttempts[emailHash] = { count: 0, lastAttempt: now, blocked: false, blockUntil: 0 };
  }
  
  const attempt = loginAttempts[emailHash];
  attempt.count++;
  attempt.lastAttempt = now;
  
  // Blocca l'account dopo troppi tentativi
  if (attempt.count >= MAX_LOGIN_ATTEMPTS) {
    attempt.blocked = true;
    attempt.blockUntil = now + BLOCK_TIME;
  }
}

/**
 * Resetta il contatore dei tentativi di login
 * @param email Email dell'utente
 */
export function resetLoginAttempts(email: string): void {
  const emailHash = hashEmail(email);
  
  if (loginAttempts[emailHash]) {
    loginAttempts[emailHash].count = 0;
    loginAttempts[emailHash].blocked = false;
  }
}
