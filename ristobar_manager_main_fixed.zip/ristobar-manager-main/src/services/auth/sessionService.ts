
import { auth } from './config';
import { supabase } from '@/integrations/supabase/client';
import { getRegisteredUserData } from './utilsService';
import { isTokenRevoked, getTokenAsync } from './tokenService';

/**
 * Verifica se l'utente è autenticato
 * @returns true se l'utente è autenticato
 */
export async function isAuthenticated(): Promise<boolean> {
  try {
    // Verifica la sessione con Supabase (priorità principale)
    const { data } = await supabase.auth.getSession();
    
    if (data.session) {
      // Verifica anche che il token non sia nella lista dei revocati
      const token = data.session.access_token;
      if (token && !(await isTokenRevoked(token))) {
        return true;
      }
    }
    
    // Check for token in localStorage/sessionStorage using the async method
    const token = await getTokenAsync();
    if (token && !(await isTokenRevoked(token))) {
      return true;
    }
    
    // Se non c'è una sessione valida, controlla sessionStorage
    const sessionData = getRegisteredUserData();
    return !!sessionData;
  } catch (error) {
    console.error('Errore nel controllo della sessione:', error);
    return false;
  }
}
