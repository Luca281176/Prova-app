
import { supabase } from '@/integrations/supabase/client';
import { syncRevokedToken } from '@/integrations/supabase/tokenSync';

/**
 * Salva un token revocato nel database Supabase
 * @param token Token da revocare
 * @param userId ID dell'utente associato al token (opzionale)
 * @returns Promise<boolean> True se il salvataggio è avvenuto con successo
 */
export async function saveRevokedTokenToSupabase(token: string, userId?: string): Promise<boolean> {
  return await syncRevokedToken(token, userId);
}

/**
 * Verifica se un token è stato revocato controllando il database Supabase
 * @param token Token da verificare
 * @returns Promise<boolean> True se il token è stato revocato
 */
export async function isTokenRevokedInSupabase(token: string): Promise<boolean> {
  try {
    if (!token) return true; // Consideriamo un token vuoto come revocato

    // Crea un hash del token per la ricerca
    const tokenHash = await createTokenHash(token);

    const { data, error } = await supabase
      .from('revoked_tokens')
      .select('*')
      .eq('token_hash', tokenHash)
      .single();

    if (error) {
      // Se l'errore è "No rows found", significa che il token non è revocato
      if (error.code === 'PGRST116') {
        return false;
      }
      
      console.error('Errore durante la verifica del token revocato:', error);
      // In caso di errore, meglio essere sicuri e considerare il token come valido
      return false;
    }

    return !!data;
  } catch (error) {
    console.error('Errore imprevisto durante la verifica del token:', error);
    // In caso di errore, meglio essere sicuri e considerare il token come valido
    return false;
  }
}

/**
 * Crea un hash del token per non salvare il token completo nel database
 * @param token Token da hashare
 * @returns Promise<string> Hash del token
 */
async function createTokenHash(token: string): Promise<string> {
  // Utilizziamo un algoritmo di hashing semplice per l'esempio
  // In produzione, utilizzare un algoritmo più robusto come bcrypt
  const encoder = new TextEncoder();
  const data = encoder.encode(token);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

/**
 * Pulisce i token revocati scaduti dal database
 * @returns Promise<boolean> True se la pulizia è avvenuta con successo
 */
export async function cleanupExpiredTokens(): Promise<boolean> {
  try {
    const now = new Date().toISOString();
    
    const { error } = await supabase
      .from('revoked_tokens')
      .delete()
      .lt('expires_at', now);

    if (error) {
      console.error('Errore durante la pulizia dei token scaduti:', error);
      return false;
    }

    console.log('Pulizia dei token scaduti completata con successo');
    return true;
  } catch (error) {
    console.error('Errore imprevisto durante la pulizia dei token:', error);
    return false;
  }
}

/**
 * Revoca tutti i token di un utente
 * @param userId ID dell'utente
 * @returns Promise<boolean> True se la revoca è avvenuta con successo
 */
export async function revokeAllUserTokens(userId: string): Promise<boolean> {
  try {
    if (!userId) {
      console.warn('Tentativo di revocare i token di un utente senza ID');
      return false;
    }

    // Ottiene la sessione corrente
    const { data: { session } } = await supabase.auth.getSession();
    
    // Se c'è una sessione attiva, revoca anche il token corrente
    if (session?.access_token) {
      await saveRevokedTokenToSupabase(session.access_token, userId);
    }

    // Rigenera il JWT token dell'utente tramite Supabase Auth
    // Questo invalida tutti i token precedenti
    const { error } = await supabase.auth.refreshSession();

    if (error) {
      console.error('Errore durante il refresh della sessione:', error);
      return false;
    }

    console.log('Tutti i token dell\'utente sono stati revocati con successo');
    return true;
  } catch (error) {
    console.error('Errore imprevisto durante la revoca di tutti i token:', error);
    return false;
  }
}
