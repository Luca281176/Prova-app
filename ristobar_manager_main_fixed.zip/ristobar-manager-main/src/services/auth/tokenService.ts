
import { revokeToken as supabaseRevokeToken } from '@/integrations/supabase/client';
import { saveRevokedTokenToSupabase, isTokenRevokedInSupabase } from './supabaseTokenService';
import { supabase } from '@/integrations/supabase/client';

// In-memory cache of revoked tokens
const revokedTokens = new Set<string>();

// Load revoked tokens from localStorage
try {
  const storedTokens = localStorage.getItem('revoked_tokens');
  if (storedTokens) {
    const tokens = JSON.parse(storedTokens);
    tokens.forEach((token: string) => {
      revokedTokens.add(token);
    });
    console.log(`Loaded ${tokens.length} revoked tokens from localStorage`);
  }
} catch (error) {
  console.warn('Error loading revoked tokens from localStorage:', error);
}

// Token interface
export interface AuthToken {
  token: string;
  expiresAt: number;
}

/**
 * Saves the JWT token to both localStorage and sessionStorage for redundancy
 * @param token JWT token
 */
export function saveToken(token: string): boolean {
  try {
    // Set expiration to 30 minutes (more secure than the previous 24 hours)
    const expiresAt = Date.now() + 30 * 60 * 1000;
    
    const authToken: AuthToken = {
      token,
      expiresAt
    };
    
    const tokenData = JSON.stringify(authToken);
    
    // Try to save in localStorage first
    try {
      localStorage.setItem('auth_token', tokenData);
    } catch (localError) {
      console.warn('Error saving token to localStorage:', localError);
    }
    
    // Also try to save in sessionStorage as backup
    try {
      sessionStorage.setItem('auth_token', tokenData);
    } catch (sessionError) {
      console.warn('Error saving token to sessionStorage:', sessionError);
    }
    
    return true;
  } catch (error) {
    console.error('Error saving token:', error);
    return false;
  }
}

/**
 * Gets the JWT token
 * @returns JWT token or null
 */
export function getToken(): string | null {
  try {
    // Check for token in localStorage and sessionStorage
    // Since getSession() is async, we don't use it in this synchronous function
    
    // First check localStorage
    let authTokenStr = localStorage.getItem('auth_token');
    
    // If not in localStorage, try sessionStorage
    if (!authTokenStr) {
      try {
        authTokenStr = sessionStorage.getItem('auth_token');
      } catch (sessionError) {
        console.warn('Error getting token from sessionStorage:', sessionError);
      }
    }
    
    if (!authTokenStr) return null;
    
    try {
      const authToken: AuthToken = JSON.parse(authTokenStr);
      
      // Check if token is expired
      if (authToken.expiresAt < Date.now()) {
        localStorage.removeItem('auth_token');
        sessionStorage.removeItem('auth_token');
        return null;
      }
      
      // Check if token is revoked in memory
      if (revokedTokens.has(authToken.token)) {
        localStorage.removeItem('auth_token');
        sessionStorage.removeItem('auth_token');
        return null;
      }
      
      return authToken.token;
    } catch (error) {
      console.error('Error parsing token:', error);
      localStorage.removeItem('auth_token');
      sessionStorage.removeItem('auth_token');
      return null;
    }
  } catch (error) {
    console.error('Error getting token:', error);
    return null;
  }
}

/**
 * Gets the JWT token asynchronously, also checking Supabase session
 * @returns Promise resolving to JWT token or null
 */
export async function getTokenAsync(): Promise<string | null> {
  try {
    // Check first for Supabase session
    const { data: sessionData } = await supabase.auth.getSession();
    if (sessionData && sessionData.session?.access_token) {
      return sessionData.session.access_token;
    }
    
    // If no Supabase session, use the synchronous getToken function
    return getToken();
  } catch (error) {
    console.error('Error getting token asynchronously:', error);
    return getToken(); // Fallback to synchronous method
  }
}

/**
 * Revokes a JWT token both in memory and in the database
 * @param token JWT token to revoke
 * @param userId ID of the user associated with the token (optional)
 */
export async function revokeTokenLocal(token: string, userId?: string): Promise<void> {
  // Add token to the revoked list in memory
  revokedTokens.add(token);
  
  // Store in localStorage
  try {
    const storedTokens = localStorage.getItem('revoked_tokens');
    const tokens = storedTokens ? JSON.parse(storedTokens) : [];
    if (!tokens.includes(token)) {
      tokens.push(token);
      localStorage.setItem('revoked_tokens', JSON.stringify(tokens));
    }
  } catch (error) {
    console.warn('Error storing revoked token in localStorage:', error);
  }
  
  // Revoke token in Supabase (client.ts)
  supabaseRevokeToken(token);
  
  // Save the revoked token to the Supabase database
  try {
    await saveRevokedTokenToSupabase(token, userId);
  } catch (error) {
    console.error('Error saving revoked token to Supabase:', error);
  }
}

/**
 * Checks if a token is revoked
 * @param token Token to check
 * @returns Promise<boolean> True if the token is revoked
 */
export async function isTokenRevoked(token: string): Promise<boolean> {
  // Check in memory first (faster)
  if (revokedTokens.has(token)) {
    return true;
  }
  
  // If not in memory, check in the database
  try {
    const isRevokedInDb = await isTokenRevokedInSupabase(token);
    
    // If the token is revoked in the database, add it to memory as well
    if (isRevokedInDb) {
      revokedTokens.add(token);
      
      // Also store in localStorage
      try {
        const storedTokens = localStorage.getItem('revoked_tokens');
        const tokens = storedTokens ? JSON.parse(storedTokens) : [];
        if (!tokens.includes(token)) {
          tokens.push(token);
          localStorage.setItem('revoked_tokens', JSON.stringify(tokens));
        }
      } catch (error) {
        console.warn('Error storing revoked token in localStorage:', error);
      }
    }
    
    return isRevokedInDb;
  } catch (error) {
    console.error('Error checking revoked token:', error);
    // In case of error, for security consider the token as valid
    return false;
  }
}

/**
 * Checks if a token is revoked (synchronous version, memory only)
 * @param token Token to check
 * @returns boolean true if the token is revoked in memory
 */
export function isTokenRevokedSync(token: string): boolean {
  return revokedTokens.has(token);
}
