
import { User } from '@/contexts/user/types';

// Interfaccia per la risposta di login
export interface LoginResponse {
  user: User;
  token: string;
  tenant: {
    id: string;
    name: string;
    slug: string;
    schema_name: string;
    storage_path: string;
  }
}

// Interfaccia per la risposta di registrazione
export interface RegisterResponse extends LoginResponse {}
