
import { supabase } from '@/integrations/supabase/client';
import { clearAllUserData } from '@/contexts/user/storageUtils';

/**
 * Restores user data from Supabase
 * @param userId User ID to restore data for
 * @returns Promise<boolean> True if restoration was successful
 */
export async function restoreUserData(userId: string): Promise<boolean> {
  console.log(`Restoring user data for ${userId} from multiple sources, FORCING SUPABASE RETRIEVAL`);
  
  try {
    // Force retrieval of user data from Supabase for cross-browser sync
    const { data: userData, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) {
      console.warn("Could not fetch user data from Supabase:", error);
    } else if (userData) {
      console.log("Successfully retrieved user data from Supabase");
      
      // Save to local storage and sessionStorage
      try {
        localStorage.setItem('userDataFromSupabase', JSON.stringify(userData));
        localStorage.setItem('user_data', JSON.stringify(userData));
        sessionStorage.setItem('user_data', JSON.stringify(userData));
      } catch (storageError) {
        console.warn("Error saving Supabase user data to localStorage:", storageError);
      }
    }
    
    // Try to get restaurant settings
    const { data: settingsData, error: settingsError } = await supabase
      .from('restaurant_settings')
      .select('*')
      .eq('tenant_id', userId)
      .single();
    
    if (!settingsError && settingsData) {
      console.log("Successfully retrieved restaurant settings from Supabase");
      
      // Save to local storage with user-specific key
      try {
        localStorage.setItem(`${userId}_restaurantInfo`, JSON.stringify(settingsData));
        
        if (settingsData.general_settings) {
          const generalSettingsStr = typeof settingsData.general_settings === 'string' 
            ? settingsData.general_settings 
            : JSON.stringify(settingsData.general_settings);
          
          localStorage.setItem(`${userId}_generalSettings`, generalSettingsStr);
          localStorage.setItem(`${userId}_userPreferences`, generalSettingsStr);
        }
        
        if (settingsData.restaurant_name) {
          localStorage.setItem(`${userId}_restaurantName`, settingsData.restaurant_name);
        }
        
        if (settingsData.restaurant_logo) {
          localStorage.setItem(`${userId}_restaurantLogo`, settingsData.restaurant_logo);
        }
      } catch (storageError) {
        console.warn("Error saving restaurant settings to localStorage:", storageError);
      }
    }
    
    // Get all restaurant_data entries for this user
    const { data: restaurantData, error: dataError } = await supabase
      .from('restaurant_data')
      .select('data_type, data, version')
      .eq('tenant_id', userId)
      .eq('is_deleted', false);
      
    if (!dataError && restaurantData && restaurantData.length > 0) {
      console.log(`Found ${restaurantData.length} data items in restaurant_data`);
      
      // Process each data item
      for (const item of restaurantData) {
        try {
          const { data_type, data, version } = item;
          
          if (data_type && data) {
            // Store with user-specific key
            const storageKey = `${userId}_${data_type}`;
            const jsonData = typeof data === 'string' ? data : JSON.stringify(data);
            
            console.log(`Restoring data for ${data_type} (version: ${version})`);
            
            // Save to localStorage
            localStorage.setItem(storageKey, jsonData);
            
            try {
              sessionStorage.setItem(storageKey, jsonData);
            } catch (sessionError) {
              // Ignore session storage errors
            }
          }
        } catch (itemError) {
          console.warn(`Error processing data item:`, itemError);
        }
      }
      
      console.log(`Successfully restored user data from restaurant_data table`);
    }
    
    return true;
  } catch (error) {
    console.error("Error restoring user data:", error);
    return false;
  }
}

/**
 * Clears all user related data from storage
 */
export function clearUserData() {
  clearAllUserData();
}

/**
 * Sync user data to Supabase for cross-browser access
 * @param userId User ID to sync data for
 * @returns Promise<boolean> True if sync was successful
 */
export async function syncUserDataToSupabase(userId: string): Promise<boolean> {
  try {
    // Save critical user preferences to Supabase
    const userPrefs = localStorage.getItem(`${userId}_userPreferences`);
    const restaurantInfo = localStorage.getItem(`${userId}_restaurantInfo`);
    const generalSettings = localStorage.getItem(`${userId}_generalSettings`);
    
    if (userPrefs || restaurantInfo || generalSettings) {
      // Get the restaurant name from localStorage or use a default value
      const restaurantName = localStorage.getItem(`${userId}_restaurantName`) || '';
      
      await supabase
        .from('restaurant_settings')
        .upsert({
          tenant_id: userId,
          restaurant_name: restaurantName,
          general_settings: generalSettings || '{}',
          updated_at: new Date().toISOString()
        })
        .eq('tenant_id', userId);
        
      console.log("User settings successfully synced to Supabase for cross-browser access");
    }
    
    // Loop through all localStorage keys for this user and sync appropriate ones to restaurant_data
    const keysToSync = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(`${userId}_`) && 
          !key.includes('userPreferences') && 
          !key.includes('generalSettings') && 
          !key.includes('restaurantInfo') && 
          !key.includes('restaurantName') && 
          !key.includes('auth')) {
        
        try {
          const dataType = key.replace(`${userId}_`, '');
          const data = localStorage.getItem(key);
          
          if (data) {
            await supabase
              .from('restaurant_data')
              .upsert({
                tenant_id: userId,
                data_type: dataType,
                data: JSON.parse(data),
                updated_at: new Date().toISOString()
              }, { onConflict: 'tenant_id, data_type' });
              
            keysToSync.push(dataType);
          }
        } catch (keyError) {
          console.warn(`Error syncing key ${key} to restaurant_data:`, keyError);
        }
      }
    }
    
    if (keysToSync.length > 0) {
      console.log(`Synced ${keysToSync.join(', ')} to restaurant_data`);
    }
    
    return true;
  } catch (error) {
    console.error("Error syncing data to Supabase:", error);
    return false;
  }
}

/**
 * Migrate local storage data to the new format
 * @param userId User ID to migrate data for
 * @returns Promise<boolean> True if migration was successful
 */
export async function migrateLocalStorageData(userId: string): Promise<boolean> {
  try {
    // Look for old format data
    const oldUserData = localStorage.getItem('user_data');
    
    if (oldUserData) {
      try {
        // Parse the old data
        const userData = JSON.parse(oldUserData);
        
        // Store with new user-specific key format
        localStorage.setItem(`${userId}_userData`, oldUserData);
        
        console.log("Migrated user_data to new format with user-specific key");
      } catch (parseError) {
        console.warn("Error parsing old user_data:", parseError);
      }
    }
    
    // Look for other common data that might need migration
    const oldKeys = [
      'restaurantSettings', 
      'menuCategories', 
      'menuItems', 
      'tables', 
      'rooms'
    ];
    
    for (const key of oldKeys) {
      const oldData = localStorage.getItem(key);
      if (oldData) {
        try {
          // Store with new user-specific key format
          localStorage.setItem(`${userId}_${key}`, oldData);
          console.log(`Migrated ${key} to new format with user-specific key`);
        } catch (migrationError) {
          console.warn(`Error migrating ${key}:`, migrationError);
        }
      }
    }
    
    return true;
  } catch (error) {
    console.error("Error during localStorage migration:", error);
    return false;
  }
}

/**
 * Retrieves user data from localStorage with user-specific key
 * @param userId User ID
 * @param dataType Data type to get
 * @returns Data object or null
 */
export function getUserData(userId: string, dataType: string): any {
  try {
    const storageKey = `${userId}_${dataType}`;
    const data = localStorage.getItem(storageKey);
    
    if (!data) return null;
    
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error getting ${dataType} for user ${userId}:`, error);
    return null;
  }
}
