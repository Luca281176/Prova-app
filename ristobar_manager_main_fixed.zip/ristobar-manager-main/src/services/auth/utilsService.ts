
/**
 * Genera uno slug dal nome del ristorante
 * @param name Nome del ristorante
 * @returns Slug generato
 */
export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^\w\s]/gi, '')
    .replace(/\s+/g, '-');
}

/**
 * Ottiene i dati dell'utente appena registrato
 * @returns Dati dell'utente registrato o null
 */
export function getRegisteredUserData(): { user: any, token: string, tenant: any } | null {
  try {
    const sessionData = sessionStorage.getItem('registered_user');
    if (!sessionData) return null;
    
    return JSON.parse(sessionData);
  } catch (error) {
    console.error('Errore nel recupero dei dati di registrazione:', error);
    return null;
  }
}

/**
 * Rimuove i dati dell'utente appena registrato
 */
export function clearRegisteredUserData(): void {
  try {
    sessionStorage.removeItem('registered_user');
  } catch (error) {
    console.error('Errore nella pulizia dei dati di registrazione:', error);
  }
}
