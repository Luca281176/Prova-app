
import { supabase } from '@/config/supabase';

export async function getUserSession() {
    const { data, error } = await supabase.auth.getSession();
    if (error) {
        console.error("❌ Errore nel recupero della sessione:", error);
        return null;
    }
    return data.session;
}

export async function refreshUserSession() {
    try {
        const { data, error } = await supabase.auth.refreshSession();
        if (error) {
            console.error("⚠️ Errore durante il refresh della sessione:", error);
            return null;
        }
        return data.session;
    } catch (err) {
        console.error("❌ Errore critico nel refresh della sessione:", err);
        return null;
    }
}

export async function logoutUser() {
    await supabase.auth.signOut();
    console.log("✅ Utente disconnesso con successo!");
}
