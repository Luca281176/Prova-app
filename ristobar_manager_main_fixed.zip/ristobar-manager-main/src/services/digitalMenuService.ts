
import { Category, Dish, loadMenuData, loadMenuSettings, updateDish } from './menuService';
import { getRestaurantInfoSync } from '@/components/cashier/bill/RestaurantInfoProvider';
import { realtimeSync } from '@/contexts/user/storage/sync/realtimeSync';
import { DataSyncWorker } from '@/contexts/user/storage/DataSyncWorker';

/**
 * Loads menu data specifically for the digital menu view
 * This filters out any dishes that have been marked as not visible
 * and applies the menu settings for visibility
 */
export const loadDigitalMenuData = (): Category[] => {
  const menuData = loadMenuData();
  const menuSettings = loadMenuSettings();
  const customization = menuSettings.customization || {};
  
  console.log("[digitalMenuService] Filtering menu data for digital menu");
  console.log("[digitalMenuService] Using customization settings:", customization);
  
  // Check if we should show unavailable dishes
  const showUnavailable = customization.visibility?.unavailable === true;
  
  // Filter out hidden dishes (explicitly checking visible === true)
  // and unavailable dishes if showUnavailable is false
  const filteredMenu = menuData.map(category => ({
    ...category,
    dishes: category.dishes.filter(dish => {
      const isVisible = dish.visible !== false; // Default to visible if not explicitly set
      const isAvailable = dish.available === true;
      
      // Show the dish if:
      // 1. It's marked as visible AND
      // 2. Either it's available OR we're showing unavailable dishes
      return isVisible && (isAvailable || showUnavailable);
    })
  }));
  
  // Also filter out empty categories
  const nonEmptyCategories = filteredMenu.filter(category => category.dishes.length > 0);
  
  console.log(
    "[digitalMenuService] Digital menu contains",
    nonEmptyCategories.reduce((total, cat) => total + cat.dishes.length, 0),
    "visible dishes across",
    nonEmptyCategories.length,
    "categories"
  );
  
  return nonEmptyCategories;
};

/**
 * Gets restaurant information specifically for digital menu display
 * Ensures all required restaurant information is included
 * and applies any custom info from the menu settings
 */
export const getDigitalMenuRestaurantInfo = () => {
  console.log("[digitalMenuService] Loading restaurant info for digital menu");
  
  // Use the synchronous version of getRestaurantInfo
  const restaurantInfo = getRestaurantInfoSync();
  
  // Get any custom information from menu settings
  const menuSettings = loadMenuSettings();
  const customization = menuSettings.customization || {};
  
  console.log("[digitalMenuService] Restaurant info from settings:", customization);
  console.log("[digitalMenuService] Default restaurant info:", restaurantInfo);
  
  // Return merged information, prioritizing custom values
  return {
    name: customization.title || restaurantInfo.name || "Ristorante",
    address: customization.address || restaurantInfo.address || "",
    phone: customization.phone || restaurantInfo.phone || "",
    vat: customization.vat || restaurantInfo.vat || "",
    email: customization.email || restaurantInfo.email || "",
    website: customization.website || restaurantInfo.website || "",
    description: customization.description || restaurantInfo.description || "",
    openingHours: customization.openingHours || restaurantInfo.openingHours || "",
    logo: restaurantInfo.logo || "", // Logo is always from restaurantInfo for now
    
    // Include all customization settings to ensure they're available to the menu
    primaryColor: customization.primaryColor,
    accentColor: customization.accentColor,
    showLogo: customization.showLogo,
    headerVisibility: customization.headerVisibility || {},
    visibility: customization.visibility || {}
  };
};

/**
 * Update dish visibility in the digital menu
 */
export const updateDishVisibility = (
  categoryId: string, 
  dishId: string, 
  isVisible: boolean
): boolean => {
  try {
    const result = updateDish(categoryId, dishId, { visible: isVisible });
    return result !== null;
  } catch (error) {
    console.error("[digitalMenuService] Error updating dish visibility:", error);
    return false;
  }
};

/**
 * Check QR code settings existence and validity
 */
export const validateQrCodeSettings = () => {
  try {
    // This would verify that QR code settings exist and are valid
    const menuSettingsStr = localStorage.getItem('risto_menu_settings');
    if (!menuSettingsStr) return false;
    
    const menuSettings = JSON.parse(menuSettingsStr);
    return (
      menuSettings && 
      menuSettings.qrSettings && 
      menuSettings.qrSettings.generated && 
      menuSettings.qrSettings.url
    );
  } catch (error) {
    console.error("[digitalMenuService] Error validating QR code settings:", error);
    return false;
  }
};

/**
 * Save menu settings and broadcast the change to all connected devices
 * @param settings The menu settings to save
 */
export const saveMenuSettings = (settings: any) => {
  try {
    localStorage.setItem('risto_menu_settings', JSON.stringify(settings));
    
    // Dispatch an event that other tabs/components can listen for
    const event = new CustomEvent('menu-settings-updated', { detail: settings });
    window.dispatchEvent(event);
    
    // Also synchronize to server for cross-device access
    if (settings && settings.tenantId) {
      try {
        const syncWorker = DataSyncWorker.getInstance();
        syncWorker.forceSyncNow().then(() => {
          console.log("[digitalMenuService] Menu settings synchronized to server");
        });
      } catch (e) {
        console.warn("[digitalMenuService] Error during server sync:", e);
      }
    }
    
    console.log("[digitalMenuService] Menu settings saved and broadcast", settings);
    return true;
  } catch (error) {
    console.error("[digitalMenuService] Error saving menu settings:", error);
    return false;
  }
};

/**
 * Set up realtime sync for menu settings changes
 * @param tenantId The tenant ID to subscribe to changes for
 * @param onDataChange Callback when data changes
 */
export const setupMenuSettingsSync = (tenantId: string, onDataChange: (settings: any) => void) => {
  if (!tenantId) {
    console.warn("[digitalMenuService] Cannot set up sync without tenant ID");
    return null;
  }
  
  console.log("[digitalMenuService] Setting up realtime sync for menu settings");
  
  // Set up a local storage event listener for changes in the same browser
  const handleStorageChange = (event: StorageEvent) => {
    if (event.key === 'risto_menu_settings' && event.newValue) {
      try {
        const settings = JSON.parse(event.newValue);
        onDataChange(settings);
        console.log("[digitalMenuService] Menu settings updated from localStorage event");
      } catch (e) {
        console.error("[digitalMenuService] Error parsing menu settings from storage event:", e);
      }
    }
  };
  
  // Set up a custom event listener for changes in the same tab
  const handleCustomEvent = (event: CustomEvent) => {
    onDataChange(event.detail);
    console.log("[digitalMenuService] Menu settings updated from custom event");
  };
  
  window.addEventListener('storage', handleStorageChange);
  window.addEventListener('menu-settings-updated', handleCustomEvent as EventListener);
  
  // Also set up the DataSyncWorker for cross-device sync
  try {
    const syncWorker = DataSyncWorker.getInstance();
    
    // Schedule regular sync checks for menu settings
    const syncInterval = setInterval(() => {
      syncWorker.forceSyncNow().then(() => {
        console.log("[digitalMenuService] Periodic menu settings sync completed");
      });
    }, 30000); // Check every 30 seconds
    
    // Set up Supabase realtime subscription for cross-device sync
    const channel = realtimeSync.subscribeToRestaurantData(
      tenantId,
      (dataType, newData) => {
        if (dataType === 'menuSettings' && newData) {
          // Update local storage with the new data
          localStorage.setItem('risto_menu_settings', JSON.stringify(newData));
          
          // Notify the callback
          onDataChange(newData);
          console.log("[digitalMenuService] Menu settings updated from Supabase realtime");
        }
      }
    );
    
    // Return a cleanup function
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('menu-settings-updated', handleCustomEvent as EventListener);
      clearInterval(syncInterval);
      
      if (channel) {
        realtimeSync.unsubscribeChannel(channel);
      }
    };
  } catch (e) {
    console.warn("[digitalMenuService] Error setting up DataSyncWorker:", e);
    
    // Return a cleanup function for the event listeners only
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('menu-settings-updated', handleCustomEvent as EventListener);
    };
  }
};
