
import { 
  InventoryItem, 
  Supplier, 
  InventoryOrder, 
  InventoryNotification,
  OrderStatus,
  NotificationType
} from '@/contexts/InventoryContext';

// Local storage keys
const INVENTORY_ITEMS_KEY = 'inventory_items';
const INVENTORY_SUPPLIERS_KEY = 'inventory_suppliers';
const INVENTORY_ORDERS_KEY = 'inventory_orders';
const INVENTORY_NOTIFICATIONS_KEY = 'inventory_notifications';

// Helper to generate unique IDs
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Initialize or get data from localStorage with fallback to initial data
const getStoredData = <T>(key: string, initialData: T[]): T[] => {
  try {
    const storedData = localStorage.getItem(key);
    if (storedData) {
      return JSON.parse(storedData);
    }
    // Store initial data if not found
    localStorage.setItem(key, JSON.stringify(initialData));
    return initialData;
  } catch (error) {
    console.error(`Error retrieving data for ${key}:`, error);
    return initialData;
  }
};

// Save data to localStorage
const saveToStorage = <T>(key: string, data: T[]): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    // Dispatch an event to notify other tabs/windows
    window.dispatchEvent(new CustomEvent('inventory-updated', { detail: { key } }));
  } catch (error) {
    console.error(`Error saving data for ${key}:`, error);
  }
};

// Inventory Items operations
export const getInventoryItems = async (initialData: InventoryItem[]): Promise<InventoryItem[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const items = getStoredData(INVENTORY_ITEMS_KEY, initialData);
      resolve(items);
    }, 500);
  });
};

export const addInventoryItem = async (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>): Promise<InventoryItem> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const items = getStoredData<InventoryItem>(INVENTORY_ITEMS_KEY, []);
      
      const newItem: InventoryItem = {
        ...item,
        id: generateId(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const updatedItems = [...items, newItem];
      saveToStorage(INVENTORY_ITEMS_KEY, updatedItems);
      
      resolve(newItem);
    }, 600);
  });
};

export const updateInventoryItem = async (id: string, updatedFields: Partial<InventoryItem>): Promise<InventoryItem> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const items = getStoredData<InventoryItem>(INVENTORY_ITEMS_KEY, []);
      const itemIndex = items.findIndex(item => item.id === id);
      
      if (itemIndex === -1) {
        reject(new Error(`Item with ID ${id} not found`));
        return;
      }
      
      const updatedItem = {
        ...items[itemIndex],
        ...updatedFields,
        updatedAt: new Date().toISOString()
      };
      
      const updatedItems = [...items];
      updatedItems[itemIndex] = updatedItem;
      
      saveToStorage(INVENTORY_ITEMS_KEY, updatedItems);
      resolve(updatedItem);
    }, 600);
  });
};

export const deleteInventoryItem = async (id: string): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const items = getStoredData<InventoryItem>(INVENTORY_ITEMS_KEY, []);
      const itemExists = items.some(item => item.id === id);
      
      if (!itemExists) {
        reject(new Error(`Item with ID ${id} not found`));
        return;
      }
      
      const updatedItems = items.filter(item => item.id !== id);
      saveToStorage(INVENTORY_ITEMS_KEY, updatedItems);
      
      resolve(true);
    }, 600);
  });
};

// Suppliers operations
export const getSuppliers = async (initialData: Supplier[]): Promise<Supplier[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const suppliers = getStoredData(INVENTORY_SUPPLIERS_KEY, initialData);
      resolve(suppliers);
    }, 500);
  });
};

export const addSupplier = async (supplier: Omit<Supplier, 'id'>): Promise<Supplier> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const suppliers = getStoredData<Supplier>(INVENTORY_SUPPLIERS_KEY, []);
      
      const newSupplier: Supplier = {
        ...supplier,
        id: generateId()
      };
      
      const updatedSuppliers = [...suppliers, newSupplier];
      saveToStorage(INVENTORY_SUPPLIERS_KEY, updatedSuppliers);
      
      resolve(newSupplier);
    }, 600);
  });
};

export const updateSupplier = async (id: string, updatedFields: Partial<Supplier>): Promise<Supplier> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const suppliers = getStoredData<Supplier>(INVENTORY_SUPPLIERS_KEY, []);
      const supplierIndex = suppliers.findIndex(supplier => supplier.id === id);
      
      if (supplierIndex === -1) {
        reject(new Error(`Supplier with ID ${id} not found`));
        return;
      }
      
      const updatedSupplier = {
        ...suppliers[supplierIndex],
        ...updatedFields
      };
      
      const updatedSuppliers = [...suppliers];
      updatedSuppliers[supplierIndex] = updatedSupplier;
      
      saveToStorage(INVENTORY_SUPPLIERS_KEY, updatedSuppliers);
      resolve(updatedSupplier);
    }, 600);
  });
};

export const deleteSupplier = async (id: string): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const suppliers = getStoredData<Supplier>(INVENTORY_SUPPLIERS_KEY, []);
      const supplierExists = suppliers.some(supplier => supplier.id === id);
      
      if (!supplierExists) {
        reject(new Error(`Supplier with ID ${id} not found`));
        return;
      }
      
      const updatedSuppliers = suppliers.filter(supplier => supplier.id !== id);
      saveToStorage(INVENTORY_SUPPLIERS_KEY, updatedSuppliers);
      
      resolve(true);
    }, 600);
  });
};

// Orders operations
export const getOrders = async (initialData: InventoryOrder[]): Promise<InventoryOrder[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const orders = getStoredData(INVENTORY_ORDERS_KEY, initialData);
      resolve(orders);
    }, 500);
  });
};

export const createOrder = async (order: Omit<InventoryOrder, 'id' | 'createdAt' | 'updatedAt'>): Promise<InventoryOrder> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const orders = getStoredData<InventoryOrder>(INVENTORY_ORDERS_KEY, []);
      
      const newOrder: InventoryOrder = {
        ...order,
        id: generateId(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const updatedOrders = [...orders, newOrder];
      saveToStorage(INVENTORY_ORDERS_KEY, updatedOrders);
      
      resolve(newOrder);
    }, 600);
  });
};

export const updateOrderStatus = async (id: string, status: OrderStatus): Promise<InventoryOrder> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const orders = getStoredData<InventoryOrder>(INVENTORY_ORDERS_KEY, []);
      const orderIndex = orders.findIndex(order => order.id === id);
      
      if (orderIndex === -1) {
        reject(new Error(`Order with ID ${id} not found`));
        return;
      }
      
      const updatedOrder = {
        ...orders[orderIndex],
        status,
        updatedAt: new Date().toISOString()
      };
      
      if (status === 'delivered') {
        updatedOrder.actualDeliveryDate = new Date().toISOString().split('T')[0];
      }
      
      const updatedOrders = [...orders];
      updatedOrders[orderIndex] = updatedOrder;
      
      saveToStorage(INVENTORY_ORDERS_KEY, updatedOrders);
      resolve(updatedOrder);
    }, 600);
  });
};

// Notifications operations
export const getNotifications = async (initialData: InventoryNotification[]): Promise<InventoryNotification[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const notifications = getStoredData(INVENTORY_NOTIFICATIONS_KEY, initialData);
      resolve(notifications);
    }, 500);
  });
};

export const addNotification = async (message: string, type: NotificationType): Promise<InventoryNotification> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const notifications = getStoredData<InventoryNotification>(INVENTORY_NOTIFICATIONS_KEY, []);
      
      const newNotification: InventoryNotification = {
        id: generateId(),
        message,
        type,
        read: false,
        createdAt: new Date().toISOString()
      };
      
      const updatedNotifications = [newNotification, ...notifications];
      saveToStorage(INVENTORY_NOTIFICATIONS_KEY, updatedNotifications);
      
      resolve(newNotification);
    }, 300);
  });
};

export const markNotificationAsRead = async (id: string): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const notifications = getStoredData<InventoryNotification>(INVENTORY_NOTIFICATIONS_KEY, []);
      const notificationIndex = notifications.findIndex(notification => notification.id === id);
      
      if (notificationIndex === -1) {
        reject(new Error(`Notification with ID ${id} not found`));
        return;
      }
      
      const updatedNotification = {
        ...notifications[notificationIndex],
        read: true
      };
      
      const updatedNotifications = [...notifications];
      updatedNotifications[notificationIndex] = updatedNotification;
      
      saveToStorage(INVENTORY_NOTIFICATIONS_KEY, updatedNotifications);
      resolve(true);
    }, 300);
  });
};

// Set up event listeners for cross-tab updates
export const setupInventorySyncListeners = (callback: (key: string) => void): (() => void) => {
  const handleStorageChange = (event: StorageEvent) => {
    if (event.key === INVENTORY_ITEMS_KEY || 
        event.key === INVENTORY_SUPPLIERS_KEY || 
        event.key === INVENTORY_ORDERS_KEY || 
        event.key === INVENTORY_NOTIFICATIONS_KEY) {
      callback(event.key);
    }
  };
  
  const handleCustomEvent = (event: CustomEvent) => {
    if (event.detail && event.detail.key) {
      callback(event.detail.key);
    }
  };
  
  window.addEventListener('storage', handleStorageChange);
  window.addEventListener('inventory-updated', handleCustomEvent as EventListener);
  
  // Return cleanup function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
    window.removeEventListener('inventory-updated', handleCustomEvent as EventListener);
  };
};
