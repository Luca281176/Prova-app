
// Storage key for locations
const LOCATIONS_STORAGE_KEY = 'restaurant_locations';
const SELECTED_LOCATION_KEY = 'current_location';

interface LocationsData {
  locations: string[];
  selectedLocation: string;
}

// Initialize locations from localStorage
export const initializeLocations = (userId?: string): LocationsData => {
  // Try to get locations from localStorage first
  try {
    const storedLocations = localStorage.getItem(LOCATIONS_STORAGE_KEY);
    const parsedLocations = storedLocations ? JSON.parse(storedLocations) : ['Sede Principale'];
    
    const storedSelectedLocation = localStorage.getItem(SELECTED_LOCATION_KEY);
    let selectedLocation = storedSelectedLocation;
    
    // If no location is selected or the selected one isn't in the list, select the first one
    if (!selectedLocation || !parsedLocations.includes(selectedLocation)) {
      selectedLocation = parsedLocations[0];
      localStorage.setItem(SELECTED_LOCATION_KEY, selectedLocation);
    }
    
    return {
      locations: parsedLocations,
      selectedLocation
    };
  } catch (error) {
    console.error('Error initializing locations:', error);
    
    // Return defaults if there's an error
    const defaultData = {
      locations: ['Sede Principale'],
      selectedLocation: 'Sede Principale'
    };
    
    // Save defaults to localStorage
    localStorage.setItem(LOCATIONS_STORAGE_KEY, JSON.stringify(defaultData.locations));
    localStorage.setItem(SELECTED_LOCATION_KEY, defaultData.selectedLocation);
    
    return defaultData;
  }
};

// Save locations to localStorage
const saveLocationsToStorage = (locations: string[]): void => {
  try {
    localStorage.setItem(LOCATIONS_STORAGE_KEY, JSON.stringify(locations));
    
    // Dispatch a custom event to notify other tabs/components
    window.dispatchEvent(new CustomEvent('locations-updated'));
  } catch (error) {
    console.error('Error saving locations to storage:', error);
  }
};

// Add a new location
export const addLocation = (userId: string, locationName: string): LocationsData => {
  if (!locationName.trim()) {
    throw new Error('Il nome della sede non può essere vuoto');
  }
  
  const { locations } = initializeLocations(userId);
  
  if (locations.includes(locationName)) {
    throw new Error(`La sede "${locationName}" esiste già`);
  }
  
  const updatedLocations = [...locations, locationName];
  saveLocationsToStorage(updatedLocations);
  
  return {
    locations: updatedLocations,
    selectedLocation: localStorage.getItem(SELECTED_LOCATION_KEY) || locationName
  };
};

// Update a location
export const updateLocation = (userId: string, oldName: string, newName: string): LocationsData => {
  if (!newName.trim()) {
    throw new Error('Il nome della sede non può essere vuoto');
  }
  
  const { locations, selectedLocation } = initializeLocations(userId);
  
  if (oldName === newName) {
    return { locations, selectedLocation };
  }
  
  if (locations.includes(newName)) {
    throw new Error(`La sede "${newName}" esiste già`);
  }
  
  const updatedLocations = locations.map(loc => loc === oldName ? newName : loc);
  saveLocationsToStorage(updatedLocations);
  
  // Update selected location if it was renamed
  let newSelectedLocation = selectedLocation;
  if (selectedLocation === oldName) {
    newSelectedLocation = newName;
    setSelectedLocation(userId, newName);
  }
  
  return {
    locations: updatedLocations,
    selectedLocation: newSelectedLocation
  };
};

// Delete a location
export const deleteLocation = (userId: string, locationName: string): LocationsData => {
  const { locations, selectedLocation } = initializeLocations(userId);
  
  if (locations.length <= 1) {
    throw new Error('Devi mantenere almeno una sede');
  }
  
  const updatedLocations = locations.filter(loc => loc !== locationName);
  saveLocationsToStorage(updatedLocations);
  
  // Update selected location if it was deleted
  let newSelectedLocation = selectedLocation;
  if (selectedLocation === locationName) {
    newSelectedLocation = updatedLocations[0];
    setSelectedLocation(userId, newSelectedLocation);
  }
  
  return {
    locations: updatedLocations,
    selectedLocation: newSelectedLocation
  };
};

// Set the selected location
export const setSelectedLocation = (userId: string, locationName: string): void => {
  const { locations } = initializeLocations(userId);
  
  if (!locations.includes(locationName)) {
    throw new Error(`La sede "${locationName}" non esiste`);
  }
  
  localStorage.setItem(SELECTED_LOCATION_KEY, locationName);
  
  // Dispatch a custom event to notify other tabs/components
  window.dispatchEvent(new CustomEvent('selected-location-updated'));
};

// Get the selected location
export const getSelectedLocation = (userId: string): string => {
  const { selectedLocation } = initializeLocations(userId);
  return selectedLocation;
};

// Setup listener for location changes
export const setupLocationsSyncListener = (
  callback: (userId?: string) => void
): (() => void) => {
  const handleStorageChange = (event: StorageEvent) => {
    if (
      event.key === LOCATIONS_STORAGE_KEY ||
      event.key === SELECTED_LOCATION_KEY
    ) {
      callback();
    }
  };
  
  const handleCustomEvent = () => {
    callback();
  };
  
  window.addEventListener('storage', handleStorageChange);
  window.addEventListener('locations-updated', handleCustomEvent);
  window.addEventListener('selected-location-updated', handleCustomEvent);
  
  // Return cleanup function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
    window.removeEventListener('locations-updated', handleCustomEvent);
    window.removeEventListener('selected-location-updated', handleCustomEvent);
  };
};
