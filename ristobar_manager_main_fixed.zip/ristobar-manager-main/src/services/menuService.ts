
// Tipi per i dati del menu
export interface Dish {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;  // Campo aggiunto per salvare il prezzo originale in caso di sconti
  description: string;
  image: string;
  available: boolean;
  allergies: string[];
  visible: boolean; // New property to control visibility in digital menu
}

export interface Category {
  id: string;
  name: string;
  dishes: Dish[];
  order: number;
}

export interface MenuSettings {
  timeSettings?: {
    lunch: { enabled: boolean; start: string; end: string };
    dinner: { enabled: boolean; start: string; end: string };
  };
  discountSettings?: {
    type: string;
    value: string;
    applyTo: string;
    specificCategory?: string;
  };
  qrSettings?: {
    generated: boolean;
    selectedMenu: string;
    url: string;
  };
  inventoryIntegrated?: boolean;
  customMenus?: Array<{
    id: string;
    name: string;
    baseMenu: string;
  }>;
  specialDates?: Array<{
    date: string;
    menuType: string;
  }>;
  customization?: {
    primaryColor?: string;
    accentColor?: string;
    title?: string;
    address?: string;
    phone?: string;
    email?: string;
    website?: string;
    vat?: string;
    description?: string;
    openingHours?: string;
    showLogo?: boolean;
    headerVisibility?: {
      address?: boolean;
      phone?: boolean;
      email?: boolean;
      website?: boolean;
      vat?: boolean;
      description?: boolean;
      openingHours?: boolean;
    };
    visibility?: {
      prices?: boolean;
      descriptions?: boolean;
      allergens?: boolean;
      unavailable?: boolean;
    }
  };
}

// Chiavi per il localStorage
const MENU_STORAGE_KEY = 'risto_menu_data';
const MENU_SETTINGS_KEY = 'risto_menu_settings';

// Dati di esempio per il primo avvio
const initialMenuData: Category[] = [
  {
    id: '1',
    name: 'Antipasti',
    dishes: [
      { id: '1', name: 'Bruschetta', price: 6.50, description: 'Pane tostato con pomodori, aglio e basilico', image: 'https://images.unsplash.com/photo-1572695157366-5efbfc31c551?w=300', available: true, allergies: ['glutine'], visible: true },
      { id: '2', name: 'Caprese', price: 8.00, description: 'Mozzarella, pomodoro e basilico', image: 'https://images.unsplash.com/photo-1625944525533-473f1a3d54e7?w=300', available: true, allergies: ['lattosio'], visible: true }
    ],
    order: 1
  },
  {
    id: '2',
    name: 'Primi Piatti',
    dishes: [
      { id: '3', name: 'Spaghetti alla Carbonara', price: 12.00, description: 'Pasta con uova, pecorino, guanciale e pepe', image: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=300', available: true, allergies: ['glutine', 'uova'], visible: true },
      { id: '4', name: 'Risotto ai Funghi', price: 14.00, description: 'Riso con funghi porcini e parmigiano', image: 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=300', available: true, allergies: ['lattosio'], visible: true }
    ],
    order: 2
  },
  {
    id: '3',
    name: 'Secondi Piatti',
    dishes: [
      { id: '5', name: 'Bistecca alla Fiorentina', price: 25.00, description: 'Bistecca di manzo cotta alla griglia', image: 'https://images.unsplash.com/photo-1558030006-450675393462?w=300', available: true, allergies: [], visible: true },
      { id: '6', name: 'Orata al Forno', price: 18.00, description: 'Orata fresca al forno con patate e rosmarino', image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a3d54e7?w=300', available: false, allergies: ['pesce'], visible: true }
    ],
    order: 3
  }
];

// Impostazioni di default
const defaultMenuSettings: MenuSettings = {
  timeSettings: {
    lunch: { enabled: true, start: "11:30", end: "15:00" },
    dinner: { enabled: true, start: "18:30", end: "23:00" }
  },
  discountSettings: {
    type: "none",
    value: "0",
    applyTo: "all"
  },
  qrSettings: {
    generated: false,
    selectedMenu: "standard",
    url: ""
  },
  inventoryIntegrated: false,
  customMenus: [],
  specialDates: [],
  customization: {
    primaryColor: '#007bff',
    accentColor: '#28a745',
    title: 'Ristorante',
    address: '',
    phone: '',
    email: '',
    website: '',
    vat: '',
    description: '',
    openingHours: '',
    showLogo: true,
    headerVisibility: {
      address: true,
      phone: true,
      email: true,
      website: true,
      vat: true,
      description: true,
      openingHours: true
    },
    visibility: {
      prices: true,
      descriptions: true,
      allergens: true,
      unavailable: true
    }
  }
};

// Caricamento dei dati menu
export const loadMenuData = (): Category[] => {
  try {
    console.log("[menuService] Loading menu data from localStorage");
    const storedData = localStorage.getItem(MENU_STORAGE_KEY);
    
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      console.log("[menuService] Menu data loaded:", 
        parsedData.reduce((total, cat) => total + cat.dishes.length, 0), 
        "dishes across", 
        parsedData.length, 
        "categories"
      );
      
      // Ensure we're properly handling the visible property for all dishes
      const validatedData = parsedData.map(category => ({
        ...category,
        dishes: category.dishes.map(dish => ({
          ...dish,
          // Ensure visible is a boolean (if undefined, default to true)
          visible: dish.visible === undefined ? true : Boolean(dish.visible)
        }))
      }));
      
      // Log validation results for debugging
      console.log("[menuService] Validated dish visibility status:", 
        validatedData.reduce((total, cat) => total + cat.dishes.filter(d => d.visible).length, 0), 
        "visible dishes out of",
        validatedData.reduce((total, cat) => total + cat.dishes.length, 0),
        "total dishes"
      );
      
      return validatedData;
    }
    
    // Se non ci sono dati, inizializza con i dati di esempio
    console.log("[menuService] No stored data found, initializing with example data");
    saveMenuData(initialMenuData);
    return initialMenuData;
  } catch (error) {
    console.error('[menuService] Error loading menu data:', error);
    return initialMenuData;
  }
};

// Salvataggio dei dati menu
export const saveMenuData = (data: Category[]): void => {
  try {
    localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(data));
    // Evento personalizzato per sincronizzare tra tabs
    window.dispatchEvent(new CustomEvent('menu-data-updated'));
  } catch (error) {
    console.error('Error saving menu data:', error);
  }
};

// Caricamento delle impostazioni
export const loadMenuSettings = (): MenuSettings => {
  try {
    const storedSettings = localStorage.getItem(MENU_SETTINGS_KEY);
    if (storedSettings) {
      return JSON.parse(storedSettings);
    }
    // Se non ci sono impostazioni, inizializza con i dati di default
    saveMenuSettings(defaultMenuSettings);
    return defaultMenuSettings;
  } catch (error) {
    console.error('Error loading menu settings:', error);
    return defaultMenuSettings;
  }
};

// Salvataggio delle impostazioni
export const saveMenuSettings = (settings: MenuSettings): void => {
  try {
    localStorage.setItem(MENU_SETTINGS_KEY, JSON.stringify(settings));
    // Evento personalizzato per sincronizzare tra tabs
    window.dispatchEvent(new CustomEvent('menu-settings-updated'));
  } catch (error) {
    console.error('Error saving menu settings:', error);
  }
};

// Aggiornamento parziale delle impostazioni
export const updateMenuSettings = (partialSettings: Partial<MenuSettings>): MenuSettings => {
  const currentSettings = loadMenuSettings();
  const updatedSettings = { ...currentSettings, ...partialSettings };
  saveMenuSettings(updatedSettings);
  return updatedSettings;
};

// Generazione di un ID univoco
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Aggiunta di una categoria
export const addCategory = (name: string): Category => {
  const categories = loadMenuData();
  const newCategory: Category = {
    id: generateId(),
    name,
    dishes: [],
    order: categories.length + 1
  };
  
  categories.push(newCategory);
  saveMenuData(categories);
  return newCategory;
};

// Aggiornamento di una categoria
export const updateCategory = (categoryId: string, data: Partial<Category>): Category | null => {
  const categories = loadMenuData();
  const index = categories.findIndex(c => c.id === categoryId);
  
  if (index === -1) return null;
  
  const updatedCategory = { ...categories[index], ...data };
  categories[index] = updatedCategory;
  saveMenuData(categories);
  return updatedCategory;
};

// Eliminazione di una categoria
export const deleteCategory = (categoryId: string): boolean => {
  const categories = loadMenuData();
  const filteredCategories = categories.filter(c => c.id !== categoryId);
  
  if (filteredCategories.length === categories.length) {
    return false; // Nessuna categoria è stata eliminata
  }
  
  // Aggiornamento degli ordini
  filteredCategories.forEach((category, index) => {
    category.order = index + 1;
  });
  
  saveMenuData(filteredCategories);
  return true;
};

// Spostamento categoria (su/giù)
export const moveCategory = (categoryId: string, direction: 'up' | 'down'): boolean => {
  const categories = loadMenuData();
  const index = categories.findIndex(c => c.id === categoryId);
  
  if (index === -1) return false;
  if (direction === 'up' && index === 0) return false;
  if (direction === 'down' && index === categories.length - 1) return false;
  
  const newIndex = direction === 'up' ? index - 1 : index + 1;
  const temp = categories[newIndex];
  categories[newIndex] = categories[index];
  categories[index] = temp;
  
  // Aggiornamento degli ordini
  categories.forEach((category, idx) => {
    category.order = idx + 1;
  });
  
  saveMenuData(categories);
  return true;
};

// Aggiunta di un piatto
export const addDish = (categoryId: string, dish: Omit<Dish, 'id'>): Dish | null => {
  const categories = loadMenuData();
  const categoryIndex = categories.findIndex(c => c.id === categoryId);
  
  if (categoryIndex === -1) return null;
  
  const newDish: Dish = {
    ...dish,
    id: generateId()
  };
  
  categories[categoryIndex].dishes.push(newDish);
  saveMenuData(categories);
  return newDish;
};

// Aggiornamento di un piatto
export const updateDish = (categoryId: string, dishId: string, data: Partial<Dish>): Dish | null => {
  const categories = loadMenuData();
  const categoryIndex = categories.findIndex(c => c.id === categoryId);
  
  if (categoryIndex === -1) return null;
  
  const dishIndex = categories[categoryIndex].dishes.findIndex(d => d.id === dishId);
  
  if (dishIndex === -1) return null;
  
  const updatedDish = { ...categories[categoryIndex].dishes[dishIndex], ...data };
  categories[categoryIndex].dishes[dishIndex] = updatedDish;
  
  console.log("[menuService] Updating dish:", dishId, "in category:", categoryId);
  console.log("[menuService] Updated properties:", Object.keys(data).join(", "));
  
  // If visibility is being updated, log it specifically
  if (data.visible !== undefined) {
    console.log("[menuService] Dish visibility set to:", Boolean(data.visible));
  }
  
  saveMenuData(categories);
  return updatedDish;
};

// Eliminazione di un piatto
export const deleteDish = (categoryId: string, dishId: string): boolean => {
  const categories = loadMenuData();
  const categoryIndex = categories.findIndex(c => c.id === categoryId);
  
  if (categoryIndex === -1) return false;
  
  const originalLength = categories[categoryIndex].dishes.length;
  categories[categoryIndex].dishes = categories[categoryIndex].dishes.filter(d => d.id !== dishId);
  
  if (categories[categoryIndex].dishes.length === originalLength) {
    return false; // Nessun piatto è stato eliminato
  }
  
  saveMenuData(categories);
  return true;
};

// Create a new custom menu based on an existing menu
export const createCustomMenu = (name: string, baseMenuId: string): string => {
  // Load current settings
  const currentSettings = loadMenuSettings();
  const customMenuId = `custom_${generateId()}`;
  
  // Create new menu entry in settings
  const updatedSettings = {
    ...currentSettings,
    customMenus: [
      ...(currentSettings.customMenus || []),
      {
        id: customMenuId,
        name: name,
        baseMenu: baseMenuId
      }
    ]
  };
  
  // Save updated settings
  saveMenuSettings(updatedSettings);
  
  // Clone the base menu data for the new custom menu
  // In a real application, this would create a copy of the menu data
  // For now, we're just returning the ID of the new menu
  console.log(`Created new custom menu: ${name} (${customMenuId}) based on ${baseMenuId}`);
  
  return customMenuId;
};
