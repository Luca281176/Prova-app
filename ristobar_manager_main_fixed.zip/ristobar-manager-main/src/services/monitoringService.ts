
import { supabase } from '@/integrations/supabase/client';

/**
 * Servizio per il monitoraggio e il logging degli errori
 * In una implementazione reale, questo utilizzerebbe Sentry o un servizio simile
 */
export const MonitoringService = {
  /**
   * Registra un errore
   * @param error Errore da registrare
   * @param context Contesto dell'errore
   */
  async logError(error: Error | string, context?: Record<string, any>): Promise<void> {
    const errorMessage = error instanceof Error ? error.message : error;
    const errorStack = error instanceof Error ? error.stack : undefined;
    
    console.error('Errore rilevato:', errorMessage);
    if (errorStack) {
      console.error('Stack trace:', errorStack);
    }
    if (context) {
      console.error('Contesto:', context);
    }
    
    try {
      // Salva l'errore in Supabase
      const { error: dbError } = await supabase
        .from('error_logs')
        .insert({
          message: errorMessage,
          stack: errorStack,
          context: context ? JSON.stringify(context) : null,
          timestamp: new Date().toISOString()
        });
        
      if (dbError) {
        console.error('Errore durante il salvataggio del log:', dbError);
      }
    } catch (loggingError) {
      console.error('Errore durante il logging dell\'errore:', loggingError);
    }
    
    // In una implementazione reale, qui invieremmo l'errore a Sentry
    // Sentry.captureException(error, { extra: context });
  },
  
  /**
   * Registra un evento
   * @param eventName Nome dell'evento
   * @param data Dati associati all'evento
   */
  async logEvent(eventName: string, data?: Record<string, any>): Promise<void> {
    console.log(`Evento: ${eventName}`, data);
    
    try {
      // Salva l'evento in Supabase
      const { error: dbError } = await supabase
        .from('event_logs')
        .insert({
          event_name: eventName,
          data: data ? JSON.stringify(data) : null,
          timestamp: new Date().toISOString()
        });
        
      if (dbError) {
        console.error('Errore durante il salvataggio dell\'evento:', dbError);
      }
    } catch (loggingError) {
      console.error('Errore durante il logging dell\'evento:', loggingError);
    }
    
    // In una implementazione reale, qui invieremmo l'evento a Sentry
    // Sentry.captureEvent({ message: eventName, extra: data });
  },
  
  /**
   * Inizializza il servizio di monitoraggio
   */
  init(): void {
    // In una implementazione reale, qui inizializzeremmo Sentry
    console.log('Servizio di monitoraggio inizializzato');
    
    // Configurazione globale per intercettare gli errori non gestiti
    window.addEventListener('error', (event) => {
      this.logError(event.error || event.message, {
        location: window.location.href,
        timestamp: new Date().toISOString()
      });
    });
    
    // Configurazione per intercettare le promise non gestite
    window.addEventListener('unhandledrejection', (event) => {
      const error = event.reason instanceof Error ? event.reason : new Error(String(event.reason));
      this.logError(error, {
        type: 'unhandledrejection',
        location: window.location.href,
        timestamp: new Date().toISOString()
      });
    });
  }
};

export default MonitoringService;
