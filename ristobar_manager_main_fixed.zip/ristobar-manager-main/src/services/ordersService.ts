
// Add any imports needed here
import { updateTableStatus as updateRoomTableStatus } from './roomsService';

// Define the interfaces for order items and orders
export interface OrderItem {
  menuItemId?: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
  priority?: string;
  category?: string;
}

export interface Order {
  id: string;
  tableId: string;
  tableName: string;
  items: OrderItem[];
  total: number;
  timestamp: string;
  status: 'pending' | 'completed' | 'paid' | 'cancelled';
  operatorId?: string;
  operatorName?: string;
  covers?: number;
  notes?: string;
  locationId?: string;  // Add locationId to track which location the order belongs to
}

// Mock database of orders - Use localStorage to persist orders across refreshes
const getStoredOrders = (): Order[] => {
  try {
    const stored = localStorage.getItem('restaurant_orders');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading orders from storage', error);
    return [];
  }
};

const saveOrders = (orders: Order[]) => {
  try {
    localStorage.setItem('restaurant_orders', JSON.stringify(orders));
  } catch (error) {
    console.error('Error saving orders to storage', error);
  }
};

let orders: Order[] = getStoredOrders();
let cashierQueue: Order[] = [];

// Function to generate a unique ID
const generateId = () => {
  return Math.random().toString(36).substr(2, 9);
};

// Add a new order
export const addOrder = async (orderData: Omit<Order, 'id'>): Promise<Order> => {
  const newOrder = {
    ...orderData,
    id: generateId()
  };
  
  orders.push(newOrder);
  saveOrders(orders);
  
  // Dispatch event to notify about order changes
  window.dispatchEvent(new CustomEvent('orders-updated'));
  
  return newOrder;
};

// Update an existing order
export const updateOrder = async (orderId: string, orderData: Partial<Order>): Promise<Order | null> => {
  const orderIndex = orders.findIndex(order => order.id === orderId);
  if (orderIndex === -1) return null;
  
  const updatedOrder = {
    ...orders[orderIndex],
    ...orderData
  };
  
  orders[orderIndex] = updatedOrder;
  saveOrders(orders);
  
  // Dispatch event to notify about order changes
  window.dispatchEvent(new CustomEvent('orders-updated'));
  
  return updatedOrder;
};

// Get all orders
export const getAllOrders = async (): Promise<Order[]> => {
  return orders;
};

// Fetch all orders (alias for getAllOrders to match import in ActiveOrders.tsx)
export const fetchOrders = async (): Promise<Order[]> => {
  return orders;
};

// Get orders for a specific table
export const getOrdersForTable = async (tableId: string): Promise<Order[]> => {
  return orders.filter(order => order.tableId === tableId);
};

// Get a specific order by ID
export const getOrderById = async (orderId: string): Promise<Order | null> => {
  return orders.find(order => order.id === orderId) || null;
};

// Delete an order
export const deleteOrder = async (orderId: string): Promise<boolean> => {
  const initialLength = orders.length;
  orders = orders.filter(order => order.id !== orderId);
  saveOrders(orders);
  
  // Dispatch event to notify about order changes
  if (orders.length !== initialLength) {
    window.dispatchEvent(new CustomEvent('orders-updated'));
    return true;
  }
  
  return false;
};

// Update order status
export const updateOrderStatus = async (orderId: string, status: 'pending' | 'completed' | 'paid' | 'cancelled'): Promise<Order | null> => {
  const orderIndex = orders.findIndex(order => order.id === orderId);
  if (orderIndex === -1) return null;
  
  orders[orderIndex] = {
    ...orders[orderIndex],
    status
  };
  saveOrders(orders);
  
  // Dispatch event to notify about order changes
  window.dispatchEvent(new CustomEvent('orders-updated'));
  
  return orders[orderIndex];
};

// Complete an order (changes status to completed and adds it to cashier queue)
export const completeOrder = async (orderId: string): Promise<Order | null> => {
  console.log(`Completing order ${orderId}`);
  const orderIndex = orders.findIndex(order => order.id === orderId);
  if (orderIndex === -1) {
    console.error(`Order ${orderId} not found`);
    return null;
  }
  
  const order = orders[orderIndex];
  console.log(`Found order to complete:`, order);
  
  // Update status to completed
  const updatedOrder = {
    ...order,
    status: 'completed' as const
  };
  
  orders[orderIndex] = updatedOrder;
  saveOrders(orders);
  
  // Add to cashier queue
  const alreadyInQueue = cashierQueue.some(queuedOrder => queuedOrder.id === updatedOrder.id);
  if (!alreadyInQueue) {
    cashierQueue.push(updatedOrder);
  }
  
  // Dispatch events to notify about changes - do this first before trying table update
  console.log(`Dispatching events for completed order ${orderId}`);
  window.dispatchEvent(new CustomEvent('orders-updated'));
  window.dispatchEvent(new CustomEvent('cashier-queue-updated'));
  window.dispatchEvent(new CustomEvent('order-completed', { 
    detail: { 
      tableId: order.tableId,
      orderId: order.id,
      status: 'waiting',
      locationId: order.locationId
    }
  }));
  
  // Force a rooms update event with extra details
  window.dispatchEvent(new CustomEvent('rooms-updated', {
    detail: { 
      locationId: order.locationId,
      tableId: order.tableId,
      forceUpdate: true
    }
  }));
  
  try {
    console.log(`Updating table ${order.tableId} status to waiting with locationId ${order.locationId || undefined}`);
    
    // We'll continue even if the table update fails
    // This is a critical change - don't throw an error if table update fails
    try {
      await updateRoomTableStatus(order.tableId, 'waiting', order.locationId);
      console.log(`Table status updated successfully to waiting`);
    } catch (error) {
      console.warn(`Could not update table status, but order was completed successfully:`, error);
      // Don't rethrow - we want to return the updated order regardless
    }
    
    return updatedOrder;
  } catch (error) {
    console.error(`Unexpected error in completeOrder:`, error);
    // Still return the updated order even if there was an error updating the table
    return updatedOrder;
  }
};

// Get orders in cashier queue
export const getCashierOrders = async (): Promise<Order[]> => {
  // Filter the orders to only include completed orders that aren't paid or cancelled
  const queuedOrders = orders.filter(order => order.status === 'completed');
  return queuedOrders;
};

// Remove an order from cashier queue
export const removeOrderFromCashier = async (orderId: string): Promise<boolean> => {
  const orderIndex = orders.findIndex(order => order.id === orderId && order.status === 'completed');
  if (orderIndex !== -1) {
    // Get the order before updating it
    const order = orders[orderIndex];
    
    // Update order status to paid (instead of deleting)
    const updatedOrder = {
      ...order,
      status: 'paid' as const
    };
    
    orders[orderIndex] = updatedOrder;
    saveOrders(orders);
    
    // Notify of changes
    window.dispatchEvent(new CustomEvent('cashier-queue-updated'));
    window.dispatchEvent(new CustomEvent('orders-updated'));
    
    // Update table status to available after payment
    try {
      if (order.tableId) {
        // Console log for debugging
        console.log(`Updating table ${order.tableId} status to available after payment`);
        
        // Make sure this call succeeds
        await updateRoomTableStatus(order.tableId, 'available', order.locationId);
        console.log(`Table ${order.tableId} status updated to available after payment`);
        
        // Dispatch a rooms-updated event to force refresh the UI
        window.dispatchEvent(new CustomEvent('rooms-updated', {
          detail: { 
            locationId: order.locationId,
            tableId: order.tableId,
            forceUpdate: true
          }
        }));
      }
    } catch (error) {
      console.error(`Error updating table status to available after payment:`, error);
      // Still return true even if table status update fails
    }
    
    return true;
  }
  
  return false;
};
