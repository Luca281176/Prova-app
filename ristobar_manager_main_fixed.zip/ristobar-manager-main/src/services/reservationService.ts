import { Reservation } from '@/types/reservations';
import { toast } from 'sonner';

// Storage key for reservations
const RESERVATIONS_STORAGE_KEY = 'restaurant_reservations_data';

// Helper to generate unique IDs
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Get storage key for a specific location
const getStorageKey = (locationId?: string): string => {
  return locationId 
    ? `${RESERVATIONS_STORAGE_KEY}_${locationId}` 
    : RESERVATIONS_STORAGE_KEY;
};

// Initialize reservations from localStorage
const initializeReservations = (locationId?: string): Reservation[] => {
  const storageKey = getStorageKey(locationId);
  
  try {
    const storedData = localStorage.getItem(storageKey);
    if (storedData) {
      const parsedData = JSON.parse(storedData);
      return parsedData;
    }
    
    // Try to get data from user-specific storage if standard key fails
    const userStr = localStorage.getItem('user');
    if (userStr) {
      const user = JSON.parse(userStr);
      if (user && user.id) {
        const userSpecificKey = `${user.id}_${storageKey}`;
        const userData = localStorage.getItem(userSpecificKey);
        if (userData) {
          try {
            const parsedUserData = JSON.parse(userData);
            
            // Save to standard key for future access
            localStorage.setItem(storageKey, userData);
            
            return parsedUserData;
          } catch (e) {
            console.warn('Error parsing user-specific reservations data:', e);
          }
        }
      }
    }
  } catch (error) {
    console.error('Error initializing reservations:', error);
  }
  
  // Return empty array if nothing in localStorage
  return [];
};

// Save reservations data to localStorage
const saveReservationsToStorage = (reservations: Reservation[], locationId?: string): void => {
  const storageKey = getStorageKey(locationId);
  
  try {
    localStorage.setItem(storageKey, JSON.stringify(reservations));
    
    // Also save to user-specific storage if possible
    try {
      const userStr = localStorage.getItem('user');
      if (userStr) {
        const user = JSON.parse(userStr);
        if (user && user.id) {
          const userSpecificKey = `${user.id}_${storageKey}`;
          localStorage.setItem(userSpecificKey, JSON.stringify(reservations));
        }
      }
    } catch (userError) {
      console.warn('Error saving to user-specific storage:', userError);
    }
    
    // Dispatch an event to notify other tabs/windows
    window.dispatchEvent(new CustomEvent('reservations-updated', {
      detail: { locationId }
    }));
  } catch (error) {
    console.error('Error saving reservations data to storage:', error);
  }
};

// Get all reservations
export const getReservations = async (locationId?: string) => {
  try {
    const reservations = initializeReservations(locationId);
    return { data: reservations, error: null };
  } catch (error) {
    console.error('Error getting reservations:', error);
    return { data: null, error: 'Failed to get reservations' };
  }
};

// Get a reservation by ID
export const getReservationById = async (id: string, locationId?: string) => {
  try {
    const reservations = initializeReservations(locationId);
    const reservation = reservations.find(r => r.id === id);
    
    if (!reservation) {
      return { data: null, error: 'Reservation not found' };
    }
    
    return { data: reservation, error: null };
  } catch (error) {
    console.error('Error getting reservation:', error);
    return { data: null, error: 'Failed to get reservation' };
  }
};

// Get a reservation by table ID (get the most recent reservation for this table)
export const getReservationByTableId = async (tableId: string): Promise<Reservation | null> => {
  try {
    console.log(`Getting reservation for table ID: ${tableId}`);
    
    // In an actual app with a database, we would filter by table_id and order by date
    // For now, we'll get all reservations and filter them here
    const result = await getReservations();
    
    if (result.error) {
      console.error('Error fetching reservations:', result.error);
      return null;
    }
    
    const reservations = result.data || [];
    
    // Find the reservation for this table
    // Filter for active reservations (not cancelled, completed, or no-show)
    const tableReservations = reservations.filter(r => 
      r.tableId === tableId && 
      r.status !== 'cancelled' && 
      r.status !== 'no-show' &&
      r.status !== 'completed'
    );
    
    // Sort by date/time to get the most recent
    if (tableReservations.length > 0) {
      // Here we would sort by date & time, but for now we'll just take the first one
      const reservation = tableReservations[0];
      console.log(`Found reservation for table ${tableId}:`, reservation);
      
      return reservation;
    }
    
    return null;
  } catch (error) {
    console.error(`Error getting reservation for table ID ${tableId}:`, error);
    return null;
  }
};

// Check if a given table should be marked as reserved based on upcoming reservations
export const shouldTableBeReserved = async (tableId: string): Promise<boolean> => {
  try {
    console.log(`Checking if table ${tableId} should be reserved...`);
    const reservation = await getReservationByTableId(tableId);
    
    if (!reservation || !reservation.time || reservation.status === 'cancelled' || reservation.status === 'completed') {
      console.log(`Table ${tableId} should not be reserved: no active reservation found`);
      return false;
    }
    
    console.log(`Found reservation for table ${tableId}:`, reservation);
    
    // Get current time
    const now = new Date();
    
    // Create reservation date & time
    const reservationDate = typeof reservation.date === 'string' 
      ? new Date(reservation.date) 
      : new Date(reservation.date);
    
    const [hours, minutes] = reservation.time.split(':').map(Number);
    reservationDate.setHours(hours, minutes, 0, 0);
    
    // Check if reservation is within 3 hours
    const diffMs = reservationDate.getTime() - now.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    
    console.log(`Reservation time check for table ${tableId}:`, {
      reservationTime: reservationDate.toLocaleString(),
      currentTime: now.toLocaleString(),
      diffHours,
      shouldReserve: diffHours <= 3 && diffHours > -24
    });
    
    // Only mark as reserved if within 3 hours of the reservation time
    // AND not more than 24 hours in the past
    return diffHours <= 3 && diffHours > -24;
  } catch (error) {
    console.error(`Error checking if table ${tableId} should be reserved:`, error);
    return false;
  }
};

// Check if a table is already booked for a specific date and time
export const isTableAlreadyBooked = async (
  tableId: string,
  date: Date | string,
  time: string,
  locationId?: string,
  excludeReservationId?: string
): Promise<boolean> => {
  try {
    console.log(`Checking if table ${tableId} is already booked for ${typeof date === 'string' ? date : date.toDateString()} at ${time}`);
    
    // Get all reservations
    const { data: reservations, error } = await getReservations(locationId);
    if (error || !reservations) {
      console.error('Error getting reservations:', error);
      return false;
    }
    
    // Format the date for comparison
    const reservationDate = typeof date === 'string' 
      ? new Date(date).toDateString() 
      : date.toDateString();
      
    console.log('Checking against existing reservations:', reservations.length);
    
    // Convert requested time to minutes for time range comparison
    const requestTimeMinutes = convertTimeToMinutes(time);
    
    // Check if there's an existing reservation for this table, date, and time range
    const existingReservation = reservations.find(r => {
      // Skip the current reservation when editing
      if (excludeReservationId && r.id === excludeReservationId) {
        return false;
      }
      
      // Skip cancelled, no-show or completed reservations
      if (r.status === 'cancelled' || r.status === 'no-show' || r.status === 'completed') {
        return false;
      }
      
      // Check if it's the same table
      if (r.tableId !== tableId) {
        return false;
      }
      
      // Format date for comparison
      const rDate = typeof r.date === 'string' 
        ? new Date(r.date).toDateString() 
        : r.date.toDateString();
        
      // Check if it's the same date
      if (rDate !== reservationDate) {
        return false;
      }
      
      // Compare times to check for overlapping time slots
      // Convert existing reservation time to minutes
      const existingTimeMinutes = convertTimeToMinutes(r.time);
      
      // Define the buffer times: 1 hour before and 3 hours after
      const bufferBefore = 60; // 1 hour in minutes
      const bufferAfter = 180;  // 3 hours in minutes
      
      // Check if the requested time falls within the buffer zone of an existing reservation
      const isWithinBufferZone = 
        (requestTimeMinutes >= existingTimeMinutes - bufferBefore) && 
        (requestTimeMinutes <= existingTimeMinutes + bufferAfter);
      
      // Log the time comparison
      console.log('Time comparison:', {
        existingTime: r.time,
        existingMinutes: existingTimeMinutes,
        requestTime: time,
        requestMinutes: requestTimeMinutes,
        isWithinBufferZone
      });
      
      return isWithinBufferZone;
    });
    
    if (existingReservation) {
      console.log('Found conflicting reservation:', existingReservation);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`Error checking if table ${tableId} is already booked:`, error);
    return false;
  }
};

// Helper function to convert time string (HH:MM) to minutes for easier comparison
const convertTimeToMinutes = (timeStr: string): number => {
  // Handle time strings across midnight (00:00-04:00)
  const [hours, minutes] = timeStr.split(':').map(Number);
  
  // Convert to total minutes
  return (hours * 60) + minutes;
};

// Create a new reservation
export const createReservation = async (reservationData: Omit<Reservation, 'id'>, locationId?: string) => {
  try {
    // If table is specified, check if it's already booked
    if (reservationData.tableId) {
      const isBooked = await isTableAlreadyBooked(
        reservationData.tableId,
        reservationData.date,
        reservationData.time,
        locationId
      );
      
      if (isBooked) {
        return { 
          data: null, 
          error: 'Questo tavolo è già prenotato per la data e l\'orario selezionati.' 
        };
      }
    }
    
    const reservations = initializeReservations(locationId);
    const newReservation: Reservation = {
      id: generateId(),
      ...reservationData
    };
    
    const updatedReservations = [...reservations, newReservation];
    saveReservationsToStorage(updatedReservations, locationId);
    
    return { data: newReservation, error: null };
  } catch (error) {
    console.error('Error creating reservation:', error);
    return { data: null, error: 'Failed to create reservation' };
  }
};

// Add reservation (alias for createReservation to fix compatibility)
export const addReservation = async (reservationData: Omit<Reservation, 'id'>, locationId?: string) => {
  return createReservation(reservationData, locationId);
};

// Update a reservation
export const updateReservation = async (id: string, reservationData: Partial<Reservation>, locationId?: string) => {
  try {
    const reservations = initializeReservations(locationId);
    const index = reservations.findIndex(r => r.id === id);
    
    if (index === -1) {
      return { data: null, error: 'Reservation not found' };
    }
    
    // If updating table, date, or time, check for conflicts
    if (
      (reservationData.tableId || reservations[index].tableId) &&
      (reservationData.date || reservations[index].date) &&
      (reservationData.time || reservations[index].time)
    ) {
      const isBooked = await isTableAlreadyBooked(
        reservationData.tableId || reservations[index].tableId!,
        reservationData.date || reservations[index].date,
        reservationData.time || reservations[index].time,
        locationId,
        id // Exclude the current reservation from the check
      );
      
      if (isBooked) {
        return { 
          data: null, 
          error: 'Questo tavolo è già prenotato per la data e l\'orario selezionati.' 
        };
      }
    }
    
    const updatedReservation = {
      ...reservations[index],
      ...reservationData
    };
    
    const updatedReservations = [...reservations];
    updatedReservations[index] = updatedReservation;
    
    saveReservationsToStorage(updatedReservations, locationId);
    
    return { data: updatedReservation, error: null };
  } catch (error) {
    console.error('Error updating reservation:', error);
    return { data: null, error: 'Failed to update reservation' };
  }
};

// Update reservation status
export const updateReservationStatus = async (id: string, status: Reservation['status'], locationId?: string) => {
  const result = await updateReservation(id, { status }, locationId);
  return result;
};

// Delete a reservation
export const deleteReservation = async (id: string, locationId?: string) => {
  try {
    const reservations = initializeReservations(locationId);
    const filteredReservations = reservations.filter(r => r.id !== id);
    
    if (filteredReservations.length === reservations.length) {
      return { success: false, error: 'Reservation not found' };
    }
    
    saveReservationsToStorage(filteredReservations, locationId);
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting reservation:', error);
    return { success: false, error: 'Failed to delete reservation' };
  }
};

// Add table assignment to a reservation
export const assignTableToReservation = async (reservationId: string, tableId: string, locationId?: string) => {
  const result = await updateReservation(reservationId, { tableId }, locationId);
  return result;
};

// Get active reservation for a table
export const getActiveReservationForTable = async (tableId: string, locationId?: string) => {
  try {
    const reservations = initializeReservations(locationId);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Find reservations for this table that are for today and have a status of confirmed or pending
    const tableReservations = reservations.filter(r => {
      // Check if the reservation has this table ID
      if (r.tableId !== tableId) return false;
      
      // Skip cancelled, no-show, or completed reservations
      if (r.status === 'cancelled' || r.status === 'no-show' || r.status === 'completed') return false;
      
      // Convert the reservation date to a Date object if it's a string
      const reservationDate = typeof r.date === 'string' ? new Date(r.date) : r.date;
      
      // Check if the reservation is for today
      const isSameDay = 
        reservationDate.getFullYear() === today.getFullYear() &&
        reservationDate.getMonth() === today.getMonth() &&
        reservationDate.getDate() === today.getDate();
      
      // Check if the status is confirmed, pending or arrived
      const isActive = r.status === 'confirmed' || r.status === 'pending' || r.status === 'arrived';
      
      // For now just check if it's the same day and active
      return isSameDay && isActive;
    });
    
    // Return the first matching reservation or null
    return tableReservations.length > 0 ? tableReservations[0] : null;
  } catch (error) {
    console.error('Error getting active reservation for table:', error);
    return null;
  }
};

// Listen for reservation updates
export const setupReservationsSyncListeners = (
  callback: (locationId?: string) => void
): (() => void) => {
  const handleStorageChange = (event: StorageEvent) => {
    if (event.key && event.key.startsWith(RESERVATIONS_STORAGE_KEY)) {
      // Extract locationId from the key
      const keyParts = event.key.split('_');
      const locationId = keyParts.length > 2 ? keyParts.slice(2).join('_') : undefined;
      callback(locationId);
    }
  };
  
  const handleCustomEvent = (event: CustomEvent<{ locationId?: string }>) => {
    callback(event.detail?.locationId);
  };
  
  window.addEventListener('storage', handleStorageChange);
  window.addEventListener('reservations-updated', handleCustomEvent as EventListener);
  
  // Return cleanup function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
    window.removeEventListener('reservations-updated', handleCustomEvent as EventListener);
  };
};

// Generate sample reservations (for testing)
export const generateSampleReservations = (locationId?: string) => {
  const existingReservations = initializeReservations(locationId);
  
  if (existingReservations.length > 0) {
    toast.info('Sono già presenti delle prenotazioni');
    return;
  }
  
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  
  const sampleReservations: Reservation[] = [
    {
      id: generateId(),
      customerName: 'Mario Rossi',
      phone: '+39 333 1234567',
      email: 'mario.rossi@example.com',
      date: today,
      time: '20:00',
      partySize: 4,
      status: 'confirmed',
      notes: 'Preferisce un tavolo vicino alla finestra'
    },
    {
      id: generateId(),
      customerName: 'Giulia Bianchi',
      phone: '+39 333 7654321',
      date: today,
      time: '19:30',
      partySize: 2,
      status: 'pending'
    },
    {
      id: generateId(),
      customerName: 'Luca Verdi',
      phone: '+39 333 9876543',
      email: 'luca.verdi@example.com',
      date: tomorrow,
      time: '21:00',
      partySize: 6,
      status: 'confirmed',
      specialRequests: ['Seggiolone per bambini', 'Menù senza glutine']
    },
    {
      id: generateId(),
      customerName: 'Anna Neri',
      phone: '+39 333 5555555',
      date: tomorrow,
      time: '13:00',
      partySize: 3,
      status: 'cancelled',
      notes: 'Cancellata per imprevisto'
    }
  ];
  
  saveReservationsToStorage(sampleReservations, locationId);
  toast.success('Prenotazioni di esempio generate con successo');
};
