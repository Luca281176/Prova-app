import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface RestaurantInfo {
  name: string;
  address: string;
  phone: string;
  vat: string;
  logo: string | null;
  email?: string;
  website?: string;
  description?: string;
  openingHours?: string;
}

// Get restaurant info from Supabase
export const getRestaurantInfo = async (): Promise<RestaurantInfo> => {
  try {
    // Try to get restaurant settings from Supabase
    const { data: settings, error } = await supabase
      .from('restaurant_settings')
      .select('*')
      .single();
    
    if (error) {
      console.error("Error fetching restaurant info:", error);
      // Return default values if there's an error
      return {
        name: "Ristorante Esempio",
        address: "Via Roma 123, 00100 Roma",
        phone: "+39 06 1234567",
        vat: "P.IVA: IT12345678901",
        logo: null,
        email: "",
        website: "",
        description: "",
        openingHours: ""
      };
    }
    
    // Return restaurant info from settings
    return {
      name: settings.restaurant_name || "Ristorante Esempio",
      address: settings.general_settings?.address || "Via Roma 123, 00100 Roma",
      phone: settings.general_settings?.phone || "+39 06 1234567",
      vat: settings.general_settings?.vat || "P.IVA: IT12345678901",
      logo: settings.restaurant_logo || null,
      email: settings.general_settings?.email || "",
      website: settings.general_settings?.website || "",
      description: settings.general_settings?.description || "",
      openingHours: settings.general_settings?.opening_hours || ""
    };
  } catch (error) {
    console.error("Error in getRestaurantInfo:", error);
    // Return default values if there's an error
    return {
      name: "Ristorante Esempio",
      address: "Via Roma 123, 00100 Roma",
      phone: "+39 06 1234567",
      vat: "P.IVA: IT12345678901",
      logo: null,
      email: "",
      website: "",
      description: "",
      openingHours: ""
    };
  }
};

// Save restaurant info to Supabase
export const saveRestaurantInfo = async (data: Partial<RestaurantInfo>): Promise<boolean> => {
  try {
    // Check if current user is authenticated
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error('User not authenticated:', userError);
      toast.error(`Errore di autenticazione: ${userError?.message || 'Utente non autenticato'}`);
      return false;
    }
    
    // Get current settings
    const { data: existingSettings, error: fetchError } = await supabase
      .from('restaurant_settings')
      .select('*')
      .maybeSingle();
    
    if (fetchError && fetchError.code !== 'PGRST116') { // PGRST116 is "No rows found" error
      console.error('Error fetching settings:', fetchError);
      toast.error(`Errore nel recupero delle impostazioni: ${fetchError.message}`);
      return false;
    }
    
    // Prepare general settings with new data
    const generalSettings = {
      ...(existingSettings?.general_settings || {}),
      ...(data.address ? { address: data.address } : {}),
      ...(data.phone ? { phone: data.phone } : {}),
      ...(data.vat ? { vat: data.vat } : {}),
      ...(data.email ? { email: data.email } : {}),
      ...(data.website ? { website: data.website } : {}),
      ...(data.description ? { description: data.description } : {}),
      ...(data.openingHours ? { opening_hours: data.openingHours } : {})
    };
    
    // If settings exist, update them
    if (existingSettings) {
      const { error: updateError } = await supabase
        .from('restaurant_settings')
        .update({
          restaurant_name: data.name || existingSettings.restaurant_name,
          restaurant_logo: data.logo !== undefined ? data.logo : existingSettings.restaurant_logo,
          general_settings: generalSettings,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingSettings.id);
      
      if (updateError) {
        console.error('Error updating settings:', updateError);
        toast.error(`Errore nell'aggiornamento delle impostazioni: ${updateError.message}`);
        return false;
      }
    } else {
      // If settings don't exist, create them
      const { error: insertError } = await supabase
        .from('restaurant_settings')
        .insert({
          user_id: userData.user.id,
          restaurant_name: data.name || "Ristorante Esempio",
          restaurant_logo: data.logo || null,
          general_settings: generalSettings
        });
      
      if (insertError) {
        console.error('Error creating settings:', insertError);
        toast.error(`Errore nella creazione delle impostazioni: ${insertError.message}`);
        return false;
      }
    }
    
    // Dispatch an event to notify other components
    window.dispatchEvent(new CustomEvent('restaurant-info-updated'));
    
    console.log("Restaurant info updated successfully");
    toast.success("Informazioni ristorante aggiornate con successo");
    return true;
  } catch (error) {
    console.error("Error saving restaurant info:", error);
    toast.error(`Errore nel salvare le informazioni del ristorante: ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
};

// Delete restaurant logo
export const deleteRestaurantLogo = async (): Promise<boolean> => {
  try {
    // Get current settings
    const { data: settings, error: fetchError } = await supabase
      .from('restaurant_settings')
      .select('*')
      .single();
    
    if (fetchError) {
      console.error('Error fetching settings:', fetchError);
      toast.error(`Errore nel recupero delle impostazioni: ${fetchError.message}`);
      return false;
    }
    
    // Update settings to remove logo
    const { error: updateError } = await supabase
      .from('restaurant_settings')
      .update({
        restaurant_logo: null,
        updated_at: new Date().toISOString()
      })
      .eq('id', settings.id);
    
    if (updateError) {
      console.error('Error updating settings:', updateError);
      toast.error(`Errore nell'aggiornamento delle impostazioni: ${updateError.message}`);
      return false;
    }
    
    // Dispatch an event to notify other components
    window.dispatchEvent(new CustomEvent('restaurant-info-updated'));
    
    console.log("Restaurant logo deleted successfully");
    toast.success("Logo ristorante rimosso con successo");
    return true;
  } catch (error) {
    console.error("Error deleting restaurant logo:", error);
    toast.error(`Errore nella rimozione del logo: ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
};
