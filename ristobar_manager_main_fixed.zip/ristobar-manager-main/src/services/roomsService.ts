
import { Room, Table } from '@/components/RoomGrid';

// Prefix for storage keys
const STORAGE_KEY_PREFIX = 'restaurant_rooms_data';

// Helper to generate unique IDs
const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Get storage key for a specific location
const getStorageKey = (locationId?: string): string => {
  return locationId 
    ? `${STORAGE_KEY_PREFIX}_${locationId}` 
    : STORAGE_KEY_PREFIX;
};

// Helper to get a single room by ID
export const getRoomById = async (roomId: string, locationId?: string): Promise<Room | null> => {
  try {
    console.log(`getRoomById: Looking for room ${roomId} in location ${locationId || 'default'}`);
    const rooms = initializeRooms(locationId);
    const room = rooms.find(room => room.id === roomId);
    
    if (room) {
      // Ensure tables is an array
      if (!Array.isArray(room.tables)) {
        console.warn(`Room ${roomId} has invalid tables property, fixing it`);
        room.tables = [];
      }
      
      console.log(`Room found:`, room);
      console.log(`Room has ${room.tables.length} tables`);
    } else {
      console.warn(`Room ${roomId} not found`);
    }
    
    return room || null;
  } catch (error) {
    console.error(`Error in getRoomById for room ${roomId}:`, error);
    return null;
  }
};

// Initialize data from localStorage with better error handling and logging
export const initializeRooms = (locationId?: string): Room[] => {
  const storageKey = getStorageKey(locationId);
  console.log(`Initializing rooms from storage key: ${storageKey}`);
  
  try {
    const storedData = localStorage.getItem(storageKey);
    
    if (!storedData) {
      console.log(`No rooms data found in localStorage for ${locationId || 'default location'}, creating empty array`);
      localStorage.setItem(storageKey, JSON.stringify([]));
      return [];
    }
    
    try {
      const parsedData = JSON.parse(storedData);
      if (!Array.isArray(parsedData)) {
        console.warn(`Invalid rooms data format in localStorage, expected array but got:`, typeof parsedData);
        localStorage.setItem(storageKey, JSON.stringify([]));
        return [];
      }
      
      console.log(`Retrieved ${parsedData.length} rooms from localStorage for ${locationId || 'default location'}`);
      
      // Ensure all rooms have properly initialized tables arrays
      const normalizedData = parsedData.map((room: Room) => {
        // Create a new room object with all properties from the original
        const normalizedRoom = {
          ...room,
          // Ensure tables is an array
          tables: Array.isArray(room.tables) ? room.tables.map((table: Table) => ({
            ...table,
            status: table.status || 'available'  // Default to available if status is missing
          })) : []
        };
        
        console.log(`Room ${room.id} (${room.name}) has ${normalizedRoom.tables.length} tables after normalization`);
        return normalizedRoom;
      });
      
      // Save the normalized data back to localStorage
      localStorage.setItem(storageKey, JSON.stringify(normalizedData));
      
      return normalizedData;
    } catch (error) {
      console.error('Error parsing stored rooms data:', error);
      localStorage.setItem(storageKey, JSON.stringify([]));
      return [];
    }
  } catch (error) {
    console.error('Error accessing localStorage:', error);
    return [];
  }
};

// Save rooms data to localStorage with better error handling
const saveRoomsToStorage = (rooms: Room[], locationId?: string): void => {
  const storageKey = getStorageKey(locationId);
  
  try {
    console.log(`Saving ${rooms.length} rooms to localStorage for ${locationId || 'default location'}`);
    
    // Ensure all rooms have properly initialized tables arrays
    const normalizedRooms = rooms.map(room => {
      if (!Array.isArray(room.tables)) {
        console.warn(`Room ${room.id} (${room.name}) has invalid tables property, fixing it before saving`);
        return { ...room, tables: [] };
      }
      return room;
    });
    
    // Log each room's tables for debugging
    normalizedRooms.forEach(room => {
      console.log(`Room ${room.id} (${room.name}) has ${room.tables.length} tables before saving`);
    });
    
    localStorage.setItem(storageKey, JSON.stringify(normalizedRooms));
    console.log(`Rooms saved successfully to localStorage key: ${storageKey}`);
    
    // Dispatch an event to notify other tabs/windows
    window.dispatchEvent(new CustomEvent('rooms-updated', {
      detail: { locationId }
    }));
  } catch (error) {
    console.error('Error saving rooms data to storage:', error);
  }
};

// Helper to find a room by table ID
export const findRoomByTableId = async (tableId: string, locationId?: string): Promise<Room | null> => {
  const rooms = initializeRooms(locationId);
  console.log(`Finding room for table ${tableId} among ${rooms.length} rooms`);
  
  for (const room of rooms) {
    if (!Array.isArray(room.tables)) {
      console.warn(`Room ${room.id} has invalid tables property`);
      continue;
    }
    
    const tableExists = room.tables.some(table => table.id === tableId);
    if (tableExists) {
      console.log(`Found table ${tableId} in room ${room.id}`);
      return room;
    }
  }
  console.warn(`No room found containing table ${tableId}`);
  return null;
};

// Room operations
export const fetchRooms = async (locationId?: string): Promise<Room[]> => {
  return new Promise((resolve) => {
    // No simulated delay, just return the rooms
    const rooms = initializeRooms(locationId);
    console.log("roomsService: Fetched rooms:", rooms);
    resolve(rooms);
  });
};

export const addRoom = async (
  roomData: { name: string; capacity: number }, 
  locationId?: string
): Promise<Room> => {
  return new Promise((resolve) => {
    const rooms = initializeRooms(locationId);
    const newRoom: Room = {
      id: generateId(),
      name: roomData.name,
      capacity: roomData.capacity,
      tables: []
    };
    
    const updatedRooms = [...rooms, newRoom];
    saveRoomsToStorage(updatedRooms, locationId);
    resolve(newRoom);
  });
};

export const updateRoom = async (
  roomId: string, 
  roomData: { name: string; capacity: number },
  locationId?: string
): Promise<Room> => {
  return new Promise((resolve, reject) => {
    const rooms = initializeRooms(locationId);
    const roomIndex = rooms.findIndex(room => room.id === roomId);
    
    if (roomIndex === -1) {
      reject(new Error(`Room with ID ${roomId} not found`));
      return;
    }
    
    const updatedRoom = {
      ...rooms[roomIndex],
      name: roomData.name,
      capacity: roomData.capacity
    };
    
    const updatedRooms = [...rooms];
    updatedRooms[roomIndex] = updatedRoom;
    
    saveRoomsToStorage(updatedRooms, locationId);
    resolve(updatedRoom);
  });
};

export const deleteRoom = async (
  roomId: string,
  locationId?: string
): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    const rooms = initializeRooms(locationId);
    const roomIndex = rooms.findIndex(room => room.id === roomId);
    
    if (roomIndex === -1) {
      reject(new Error(`Room with ID ${roomId} not found`));
      return;
    }
    
    const updatedRooms = rooms.filter(room => room.id !== roomId);
    saveRoomsToStorage(updatedRooms, locationId);
    resolve(true);
  });
};

// Table operations with fixed validation and error handling
export const addTable = async (
  roomId: string, 
  tableData: Partial<Table>,
  locationId?: string
): Promise<Table> => {
  return new Promise((resolve, reject) => {
    try {
      console.log(`Adding table to room ${roomId} with data:`, tableData);
      
      // Get all rooms
      const rooms = initializeRooms(locationId);
      console.log(`Got ${rooms.length} rooms, searching for room ${roomId}`);
      
      // Find the room
      const roomIndex = rooms.findIndex(r => r.id === roomId);
      if (roomIndex === -1) {
        const error = `Room with ID ${roomId} not found in rooms array`;
        console.error(error);
        reject(new Error(error));
        return;
      }
      
      // Ensure the room has a tables array
      if (!Array.isArray(rooms[roomIndex].tables)) {
        console.warn(`Room ${roomId} had no tables array, creating one`);
        rooms[roomIndex].tables = [];
      }
      
      // Create the new table with all required fields
      const newTable: Table = {
        id: generateId(),
        name: tableData.name || 'Nuovo Tavolo',
        seats: tableData.seats || 4,
        status: tableData.status || 'available',
        shape: tableData.shape || 'round',
      };
      
      console.log(`Created new table:`, newTable);
      
      // Add the new table to the room
      rooms[roomIndex].tables.push(newTable);
      
      // Log the updated room
      console.log(`Room ${roomId} now has ${rooms[roomIndex].tables.length} tables after adding new table`);
      
      // Save to storage
      saveRoomsToStorage(rooms, locationId);
      
      // Double check if the table was added correctly
      const freshRooms = initializeRooms(locationId);
      const freshRoom = freshRooms.find(r => r.id === roomId);
      
      if (!freshRoom || !Array.isArray(freshRoom.tables) || !freshRoom.tables.some(t => t.id === newTable.id)) {
        console.error("Table was not properly saved to storage!");
        console.log("Fresh rooms:", freshRooms);
        if (freshRoom) {
          console.log(`Fresh room tables:`, freshRoom.tables);
        }
      } else {
        console.log(`Table successfully saved. Room now has ${freshRoom.tables.length} tables`);
      }
      
      resolve(newTable);
    } catch (error) {
      console.error(`Error in addTable:`, error);
      reject(error);
    }
  });
};

export const updateTable = async (
  roomId: string,
  tableId: string,
  tableData: Partial<Table>,
  locationId?: string
): Promise<Table> => {
  return new Promise((resolve, reject) => {
    const rooms = initializeRooms(locationId);
    const roomIndex = rooms.findIndex(room => room.id === roomId);
    
    if (roomIndex === -1) {
      reject(new Error(`Room with ID ${roomId} not found`));
      return;
    }
    
    // Ensure tables is an array
    if (!Array.isArray(rooms[roomIndex].tables)) {
      rooms[roomIndex].tables = [];
    }
    
    const tableIndex = rooms[roomIndex].tables.findIndex(table => table.id === tableId);
    
    if (tableIndex === -1) {
      reject(new Error(`Table with ID ${tableId} not found in room ${roomId}`));
      return;
    }
    
    const updatedTable = {
      ...rooms[roomIndex].tables[tableIndex],
      ...tableData
    };
    
    const updatedTables = [...rooms[roomIndex].tables];
    updatedTables[tableIndex] = updatedTable;
    
    const updatedRoom = {
      ...rooms[roomIndex],
      tables: updatedTables
    };
    
    const updatedRooms = [...rooms];
    updatedRooms[roomIndex] = updatedRoom;
    
    saveRoomsToStorage(updatedRooms, locationId);
    resolve(updatedTable);
  });
};

export const updateTableStatus = async (
  tableId: string, 
  newStatus: Table['status'],
  locationId?: string
): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    console.log(`Updating table ${tableId} status to ${newStatus}`);
    const rooms = initializeRooms(locationId);
    let tableFound = false;
    let updatedRooms = [...rooms];
    
    for (let i = 0; i < updatedRooms.length; i++) {
      // Ensure tables is an array
      if (!Array.isArray(updatedRooms[i].tables)) {
        updatedRooms[i].tables = [];
        continue;
      }
      
      for (let j = 0; j < updatedRooms[i].tables.length; j++) {
        if (updatedRooms[i].tables[j].id === tableId) {
          tableFound = true;
          console.log(`Found table ${tableId} in room ${updatedRooms[i].id}, updating status from ${updatedRooms[i].tables[j].status} to ${newStatus}`);
          
          // Create a new table with updated status
          const updatedTable = {
            ...updatedRooms[i].tables[j],
            status: newStatus
          };
          
          // Create a new tables array
          const updatedTables = [...updatedRooms[i].tables];
          updatedTables[j] = updatedTable;
          
          // Create a new room with updated tables
          updatedRooms[i] = {
            ...updatedRooms[i],
            tables: updatedTables
          };
          
          break;
        }
      }
      
      if (tableFound) break;
    }
    
    if (!tableFound) {
      console.error(`Table with ID ${tableId} not found`);
      reject(new Error(`Table with ID ${tableId} not found`));
      return;
    }
    
    saveRoomsToStorage(updatedRooms, locationId);
    console.log("Table status updated successfully");
    resolve(true);
  });
};

export const deleteTable = async (
  roomId: string, 
  tableId: string,
  locationId?: string
): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    const rooms = initializeRooms(locationId);
    const roomIndex = rooms.findIndex(room => room.id === roomId);
    
    if (roomIndex === -1) {
      reject(new Error(`Room with ID ${roomId} not found`));
      return;
    }
    
    // Ensure tables is an array
    if (!Array.isArray(rooms[roomIndex].tables)) {
      rooms[roomIndex].tables = [];
      reject(new Error(`Table with ID ${tableId} not found in room ${roomId}`));
      return;
    }
    
    const tableExists = rooms[roomIndex].tables.some(table => table.id === tableId);
    
    if (!tableExists) {
      reject(new Error(`Table with ID ${tableId} not found in room ${roomId}`));
      return;
    }
    
    const updatedRoom = {
      ...rooms[roomIndex],
      tables: rooms[roomIndex].tables.filter(table => table.id !== tableId)
    };
    
    const updatedRooms = [...rooms];
    updatedRooms[roomIndex] = updatedRoom;
    
    saveRoomsToStorage(updatedRooms, locationId);
    resolve(true);
  });
};

// Listen for storage events (for cross-tab updates)
export const setupRoomsSyncListeners = (
  callback: (locationId?: string) => void
): (() => void) => {
  const handleStorageChange = (event: StorageEvent) => {
    if (event.key && event.key.startsWith(STORAGE_KEY_PREFIX)) {
      // Extract locationId from the key
      const keyParts = event.key.split('_');
      const locationId = keyParts.length > 2 ? keyParts.slice(2).join('_') : undefined;
      callback(locationId);
    }
  };
  
  const handleCustomEvent = (event: CustomEvent<{ locationId?: string }>) => {
    callback(event.detail?.locationId);
  };
  
  window.addEventListener('storage', handleStorageChange);
  window.addEventListener('rooms-updated', handleCustomEvent as EventListener);
  
  // Return cleanup function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
    window.removeEventListener('rooms-updated', handleCustomEvent as EventListener);
  };
};
