
// Check if we're running in the browser or in a test environment
const isBrowser = typeof window !== 'undefined';

// Restaurant information storage key
const RESTAURANT_INFO_KEY = 'risto_restaurant_info';

// Default restaurant info
const defaultRestaurantInfo = {
  name: 'Ristorante Esempio',
  address: 'Via Roma 123, 00100 Roma',
  phone: '+39 06 1234567',
  email: 'info@ristoranteesempio.it',
  website: 'www.ristoranteesempio.it',
  logo: '',
  taxId: 'IT12345678901',
  businessName: 'Ristorante Esempio S.r.l.'
};

// Business settings storage key
const BUSINESS_SETTINGS_KEY = 'risto_business_settings';

// Default business settings
const defaultBusinessSettings = {
  currency: 'EUR',
  taxRate: 10,
  serviceCharge: 0,
  tipOptions: [5, 10, 15, 20],
  enableTipping: true,
  receiptFooterText: 'Grazie per averci scelto! Torna a trovarci presto.',
  language: 'it',
  timeFormat: '24h' // or '12h'
};

// UI settings storage key
const UI_SETTINGS_KEY = 'risto_ui_settings';

// Default UI settings
const defaultUiSettings = {
  theme: 'light',
  primaryColor: '#1e40af', // Primary blue
  fontFamily: 'Inter',
  fontSize: 'medium',
  compactMode: false,
  animationsEnabled: true,
  dashboardLayout: 'default'
};

// Cashier settings storage key
const CASHIER_SETTINGS_KEY = 'risto_cashier_settings';

// Default cashier settings
export interface CashierSettings {
  enableCreditCard: boolean;
  enableDigitalPayments: boolean;
  enableInvoice: boolean;
  vatRate: number;
  autoPrint: boolean;
  printLogo: boolean;
  receiptFooter: string;
}

const defaultCashierSettings: CashierSettings = {
  enableCreditCard: true,
  enableDigitalPayments: true,
  enableInvoice: true,
  vatRate: 22,
  autoPrint: true,
  printLogo: true,
  receiptFooter: 'Grazie per averci scelto!'
};

// Inventory settings storage key
const INVENTORY_SETTINGS_KEY = 'risto_inventory_settings';

// Default inventory settings
export interface InventorySettings {
  lowStockThreshold: number;
  expiryWarningDays: number;
  autoOrderEnabled: boolean;
  orderNotifications: boolean;
  preferredSuppliers: string[];
}

const defaultInventorySettings: InventorySettings = {
  lowStockThreshold: 10,
  expiryWarningDays: 14,
  autoOrderEnabled: true,
  orderNotifications: true,
  preferredSuppliers: []
};

// Function to load restaurant information
export const loadRestaurantInfo = () => {
  if (!isBrowser) return defaultRestaurantInfo;
  
  try {
    const storedInfo = localStorage.getItem(RESTAURANT_INFO_KEY);
    if (storedInfo) {
      return JSON.parse(storedInfo);
    }
    // If no stored info, save and return defaults
    saveRestaurantInfo(defaultRestaurantInfo);
    return defaultRestaurantInfo;
  } catch (error) {
    console.error('Error loading restaurant info:', error);
    return defaultRestaurantInfo;
  }
};

// Function to save restaurant information
export const saveRestaurantInfo = (info) => {
  if (!isBrowser) return;
  
  try {
    localStorage.setItem(RESTAURANT_INFO_KEY, JSON.stringify(info));
  } catch (error) {
    console.error('Error saving restaurant info:', error);
  }
};

// Function to update restaurant logo
export const updateRestaurantLogo = (logoUrl) => {
  if (!isBrowser) return;
  
  try {
    const currentInfo = loadRestaurantInfo();
    const updatedInfo = { ...currentInfo, logo: logoUrl };
    saveRestaurantInfo(updatedInfo);
    return updatedInfo;
  } catch (error) {
    console.error('Error updating restaurant logo:', error);
  }
};

// Function to delete restaurant logo
export const deleteRestaurantLogo = (userId?: string) => {
  if (!isBrowser) return false;
  
  try {
    const currentInfo = loadRestaurantInfo();
    const updatedInfo = { ...currentInfo, logo: '' };
    saveRestaurantInfo(updatedInfo);
    
    // If user ID is provided, remove from user-specific storage too
    if (userId) {
      localStorage.removeItem(`${userId}_restaurantLogo`);
    }
    
    return true;
  } catch (error) {
    console.error('Error deleting restaurant logo:', error);
    return false;
  }
};

// Function to load business settings
export const loadBusinessSettings = () => {
  if (!isBrowser) return defaultBusinessSettings;
  
  try {
    const storedSettings = localStorage.getItem(BUSINESS_SETTINGS_KEY);
    if (storedSettings) {
      return JSON.parse(storedSettings);
    }
    // If no stored settings, save and return defaults
    saveBusinessSettings(defaultBusinessSettings);
    return defaultBusinessSettings;
  } catch (error) {
    console.error('Error loading business settings:', error);
    return defaultBusinessSettings;
  }
};

// Function to save business settings
export const saveBusinessSettings = (settings) => {
  if (!isBrowser) return;
  
  try {
    localStorage.setItem(BUSINESS_SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error('Error saving business settings:', error);
  }
};

// Function to load UI settings
export const loadUiSettings = () => {
  if (!isBrowser) return defaultUiSettings;
  
  try {
    const storedSettings = localStorage.getItem(UI_SETTINGS_KEY);
    if (storedSettings) {
      return JSON.parse(storedSettings);
    }
    // If no stored settings, save and return defaults
    saveUiSettings(defaultUiSettings);
    return defaultUiSettings;
  } catch (error) {
    console.error('Error loading UI settings:', error);
    return defaultUiSettings;
  }
};

// Function to save UI settings
export const saveUiSettings = (settings) => {
  if (!isBrowser) return;
  
  try {
    localStorage.setItem(UI_SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error('Error saving UI settings:', error);
  }
};

// Function to update a specific UI setting
export const updateUiSetting = (key, value) => {
  if (!isBrowser) return;
  
  try {
    const currentSettings = loadUiSettings();
    const updatedSettings = { ...currentSettings, [key]: value };
    saveUiSettings(updatedSettings);
    return updatedSettings;
  } catch (error) {
    console.error(`Error updating UI setting '${key}':`, error);
  }
};

// Function to load cashier settings
export const loadCashierSettings = (userId?: string) => {
  if (!isBrowser) return defaultCashierSettings;
  
  try {
    const storageKey = userId ? `${userId}_${CASHIER_SETTINGS_KEY}` : CASHIER_SETTINGS_KEY;
    const storedSettings = localStorage.getItem(storageKey);
    if (storedSettings) {
      return JSON.parse(storedSettings);
    }
    // If no stored settings, save and return defaults
    saveCashierSettings(defaultCashierSettings, userId);
    return defaultCashierSettings;
  } catch (error) {
    console.error('Error loading cashier settings:', error);
    return defaultCashierSettings;
  }
};

// Function to save cashier settings
export const saveCashierSettings = (settings: CashierSettings, userId?: string): boolean => {
  if (!isBrowser) return false;
  
  try {
    const storageKey = userId ? `${userId}_${CASHIER_SETTINGS_KEY}` : CASHIER_SETTINGS_KEY;
    localStorage.setItem(storageKey, JSON.stringify(settings));
    return true;
  } catch (error) {
    console.error('Error saving cashier settings:', error);
    return false;
  }
};

// Function to load inventory settings
export const loadInventorySettings = (userId?: string) => {
  if (!isBrowser) return defaultInventorySettings;
  
  try {
    const storageKey = userId ? `${userId}_${INVENTORY_SETTINGS_KEY}` : INVENTORY_SETTINGS_KEY;
    const storedSettings = localStorage.getItem(storageKey);
    if (storedSettings) {
      return JSON.parse(storedSettings);
    }
    // If no stored settings, save and return defaults
    saveInventorySettings(defaultInventorySettings, userId);
    return defaultInventorySettings;
  } catch (error) {
    console.error('Error loading inventory settings:', error);
    return defaultInventorySettings;
  }
};

// Function to save inventory settings
export const saveInventorySettings = (settings: InventorySettings, userId?: string): boolean => {
  if (!isBrowser) return false;
  
  try {
    const storageKey = userId ? `${userId}_${INVENTORY_SETTINGS_KEY}` : INVENTORY_SETTINGS_KEY;
    localStorage.setItem(storageKey, JSON.stringify(settings));
    return true;
  } catch (error) {
    console.error('Error saving inventory settings:', error);
    return false;
  }
};
