
import { v4 as uuidv4 } from 'uuid';
import { StaffMember, Shift, PerformanceRecord } from '@/contexts/StaffContext';
import { getUserData, saveUserDataToStorage } from '@/contexts/user/storage/userDataStorage';

// Local storage keys with tenant isolation
const STAFF_MEMBERS_KEY = 'staff_members';
const SHIFTS_KEY = 'staff_shifts';
const PERFORMANCE_KEY = 'staff_performance';

// Get the current user ID from UserContext
const getCurrentUserId = (): string => {
  try {
    const userFromStorage = localStorage.getItem('user');
    if (userFromStorage) {
      const userData = JSON.parse(userFromStorage);
      return userData.id;
    }
    // Fallback to sessionStorage if not in localStorage
    const sessionUser = sessionStorage.getItem('registered_user');
    if (sessionUser) {
      const sessionData = JSON.parse(sessionUser);
      if (sessionData && sessionData.user) {
        return sessionData.user.id;
      }
    }
    console.warn('No user ID found, using default');
    return 'default_user';
  } catch (error) {
    console.error('Error getting current user ID:', error);
    return 'default_user';
  }
};

// Get staff members from storage
export const getStaffMembers = async (defaultStaff: StaffMember[] = []): Promise<StaffMember[]> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Getting staff members for user: ${userId}`);
    const staff = await getUserData(userId, STAFF_MEMBERS_KEY, defaultStaff);
    return Array.isArray(staff) ? staff : defaultStaff;
  } catch (error) {
    console.error('Error getting staff members:', error);
    return defaultStaff;
  }
};

// Save staff members to storage
export const saveStaffMembers = async (staff: StaffMember[]): Promise<void> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Saving staff members for user: ${userId}`, staff);
    await saveUserDataToStorage(userId, STAFF_MEMBERS_KEY, staff);
    
    // Also save to localStorage directly as a backup
    try {
      localStorage.setItem(`${userId}_${STAFF_MEMBERS_KEY}`, JSON.stringify(staff));
    } catch (localError) {
      console.warn('Failed to save to localStorage directly:', localError);
    }
  } catch (error) {
    console.error('Error saving staff members:', error);
    // Attempt to save directly to localStorage as emergency fallback
    try {
      localStorage.setItem(`${userId}_${STAFF_MEMBERS_KEY}`, JSON.stringify(staff));
    } catch (fallbackError) {
      console.error('Emergency fallback failed too:', fallbackError);
    }
  }
};

// Add a new staff member
export const addStaffMember = async (staffMember: Omit<StaffMember, 'id'>): Promise<StaffMember> => {
  const newMember: StaffMember = {
    ...staffMember,
    id: uuidv4()
  };
  
  const currentStaff = await getStaffMembers();
  const updatedStaff = [...currentStaff, newMember];
  await saveStaffMembers(updatedStaff);
  
  return newMember;
};

// Update an existing staff member
export const updateStaffMember = async (id: string, data: Partial<StaffMember>): Promise<StaffMember> => {
  const currentStaff = await getStaffMembers();
  const memberIndex = currentStaff.findIndex(member => member.id === id);
  
  if (memberIndex === -1) {
    throw new Error(`Staff member with ID ${id} not found`);
  }
  
  const updatedMember = {
    ...currentStaff[memberIndex],
    ...data
  };
  
  const updatedStaff = [...currentStaff];
  updatedStaff[memberIndex] = updatedMember;
  await saveStaffMembers(updatedStaff);
  
  return updatedMember;
};

// Delete a staff member
export const deleteStaffMember = async (id: string): Promise<void> => {
  const currentStaff = await getStaffMembers();
  const updatedStaff = currentStaff.filter(member => member.id !== id);
  
  if (updatedStaff.length === currentStaff.length) {
    throw new Error(`Staff member with ID ${id} not found`);
  }
  
  await saveStaffMembers(updatedStaff);
  
  // Also remove related shifts and performance records
  const userId = getCurrentUserId();
  const shifts = await getShifts();
  const updatedShifts = shifts.filter(shift => shift.staffId !== id);
  await saveShifts(updatedShifts);
  
  const performance = await getPerformanceRecords();
  const updatedPerformance = performance.filter(record => record.staffId !== id);
  await savePerformanceRecords(updatedPerformance);
};

// Get shifts from storage
export const getShifts = async (defaultShifts: Shift[] = []): Promise<Shift[]> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Getting shifts for user: ${userId}`);
    const shifts = await getUserData(userId, SHIFTS_KEY, defaultShifts);
    return Array.isArray(shifts) ? shifts : defaultShifts;
  } catch (error) {
    console.error('Error getting shifts:', error);
    return defaultShifts;
  }
};

// Save shifts to storage
export const saveShifts = async (shifts: Shift[]): Promise<void> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Saving shifts for user: ${userId}`);
    await saveUserDataToStorage(userId, SHIFTS_KEY, shifts);
    // Direct backup to localStorage
    localStorage.setItem(`${userId}_${SHIFTS_KEY}`, JSON.stringify(shifts));
  } catch (error) {
    console.error('Error saving shifts:', error);
    // Fallback direct save
    try {
      localStorage.setItem(`${userId}_${SHIFTS_KEY}`, JSON.stringify(shifts));
    } catch (fallbackError) {
      console.error('Fallback save failed:', fallbackError);
    }
  }
};

// Add a new shift
export const addShift = async (shift: Omit<Shift, 'id'>): Promise<Shift> => {
  const newShift: Shift = {
    ...shift,
    id: uuidv4()
  };
  
  const currentShifts = await getShifts();
  await saveShifts([...currentShifts, newShift]);
  
  return newShift;
};

// Update an existing shift
export const updateShift = async (id: string, data: Partial<Shift>): Promise<Shift> => {
  const currentShifts = await getShifts();
  const shiftIndex = currentShifts.findIndex(shift => shift.id === id);
  
  if (shiftIndex === -1) {
    throw new Error(`Shift with ID ${id} not found`);
  }
  
  const updatedShift = {
    ...currentShifts[shiftIndex],
    ...data
  };
  
  const updatedShifts = [...currentShifts];
  updatedShifts[shiftIndex] = updatedShift;
  await saveShifts(updatedShifts);
  
  return updatedShift;
};

// Delete a shift
export const deleteShift = async (id: string): Promise<void> => {
  const currentShifts = await getShifts();
  const updatedShifts = currentShifts.filter(shift => shift.id !== id);
  
  if (updatedShifts.length === currentShifts.length) {
    throw new Error(`Shift with ID ${id} not found`);
  }
  
  await saveShifts(updatedShifts);
};

// Get performance records from storage
export const getPerformanceRecords = async (defaultRecords: PerformanceRecord[] = []): Promise<PerformanceRecord[]> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Getting performance records for user: ${userId}`);
    const records = await getUserData(userId, PERFORMANCE_KEY, defaultRecords);
    return Array.isArray(records) ? records : defaultRecords;
  } catch (error) {
    console.error('Error getting performance records:', error);
    return defaultRecords;
  }
};

// Save performance records to storage
export const savePerformanceRecords = async (records: PerformanceRecord[]): Promise<void> => {
  const userId = getCurrentUserId();
  try {
    console.log(`Saving performance records for user: ${userId}`);
    await saveUserDataToStorage(userId, PERFORMANCE_KEY, records);
    // Direct backup
    localStorage.setItem(`${userId}_${PERFORMANCE_KEY}`, JSON.stringify(records));
  } catch (error) {
    console.error('Error saving performance records:', error);
    try {
      localStorage.setItem(`${userId}_${PERFORMANCE_KEY}`, JSON.stringify(records));
    } catch (fallbackError) {
      console.error('Fallback save failed:', fallbackError);
    }
  }
};

// Add a new performance record
export const addPerformanceRecord = async (record: Omit<PerformanceRecord, 'id'>): Promise<PerformanceRecord> => {
  const newRecord: PerformanceRecord = {
    ...record,
    id: uuidv4()
  };
  
  const currentRecords = await getPerformanceRecords();
  await savePerformanceRecords([...currentRecords, newRecord]);
  
  return newRecord;
};

// Update a performance record
export const updatePerformanceRecord = async (id: string, data: Partial<PerformanceRecord>): Promise<PerformanceRecord> => {
  const currentRecords = await getPerformanceRecords();
  const recordIndex = currentRecords.findIndex(record => record.id === id);
  
  if (recordIndex === -1) {
    throw new Error(`Performance record with ID ${id} not found`);
  }
  
  const updatedRecord = {
    ...currentRecords[recordIndex],
    ...data
  };
  
  const updatedRecords = [...currentRecords];
  updatedRecords[recordIndex] = updatedRecord;
  await savePerformanceRecords(updatedRecords);
  
  return updatedRecord;
};

// Setup storage event listeners for real-time sync
export const setupStaffSyncListeners = (
  onStorageChange: (key: string) => void
): (() => void) => {
  const handleStorageChange = (e: StorageEvent) => {
    const key = e.key;
    if (!key) return;
    
    const userId = getCurrentUserId();
    const staffKey = `${userId}_${STAFF_MEMBERS_KEY}`;
    const shiftsKey = `${userId}_${SHIFTS_KEY}`;
    const performanceKey = `${userId}_${PERFORMANCE_KEY}`;
    
    if (key === staffKey || key === shiftsKey || key === performanceKey) {
      console.log(`Storage changed: ${key}`);
      onStorageChange(key);
    }
  };
  
  window.addEventListener('storage', handleStorageChange);
  
  // Return a cleanup function
  return () => {
    window.removeEventListener('storage', handleStorageChange);
  };
};
