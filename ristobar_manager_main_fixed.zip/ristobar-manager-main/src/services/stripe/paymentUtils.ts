
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export type PaymentStatus = 'success' | 'failed' | 'pending';

interface SendPaymentConfirmationParams {
  userId: string;
  paymentType: 'subscription' | 'order';
  paymentDetails: {
    planName?: string;
    planPrice?: string;
    status?: 'success' | 'failed';
    orderNumber?: string;
    totalAmount?: string;
  };
}

/**
 * Verifica lo stato di un pagamento Stripe
 */
export const verifyPaymentStatus = async (paymentIntentId: string): Promise<PaymentStatus> => {
  try {
    console.log('Verifying payment status:', paymentIntentId);
    
    const { data, error } = await supabase.functions.invoke('verify-payment', {
      body: { paymentIntentId }
    });
    
    if (error) {
      console.error('Error verifying payment:', error);
      return 'failed';
    }
    
    return data.status as PaymentStatus;
  } catch (error) {
    console.error('Error in payment verification:', error);
    return 'failed';
  }
};

/**
 * Invia una email di conferma di pagamento
 */
export const sendPaymentConfirmationEmail = async (params: SendPaymentConfirmationParams): Promise<boolean> => {
  try {
    console.log('Sending payment confirmation email:', params);
    
    const { data, error } = await supabase.functions.invoke('send-payment-confirmation', {
      body: params
    });
    
    if (error) {
      console.error('Error sending payment confirmation:', error);
      toast.error('Errore nell\'invio dell\'email di conferma');
      return false;
    }
    
    console.log('Payment confirmation email sent successfully');
    return true;
  } catch (error) {
    console.error('Error in sending payment confirmation:', error);
    toast.error('Errore nell\'invio dell\'email di conferma');
    return false;
  }
};

/**
 * Aggiorna lo stato di un ordine dopo un pagamento
 */
export const updateOrderAfterPayment = async (
  orderId: string, 
  paymentStatus: PaymentStatus
): Promise<boolean> => {
  try {
    console.log('Updating order after payment:', { orderId, paymentStatus });
    
    const { error } = await supabase
      .from('orders')
      .update({ 
        status: paymentStatus === 'success' ? 'paid' : 'payment_failed',
        updated_at: new Date().toISOString()
      })
      .eq('id', orderId);
    
    if (error) {
      console.error('Error updating order status:', error);
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error in order update:', error);
    return false;
  }
};

/**
 * Simula un pagamento fallito per test
 */
export const simulateFailedPayment = async (subscriptionId: string): Promise<boolean> => {
  try {
    // Questa funzione è solo per test e simulerà un pagamento fallito
    console.log('Simulating failed payment for subscription:', subscriptionId);
    
    // Aggiorna lo stato dell'abbonamento
    const { error } = await supabase
      .from('user_subscriptions')
      .update({ 
        status: 'past_due',
        updated_at: new Date().toISOString()
      })
      .eq('id', subscriptionId);
    
    if (error) {
      console.error('Error simulating failed payment:', error);
      return false;
    }
    
    // Mostra una notifica di test
    toast.error('Simulazione: Pagamento fallito', {
      description: 'Lo stato dell\'abbonamento è stato aggiornato a "past_due"',
    });
    
    return true;
  } catch (error) {
    console.error('Error in payment simulation:', error);
    return false;
  }
};

/**
 * Processa un pagamento dopo un checkout
 */
export const processPaymentAfterCheckout = async (
  sessionId: string,
  orderId?: string
): Promise<boolean> => {
  try {
    console.log('Processing payment after checkout:', { sessionId, orderId });
    
    const { data, error } = await supabase.functions.invoke('process-checkout-payment', {
      body: { 
        sessionId,
        orderId
      }
    });
    
    if (error) {
      console.error('Error processing payment:', error);
      toast.error('Errore nell\'elaborazione del pagamento');
      return false;
    }
    
    if (data.success) {
      toast.success('Pagamento elaborato con successo');
      return true;
    } else {
      toast.error('Errore nell\'elaborazione del pagamento');
      return false;
    }
  } catch (error) {
    console.error('Error in payment processing:', error);
    toast.error('Errore nell\'elaborazione del pagamento');
    return false;
  }
};

/**
 * Verifica che un webhook di Stripe abbia aggiornato correttamente il database
 */
export const verifyStripeWebhookUpdate = async (
  eventId: string
): Promise<boolean> => {
  try {
    console.log('Verifying Stripe webhook update:', eventId);
    
    // In un ambiente di produzione, questo verificherebbe il webhook
    // Questa è una funzione di test che simula sempre successo
    toast.info('Verifica webhook Stripe: simulazione di successo', {
      description: 'In un ambiente di produzione, questo verificherebbe le modifiche dal webhook'
    });
    
    return true;
  } catch (error) {
    console.error('Error verifying webhook update:', error);
    return false;
  }
};
