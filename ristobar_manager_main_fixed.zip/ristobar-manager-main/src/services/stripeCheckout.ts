
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

/**
 * Creates a Stripe checkout session for subscribing to a plan
 */
export async function createCheckoutSession(priceId: string, userId: string) {
  try {
    const { data, error } = await supabase.functions.invoke('create-checkout-session', {
      body: { 
        priceId,
        userId
      }
    });

    if (error) {
      console.error('Error creating checkout session:', error);
      toast.error("Si è verificato un errore nella creazione della sessione di pagamento");
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Error in checkout process:', error);
    toast.error("Si è verificato un errore nel processo di pagamento");
    throw error;
  }
}

/**
 * Verifies a Stripe payment session after successful checkout
 */
export async function verifyPaymentSession(sessionId: string) {
  try {
    const { data, error } = await supabase.functions.invoke('verify-payment-session', {
      body: { sessionId }
    });

    if (error) {
      console.error('Error verifying payment session:', error);
      toast.error("Si è verificato un errore nella verifica del pagamento");
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Error in payment verification:', error);
    toast.error("Si è verificato un errore nella verifica del pagamento");
    throw error;
  }
}

/**
 * Gets Stripe portal session for managing subscriptions
 */
export async function getCustomerPortalSession(customerId: string) {
  try {
    const { data, error } = await supabase.functions.invoke('create-customer-portal-session', {
      body: { customerId }
    });

    if (error) {
      console.error('Error creating customer portal session:', error);
      toast.error("Si è verificato un errore nell'accesso al portale cliente");
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Error in customer portal access:', error);
    toast.error("Si è verificato un errore nell'accesso al portale cliente");
    throw error;
  }
}

/**
 * Cancels a Stripe subscription
 */
export async function cancelSubscription(subscriptionId: string) {
  try {
    const { data, error } = await supabase.functions.invoke('cancel-stripe-subscription', {
      body: { subscriptionId }
    });

    if (error) {
      console.error('Error cancelling subscription:', error);
      toast.error("Si è verificato un errore nell'annullamento dell'abbonamento");
      throw error;
    }

    toast.success("Abbonamento annullato con successo. Rimarrà attivo fino alla fine del periodo corrente.");
    return data;
  } catch (error) {
    console.error('Error in subscription cancellation:', error);
    toast.error("Si è verificato un errore nell'annullamento dell'abbonamento");
    throw error;
  }
}

/**
 * Sets up real-time subscription updates via Supabase
 */
export function setupSubscriptionSync(userId: string, onSubscriptionUpdate: (subscription: any) => void) {
  if (!userId) return () => {}; // No cleanup needed if no user
  
  console.log("Setting up real-time subscription updates for user:", userId);
  
  // Listen for changes to the user_subscriptions table
  const channel = supabase
    .channel("subscription_updates")
    .on('postgres_changes', { 
      event: '*', // Listen for all events (INSERT, UPDATE, DELETE)
      schema: 'public', 
      table: 'user_subscriptions',
      filter: `user_id=eq.${userId}`
    }, (payload) => {
      console.log("Real-time subscription update received:", payload);
      
      if (payload.eventType === 'DELETE') {
        // Handle subscription deletion
        toast.error("L'abbonamento è stato rimosso", {
          description: "Il tuo abbonamento non è più attivo"
        });
        onSubscriptionUpdate(null);
      } else if (payload.new) {
        // Handle subscription creation or update
        onSubscriptionUpdate(payload.new);
        
        if (payload.eventType === 'INSERT') {
          toast.success("Nuovo abbonamento attivato", {
            description: `Piano ${payload.new.plan_id} attivato con successo`
          });
        } else if (payload.eventType === 'UPDATE') {
          // Only show toast if subscription status changed
          if (payload.old && payload.old.status !== payload.new.status) {
            if (payload.new.status === 'active') {
              toast.success("Abbonamento attivato", {
                description: `Il tuo abbonamento ${payload.new.plan_id} è ora attivo`
              });
            } else if (payload.new.status === 'canceled') {
              toast.info("Abbonamento annullato", {
                description: "L'abbonamento rimarrà attivo fino alla fine del periodo corrente"
              });
            } else if (payload.new.status === 'past_due') {
              toast.error("Problema con il pagamento", {
                description: "C'è un problema con il tuo metodo di pagamento"
              });
            }
          }
        }
      }
    })
    .subscribe();

  // Return a cleanup function
  return () => {
    supabase.removeChannel(channel);
  };
}
