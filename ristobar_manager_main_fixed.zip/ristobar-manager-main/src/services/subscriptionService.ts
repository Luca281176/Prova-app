
// This file is kept for backward compatibility
// It re-exports everything from the new modular subscription services

export * from './subscriptions';

// Utility function to get user-specific localStorage key
export const getUserStorageKey = (userId: string, key: string) => `${userId}_${key}`;

// Function to save user-specific data to localStorage
export const saveUserData = (userId: string, key: string, data: any) => {
  const storageKey = getUserStorageKey(userId, key);
  localStorage.setItem(storageKey, JSON.stringify(data));
};

// Function to get user-specific data from localStorage
export const getUserData = (userId: string, key: string, defaultValue: any = null) => {
  const storageKey = getUserStorageKey(userId, key);
  const data = localStorage.getItem(storageKey);
  return data ? JSON.parse(data) : defaultValue;
};

// Add an alias for saveUserData to match the import in UserContext.tsx
export const saveUserDataToStorage = saveUserData;
