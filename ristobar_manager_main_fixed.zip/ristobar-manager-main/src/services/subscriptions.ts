
import { User } from '@/contexts/user/types';
import { supabase } from '@/integrations/supabase/client';
import { FeatureAccessLevel } from './subscriptions/types';
import { hasAccess as hasFeatureAccess, hasSubscriptionLevel as hasLevel } from './subscriptions/featureAccess';

// Intervalli di prezzo per i piani
export const PRICING_TIERS = {
  starter: 24.99,
  pro: 69.99,
  ultimate: 149.99
};

// Definizione dei piani di abbonamento
export const subscriptionPlans = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'Ideale per piccoli ristoranti e bar',
    price: PRICING_TIERS.starter,
    stripePriceId: 'price_starter_monthly',
    features: [
      'Gestione tavoli e ordini',
      'Menu digitale personalizzabile',
      'Dashboard base',
      'Supporto email',
      '1 sede'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'Per ristoranti in crescita',
    price: PRICING_TIERS.pro,
    isRecommended: true,
    isPopular: true,
    stripePriceId: 'price_pro_monthly',
    features: [
      'Tutte le funzionalità Starter',
      'Sistema di prenotazioni avanzato',
      'Gestione completa dell\'inventario',
      'Dashboard finanziaria avanzata',
      'Supporto prioritario',
      '2 sedi'
    ]
  },
  {
    id: 'ultimate',
    name: 'Ultimate',
    description: 'Per grandi ristoranti e catene',
    price: PRICING_TIERS.ultimate,
    stripePriceId: 'price_ultimate_monthly',
    features: [
      'Tutte le funzionalità Pro',
      'Multi-sede illimitata',
      'API personalizzate',
      'Dashboard avanzate con ML',
      'Account manager dedicato',
      'Supporto telefonico 24/7'
    ]
  }
];

// Interfaccia per gli abbonamenti utente
export interface UserSubscription {
  id: string;
  userId: string;
  planId: string;
  status: 'active' | 'canceled' | 'past_due' | 'trialing' | 'inactive' | 'expired' | 'incomplete';
  currentPeriodEnd: string;
  createdAt: string;
  updatedAt: string;
  cancelAtPeriodEnd: boolean;
  paymentMethod: string;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  restaurantId?: string;
}

// Re-export types from subscriptions/types.ts
export { FeatureAccessLevel } from './subscriptions/types';
export type { SubscriptionPlan } from './subscriptions/types';

// Re-export functions from featureAccess.ts
export const hasAccess = hasFeatureAccess;
export const hasSubscriptionLevel = hasLevel;

// Import other functions from types.ts
import { isSubscriptionActive as isActive, getDaysRemaining as getRemainingDays } from './subscriptions/types';

// Re-export these functions
export const isSubscriptionActive = isActive;
export const getDaysRemaining = getRemainingDays;

/**
 * Funzione per ottenere un abbonamento di prova
 * @param userId ID dell'utente
 * @param planId ID del piano
 * @returns Abbonamento di prova
 */
export const getTrialSubscription = (userId: string, planId: string = 'pro'): UserSubscription => {
  // Data di fine prova (14 giorni da oggi)
  const trialEnd = new Date();
  trialEnd.setDate(trialEnd.getDate() + 14);
  
  return {
    id: `sub_trial_${userId}`,
    userId,
    planId,
    status: 'trialing',
    currentPeriodEnd: trialEnd.toISOString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    cancelAtPeriodEnd: false,
    paymentMethod: 'none',
    restaurantId: `restaurant_${userId}`,
    stripeCustomerId: undefined,
    stripeSubscriptionId: undefined
  };
};

/**
 * Funzione per ottenere l'abbonamento di un utente
 * @param userId ID dell'utente
 * @returns Promise con l'abbonamento dell'utente
 */
export const getUserSubscription = async (userId: string): Promise<UserSubscription | null> => {
  if (!userId) {
    console.warn('getUserSubscription chiamato senza userId');
    return null;
  }
  
  try {
    console.log(`Fetching subscription for user: ${userId}`);
    
    // In una implementazione reale, qui faremmo una chiamata a un'API
    // Per ora restituiamo un abbonamento di prova
    return getTrialSubscription(userId);
  } catch (error) {
    console.error('Error fetching subscription:', error);
    return null;
  }
};

/**
 * Funzione per aggiornare l'abbonamento di un utente
 * @param userId ID dell'utente
 * @param planId ID del nuovo piano
 * @returns Promise con l'abbonamento aggiornato
 */
export const updateSubscription = async (
  subscriptionId: string, 
  updates: Partial<UserSubscription>
): Promise<UserSubscription | null> => {
  if (!subscriptionId) {
    console.error('updateSubscription chiamato senza subscriptionId');
    return null;
  }
  
  try {
    console.log(`Updating subscription ${subscriptionId} with:`, updates);
    
    // Mock dell'aggiornamento di un abbonamento esistente
    // In una implementazione reale, qui faremmo una chiamata a un'API
    const mockSubscription: UserSubscription = {
      id: subscriptionId,
      userId: "user_123",
      planId: updates.planId || "starter",
      status: (updates.status as UserSubscription['status']) || 'active',
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      cancelAtPeriodEnd: updates.cancelAtPeriodEnd || false,
      paymentMethod: "card",
      restaurantId: "restaurant_123"
    };
    
    return mockSubscription;
  } catch (error) {
    console.error('Error updating subscription:', error);
    return null;
  }
};

/**
 * Funzione per cancellare un abbonamento
 */
export const cancelSubscription = async (subscriptionId: string): Promise<UserSubscription | null> => {
  if (!subscriptionId) {
    console.error('cancelSubscription chiamato senza subscriptionId');
    return null;
  }
  
  try {
    console.log(`Cancelling subscription ${subscriptionId}`);
    
    // Mock della cancellazione di un abbonamento
    // In una implementazione reale, qui faremmo una chiamata a un'API
    const mockSubscription: UserSubscription = {
      id: subscriptionId,
      userId: "user_123",
      planId: "starter",
      status: 'canceled',
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      cancelAtPeriodEnd: true,
      paymentMethod: "card",
      restaurantId: "restaurant_123"
    };
    
    return mockSubscription;
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    return null;
  }
};

/**
 * Funzione per creare un nuovo abbonamento
 */
export const createSubscription = async (userId: string, planId: string): Promise<UserSubscription | null> => {
  if (!userId || !planId) {
    console.error('createSubscription chiamato senza userId o planId');
    return null;
  }
  
  try {
    console.log(`Creating subscription for user ${userId} with plan ${planId}`);
    
    // Mock della creazione di un nuovo abbonamento
    // In una implementazione reale, qui faremmo una chiamata a un'API
    return getTrialSubscription(userId, planId);
  } catch (error) {
    console.error('Error creating subscription:', error);
    return null;
  }
};

/**
 * Funzione per ottenere tutti gli abbonamenti (admin)
 */
export const getSubscriptions = async (page = 1, limit = 10): Promise<{subscriptions: UserSubscription[], total: number}> => {
  try {
    console.log(`Fetching subscriptions, page ${page}, limit ${limit}`);
    
    // Mock per ottenere tutti gli abbonamenti
    // In una implementazione reale, qui faremmo una chiamata a un'API
    const mockSubscriptions: UserSubscription[] = [
      getTrialSubscription("user_1", "starter"),
      getTrialSubscription("user_2", "pro"),
      getTrialSubscription("user_3", "ultimate"),
    ];
    
    return {
      subscriptions: mockSubscriptions,
      total: mockSubscriptions.length
    };
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    return {
      subscriptions: [],
      total: 0
    };
  }
};

/**
 * Funzione per ottenere la chiave di storage per un utente
 * @param userId ID dell'utente
 * @returns Chiave di storage
 */
export const getUserStorageKey = (userId: string): string => {
  return `user_${userId}`;
};
