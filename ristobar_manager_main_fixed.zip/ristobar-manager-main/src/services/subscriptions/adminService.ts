import { UserSubscription, PaymentRecord, FeatureAccessLevel } from './types';

// Mock function to get all subscriptions (admin only)
export const getSubscriptions = async (page: number = 1, limit: number = 10): Promise<{subscriptions: UserSubscription[], total: number}> => {
  // In a real app, this would be a backend API call
  console.log(`Fetching subscriptions page ${page}, limit ${limit}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Mock data with correct enum values
  const mockSubscriptions: UserSubscription[] = Array.from({ length: 15 }, (_, i) => ({
    id: `sub_${Date.now() + i}`,
    userId: `user_${1000 + i}`,
    planId: i % 3 === 0 ? FeatureAccessLevel.STARTER : 
            i % 3 === 1 ? FeatureAccessLevel.PRO : 
            FeatureAccessLevel.ULTIMATE,
    status: i % 4 === 0 ? 'past_due' : i % 5 === 0 ? 'canceled' : 'active',
    currentPeriodEnd: new Date(Date.now() + (30 - (i % 10)) * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - (i * 10) * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    cancelAtPeriodEnd: i % 7 === 0,
    paymentMethod: 'card',
    stripeCustomerId: `cus_mock${1000 + i}`,
    stripeSubscriptionId: `sub_mock${1000 + i}`,
    restaurantId: `rest_${1000 + i}`
  }));
  
  // Calculate pagination
  const start = (page - 1) * limit;
  const end = start + limit;
  const paginatedSubscriptions = mockSubscriptions.slice(start, end);
  
  return {
    subscriptions: paginatedSubscriptions,
    total: mockSubscriptions.length
  };
};

// Mock function to get all payments (admin only)
export const getPayments = async (page: number = 1, limit: number = 10): Promise<{payments: PaymentRecord[], total: number}> => {
  // In a real app, this would be a backend API call
  console.log(`Fetching payments page ${page}, limit ${limit}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Mock data
  const mockPayments: PaymentRecord[] = Array.from({ length: 20 }, (_, i) => ({
    id: `pay_${Date.now() + i}`,
    subscriptionId: `sub_${Date.now() + (i % 5)}`,
    userId: `user_${1000 + (i % 10)}`,
    amount: (i % 3 === 0 ? 24.99 : i % 3 === 1 ? 69.99 : 149.99),
    currency: 'EUR',
    status: i % 10 === 0 ? 'failed' : i % 15 === 0 ? 'refunded' : 'successful',
    paymentMethod: i % 5 === 0 ? 'paypal' : 'card',
    createdAt: new Date(Date.now() - (i * 3) * 24 * 60 * 60 * 1000).toISOString()
  }));
  
  // Calculate pagination
  const start = (page - 1) * limit;
  const end = start + limit;
  const paginatedPayments = mockPayments.slice(start, end);
  
  return {
    payments: paginatedPayments,
    total: mockPayments.length
  };
};

// Send notification emails (mock)
export const sendSubscriptionNotification = async (
  userId: string, 
  type: 'welcome' | 'renewal' | 'expiring' | 'canceled' | 'payment_failed'
): Promise<boolean> => {
  console.log(`Sending ${type} notification to user: ${userId}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // In a real app, this would send an actual email
  return true;
};
