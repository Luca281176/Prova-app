
import { FeatureAccessLevel, FEATURE_ACCESS, UserSubscription } from "./types";

// Export FeatureAccessLevel for use in other files
export { FeatureAccessLevel } from "./types";

/**
 * Checks if a feature is available for the given subscription plan
 * @param userSubscription The user's subscription
 * @param feature The feature to check
 * @returns True if the feature is available, false otherwise
 */
export const hasAccess = (
  userSubscription: UserSubscription | null | undefined,
  feature: string
): boolean => {
  if (!userSubscription) return false;
  
  // Log per debug
  console.log(`Checking access for feature: ${feature}, user subscription plan: ${userSubscription.planId}`);
  
  // Get the required access level for this feature
  const requiredLevel = FEATURE_ACCESS[feature];
  if (!requiredLevel) {
    console.warn(`Feature "${feature}" is not defined in FEATURE_ACCESS`);
    return false;
  }
  
  // Get the user's access level
  const userLevel = userSubscription.planId.toString().toLowerCase();
  
  // Compare access levels
  switch (requiredLevel) {
    case FeatureAccessLevel.STARTER:
      // All plans have access to STARTER features
      return true;
    
    case FeatureAccessLevel.PRO:
      // PRO and ULTIMATE plans have access to PRO features
      return userLevel === FeatureAccessLevel.PRO.toString() || 
             userLevel === FeatureAccessLevel.ULTIMATE.toString();
    
    case FeatureAccessLevel.ULTIMATE:
      // Only ULTIMATE plan has access to ULTIMATE features
      return userLevel === FeatureAccessLevel.ULTIMATE.toString();
    
    default:
      return false;
  }
};

/**
 * Checks if a user has at least the specified subscription level
 * @param userSubscription The user's subscription
 * @param requiredLevel The minimum required subscription level
 * @returns True if the user has the required level, false otherwise
 */
export const hasSubscriptionLevel = (
  userSubscription: UserSubscription | null | undefined,
  requiredLevel: FeatureAccessLevel | string
): boolean => {
  if (!userSubscription) return false;
  
  // Log per debug
  console.log(`Checking subscription level: required=${requiredLevel}, user plan=${userSubscription.planId}`);
  
  const userLevel = userSubscription.planId.toString().toLowerCase();
  const requiredLevelStr = requiredLevel.toString().toLowerCase();
  
  // For debugging - log the exact comparison
  console.log(`Level check: userLevel=${userLevel}, requiredLevel=${requiredLevelStr}, direct comparison=${userLevel === requiredLevelStr}`);
  
  // Handle different subscription levels with proper hierarchy
  switch (requiredLevelStr) {
    case FeatureAccessLevel.STARTER.toString():
      // All plans have at least STARTER level
      return true;
    
    case FeatureAccessLevel.PRO.toString():
      // PRO and ULTIMATE plans have at least PRO level
      return userLevel === FeatureAccessLevel.PRO.toString() || 
             userLevel === FeatureAccessLevel.ULTIMATE.toString();
    
    case FeatureAccessLevel.ULTIMATE.toString():
      // Only ULTIMATE plan has ULTIMATE level
      return userLevel === FeatureAccessLevel.ULTIMATE.toString();
    
    default:
      return false;
  }
};
