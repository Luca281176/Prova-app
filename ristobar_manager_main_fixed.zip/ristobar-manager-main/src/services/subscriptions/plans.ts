
import { SubscriptionPlan } from "./types";

// Subscription plans with updated details
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'Ideale per piccoli ristoranti e bar',
    price: 24.99,
    stripePriceId: 'price_starter_monthly',
    features: [
      'Gestione tavoli e ordini',
      'Menu digitale personalizzabile',
      'Dashboard base',
      'Supporto email',
      '1 sede'
    ]
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'Per ristoranti in crescita',
    price: 69.99,
    isRecommended: true,
    isPopular: true,
    stripePriceId: 'price_pro_monthly',
    features: [
      'Tutte le funzionalità Starter',
      'Sistema di prenotazioni avanzato',
      'Gestione completa dell\'inventario',
      'Dashboard finanziaria avanzata',
      'Supporto prioritario',
      'Massimo 2 sedi',
      'Prova gratuita di 14 giorni' // Aggiunto per chiarire che la prova gratuita è per il piano Pro
    ]
  },
  {
    id: 'ultimate',
    name: 'Ultimate',
    description: 'Per grandi ristoranti e catene',
    price: 149.99,
    stripePriceId: 'price_ultimate_monthly',
    features: [
      'Tutte le funzionalità Pro',
      'Sedi illimitate',
      'API personalizzate',
      'Dashboard avanzate con ML',
      'Account manager dedicato',
      'Supporto telefonico 24/7'
    ]
  }
];
