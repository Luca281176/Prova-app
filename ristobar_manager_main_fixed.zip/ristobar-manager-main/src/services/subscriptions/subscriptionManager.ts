
import { toast } from "sonner";
import { UserSubscription, SubscriptionStatus, FeatureAccessLevel } from "./types";
import { subscriptionPlans } from "./plans";
import { updateStripeSubscription } from "./stripeService";

// Get user subscription
export const getUserSubscription = async (userId: string): Promise<UserSubscription | null> => {
  // In a real app, this would be a backend API call
  console.log(`Fetching subscription for user: ${userId}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // First check localStorage for cached subscription
  try {
    const cachedSubscription = localStorage.getItem(`${userId}_subscription`);
    if (cachedSubscription) {
      return JSON.parse(cachedSubscription);
    }
  } catch (error) {
    console.warn('Error accessing localStorage:', error);
  }
  
  // Mock data - in a real app this would come from your backend
  const mockSubscription: UserSubscription = {
    id: 'sub_123456789',
    userId: userId,
    planId: FeatureAccessLevel.PRO, // Sempre Pro per nuovi utenti
    status: 'active' as SubscriptionStatus,
    currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
    createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(), // 60 days ago
    updatedAt: new Date().toISOString(),
    cancelAtPeriodEnd: false,
    paymentMethod: 'card',
    stripeCustomerId: 'cus_mock123456',
    stripeSubscriptionId: 'sub_mock123456'
  };
  
  // Cache subscription in localStorage
  try {
    localStorage.setItem(`${userId}_subscription`, JSON.stringify(mockSubscription));
  } catch (error) {
    console.warn('Error saving to localStorage:', error);
  }
  
  return mockSubscription;
};

// Update subscription
export const updateSubscription = async (subscriptionId: string, data: Partial<UserSubscription>): Promise<UserSubscription> => {
  // In a real app, this would be a backend API call
  console.log(`Updating subscription: ${subscriptionId}`, data);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // If we're updating the plan or cancellation status, update Stripe
  if (data.planId || data.cancelAtPeriodEnd !== undefined) {
    try {
      await updateStripeSubscription(subscriptionId, {
        planId: data.planId,
        cancelAtPeriodEnd: data.cancelAtPeriodEnd
      });
    } catch (error) {
      console.error('Error updating Stripe subscription:', error);
      throw error;
    }
  }
  
  toast.success("Abbonamento aggiornato", {
    description: "Le modifiche al tuo abbonamento sono state salvate.",
  });
  
  // Update subscription in localStorage
  try {
    const storedSubscription = localStorage.getItem(`user_123_subscription`);
    if (storedSubscription) {
      const subscription = JSON.parse(storedSubscription);
      const updatedSubscription = {
        ...subscription,
        ...data,
        updatedAt: new Date().toISOString()
      };
      localStorage.setItem(`user_123_subscription`, JSON.stringify(updatedSubscription));
      return updatedSubscription;
    }
  } catch (error) {
    console.warn('Error updating localStorage:', error);
  }
  
  // Return mock updated subscription
  return {
    id: subscriptionId,
    userId: 'user_123',
    planId: data.planId || FeatureAccessLevel.PRO, // Cambiato da STARTER a PRO
    status: data.status as SubscriptionStatus || 'active' as SubscriptionStatus,
    currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    cancelAtPeriodEnd: data.cancelAtPeriodEnd || false,
    paymentMethod: 'card',
    stripeCustomerId: 'cus_mock123456',
    stripeSubscriptionId: 'sub_mock123456'
  };
};

// Create a new subscription
export const createSubscription = async (userId: string, planId: string, isAnnual: boolean = false): Promise<UserSubscription> => {
  try {
    // Check if we've already processed this in the current session
    const processedKey = `subscription_${userId}_${planId}_${Date.now()}`;
    const alreadyProcessed = sessionStorage.getItem(processedKey);
    
    if (alreadyProcessed) {
      console.log('Subscription was already processed in this session');
      const savedSubscription = JSON.parse(alreadyProcessed);
      return savedSubscription;
    }
    
    // In a real app, this would initiate Stripe Checkout
    console.log(`Creating subscription for user ${userId} with plan ${planId}`);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Get the plan to subscribe to
    const plan = subscriptionPlans.find(p => p.id === planId);
    if (!plan) {
      throw new Error(`Plan ${planId} not found`);
    }
    
    toast.success("Abbonamento attivato", {
      description: `Il tuo abbonamento ${plan.name} è stato attivato con successo.`,
    });
    
    // Convert planId string to FeatureAccessLevel
    let featureLevel: FeatureAccessLevel;
    switch (planId.toLowerCase()) {
      case 'pro':
        featureLevel = FeatureAccessLevel.PRO;
        break;
      case 'ultimate':
        featureLevel = FeatureAccessLevel.ULTIMATE;
        break;
      default:
        featureLevel = FeatureAccessLevel.PRO; // Imposta sempre PRO come default
    }
    
    // Return mock new subscription with the correct planId as FeatureAccessLevel
    const newSubscription: UserSubscription = {
      id: `sub_${Date.now()}`,
      userId: userId,
      planId: featureLevel,
      status: 'active' as SubscriptionStatus,
      currentPeriodEnd: new Date(Date.now() + (isAnnual ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      cancelAtPeriodEnd: false,
      paymentMethod: 'card',
      stripeCustomerId: `cus_${Date.now()}`,
      stripeSubscriptionId: `sub_${Date.now()}`
    };
    
    // Save this in session storage to prevent duplicate processing
    sessionStorage.setItem(processedKey, JSON.stringify(newSubscription));
    
    // Save subscription to localStorage
    try {
      localStorage.setItem(`${userId}_subscription`, JSON.stringify(newSubscription));
    } catch (error) {
      console.warn('Error saving to localStorage:', error);
    }
    
    return newSubscription;
  } catch (error) {
    console.error("Error creating subscription:", error);
    toast.error("Errore", {
      description: "Non è stato possibile attivare l'abbonamento. Riprova più tardi.",
    });
    throw error;
  }
};

// Utility functions for subscription status
export const isSubscriptionActive = (subscription: UserSubscription | null): boolean => {
  if (!subscription) return false;
  
  return subscription.status === 'active' || 
         subscription.status === 'trialing' || 
         (subscription.status === 'canceled' && new Date(subscription.currentPeriodEnd) > new Date());
};

// Get days remaining in subscription
export const getDaysRemaining = (subscription: UserSubscription | null): number => {
  if (!subscription) return 0;
  
  const endDate = new Date(subscription.currentPeriodEnd);
  const now = new Date();
  
  const diffTime = endDate.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Send subscription email notifications (mock implementation)
export const sendSubscriptionEmail = async (userId: string, type: 'welcome' | 'renewal' | 'expiring' | 'canceled' | 'payment_failed'): Promise<boolean> => {
  console.log(`Sending ${type} email to user: ${userId}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 700));
  
  // Mock success
  return true;
};
