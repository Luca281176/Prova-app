
export enum FeatureAccessLevel {
  STARTER = 'starter',
  PRO = 'pro',
  ULTIMATE = 'ultimate'
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  isRecommended?: boolean;
  isPopular?: boolean;
  stripePriceId: string;
  features: string[];
}

export type BillingPeriod = 'monthly' | 'yearly';

// User subscription interface
export interface UserSubscription {
  id: string;
  userId: string;
  planId: FeatureAccessLevel | string; // Allow both enum and string to support backward compatibility
  status: SubscriptionStatus;
  currentPeriodEnd: string;
  createdAt: string;
  updatedAt: string;
  cancelAtPeriodEnd: boolean;
  paymentMethod: string;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  restaurantId?: string;
}

// Payment record interface
export interface PaymentRecord {
  id: string;
  subscriptionId: string;
  userId: string;
  amount: number;
  currency: string;
  status: 'successful' | 'failed' | 'refunded';
  paymentMethod: string;
  createdAt: string;
}

// Subscription status type
export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'trialing' | 'inactive' | 'expired' | 'incomplete';

// Mapping di funzionalità a livelli di accesso
export const FEATURE_ACCESS = {
  // Funzionalità di base (disponibili per tutti)
  'menu': FeatureAccessLevel.STARTER,
  'orders': FeatureAccessLevel.STARTER,
  'rooms': FeatureAccessLevel.STARTER,
  'tables': FeatureAccessLevel.STARTER,
  'basic_dashboard': FeatureAccessLevel.STARTER,
  'email_support': FeatureAccessLevel.STARTER,
  'single_location': FeatureAccessLevel.STARTER,
  
  // Funzionalità Pro
  'reservations': FeatureAccessLevel.PRO,
  'inventoryManagement': FeatureAccessLevel.PRO,
  'advancedDashboard': FeatureAccessLevel.PRO,
  'prioritySupport': FeatureAccessLevel.PRO,
  'multiLocationBasic': FeatureAccessLevel.PRO, // Pro users get basic multi-location (max 2)
  
  // Funzionalità Ultimate
  'staffManagement': FeatureAccessLevel.ULTIMATE,
  'advancedAnalytics': FeatureAccessLevel.ULTIMATE,
  'api': FeatureAccessLevel.ULTIMATE,
  'mlDashboard': FeatureAccessLevel.ULTIMATE,
  'accountManager': FeatureAccessLevel.ULTIMATE,
  'phoneSupport': FeatureAccessLevel.ULTIMATE,
  'multiLocation': FeatureAccessLevel.ULTIMATE, // For compatibility
  'multiLocationAdvanced': FeatureAccessLevel.ULTIMATE, // Unlimited locations
  'multiLocationManagement': FeatureAccessLevel.ULTIMATE // Advanced management features
};

/**
 * Verifica se un abbonamento è attivo
 * @param subscription Abbonamento da verificare
 * @returns true se l'abbonamento è attivo, altrimenti false
 */
export const isSubscriptionActive = (subscription: UserSubscription | null | undefined): boolean => {
  if (!subscription) return false;
  
  const activeStatuses = ['active', 'trialing'];
  return activeStatuses.includes(subscription.status);
};

/**
 * Calcola i giorni rimanenti di un abbonamento
 * @param subscription Abbonamento da verificare
 * @returns Numero di giorni rimanenti, 0 se scaduto o indefinito
 */
export const getDaysRemaining = (subscription: UserSubscription | null | undefined): number => {
  if (!subscription || !subscription.currentPeriodEnd) {
    return 0;
  }
  
  const now = new Date();
  const endDate = new Date(subscription.currentPeriodEnd);
  const diffTime = endDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return Math.max(0, diffDays);
};
