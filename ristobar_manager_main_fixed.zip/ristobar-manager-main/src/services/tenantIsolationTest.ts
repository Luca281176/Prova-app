
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface TestResult {
  success: boolean;
  message: string;
  details?: string;
  jwt?: any;     // Added to expose JWT information for debugging
  policies?: any[]; // Added to show active policies
  tenant_id?: string; // Added to show the tenant_id used for the test
  rls_enabled?: boolean; // Added to show if RLS is enabled
}

/**
 * Testa l'isolamento RLS inserendo un dato nel database
 * e verificando che sia accessibile solo dal tenant corretto
 */
export const testRLSIsolation = async (tenantId: string | undefined): Promise<TestResult> => {
  if (!tenantId) {
    return {
      success: false,
      message: "Nessun tenant ID fornito",
      details: "L'utente deve essere autenticato e avere un tenant ID"
    };
  }

  try {
    console.log(`Esecuzione test di isolamento RLS per tenant: ${tenantId}`);
    
    // Genera un ID test univoco
    const testId = `test_${Date.now()}`;
    
    // 1. Verifica che la sessione contenga il tenant_id corretto
    const { data: { session } } = await supabase.auth.getSession();
    const sessionTenantId = session?.user?.user_metadata?.tenant_id;
    
    if (!sessionTenantId) {
      return {
        success: false,
        message: "Tenant ID non presente nella sessione",
        details: "Il token JWT non contiene il tenant_id nei metadati utente",
        jwt: session?.access_token ? decodeJWT(session.access_token) : null,
        tenant_id: tenantId
      };
    }
    
    if (sessionTenantId !== tenantId) {
      return {
        success: false,
        message: "Mancata corrispondenza del Tenant ID",
        details: `Il tenant ID nella sessione (${sessionTenantId}) non corrisponde al tenant ID fornito (${tenantId})`,
        jwt: session?.access_token ? decodeJWT(session.access_token) : null,
        tenant_id: tenantId
      };
    }
    
    // Recupera il JWT decodificato per debug
    const decodedJWT = session?.access_token ? decodeJWT(session.access_token) : null;
    
    // 2. Verifica se RLS è attivo sulla tabella isolation_tests
    const { data: rlsData, error: rlsError } = await supabase
      .rpc('check_rls_enabled', { table_name: 'isolation_tests' })
      .single();
      
    // Conversione esplicita del valore in boolean
    const rlsEnabled: boolean = rlsError ? false : Boolean(rlsData);
    
    if (!rlsEnabled) {
      return {
        success: false,
        message: "Row Level Security non è attivo",
        details: "RLS non è abilitato sulla tabella isolation_tests",
        jwt: decodedJWT,
        tenant_id: tenantId,
        rls_enabled: false
      };
    }
    
    // 3. Ottieni le politiche RLS applicate alla tabella per debug
    const { data: policiesData, error: policiesError } = await supabase
      .from('pg_policies')
      .select('*')
      .eq('tablename', 'isolation_tests')
      .maybeSingle();
      
    const policies = policiesError ? [] : policiesData;
    
    // 4. Inserisci un record di test nella tabella
    const { error: insertError } = await supabase
      .from('isolation_tests')
      .insert({
        id: testId,
        tenant_id: tenantId,
        test_name: 'RLS Isolation Test',
        test_data: `Test data for tenant ${tenantId} at ${new Date().toISOString()}`,
      });
    
    if (insertError) {
      console.error('Errore durante inserimento test:', insertError);
      return {
        success: false,
        message: "Errore durante il test di inserimento",
        details: insertError.message,
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    // 5. Prova a leggere il record
    const { data: readData, error: readError } = await supabase
      .from('isolation_tests')
      .select('*')
      .eq('id', testId)
      .single();
    
    if (readError) {
      console.error('Errore durante lettura test:', readError);
      return {
        success: false,
        message: "Errore durante il test di lettura",
        details: readError.message,
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    if (!readData) {
      return {
        success: false,
        message: "Record non trovato dopo l'inserimento",
        details: "Il sistema non è riuscito a leggere il record appena inserito",
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    // 6. Verifica che il tenant_id sia corretto
    if (readData.tenant_id !== tenantId) {
      return {
        success: false,
        message: "Isolamento tenant fallito",
        details: `Atteso: ${tenantId}, Trovato: ${readData.tenant_id}`,
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    // 7. Prova a leggere usando un tenant ID errato simulato
    // Questo test verifica il comportamento atteso di RLS isolando correttamente i dati
    const fakeTenantId = 'fake_tenant_id';
    const { data: crossTenantData, error: crossTenantError } = await supabase
      .from('isolation_tests')
      .select('*')
      .eq('tenant_id', fakeTenantId)
      .eq('id', testId);
      
    // Con RLS attivo, dovremmo ottenere un array vuoto (nessun dato trovato)
    // perché RLS impedisce l'accesso ai dati di altri tenant
    // Conversione esplicita in boolean con il doppio operatore di negazione
    const hasCrossTenantData: boolean = !!(crossTenantData && crossTenantData.length > 0);
    
    if (hasCrossTenantData) {
      return {
        success: false,
        message: "Isolamento RLS fallito",
        details: "È stato possibile accedere ai dati di un altro tenant - L'isolamento non funziona correttamente",
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    // 8. Verifica di modifica - Tentativo di aggiornare un record con tenant diverso
    const { error: updateWrongTenantError } = await supabase
      .from('isolation_tests')
      .update({ test_data: 'Modified by wrong tenant' })
      .eq('id', testId)
      .eq('tenant_id', fakeTenantId);
    
    // Se la RLS funziona correttamente, questa operazione dovrebbe fallire o non aggiornare alcun record
    const { data: verifyNoUpdate, error: verifyError } = await supabase
      .from('isolation_tests')
      .select('test_data')
      .eq('id', testId)
      .single();
      
    // Conversione esplicita in boolean usando Boolean()
    const isWrongTenantModified: boolean = Boolean(
      verifyNoUpdate && verifyNoUpdate.test_data && verifyNoUpdate.test_data.includes('Modified by wrong tenant')
    );
      
    if (isWrongTenantModified) {
      return {
        success: false,
        message: "Isolamento RLS fallito durante l'update",
        details: "Un tenant è riuscito a modificare dati di un altro tenant",
        jwt: decodedJWT,
        policies,
        tenant_id: tenantId,
        rls_enabled: rlsEnabled
      };
    }
    
    // 9. Pulizia - Elimina il record di test
    const { error: deleteError } = await supabase
      .from('isolation_tests')
      .delete()
      .eq('id', testId);
      
    if (deleteError) {
      console.warn('Errore durante la pulizia dei dati di test:', deleteError.message);
    }
    
    // Test completato con successo
    return {
      success: true,
      message: "Test di isolamento RLS superato con successo!",
      details: "L'applicazione è correttamente configurata per l'isolamento multi-tenant con Supabase RLS.",
      jwt: decodedJWT,
      policies,
      tenant_id: tenantId,
      rls_enabled: rlsEnabled
    };
  } catch (error: any) {
    console.error('Errore durante il test di isolamento RLS:', error);
    return {
      success: false,
      message: "Errore durante il test di isolamento",
      details: error.message || String(error),
      tenant_id: tenantId
    };
  }
};

/**
 * Decodifica un token JWT
 * @param token Token JWT da decodificare
 * @returns Payload del token decodificato
 */
function decodeJWT(token: string): any {
  try {
    // JWT ha 3 parti: header.payload.signature
    const parts = token.split('.');
    if (parts.length !== 3) {
      return null;
    }
    
    // Decodifica il payload (seconda parte)
    const payload = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(payload);
  } catch (error) {
    console.error('Errore durante la decodifica del JWT:', error);
    return null;
  }
}
