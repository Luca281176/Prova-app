
import { supabase } from '@/config/supabase';

export async function getValidTenantId(userId) {
    if (!userId) {
        console.warn("⚠️ Nessun userId fornito, impossibile recuperare tenant_id.");
        return null;
    }

    const { data, error } = await supabase
        .from('tenants')
        .select('id')
        .eq('user_id', userId)
        .single();

    if (error || !data) {
        console.error("❌ Errore nel recupero del tenant_id:", error);
        return null;
    }

    console.log("✅ Tenant ID trovato:", data.id);
    return data.id;
}
