import { v4 as uuidv4 } from 'uuid';
import { Order, OrderItem } from './ordersService';
import { useTenant } from '@/contexts/tenant/TenantContext';
import { supabase } from '@/integrations/supabase/client';

export interface CustomerData {
  name: string;
  vatId: string;
  address: string;
  email?: string;
}

export interface Transaction {
  id: string;
  orderId: string;
  orderItems: OrderItem[];
  originalAmount: number;
  discount: number;
  tip: number;
  finalAmount: number;
  paymentMethod: 'cash' | 'card' | 'digital' | 'invoice';
  paymentReference?: string;
  notes?: string;
  customerData?: CustomerData;
  tableId?: string;
  tableName?: string;
  timestamp: string;
  operatorName?: string;
  status: 'completed' | 'pending' | 'refunded';
  method: 'cash' | 'card' | 'digital' | 'invoice';
  amount: number;
  customerName: string;
  time: string;
  tenantId?: string;
  synced?: boolean;
  splitPayments?: { id: number; amount: number }[];
  isSplitPayment?: boolean;
}

interface ExtraTransactionData {
  discount?: number;
  tip?: number;
  customerData?: CustomerData;
  splitPayments?: { id: number; amount: number }[];
  isSplitPayment?: boolean;
}

/**
 * Logs a failed transaction to Supabase for debugging
 */
export const logFailedTransaction = async (transaction: Transaction, errorMessage: string): Promise<void> => {
  try {
    await supabase
      .from('failed_transactions')
      .insert({
        id: uuidv4(),
        transaction_id: transaction.id,
        tenant_id: transaction.tenantId,
        error_message: errorMessage,
        transaction_data: transaction,
        timestamp: new Date().toISOString()
      });
  } catch (error) {
    console.error('Failed to log failed transaction:', error);
  }
};

export const createTransactionFromOrder = async (
  order: Order, 
  paymentMethod: 'cash' | 'card' | 'digital' | 'invoice',
  paymentReference?: string,
  notes?: string,
  extraData?: ExtraTransactionData,
  tenantId?: string
) => {
  try {
    const { discount = 0, tip = 0, customerData } = extraData || {};
    
    const finalAmount = order.total - discount + tip;
    
    const transaction: Transaction = {
      id: uuidv4(),
      orderId: order.id,
      orderItems: order.items,
      originalAmount: order.total,
      discount,
      tip,
      finalAmount,
      paymentMethod,
      paymentReference,
      notes,
      customerData,
      tableId: order.tableId,
      tableName: order.tableName,
      timestamp: new Date().toISOString(),
      operatorName: order.operatorName,
      status: 'completed' as const,
      method: paymentMethod,
      amount: finalAmount,
      customerName: customerData?.name || 'Cliente',
      time: new Date().toLocaleTimeString(),
      tenantId,
      synced: false,
      splitPayments: extraData?.splitPayments,
      isSplitPayment: extraData?.isSplitPayment
    };
    
    if (supabase) {
      try {
        const { error } = await supabase
          .from('transactions')
          .insert([transaction])
          .select();
          
        if (error) {
          console.error('Error saving transaction to Supabase:', error);
          await logFailedTransaction(transaction, error.message);
          saveToLocalStorage(transaction, tenantId);
        } else {
          transaction.synced = true;
        }
      } catch (supabaseError) {
        console.error('Error using Supabase:', supabaseError);
        const errorMessage = supabaseError instanceof Error ? supabaseError.message : 'Unknown error';
        await logFailedTransaction(transaction, errorMessage);
        saveToLocalStorage(transaction, tenantId);
      }
    } else {
      saveToLocalStorage(transaction, tenantId);
    }
    
    return transaction;
  } catch (error) {
    console.error('Error creating transaction:', error);
    throw error;
  }
};

const saveToLocalStorage = (transaction: Transaction, tenantId?: string) => {
  const storageKey = tenantId ? `transactions_${tenantId}` : 'transactions';
  const pendingStorageKey = tenantId ? `pending_transactions_${tenantId}` : 'pending_transactions';
  
  const transactions = localStorage.getItem(storageKey);
  const parsedTransactions = transactions ? JSON.parse(transactions) : [];
  parsedTransactions.push(transaction);
  localStorage.setItem(storageKey, JSON.stringify(parsedTransactions));
  
  const pendingTransactions = localStorage.getItem(pendingStorageKey);
  const parsedPendingTransactions = pendingTransactions ? JSON.parse(pendingTransactions) : [];
  parsedPendingTransactions.push(transaction);
  localStorage.setItem(pendingStorageKey, JSON.stringify(parsedPendingTransactions));
};

export const syncPendingTransactions = async (tenantId?: string): Promise<{ 
  success: number; 
  failed: number; 
  remaining: number;
}> => {
  try {
    const pendingStorageKey = tenantId ? `pending_transactions_${tenantId}` : 'pending_transactions';
    const pendingTransactions = localStorage.getItem(pendingStorageKey);
    let parsedPendingTransactions: Transaction[] = pendingTransactions ? JSON.parse(pendingTransactions) : [];
    
    let successCount = 0;
    let failedCount = 0;
    
    const stillPendingTransactions: Transaction[] = [];
    
    for (const transaction of parsedPendingTransactions) {
      try {
        const { error } = await supabase
          .from('transactions')
          .insert([transaction])
          .select();
          
        if (error) {
          console.error('Error syncing transaction:', error, transaction);
          await logFailedTransaction(transaction, error.message);
          stillPendingTransactions.push(transaction);
          failedCount++;
        } else {
          successCount++;
        }
      } catch (error) {
        console.error('Error during transaction sync:', error, transaction);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        await logFailedTransaction(transaction, errorMessage);
        stillPendingTransactions.push(transaction);
        failedCount++;
      }
    }
    
    localStorage.setItem(pendingStorageKey, JSON.stringify(stillPendingTransactions));
    
    return {
      success: successCount,
      failed: failedCount,
      remaining: stillPendingTransactions.length
    };
  } catch (error) {
    console.error('Error during pending transactions sync:', error);
    return { success: 0, failed: 0, remaining: 0 };
  }
};

export const useTenantTransactions = () => {
  const { currentTenant } = useTenant();
  
  const getTenantTransactions = async (): Promise<Transaction[]> => {
    try {
      const tenantId = currentTenant?.id;
      
      if (supabase && tenantId) {
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('tenantId', tenantId);
            
          if (error) {
            console.error('Error during transaction retrieval from Supabase:', error);
          } else if (data && data.length > 0) {
            return data;
          }
        } catch (supabaseError) {
          console.error('Error using Supabase:', supabaseError);
        }
      }
      
      const storageKey = tenantId ? `transactions_${tenantId}` : 'transactions';
      const transactions = localStorage.getItem(storageKey);
      return transactions ? JSON.parse(transactions) : [];
    } catch (error) {
      console.error('Error fetching tenant transactions:', error);
      return [];
    }
  };

  const getTransactionById = async (id: string): Promise<Transaction | null> => {
    try {
      const tenantId = currentTenant?.id;
      
      if (supabase && tenantId) {
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('id', id)
            .eq('tenantId', tenantId)
            .single();
            
          if (error) {
            console.error('Error during transaction retrieval from Supabase:', error);
          } else if (data) {
            return data;
          }
        } catch (supabaseError) {
          console.error('Error using Supabase:', supabaseError);
        }
      }
      
      const transactions = await getTenantTransactions();
      return transactions.find((transaction: Transaction) => transaction.id === id) || null;
    } catch (error) {
      console.error('Error getting transaction by ID:', error);
      return null;
    }
  };

  const getTransactionsByDate = async (dateFilter: string): Promise<Transaction[]> => {
    try {
      const tenantId = currentTenant?.id;
      
      if (supabase && tenantId) {
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('tenantId', tenantId);
            
          if (error) {
            console.error('Error during transaction retrieval from Supabase:', error);
          } else if (data && data.length > 0) {
            return data.filter(transaction => {
              if (!transaction.timestamp || typeof transaction.timestamp !== 'string') {
                return false;
              }
              const transactionDate = transaction.timestamp.split('T')[0];
              return transactionDate === dateFilter;
            });
          }
        } catch (supabaseError) {
          console.error('Error using Supabase:', supabaseError);
        }
      }
      
      const transactions = await getTenantTransactions();
      return transactions.filter((transaction: Transaction) => {
        if (!transaction.timestamp || typeof transaction.timestamp !== 'string') {
          return false;
        }
        const transactionDate = transaction.timestamp.split('T')[0];
        return transactionDate === dateFilter;
      });
    } catch (error) {
      console.error('Error filtering transactions by date:', error);
      return [];
    }
  };

  return {
    getTransactions: getTenantTransactions,
    fetchTransactions: getTenantTransactions,
    getTransactionById,
    getTransactionsByDate,
    createTransaction: (
      order: Order, 
      paymentMethod: 'cash' | 'card' | 'digital' | 'invoice',
      paymentReference?: string,
      notes?: string,
      extraData?: ExtraTransactionData
    ) => createTransactionFromOrder(
      order, 
      paymentMethod, 
      paymentReference, 
      notes, 
      extraData, 
      currentTenant?.id
    )
  };
};

export const getTransactions = async (): Promise<Transaction[]> => {
  try {
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select('*');
          
        if (error) {
          console.error('Error during transaction retrieval from Supabase:', error);
        } else if (data && data.length > 0) {
          return data;
        }
      } catch (supabaseError) {
        console.error('Error using Supabase:', supabaseError);
      }
    }
    
    const transactions = localStorage.getItem('transactions');
    return transactions ? JSON.parse(transactions) : [];
  } catch (error) {
    console.error('Error fetching transactions:', error);
    return [];
  }
};

export const fetchTransactions = async (): Promise<Transaction[]> => {
  return getTransactions();
};

export const getTransactionById = async (id: string): Promise<Transaction | null> => {
  try {
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select('*')
          .eq('id', id)
          .single();
          
        if (error) {
          console.error('Error during transaction retrieval from Supabase:', error);
        } else if (data) {
          return data;
        }
      } catch (supabaseError) {
        console.error('Error using Supabase:', supabaseError);
      }
    }
    
    const transactions = await getTransactions();
    return transactions.find((transaction: Transaction) => transaction.id === id) || null;
  } catch (error) {
    console.error('Error getting transaction by ID:', error);
    return null;
  }
};

export const getTransactionsByDate = async (dateFilter: string): Promise<Transaction[]> => {
  try {
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select('*');
          
        if (error) {
          console.error('Error during transaction retrieval from Supabase:', error);
        } else if (data && data.length > 0) {
          return data.filter(transaction => {
            if (!transaction.timestamp || typeof transaction.timestamp !== 'string') {
              return false;
            }
            const transactionDate = transaction.timestamp.split('T')[0];
            return transactionDate === dateFilter;
          });
        }
      } catch (supabaseError) {
        console.error('Error using Supabase:', supabaseError);
      }
    }
    
    const transactions = await getTransactions();
    return transactions.filter((transaction: Transaction) => {
      if (!transaction.timestamp || typeof transaction.timestamp !== 'string') {
        return false;
      }
      const transactionDate = transaction.timestamp.split('T')[0];
      return transactionDate === dateFilter;
    });
  } catch (error) {
    console.error('Error filtering transactions by date:', error);
    return [];
  }
};
