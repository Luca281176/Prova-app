
import { create } from 'zustand';
import { Reservation } from '@/types/reservations';

interface ReservationStoreState {
  activeReservation: Reservation | null;
  setActiveReservation: (reservation: Reservation | null) => void;
  clearActiveReservation: () => void;
}

export const useReservationStore = create<ReservationStoreState>((set) => ({
  activeReservation: null,
  setActiveReservation: (reservation) => set({ activeReservation: reservation }),
  clearActiveReservation: () => set({ activeReservation: null }),
}));
