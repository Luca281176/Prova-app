
export interface Reservation {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  date: Date | string;
  time: string;
  partySize: number;
  status: 'pending' | 'confirmed' | 'arrived' | 'cancelled' | 'no-show' | 'completed';
  tableId?: string;
  notes?: string;
  specialRequests?: string[];
}
