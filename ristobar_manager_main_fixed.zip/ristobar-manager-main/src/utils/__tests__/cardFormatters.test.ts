
import { formatCardNumber, formatExpiry, formatCvc } from '../cardFormatters';

describe('Card Formatters', () => {
  describe('formatCardNumber', () => {
    it('should format a 16-digit card number with spaces after every 4 digits', () => {
      expect(formatCardNumber('4242424242424242')).toBe('4242 4242 4242 4242');
    });

    it('should remove non-numeric characters', () => {
      expect(formatCardNumber('4242-4242-4242-4242')).toBe('4242 4242 4242 4242');
    });

    it('should handle partial card numbers', () => {
      expect(formatCardNumber('424242')).toBe('4242 42');
    });

    it('should return the original value if no match is found', () => {
      expect(formatCardNumber('abc')).toBe('abc');
    });

    it('should handle empty strings', () => {
      expect(formatCardNumber('')).toBe('');
    });
  });

  describe('formatExpiry', () => {
    it('should format a 4-digit expiry as MM/YY', () => {
      expect(formatExpiry('1234')).toBe('12/34');
    });

    it('should handle partial expiry input', () => {
      expect(formatExpiry('12')).toBe('12/');
    });

    it('should remove non-numeric characters', () => {
      expect(formatExpiry('12/34')).toBe('12/34');
    });

    it('should handle single digit input', () => {
      expect(formatExpiry('1')).toBe('1');
    });

    it('should handle empty strings', () => {
      expect(formatExpiry('')).toBe('');
    });
  });

  describe('formatCvc', () => {
    it('should format a 3-digit CVC', () => {
      expect(formatCvc('123')).toBe('123');
    });

    it('should truncate to 3 digits if longer', () => {
      expect(formatCvc('12345')).toBe('123');
    });

    it('should remove non-numeric characters', () => {
      expect(formatCvc('1a2b3')).toBe('123');
    });

    it('should handle empty strings', () => {
      expect(formatCvc('')).toBe('');
    });
  });
});
