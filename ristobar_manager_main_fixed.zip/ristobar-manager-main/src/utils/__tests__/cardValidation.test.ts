
import { validateCardForm } from '../cardValidation';
import { toast } from '@/hooks/use-toast';

// Mock the toast function
jest.mock('@/hooks/use-toast', () => ({
  toast: jest.fn(),
}));

describe('Card Validation', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  describe('validateCardForm', () => {
    it('should return true for valid card details', () => {
      const result = validateCardForm(
        'John Doe',
        '4242 4242 4242 4242',
        '12/25',
        '123'
      );
      expect(result).toBe(true);
      expect(toast).not.toHaveBeenCalled();
    });

    it('should return false and show toast for empty card name', () => {
      const result = validateCardForm(
        '',
        '4242 4242 4242 4242',
        '12/25',
        '123'
      );
      expect(result).toBe(false);
      expect(toast).toHaveBeenCalledWith({
        title: "Errore di validazione",
        description: "Inserisci il nome sulla carta",
        variant: "destructive",
      });
    });

    it('should return false and show toast for invalid card number length', () => {
      const result = validateCardForm(
        'John Doe',
        '4242 4242 4242',
        '12/25',
        '123'
      );
      expect(result).toBe(false);
      expect(toast).toHaveBeenCalledWith({
        title: "Errore di validazione",
        description: "Il numero carta deve essere di 16 cifre",
        variant: "destructive",
      });
    });

    it('should return false and show toast for invalid expiry format', () => {
      const result = validateCardForm(
        'John Doe',
        '4242 4242 4242 4242',
        '1225',
        '123'
      );
      expect(result).toBe(false);
      expect(toast).toHaveBeenCalledWith({
        title: "Errore di validazione",
        description: "Formato data scadenza non valido (MM/YY)",
        variant: "destructive",
      });
    });

    it('should return false and show toast for invalid CVC length', () => {
      const result = validateCardForm(
        'John Doe',
        '4242 4242 4242 4242',
        '12/25',
        '12'
      );
      expect(result).toBe(false);
      expect(toast).toHaveBeenCalledWith({
        title: "Errore di validazione",
        description: "Il CVC deve essere di 3 cifre",
        variant: "destructive",
      });
    });

    it('should log a message for test card', () => {
      // Spy on console.log
      const consoleSpy = jest.spyOn(console, 'log');
      
      const result = validateCardForm(
        'John Doe',
        '4242 4242 4242 4242',
        '12/25',
        '123'
      );
      
      expect(result).toBe(true);
      expect(consoleSpy).toHaveBeenCalledWith("Test card detected");
      
      // Restore the original implementation
      consoleSpy.mockRestore();
    });
  });
});
