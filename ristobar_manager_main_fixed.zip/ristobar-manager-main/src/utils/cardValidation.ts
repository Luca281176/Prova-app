
import { toast } from "@/hooks/use-toast";

export const validateCardForm = (
  cardName: string,
  cardNumber: string,
  expiry: string,
  cvc: string
): boolean => {
  // Check card name
  if (!cardName.trim()) {
    toast({
      title: "Errore di validazione",
      description: "Inserisci il nome sulla carta",
      variant: "destructive",
    });
    return false;
  }
  
  // For test mode, accept any credit card number that's 16 digits
  // In production this would be validated with Luhn algorithm
  if (cardNumber.replace(/\s/g, '').length !== 16) {
    toast({
      title: "Errore di validazione",
      description: "Il numero carta deve essere di 16 cifre",
      variant: "destructive",
    });
    return false;
  }
  
  // Check expiry format
  if (!expiry.includes('/') || expiry.length < 5) {
    toast({
      title: "Errore di validazione",
      description: "Formato data scadenza non valido (MM/YY)",
      variant: "destructive",
    });
    return false;
  }
  
  // Check CVC length
  if (cvc.length < 3) {
    toast({
      title: "Errore di validazione",
      description: "Il CVC deve essere di 3 cifre",
      variant: "destructive",
    });
    return false;
  }
  
  // For testing, you can use 4242 4242 4242 4242 as a test card number
  if (cardNumber.replace(/\s/g, '') === '4242424242424242') {
    console.log("Test card detected");
  }
  
  return true;
};
