
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Stripe } from 'https://esm.sh/stripe@12.0.0?target=deno';
import { corsHeaders } from '../_shared/cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
});

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const clientUrl = Deno.env.get('CLIENT_URL') || 'http://localhost:5173';

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { priceId, userId } = await req.json();
    
    if (!priceId || !userId) {
      return new Response(
        JSON.stringify({ error: 'Mancano parametri richiesti: priceId o userId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Creating checkout session with:', { priceId, userId });

    // Create a Supabase client
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Get the user from Supabase
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (userError || !userData) {
      console.error('Error fetching user:', userError);
      return new Response(
        JSON.stringify({ error: 'Utente non trovato' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let customerId = userData.stripe_customer_id;
    
    // If the user doesn't have a Stripe customer ID, create one
    if (!customerId) {
      console.log('Creating new Stripe customer for user:', userId);
      const customer = await stripe.customers.create({
        email: userData.email,
        name: userData.name || undefined,
        metadata: {
          userId: userId,
        },
      });
      
      customerId = customer.id;
      console.log('Created Stripe customer:', customerId);
      
      // Update the user with the Stripe customer ID
      await supabase
        .from('users')
        .update({ stripe_customer_id: customerId })
        .eq('id', userId);
    }
    
    // Map from our price IDs to actual Stripe price IDs
    // In production, you would store these mappings in a database or environment variables
    let stripePriceId;
    switch (priceId) {
      case 'price_starter':
        stripePriceId = 'price_1ORIVVIDqYmwSPiK9G7YMFJ3'; // Replace with actual Stripe price ID
        break;
      case 'price_pro':
        stripePriceId = 'price_1ORIVqIDqYmwSPiKOoVxTyTB'; // Replace with actual Stripe price ID
        break;
      case 'price_ultimate':
        stripePriceId = 'price_1ORIWBIDqYmwSPiKgXgXHemU'; // Replace with actual Stripe price ID
        break;
      default:
        stripePriceId = priceId; // Fallback to using the provided ID directly
    }

    console.log('Using Stripe price ID:', stripePriceId);
    
    // Create the checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price: stripePriceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${clientUrl}/checkout?success=true&session_id={CHECKOUT_SESSION_ID}&plan=${priceId}`,
      cancel_url: `${clientUrl}/subscriptions?canceled=true`,
      metadata: {
        userId: userId,
      },
    });
    
    console.log('Checkout session created:', session.id);
    
    return new Response(
      JSON.stringify({ url: session.url, sessionId: session.id }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
