
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fallback logo URL in caso il logo non sia disponibile nello storage
const fallbackLogoUrl = "https://placehold.co/200x80/ffffff/000000?text=Risto%20Bar";

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  // Controlla se il logo esiste nello storage
  const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  const logoUrl = `${supabaseUrl}/storage/v1/object/public/public/ristobar-logo.png`;
  
  try {
    // Verifica se l'immagine è accessibile
    const response = await fetch(logoUrl, { method: 'HEAD' });
    
    if (response.ok) {
      console.log("Logo trovato nello storage:", logoUrl);
      return new Response(
        JSON.stringify({ logoUrl }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      console.log("Logo non trovato nello storage, uso fallback");
      return new Response(
        JSON.stringify({ logoUrl: fallbackLogoUrl }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error('Errore durante la verifica del logo:', error);
    
    return new Response(
      JSON.stringify({ logoUrl: fallbackLogoUrl, error: 'Errore durante la verifica del logo' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
