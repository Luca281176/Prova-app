
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Resend } from 'https://esm.sh/resend@1.0.0';
import { corsHeaders } from '../_shared/cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0';

const resend = new Resend(Deno.env.get('RESEND_API_KEY') || '');
const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const clientUrl = Deno.env.get('CLIENT_URL') || 'http://localhost:5173';

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { userId, paymentType, paymentDetails } = await req.json();
    
    if (!userId || !paymentType) {
      return new Response(
        JSON.stringify({ error: 'Mancano parametri richiesti: userId o paymentType' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Sending payment confirmation email for:', { userId, paymentType });

    // Create a Supabase client
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Get the user from Supabase
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (userError || !userData) {
      console.error('Error fetching user:', userError);
      return new Response(
        JSON.stringify({ error: 'Utente non trovato' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get payment details based on type
    let emailSubject = '';
    let emailHtml = '';
    
    if (paymentType === 'subscription') {
      // Get subscription details
      const { planName, planPrice, status } = paymentDetails;
      
      emailSubject = status === 'success' 
        ? `Abbonamento ${planName} attivato con successo` 
        : 'Problema con il tuo abbonamento';
        
      // Generate HTML for subscription email
      emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
          <div style="text-align: center; padding-bottom: 20px; border-bottom: 1px solid #eaeaea; margin-bottom: 20px;">
            <h1 style="color: #333;">RistoBar Manager</h1>
            <p style="color: #666;">La piattaforma per la gestione della tua ristorazione</p>
          </div>
          
          <p>Gentile ${userData.name},</p>
          
          ${status === 'success' 
            ? `
              <p>Grazie per aver sottoscritto il piano <strong>${planName}</strong> di RistoBar Manager. 
              La tua sottoscrizione è ora attiva e puoi iniziare a utilizzare tutte le funzionalità del piano.</p>
              
              <div style="background-color: #f2f9f2; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #155724; margin-top: 0;">Dettagli Abbonamento</h3>
                <ul style="color: #155724; padding-left: 20px;">
                  <li><strong>Piano:</strong> ${planName}</li>
                  <li><strong>Prezzo:</strong> €${planPrice}/mese</li>
                  <li><strong>Stato:</strong> Attivo</li>
                  <li><strong>Data attivazione:</strong> ${new Date().toLocaleDateString('it-IT')}</li>
                </ul>
              </div>
            `
            : `
              <p>Abbiamo riscontrato un problema con il pagamento del tuo abbonamento al piano <strong>${planName}</strong>.
              Per evitare interruzioni del servizio, ti preghiamo di verificare il metodo di pagamento nel tuo account.</p>
              
              <div style="background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3 style="color: #721c24; margin-top: 0;">Problema Rilevato</h3>
                <p style="color: #721c24;">Il pagamento non è andato a buon fine. Per favore verifica i dettagli della tua carta di credito o contatta la tua banca.</p>
              </div>
              
              <div style="text-align: center; margin: 25px 0;">
                <a href="${clientUrl}/subscriptions" style="background-color: #4A6CF7; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">
                  Aggiorna Metodo di Pagamento
                </a>
              </div>
            `
          }
          
          <p>Per qualsiasi domanda o assistenza, non esitare a contattare il nostro team di supporto.</p>
          
          <p style="margin-top: 25px;">
            Cordiali saluti,<br>
            Il Team di RistoBar Manager
          </p>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eaeaea; text-align: center; font-size: 12px; color: #666;">
            <p>© 2024 RistoBar Manager. Tutti i diritti riservati.</p>
            <p>
              <a href="${clientUrl}/subscriptions" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">Gestisci Abbonamento</a> •
              <a href="${clientUrl}/privacy" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">Privacy Policy</a> •
              <a href="${clientUrl}/support" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">Supporto</a>
            </p>
          </div>
        </div>
      `;
    } else if (paymentType === 'order') {
      // Get order details
      const { orderNumber, totalAmount } = paymentDetails;
      
      emailSubject = `Conferma del tuo Ordine #${orderNumber}`;
      
      // Generate HTML for order confirmation email
      emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
          <div style="text-align: center; padding-bottom: 20px; border-bottom: 1px solid #eaeaea; margin-bottom: 20px;">
            <h1 style="color: #333;">RistoBar Manager</h1>
            <p style="color: #666;">La piattaforma per la gestione della tua ristorazione</p>
          </div>
          
          <h2 style="color: #333;">Conferma del tuo Ordine #${orderNumber}</h2>
          
          <p>Gentile ${userData.name},</p>
          
          <p>Grazie per il tuo ordine. La tua transazione è stata completata con successo.</p>
          
          <div style="background-color: #f2f9f2; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <h3 style="color: #155724; margin-top: 0;">Dettagli Ordine</h3>
            <ul style="color: #155724; padding-left: 20px;">
              <li><strong>Numero Ordine:</strong> #${orderNumber}</li>
              <li><strong>Data:</strong> ${new Date().toLocaleDateString('it-IT')}</li>
              <li><strong>Stato Pagamento:</strong> Completato</li>
              <li><strong>Totale:</strong> €${totalAmount}</li>
            </ul>
          </div>
          
          <p>Riceverai presto una fattura dettagliata via email. Il tuo ordine è in fase di elaborazione e ti aggiorneremo sullo stato.</p>
          
          <div style="text-align: center; margin: 25px 0;">
            <a href="${clientUrl}/orders/${orderNumber}" style="background-color: #4A6CF7; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Visualizza Dettagli Ordine
            </a>
          </div>
          
          <p style="margin-top: 25px;">
            Cordiali saluti,<br>
            Il Team di RistoBar Manager
          </p>
          
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eaeaea; text-align: center; font-size: 12px; color: #666;">
            <p>© 2024 RistoBar Manager. Tutti i diritti riservati.</p>
            <p>
              <a href="${clientUrl}/orders" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">I Miei Ordini</a> •
              <a href="${clientUrl}/privacy" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">Privacy Policy</a> •
              <a href="${clientUrl}/support" style="color: #4A6CF7; text-decoration: none; margin: 0 5px;">Supporto</a>
            </p>
          </div>
        </div>
      `;
    } else {
      return new Response(
        JSON.stringify({ error: 'Tipo di pagamento non valido' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    // Send email with Resend
    const result = await resend.emails.send({
      from: 'Ristobar Manager <noreply@ristobarmanager.it>',
      to: [userData.email],
      subject: emailSubject,
      html: emailHtml,
    });
    
    if (result.error) {
      throw new Error(`Error sending email: ${result.error.message}`);
    }
    
    console.log('Payment confirmation email sent successfully');
    
    return new Response(
      JSON.stringify({ success: true, messageId: result.data?.id }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Error sending payment confirmation:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
