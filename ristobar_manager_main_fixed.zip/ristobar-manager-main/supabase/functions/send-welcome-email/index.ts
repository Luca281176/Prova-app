
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.21.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WelcomeEmailData {
  name: string;
  email: string;
  restaurantName: string;
  // Aggiungiamo un ID univoco per tracciare ogni email
  userId?: string;
  // Permettiamo anche di personalizzare lo stile del ristorante
  restaurantStyle?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, email, restaurantName, userId, restaurantStyle } = await req.json() as WelcomeEmailData;
    const emailId = crypto.randomUUID(); // Genera un ID univoco per questa email

    // Verify that all required fields are present
    if (!name || !email || !restaurantName) {
      return new Response(
        JSON.stringify({ error: 'Dati mancanti. Richiesti: name, email, restaurantName' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Invio email di benvenuto a ${name} (${email}) per il ristorante "${restaurantName}" [ID: ${emailId}]`);

    // URL del logo - prima controlla se esiste nello storage, altrimenti usa fallback
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const logoUrl = `${supabaseUrl}/storage/v1/object/public/public/ristobar-logo.png`;
    
    let finalLogoUrl = logoUrl;
    try {
      // Verifica se l'immagine è accessibile
      const response = await fetch(logoUrl, { method: 'HEAD' });
      if (!response.ok) {
        // Se non accessibile, usa una URL di fallback
        finalLogoUrl = "https://placehold.co/200x80/ffffff/000000?text=Risto%20Bar";
        console.log("Logo non trovato nello storage, uso fallback:", finalLogoUrl);
      }
    } catch (error) {
      finalLogoUrl = "https://placehold.co/200x80/ffffff/000000?text=Risto%20Bar";
      console.log("Errore nel verificare il logo, uso fallback:", error);
    }

    // Personalizzazione del colore del tema in base allo stile del ristorante
    let themeColor = "#4a6da7"; // Colore predefinito
    let accentColor = "#5a7db7"; // Colore accent predefinito
    
    if (restaurantStyle) {
      switch(restaurantStyle.toLowerCase()) {
        case "italiano":
          themeColor = "#009246"; // Verde della bandiera italiana
          accentColor = "#ce2b37"; // Rosso della bandiera italiana
          break;
        case "sushi":
        case "giapponese":
          themeColor = "#bc002d"; // Rosso della bandiera giapponese
          accentColor = "#000000"; // Nero
          break;
        case "pizzeria":
          themeColor = "#ce2b37"; // Rosso pomodoro
          accentColor = "#009246"; // Verde basilico
          break;
        // Aggiungi altri stili se necessario
      }
    }

    // Ottieni la data in formato italiano per un tocco più personalizzato
    const oggi = new Date();
    const dataFormattata = oggi.toLocaleDateString('it-IT', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });

    // Creazione dell'HTML per l'email con il logo e il testo in italiano
    const emailHtml = generateWelcomeEmailHtml(
      name, 
      restaurantName, 
      finalLogoUrl, 
      themeColor,
      accentColor,
      dataFormattata,
      emailId
    );
    
    // Invia l'email usando Resend
    const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
    
    const emailResponse = await resend.emails.send({
      from: "RistoBar Manager <noreply@ristobarmanager.it>",
      to: [email],
      subject: `Benvenuto in RistoBar Manager, ${name}!`,
      html: emailHtml,
      // Aggiungiamo gli headers per il tracciamento
      headers: {
        'X-Email-ID': emailId,
        'X-Restaurant-Name': restaurantName
      }
    });
    
    console.log("Email inviata:", emailResponse);

    // Log dell'invio email nel database
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const { error: logError } = await supabaseClient
      .from("email_logs")
      .insert({
        recipient_email: email,
        recipient_name: name,
        email_type: 'welcome',
        status: 'sent',
        sent_at: new Date().toISOString(),
        email_id: emailId,
        restaurant_name: restaurantName,
        user_id: userId || null
      });

    if (logError) {
      console.error('Errore durante la registrazione dell\'email inviata:', logError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Email inviata con successo',
        emailId: emailId 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Errore durante l\'invio dell\'email di benvenuto:', error);
    
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Errore sconosciuto' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Funzione per generare l'HTML dell'email di benvenuto in italiano con logo
function generateWelcomeEmailHtml(
  name: string, 
  restaurantName: string, 
  logoUrl: string,
  themeColor: string,
  accentColor: string,
  data: string,
  emailId: string
): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Benvenuto in RistoBar Manager</title>
      <style>
        body { 
          font-family: 'Helvetica', Arial, sans-serif; 
          line-height: 1.6; 
          color: #333333; 
          margin: 0; 
          padding: 0; 
          background-color: #f9f9f9; 
        }
        .container { 
          max-width: 600px; 
          margin: 20px auto; 
          padding: 20px; 
          background-color: #ffffff; 
          border-radius: 8px; 
          box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
        }
        .header { 
          text-align: center; 
          margin-bottom: 30px; 
          border-bottom: 3px solid ${themeColor}; 
          padding-bottom: 15px;
        }
        .logo { 
          margin-bottom: 20px; 
          max-width: 200px; 
        }
        h1 { 
          color: ${themeColor}; 
          margin: 0 0 10px 0; 
          font-size: 28px; 
        }
        .content { 
          padding: 0 20px; 
        }
        .button { 
          display: inline-block; 
          background-color: ${themeColor}; 
          color: white; 
          text-decoration: none; 
          padding: 12px 25px; 
          border-radius: 4px; 
          margin: 20px 0; 
          font-weight: bold; 
        }
        .button:hover {
          background-color: ${accentColor};
        }
        .footer { 
          margin-top: 30px; 
          text-align: center; 
          font-size: 12px; 
          color: #888888; 
          border-top: 1px solid #eeeeee; 
          padding-top: 20px; 
        }
        .highlight {
          color: ${themeColor};
          font-weight: bold;
        }
        .date {
          font-style: italic;
          color: #666;
          text-align: right;
          margin-bottom: 15px;
        }
        .feature-list {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 6px;
          margin: 20px 0;
        }
        .feature-list li {
          margin-bottom: 8px;
        }
        .note {
          font-size: 13px;
          background-color: #fffde7;
          padding: 10px;
          border-left: 4px solid ${themeColor};
          margin: 20px 0;
        }
        .email-id {
          font-size: 9px;
          color: #cccccc;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <img src="${logoUrl}" alt="RistoBar Manager Logo" class="logo">
          <h1>Benvenuto in RistoBar Manager!</h1>
        </div>
        <div class="date">${data}</div>
        <div class="content">
          <p>Ciao <span class="highlight">${name}</span>,</p>
          <p>Grazie per esserti registrato a RistoBar Manager! Siamo entusiasti di averti con noi.</p>
          <p>Il tuo ristorante "<span class="highlight">${restaurantName}</span>" è stato configurato con successo e ora puoi iniziare a utilizzare tutte le funzionalità della nostra piattaforma.</p>
          
          <div class="feature-list">
            <p>Con RistoBar Manager potrai:</p>
            <ul>
              <li>Gestire facilmente le prenotazioni dei tuoi clienti</li>
              <li>Organizzare i tavoli e le sale del tuo locale</li>
              <li>Tenere traccia degli ordini e delle vendite</li>
              <li>Amministrare il personale e i turni di lavoro</li>
              <li>Molto altro ancora!</li>
            </ul>
          </div>
          
          <div class="note">
            <p>Per iniziare, ti consigliamo di configurare il profilo del tuo ristorante nelle impostazioni
            e di caricare il tuo logo personalizzato per renderlo visibile nelle fatture e nei menu digitali.</p>
          </div>
          
          <p>Se hai domande o hai bisogno di assistenza, non esitare a contattarci rispondendo a questa email o attraverso la sezione supporto della tua dashboard.</p>
          
          <center><a href="https://www.ristobarmanager.it/login" class="button">Accedi alla tua Dashboard</a></center>
          
          <p>Cordiali saluti,<br>Il Team di RistoBar Manager</p>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} RistoBar Manager. Tutti i diritti riservati.</p>
          <p>Via Roma 123, Milano, Italia</p>
          <div class="email-id">ID: ${emailId}</div>
        </div>
      </div>
    </body>
    </html>
  `;
}
