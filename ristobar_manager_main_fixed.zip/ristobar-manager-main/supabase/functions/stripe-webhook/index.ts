
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Stripe } from 'https://esm.sh/stripe@12.0.0?target=deno';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
});

const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET') || '';
const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

serve(async (req) => {
  const signature = req.headers.get('stripe-signature');
  
  if (!signature) {
    return new Response(
      JSON.stringify({ error: 'No signature provided' }),
      { status: 400 }
    );
  }
  
  try {
    const body = await req.text();
    let event;
    
    try {
      event = stripe.webhooks.constructEvent(
        body,
        signature,
        webhookSecret
      );
    } catch (err) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return new Response(
        JSON.stringify({ error: `Webhook signature verification failed: ${err.message}` }),
        { status: 400 }
      );
    }
    
    // Handle the event
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        const subscription = event.data.object;
        
        // Map Stripe price ID to our plan ID
        let planId = '';
        if (subscription.items && subscription.items.data && subscription.items.data.length > 0) {
          const priceId = subscription.items.data[0].price.id;
          
          switch (priceId) {
            case 'price_starter':
              planId = 'starter';
              break;
            case 'price_pro':
              planId = 'pro';
              break;
            case 'price_ultimate':
              planId = 'ultimate';
              break;
            default:
              planId = 'starter'; // Default fallback
          }
        }
        
        // Find the userId based on the customer ID
        const { data: userData, error: userError } = await supabase
          .from('users')
          .select('id')
          .eq('stripe_customer_id', subscription.customer)
          .single();
          
        if (userError) {
          console.error('Error finding user:', userError);
          break;
        }
        
        // Update subscription in our database
        const { error } = await supabase
          .from('subscriptions')
          .upsert({
            id: subscription.id,
            user_id: userData.id,
            plan_id: planId,
            status: subscription.status,
            current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
            cancel_at_period_end: subscription.cancel_at_period_end,
            stripe_customer_id: subscription.customer,
            updated_at: new Date().toISOString()
          });
        
        if (error) {
          console.error('Error updating subscription:', error);
        }
        break;
        
      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object;
        
        // Mark subscription as canceled in our database
        const { error: deleteError } = await supabase
          .from('subscriptions')
          .update({
            status: 'canceled',
            updated_at: new Date().toISOString()
          })
          .eq('id', deletedSubscription.id);
        
        if (deleteError) {
          console.error('Error updating subscription status:', deleteError);
        }
        break;
        
      // Add more event handlers as needed
      
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }
    
    return new Response(
      JSON.stringify({ received: true }),
      { status: 200 }
    );
    
  } catch (error) {
    console.error('Error processing webhook:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
});
