
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Stripe } from 'https://esm.sh/stripe@12.0.0?target=deno';
import { corsHeaders } from '../_shared/cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
});

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { subscriptionId, status, priceId } = await req.json();
    
    if (!subscriptionId) {
      return new Response(
        JSON.stringify({ error: 'Manca il parametro subscriptionId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let updateParams: any = {};
    let updateData: any = {};
    
    // Handle status update
    if (status) {
      // Handle status changes (in a real implementation, this would need more logic)
      // Note: Stripe doesn't allow direct status changes like this, this is simplified
      updateData.status = status;
    }

    // Handle price update (plan change)
    if (priceId) {
      // Update the subscription items with the new price
      updateParams = {
        items: [{
          id: (await stripe.subscriptions.retrieve(subscriptionId)).items.data[0].id,
          price: priceId,
        }],
      };
      
      // Get the plan ID from the price ID
      let planId = '';
      switch (priceId) {
        case 'price_starter':
          planId = 'starter';
          break;
        case 'price_pro':
          planId = 'pro';
          break;
        case 'price_ultimate':
          planId = 'ultimate';
          break;
      }
      
      if (planId) {
        updateData.planId = planId;
      }
    }

    // Update the subscription in Stripe
    const updatedSubscription = await stripe.subscriptions.update(
      subscriptionId,
      updateParams
    );
    
    // Update our database to reflect the changes
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    if (Object.keys(updateData).length > 0) {
      const { error } = await supabase
        .from('subscriptions')
        .update(updateData)
        .eq('id', subscriptionId);
      
      if (error) {
        console.error('Error updating subscription in database:', error);
      }
    }
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        subscription: updatedSubscription
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
    
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
